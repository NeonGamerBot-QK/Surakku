"use strict";
(() => {
  var q = Object.defineProperty;
  var c = (O, m) =>
    q(O, "name", {
      value: m,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-async-client-boot-apis"],
    {
      6959220389: (O, m, l) => {
        l.r(m),
          l.d(m, {
            register: () => k,
          });
        var u = l(9706240641),
          d = l(7715417323),
          F = l(1197598850);
        function P(e) {
          return D.apply(this, arguments);
        }
        c(P, "maybeFetchAllOnboardingData");
        function D() {
          return (
            (D = (0, u.coroutine)(function* (e) {
              let { apiData: t, contextualInfo: n } = e;
              const a = {
                  onboardingData: null,
                  labFeaturesStartupData: null,
                },
                { featureFlagData: o } = t,
                r = t.clientBootData;
              if (!r || !o) return a;
              const { userPrefsData: s } = r,
                i = !!(o != null && o.feature_composer_email_classification);
              var f;
              if (
                !((f = window.location.search.match("skip_onboarding")) !==
                  null && f !== void 0
                  ? f
                  : !1) &&
                s &&
                !s.onboarding_complete
              ) {
                var p;
                (a.onboardingData = yield (0, F.MC)(n)),
                  (!((p = a.onboardingData) === null || p === void 0) &&
                    p.setup_started) ||
                    (i && (a.labFeaturesStartupData = yield (0, F.yP)(n)));
              }
              return a;
            })),
            D.apply(this, arguments)
          );
        }
        c(D, "_maybeFetchAllOnboardingData");
        function V(e) {
          let { viewData: t, channelsData: n = [] } = e;
          if (!(t != null && t.channelData)) return n;
          const a = n.findIndex((o) => {
            var r;
            return (
              o &&
              o.id ===
                (t == null || (r = t.channelData) === null || r === void 0
                  ? void 0
                  : r.id)
            );
          });
          if (a !== -1) {
            const o = {
              ...n[a],
              ...t.channelData,
            };
            n.splice(a, 1, o);
          }
          return n;
        }
        c(V, "maybeMergeKnownChannelsData");
        var x = l(1044468604),
          g = l(7031360717),
          M = l(723189278),
          U = l(8957617959),
          W = l(571104883),
          E = l(9022734571),
          R = l(2786906754);
        function L(e) {
          return C.apply(this, arguments);
        }
        c(L, "maybeRedirectToTermsOfService");
        function C() {
          return (
            (C = (0, u.coroutine)(function* (e) {
              let { clientBootData: t } = e;
              var n;
              const a = t.acceptTosUrl;
              if (!a) return;
              const o =
                t == null || (n = t.teamData) === null || n === void 0
                  ? void 0
                  : n.url;
              if ((0, W.y3)()) {
                const f = `${o}ssb/redirect`,
                  h = (0, R.M6)(a, "redirect", f),
                  p = new U.A("User needs to accept Custom TOS");
                throw (
                  ((p.type = x.F9.API),
                  (p.subType = "custom_tos"),
                  (p.data = {
                    error: "user_needs_to_accept_custom_tos",
                    url: h,
                  }),
                  p)
                );
              }
              const r = (0, E.VG)(location.search, "force_cold_boot", 1),
                s = `${o}gantry${location.pathname}${r}`,
                i = (0, R.M6)(a, "redirect", s);
              return (
                (0, g.pq)(
                  "BOOT",
                  `(${t.teamData.id}) User needs to accept the terms of service; redirecting to ${i}`
                ),
                location.assign(i),
                (0, M.A)()
              );
            })),
            C.apply(this, arguments)
          );
        }
        c(C, "_maybeRedirectToTermsOfService");
        var G = l(1897173426),
          K = l(1796308251);
        function Q(e) {
          return y.apply(this, arguments);
        }
        c(Q, "maybeReloadForReAuth");
        function y() {
          return (
            (y = (0, u.coroutine)(function* (e) {
              let { clientBootData: t } = e;
              if (!(t == null ? void 0 : t.should_reauth)) return;
              (0,
              g.pq)("BOOT", "Detected need to reauth; fetching auth and halting current boot.");
              const a = !1,
                o = !1,
                r = [],
                s = !0;
              return (0, K.tw)(a, o, r, s), (0, M.A)();
            })),
            y.apply(this, arguments)
          );
        }
        c(y, "_maybeReloadForReAuth");
        var X = l(2211286378),
          j = l(3014948446),
          z = l(775242046),
          S = l(796111729),
          $ = l(9190452268),
          v = l(8445020572);
        function H(e) {
          let {
            featureFlagConfigVersionTs: t,
            experimentsConfigVersionTs: n,
            teamId: a,
          } = e;
          t || (0, $.rh)().count("mvb_missing_feature_flag_config_version"),
            n || (0, $.rh)().count("mvb_missing_experiment_config_version"),
            (0, g.pq)(
              "BOOT",
              `Feature flag config version: ${t}; Experiments config version: ${n}`
            ),
            (0, v.FX)(a, Math.min(n, t));
          const o = (0, v.Cy)();
          o
            ? (0, g.pq)(
                "BOOT",
                `Current earliest config version: ${o}; All config versions: ${(0,
                v.r6)()}`
              )
            : (0, S.Wo)().warn(
                "BOOT",
                `Missing config version: ${o}; All config versions: ${(0,
                v.r6)()}`
              );
        }
        c(H, "storeConfigVersion");
        var b = l(6422693406),
          J = l(4387630034);
        function N(e) {
          return A.apply(this, arguments);
        }
        c(N, "transformInitialApiResponses");
        function A() {
          return (
            (A = (0, u.coroutine)(function* (e) {
              let { apiCalls: t, contextualInfo: n } = e;
              const {
                  clientBootData: a,
                  clientChannelsData: o,
                  viewData: r,
                  ...s
                } = t,
                i = t.clientBootData.then(X.$);
              i.catch(d.A);
              const f = t.clientChannelsData.then(j.L);
              f.catch(d.A);
              const h = t.viewData.then(z.W);
              return (
                h.catch(d.A),
                {
                  apiCalls: {
                    clientBootData: i,
                    clientChannelsData: f,
                    viewData: h,
                    ...s,
                  },
                  contextualInfo: n,
                }
              );
            })),
            A.apply(this, arguments)
          );
        }
        c(A, "_transformInitialApiResponses");
        function Y(e) {
          return T.apply(this, arguments);
        }
        c(Y, "setConfigVersions");
        function T() {
          return (
            (T = (0, u.coroutine)(function* (e) {
              let { apiCalls: t, contextualInfo: n } = e;
              const { teamId: a } = n;
              if (!a)
                return {
                  apiCalls: t,
                  contextualInfo: n,
                };
              const { featureFlagData: o, experimentData: r } = t;
              return (
                b.S.all([o, r])
                  .then(
                    (s) => {
                      let [i, f] = s;
                      const { config_version_ts: h } = i,
                        { config_version_ts: p } = f;
                      H({
                        featureFlagConfigVersionTs: h,
                        experimentsConfigVersionTs: p,
                        teamId: a,
                      });
                    },
                    () => {}
                  )
                  .catch((s) => {
                    (0, S.Wo)().error(
                      "BOOT",
                      `Failed to store config version: ${s}`
                    );
                  }),
                {
                  apiCalls: t,
                  contextualInfo: n,
                }
              );
            })),
            T.apply(this, arguments)
          );
        }
        c(T, "_setConfigVersions");
        function Z(e) {
          return B.apply(this, arguments);
        }
        c(Z, "startOnboardingApis");
        function B() {
          return (
            (B = (0, u.coroutine)(function* (e) {
              let { apiCalls: t, contextualInfo: n } = e;
              const { getTracer: a, getTrace: o } = n.getTraceMeta(),
                r = o(),
                s = b.S.all([t.clientBootData, t.featureFlagData])
                  .then((i) => {
                    let [f, h] = i;
                    return a().traceFn(
                      {
                        name: "fetchOnboardingData",
                        options: {
                          traceId: r.getTraceId(),
                          parentSpanId: r.getRootSpanId(),
                        },
                      },
                      P.bind(null, {
                        apiData: {
                          clientBootData: f,
                          featureFlagData: h,
                        },
                        contextualInfo: n,
                      })
                    );
                  })
                  .catch((i) => {
                    throw (
                      ((i.type = x.F9.API),
                      (i.subType = "allOnboardingData"),
                      i)
                    );
                  });
              return (
                s.catch(d.A),
                {
                  apiCalls: {
                    allOnboardingData: s,
                    ...t,
                  },
                  contextualInfo: n,
                }
              );
            })),
            B.apply(this, arguments)
          );
        }
        c(B, "_startOnboardingApis");
        function w(e) {
          return I.apply(this, arguments);
        }
        c(w, "maybeMergeChannelData");
        function I() {
          return (
            (I = (0, u.coroutine)(function* (e) {
              let { apiCalls: t, contextualInfo: n } = e;
              const a = b.S.all([t.clientBootData, t.viewData]).then((o) => {
                let [r, s] = o;
                return {
                  ...r,
                  channelsData: V({
                    viewData: s,
                    channelsData: r.channelsData,
                  }),
                };
              });
              return (
                a.catch(d.A),
                {
                  apiCalls: {
                    ...t,
                    clientBootData: a,
                  },
                  contextualInfo: n,
                }
              );
            })),
            I.apply(this, arguments)
          );
        }
        c(I, "_maybeMergeChannelData");
        function k(e) {
          e.hooks.apiAfterInitialCalls.tap(
            "Transform initial API responses",
            N
          ),
            e.hooks.apiAfterInitialCalls.tap(
              "Maybe reload for a min version bump based on the client.boot response",
              (function () {
                var t = (0, u.coroutine)(function* (n) {
                  let { apiCalls: a, contextualInfo: o } = n;
                  const r = a.clientBootData.then(
                    (function () {
                      var s = (0, u.coroutine)(function* (i) {
                        return (0, G.p)({
                          clientBootData: i,
                        });
                      });
                      return function (i) {
                        return s.apply(this, arguments);
                      };
                    })()
                  );
                  return (
                    r.catch(d.A),
                    {
                      apiCalls: {
                        ...a,
                        clientBootData: r,
                      },
                      contextualInfo: o,
                    }
                  );
                });
                return function (n) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            e.hooks.apiAfterInitialCalls.tap("Store config versions", Y),
            e.hooks.apiAfterInitialCalls.tap("Start onboarding APIs", Z),
            e.hooks.apiAfterInitialCalls.tap(
              "Merge view data with client.boot channels data",
              w
            ),
            e.hooks.apiAfterInitialCalls.tap("Close API Boot Queue", J.u),
            e.hooks.apiAfterInitialCalls.tap(
              "Maybe re-auth based on the client.boot response",
              (function () {
                var t = (0, u.coroutine)(function* (n) {
                  let { apiCalls: a, contextualInfo: o } = n;
                  const r = a.clientBootData.then(
                    (function () {
                      var s = (0, u.coroutine)(function* (i) {
                        return (
                          yield Q({
                            clientBootData: i,
                          }),
                          i
                        );
                      });
                      return function (i) {
                        return s.apply(this, arguments);
                      };
                    })()
                  );
                  return (
                    r.catch(d.A),
                    {
                      apiCalls: {
                        ...a,
                        clientBootData: r,
                      },
                      contextualInfo: o,
                    }
                  );
                });
                return function (n) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            e.hooks.apiAfterInitialCalls.tap(
              "Maybe redirect to the terms of service based on the client.boot response",
              (function () {
                var t = (0, u.coroutine)(function* (n) {
                  let { apiCalls: a, contextualInfo: o } = n;
                  const r = a.clientBootData.then(
                    (function () {
                      var s = (0, u.coroutine)(function* (i) {
                        return (
                          yield L({
                            clientBootData: i,
                          }),
                          i
                        );
                      });
                      return function (i) {
                        return s.apply(this, arguments);
                      };
                    })()
                  );
                  return (
                    r.catch(d.A),
                    {
                      apiCalls: {
                        ...a,
                        clientBootData: r,
                      },
                      contextualInfo: o,
                    }
                  );
                });
                return function (n) {
                  return t.apply(this, arguments);
                };
              })()
            );
        }
        c(k, "register");
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-client-boot-apis.7c2b57c6193066c56f44.min.js.map
