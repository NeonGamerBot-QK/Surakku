"use strict";
(() => {
  var T = Object.defineProperty;
  var e = (u, s) =>
    T(u, "name", {
      value: s,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-default-boot-shared"],
    {
      1983609398: (u, s, n) => {
        n.r(s),
          n.d(s, {
            register: () => c,
            test: () => g,
          });
        var l = n(9706240641),
          h = n(735940183),
          f = n(1197598850),
          i = n(9421999304);
        function m(t) {
          return r.apply(this, arguments);
        }
        e(m, "setupLocale");
        function r() {
          return (
            (r = (0, l.coroutine)(function* (t) {
              let { contextualInfo: a } = t;
              const { teamOrEnterpriseBootId: d } = a;
              return (
                yield (0, i.xS)(
                  (0, i.JK)({
                    teamOrEnterpriseId: d,
                    recalc: !0,
                  }),
                  d,
                  {
                    shouldEnsureTranslationBundle: !1,
                  }
                ),
                {
                  contextualInfo: a,
                }
              );
            })),
            r.apply(this, arguments)
          );
        }
        e(r, "_setupLocale");
        function p(t) {
          return o.apply(this, arguments);
        }
        e(p, "setupTranslations");
        function o() {
          return (
            (o = (0, l.coroutine)(function* (t) {
              let { contextualInfo: a } = t;
              return (
                yield (0, f.W$)(
                  (0, h.Yp)({
                    recalc: !0,
                    teamOrEnterpriseId: a.teamOrEnterpriseBootId,
                  })
                ),
                {
                  contextualInfo: a,
                }
              );
            })),
            o.apply(this, arguments)
          );
        }
        e(o, "_setupTranslations");
        function c(t) {
          t.hooks.sharedTranslations.tap("Set locale", m),
            t.hooks.sharedTranslations.tap("Translations", p);
        }
        e(c, "register");
        const g = {
          setupTranslations: p,
          register: c,
        };
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-default-boot-shared.e3a328d1062139d8e0c9.min.js.map
