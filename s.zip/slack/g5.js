(() => {
  var tr = Object.defineProperty;
  var c = (W, g) =>
    tr(W, "name", {
      value: g,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-async-client-channel-list-view"],
    {
      3506776591: (W, g, e) => {
        W.exports = e.p + "pnp-bell-notification-bd530cc.png";
      },
      8790440477: (W, g, e) => {
        W.exports = e.p + "pnp-hour-glass-notification-b4dc7aa.png";
      },
      9420092417: (W, g, e) => {
        W.exports = e.p + "robot-373d319.png";
      },
      7925057078: (W, g, e) => {
        W.exports = e.p + "cloud-ladder-95ff829.svg";
      },
      3579140003: (W, g, e) => {
        W.exports = e.p + "handshake-6655502.svg";
      },
      301719806: (W, g, e) => {
        W.exports = e.p + "slack_hash_128-004f20c.png";
      },
      2121234563: (W, g, e) => {
        W.exports = e.p + "after-trial-upgrade-sidebar-gift-box-e737cf5.svg";
      },
      7531383956: (W, g, e) => {
        W.exports = e.p + "clock-eaf8850.svg";
      },
      3758927666: (W, g, e) => {
        W.exports = e.p + "gift-917e797.svg";
      },
      2455200396: (W, g, e) => {
        W.exports = e.p + "sidebar-banner-877c5f6.svg";
      },
      3680131132: (W) => {
        W.exports = {
          inline: "inline__cbb1W",
          space_25: "space_25__be1Qb",
          space_50: "space_50__PD0Bx",
          space_75: "space_75__O2LED",
          space_100: "space_100__V8NFO",
          space_150: "space_150__cGvSB",
          align_inherit: "align_inherit__nSnrm",
          align_start: "align_start__Q8jCq",
          align_center: "align_center__hCbrl",
          alignY_inherit: "alignY_inherit__eSXgq",
          alignY_start: "alignY_start__B3min",
          alignY_center: "alignY_center__VSkk_",
          alignY_end: "alignY_end__NHbzb",
          alignY_baseline: "alignY_baseline__NetmO",
        };
      },
      4593063573: (W) => {
        W.exports = {
          bannerContainer: "bannerContainer__EHIJs",
          bannerContent: "bannerContent__PWOnv",
          closeButton: "closeButton__g7AbN",
          tidyUpButton: "tidyUpButton__CELCg",
          laterButton: "laterButton__qgLJG",
          buttonsContainer: "buttonsContainer__e6qxA",
        };
      },
      3123300647: (W) => {
        W.exports = {
          sidebarSweeperSectionCreationCta:
            "sidebarSweeperSectionCreationCta__WaetD",
          descriptionBox: "descriptionBox__ktBxy",
          descriptionText: "descriptionText__oQP0a",
          sweeperIcon: "sweeperIcon__dZvud",
          goButton: "goButton__ruoRp",
          closeButton: "closeButton__XYRmF",
        };
      },
      6870134753: (W) => {
        W.exports = {
          box: "box__BbYzd",
          listStyleNone: "listStyleNone__fGPrE",
          padding50: "padding50__KTivo",
          padding100: "padding100__FO4Df",
          padding125: "padding125__wPCLi",
          paddingInlineStart125: "paddingInlineStart125__AHXRJ",
          paddingInlineStart250: "paddingInlineStart250__ryMsp",
          paddingInline25: "paddingInline25__QlxnG",
          paddingInline150: "paddingInline150__qtcbG",
          paddingInline250: "paddingInline250__ZeMZ7",
          paddingBlock100: "paddingBlock100__DVwcw",
          paddingBlockEnd150: "paddingBlockEnd150__rGDet",
          backgroundColorCoreBaseSecondary:
            "backgroundColorCoreBaseSecondary__UAaW_",
          backgroundColorCoreSurfacePrimary:
            "backgroundColorCoreSurfacePrimary__Z8_oG",
          backgroundColorCoreSurfaceHighlight3:
            "backgroundColorCoreSurfaceHighlight3__RTwhL",
          borderRadiusXLarge: "borderRadiusXLarge__Do4ag",
          borderRadiusRounded: "borderRadiusRounded__B28WR",
          borderRadiusBase: "borderRadiusBase__LrHG9",
          borderColorCoreSurfaceSecondary:
            "borderColorCoreSurfaceSecondary__wMLkW",
          borderRegular: "borderRegular__gW1CN",
          heightFill: "heightFill__XbzxW",
          inlineFlex: "inlineFlex__r7dDr",
        };
      },
      4614285233: (W) => {
        W.exports = {
          text: "text__8Y5Z3",
          fontSizeMicro: "fontSizeMicro__i1v3T",
          fontSizeCaption: "fontSizeCaption__eWVEq",
          fontSizeBase: "fontSizeBase__rD2Si",
          fontSizeSubtitle: "fontSizeSubtitle__mWX8_",
          fontWeightBase: "fontWeightBase__QRyM3",
          fontWeightSemibold: "fontWeightSemibold__bSPf1",
          fontWeightBold: "fontWeightBold__IDZui",
          fontWeightBlack: "fontWeightBlack__Kctwq",
          colorPrimary: "colorPrimary__yRXNV",
          colorSecondary: "colorSecondary__eKIeh",
          colorTertiary: "colorTertiary__i99aD",
          colorThemeInversePrimary: "colorThemeInversePrimary___hfF7",
          colorHighlight2: "colorHighlight2__RcD38",
          colorHighlight3: "colorHighlight3__r_SMh",
          colorCoreContentImportant: "colorCoreContentImportant__Wo2dH",
        };
      },
      3565677134: (W) => {
        W.exports = {
          button: "button__UBhS3",
          textContainer: "textContainer__CPJlr",
        };
      },
      3715755184: (W) => {
        W.exports = {
          container: "container__LoO3e",
          inner_container: "inner_container__b2Zyj",
          banner_button: "banner_button__ree8Y",
          sub_container: "sub_container__nxXoN",
          icon_background: "icon_background__kU4VG",
          icon: "icon__YxqSM",
          label_container: "label_container__HyEKa",
          title: "title__a0oTV",
          subtitle: "subtitle__o2aMc",
          close_button: "close_button__C3Lax",
        };
      },
      7263142004: (W) => {
        W.exports = {
          slackAiSidebarPurchaseCta: "slackAiSidebarPurchaseCta__usw5i",
          button: "button__X6nxq",
          description: "description__xWRja",
          descriptionTitle: "descriptionTitle__LwQB6",
          descriptionSubtitle: "descriptionSubtitle___GLYM",
          icon: "icon__i9CDQ",
          closeButton: "closeButton__ghgM0",
          iconBackground: "iconBackground__yhWc9",
        };
      },
      8004193929: (W) => {
        W.exports = {
          container: "container__eqSHO",
          persistentContainer: "persistentContainer__yMvkO",
          closeButton: "closeButton__unPRO",
          innerContainer: "innerContainer__V8TNv",
          cta: "cta__aGjwQ",
          cta_text: "cta_text__Ajm6l",
          expanded_text: "expanded_text__YHhNN",
          subtext: "subtext__xb97G",
          persistantCTA: "persistantCTA__jfu_4",
          alert: "alert__TEQOp",
          alertCloseIcon: "alertCloseIcon__cJ5bS",
        };
      },
      5504232338: (W) => {
        W.exports = {
          container: "container__imOBe",
          innerContainer: "innerContainer__PFSGL",
          collapsedContainer: "collapsedContainer__dc8cy",
          expandedText: "expandedText___QOj6",
          closeButton: "closeButton__f0hua",
        };
      },
      3281979720: (W) => {
        W.exports = {
          container: "container__csEMW",
          innerContainer: "innerContainer__sdwaP",
          subText: "subText__NRdPp",
          collapsedContainer: "collapsedContainer__Nqqur",
          expandedText: "expandedText__TMxRv",
          imgContainer: "imgContainer__dS80d",
          ctaButton: "ctaButton__JuRiY",
          ctaButtonText: "ctaButtonText__ehWAG",
          collapsedCtaButton: "collapsedCtaButton__UvTHp",
          closeButton: "closeButton__Y0fni",
        };
      },
      6065326583: (W) => {
        W.exports = {
          collapsed: "collapsed__OPDLU",
          widget: "widget__fdMfC",
          header: "header__RJyRD",
          buttonContent: "buttonContent__gQmqJ",
          icon: "icon__MoD8d",
        };
      },
      2539163284: (W, g, e) => {
        "use strict";
        e.d(g, {
          c: () => I,
        });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(3680131132),
          s = e.n(P);
        const I = c((v) => {
          let {
            children: T,
            space: u,
            as: h = "span",
            align: D = "inherit",
            alignY: n = "center",
          } = v;
          return t.createElement(
            h,
            {
              className: (0, O.A)(s().inline, {
                [s().space_25]: u === "25",
                [s().space_50]: u === "50",
                [s().space_75]: u === "75",
                [s().space_100]: u === "100",
                [s().space_150]: u === "150",
                [s().align_inherit]: D === "inherit",
                [s().align_start]: D === "start",
                [s().align_center]: D === "center",
                [s().alignY_inherit]: n === "inherit",
                [s().alignY_start]: n === "start",
                [s().alignY_center]: n === "center",
                [s().alignY_end]: n === "end",
                [s().alignY_baseline]: n === "baseline",
              }),
            },
            T
          );
        }, "Inline");
        I.displayName = "Inline";
      },
      7328268421: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => y,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(735940183),
          s = e(2375333597),
          I = e(4481313819),
          v = e(1224315998),
          T = e(4761125736),
          u = e(2562405183),
          h = e(8683010724),
          D = e(6105929840),
          n = e(2683115972),
          m = e(7451808829),
          l = e(6259241484),
          f = e(7003004874),
          k = e(2938177083),
          E = e(8011352381),
          r = e(5519146941),
          i = e(3193155968),
          a = e(4593063573),
          _ = e.n(a);
        const o = new P.Ay("sidebar_sweeper"),
          d = {
            eventId: v.EventId.SIDEBAR_SWEEPER_MEGAPHONE_CLICK,
            uiStep: v.UiStep.SIDEBAR_SWEEPER_BANNER,
            action: v.UiAction.CLICK,
            onClick: {
              enableClogAction: !0,
            },
          },
          A = {
            eventId: v.EventId.SIDEBAR_SWEEPER_MEGAPHONE_LATER,
            uiStep: v.UiStep.SIDEBAR_SWEEPER_BANNER,
            action: v.UiAction.CLICK,
            onClick: {
              enableClogAction: !0,
            },
          },
          C = {
            eventId: v.EventId.SIDEBAR_SWEEPER_MEGAPHONE_BANNER_CLOSE,
            uiStep: v.UiStep.SIDEBAR_SWEEPER_BANNER,
            action: v.UiAction.CLICK,
            onClick: {
              enableClogAction: !0,
            },
          },
          M = c(() => {
            const [x, N] = (0, t.useState)(!1),
              U = (0, O.wA)(),
              p = (0, u.d4)((V) => (0, T._Z)(V, "sidebar_sweeper") === "on"),
              { activeTab: Y } = (0, t.useContext)(r.A),
              z = (0, t.useCallback)(() => {
                U(
                  (0, k.A)({
                    spaceName: l.xu.SIDEBAR_MENU_HEADER,
                    action: l.hw.DISMISS,
                  })
                );
              }, [U]),
              Z = (0, t.useCallback)(() => {
                U(
                  (0, s.q)({
                    element: t.createElement(m.n, null),
                  })
                );
              }, [U]),
              w = (0, t.useCallback)(() => {
                U(
                  (0, f.A)({
                    notificationName: l.ze.EDUCATION_SIDEBAR_SWEEPER,
                    action: l.hw.CLICK,
                  })
                ),
                  N(!0);
              }, [U]);
            return !p || Y !== i.k6.Home || x
              ? null
              : t.createElement(
                  I.A,
                  {
                    eventId: v.EventId.SIDEBAR_SWEEPER_BANNER_IMPRESSION,
                    uiStep: v.UiStep.SIDEBAR_SWEEPER_BANNER,
                    action: v.UiAction.IMPRESSION,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: _().bannerContainer,
                    },
                    t.createElement(
                      "div",
                      {
                        className: _().bannerContent,
                      },
                      t.createElement(
                        E.A,
                        {
                          lines: 4,
                          breakWords: !1,
                          withTooltip: !0,
                        },
                        p
                          ? o.t(
                              "\u2728 Want personalized suggestions for tidying up your channel list? \u2728"
                            )
                          : ""
                      ),
                      t.createElement(
                        D.A,
                        {
                          "aria-label": o.t("Close"),
                          onClick: z,
                          className: _().closeButton,
                          autoClogProps: C,
                        },
                        t.createElement(h.A, {
                          name: "close",
                          size: "16",
                        })
                      )
                    ),
                    t.createElement(
                      "div",
                      {
                        className: _().buttonsContainer,
                      },
                      t.createElement(
                        n.Ay,
                        {
                          onClick: w,
                          className: _().laterButton,
                          type: "outline",
                          size: "small",
                          autoClogProps: A,
                        },
                        o.t("Later", {
                          fallbackHash:
                            "a2a8a8e7cfb75f54a65fe5ac0ba1e240d6359641",
                        })
                      ),
                      t.createElement(
                        n.Ay,
                        {
                          onClick: Z,
                          className: _().tidyUpButton,
                          type: "primary",
                          size: "small",
                          autoClogProps: d,
                        },
                        p ? o.t("Tidy Up!") : ""
                      )
                    )
                  )
                );
          }, "SidebarSweeperLaunchBanner");
        M.displayName = "SidebarSweeperLaunchBanner";
        const y = M;
      },
      5684595131: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => _,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(735940183),
          s = e(2375333597),
          I = e(2938177083),
          v = e(6259241484),
          T = e(4761125736),
          u = e(2562405183),
          h = e(8683010724),
          D = e(7648061476),
          n = e(6084388622),
          m = e(6105929840),
          l = e(1224315998),
          f = e(4481313819),
          k = e(3123300647),
          E = e.n(k);
        const r = new P.Ay("sidebar_sweeper"),
          i = {
            eventId: l.EventId.SIDEBAR_SWEEPER_BANNER_CLICK,
            elementType: l.ElementType.BUTTON,
            elementName: "sidebar_sweeper_banner_go_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          a = c(() => {
            const o = (0, O.wA)(),
              d = (0, u.d4)(
                (M) =>
                  (0, T._Z)(
                    M,
                    "sidebar_sweeper_custom_sidebar_sections_cta"
                  ) === "treatment"
              ),
              A = (0, t.useCallback)(() => {
                o(
                  (0, I.A)({
                    spaceName: v.xu.SIDEBAR_MENU_HEADER,
                    action: v.hw.DISMISS,
                  })
                );
              }, [o]),
              C = (0, t.useCallback)(() => {
                o(
                  (0, s.q)({
                    element: t.createElement(D.Ay, {
                      action: D.TH.CREATE,
                    }),
                  })
                ),
                  A();
              }, [A, o]);
            return d
              ? t.createElement(
                  f.A,
                  {
                    eventId: l.EventId.SIDEBAR_SWEEPER_BANNER_IMPRESSION,
                    elementName: "sidebar_sweeper_banner",
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: `${
                        E().sidebarSweeperSectionCreationCta
                      } dt-hocus:theme-base-pry`,
                    },
                    t.createElement(
                      "div",
                      {
                        className: E().descriptionBox,
                      },
                      t.createElement(
                        "div",
                        {
                          className: E().sweeperIcon,
                        },
                        t.createElement(h.A, {
                          name: "clear",
                          size: "20",
                        })
                      ),
                      t.createElement(
                        "span",
                        {
                          className: E().descriptionText,
                          id: "banner-description",
                        },
                        d
                          ? r.t(
                              "Create a custom section to tidy up your channel list."
                            )
                          : "Create a custom section to tidy up your channel list."
                      ),
                      t.createElement(
                        m.A,
                        {
                          "aria-label": r.t("Close"),
                          onClick: A,
                          className: E().closeButton,
                        },
                        t.createElement(h.A, {
                          name: "close",
                          size: "20",
                        })
                      )
                    ),
                    t.createElement(
                      n.Nm,
                      {
                        onClick: C,
                        className: E().goButton,
                        "aria-describedby": "banner-description",
                        autoClogProps: i,
                      },
                      t.createElement(
                        "span",
                        null,
                        d ? r.t("Let\u2019s Go!") : "Let\u2019s Go!"
                      )
                    )
                  )
                )
              : null;
          }, "SidebarSweeperSectionCreationCta");
        a.displayName = "SidebarSweeperSectionCreationCta";
        const _ = a;
      },
      5557117347: (W, g, e) => {
        "use strict";
        e.d(g, {
          P: () => _,
        });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(7043699030),
          s = e(3086269805),
          I = e(7112009473),
          v = e(8288042117),
          T = e(1983217662),
          u = e(1507833885),
          h = e(6684249197),
          D = e(3924251130),
          n = e(3514831633),
          m = e(8773153312),
          l = e(735940183),
          f = e(2562405183),
          k = e(4804990235),
          E = e(6146942550),
          r = e(3677514771);
        function i() {
          return (
            (i =
              Object.assign ||
              function (o) {
                for (var d = 1; d < arguments.length; d++) {
                  var A = arguments[d];
                  for (var C in A)
                    Object.prototype.hasOwnProperty.call(A, C) && (o[C] = A[C]);
                }
                return o;
              }),
            i.apply(this, arguments)
          );
        }
        c(i, "_extends");
        const a = new l.Ay("events"),
          _ = c((o) => {
            let {
              workspaceId: d,
              isViewingFromHome: A = !1,
              isWorkspaceHeaderMenu: C = !1,
              classNames: M,
              ariaLabel: y,
              ...x
            } = o;
            const N = (0, O.wA)(),
              U = (0, f.d4)((G) => (0, h.o)(G, d)),
              p = (0, f.d4)((G) => (0, D.VW)(G, d)),
              Y = (0, f.d4)((G) => (0, T.F)(G, d)),
              z = (0, f.d4)((G) => (0, E.i)(G, d)),
              Z = (0, f.d4)((G) => (0, u.Uq)(G, [d])),
              w = (0, f.d4)((G) => (0, k.fF)(G, d)),
              [V] = (0, v.A)((G) => {
                let { closeModal: te } = G;
                return {
                  element: t.createElement(s.i, {
                    onClose: te,
                    workspaceId: d,
                  }),
                };
              }),
              L = !Z && !p && !Y && (!U || !z),
              J = (0, f.d4)((G) => (0, r._J)(G, d)),
              se = I.n7
                .map((G) =>
                  (0, I.wN)({
                    item: G,
                    dispatch: N,
                    externalWorkspace: J,
                    isViewingFromHome: A,
                    canCurrentUserOpenCommunityAdminDashboard: U,
                    canUserCreateSlackConnectWorkspaceInvites: p,
                    canUserCreatePinnedCanvasItem: Y,
                    canCreateChannelsInExternalWorkspace: Z,
                    communityAdminDashboardUrl: z,
                    shouldRemoveSeparators: L,
                    openAddToHomeConfirmationModal: V,
                    isWorkspaceAddedToHome: w,
                    isWorkspaceHeaderMenu: C,
                  })
                )
                .flat(),
              j = (0, t.useMemo)(() => {
                const G = {
                  children: t.createElement(P.A, {
                    customTeam: J,
                    key: "team-blurb-menu-item",
                    isMenuItem: U,
                    ariaDescribedById: "team-blurb-text",
                    customSubtitle: a.t("External workspace"),
                  }),
                  type: U ? void 0 : m.A.custom,
                  key: "team-blurb-menu-item",
                };
                return C && se.length === 2
                  ? [G, ...se]
                  : C && se.length > 2
                  ? [
                      G,
                      {
                        type: m.A.separator,
                      },
                      ...se,
                    ]
                  : L
                  ? [...se]
                  : se;
              }, [U, J, L, C, se]);
            return t.createElement(
              n.a,
              i({}, x, {
                template: j,
                menuClassNames: M,
                "aria-label": y,
              })
            );
          }, "ExternalWorkspaceActionsMenu");
        _.displayName = "ExternalWorkspaceActionsMenu";
      },
      7043699030: (W, g, e) => {
        "use strict";
        e.d(g, {
          A: () => k,
        });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(7715417323),
          s = e(3677514771),
          I = e(6839188756),
          v = e(698013937),
          T = e(1610251172),
          u = e(5510392579),
          h = e(636674013),
          D = e(135069931),
          n = e(6334717308),
          m = e(3328068409),
          l = e(2562405183);
        const f = c((E) => {
          let {
            customTeam: r,
            customSubtitle: i,
            onMouseEnter: a = P.A,
            isMenuItem: _ = !1,
            ariaDescribedById: o,
            dataQa: d,
          } = E;
          const A = (0, l.d4)(s.H7),
            C = r ?? A,
            M = (0, I.F1)(C),
            y = (0, I.Zl)(C, "", !0),
            x = (0, l.d4)(h.S),
            N = (0, l.d4)(n.c),
            U = (0, l.d4)(m.to),
            p = (0, l.d4)(
              (z) =>
                (x === D.S.SharedChannelInvite || x === D.S.SharedDmInvite) &&
                ((0, u.Zo)(z) || (0, u.p2)(z))
            ),
            Y = (0, O.A)(
              "p-classic_nav__team_menu__blurb--team classic_nav__team_menu__blurb p-classic_nav__team_menu__blurb--ia4",
              {
                "p-classic_nav__team_menu__blurb_submenu": _ || p,
                "p-classic_nav__team_menu__blurb": !(_ || p),
              }
            );
          return t.createElement(
            "div",
            {
              onMouseEnter: a,
            },
            t.createElement(
              "div",
              {
                className: Y,
                "data-qa": d,
              },
              t.createElement(v.A, {
                id: C.id,
                size: 36,
                className: "p-classic_nav__team_menu__blurb__icon",
              }),
              t.createElement(
                "div",
                {
                  className: "p-classic_nav__team_menu__blurb__right",
                },
                t.createElement(
                  "div",
                  {
                    className: "p-classic_nav__team_menu__blurb__name",
                  },
                  N
                    ? t.createElement(T.A, {
                        type: "gov-slack",
                        size: "inherit",
                        inline: !0,
                        className: (0, O.A)(
                          "p-classic_nav__team_menu__blurb__name--gov_slack_icon",
                          `p-classic_nav__team_menu__blurb__name--gov_slack_icon--${U}`
                        ),
                      })
                    : null,
                  M
                ),
                t.createElement(
                  "div",
                  {
                    className: "p-classic_nav__team_menu__blurb__sub",
                    id: o,
                  },
                  i ?? y
                )
              )
            )
          );
        }, "TeamBlurb");
        f.displayName = "TeamBlurb";
        const k = f;
      },
      320067417: (W, g, e) => {
        "use strict";
        e.d(g, {
          a: () => I,
        });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(6870134753),
          s = e.n(P);
        const I = c((v) => {
          let {
            children: T,
            as: u = "div",
            padding: h,
            paddingInlineStart: D,
            paddingInline: n,
            paddingBlock: m,
            paddingBlockEnd: l,
            backgroundColor: f,
            border: k,
            borderColor: E,
            borderRadius: r,
            height: i,
            flex: a,
          } = v;
          return t.createElement(
            u,
            {
              className: (0, O.A)(s().box, {
                [s().backgroundColorCoreBaseSecondary]:
                  f === "Core/Base/Secondary",
                [s().backgroundColorCoreSurfacePrimary]:
                  f === "Core/Surface/Primary",
                [s().backgroundColorCoreSurfaceHighlight3]:
                  f === "Core/Surface/Highlight 3",
                [s().borderRegular]: k === "regular",
                [s().borderColorCoreSurfaceSecondary]:
                  E === "Core/Surface/Secondary",
                [s().borderRadiusXLarge]: r === "x-large",
                [s().borderRadiusRounded]: r === "rounded",
                [s().borderRadiusBase]: r === "base",
                [s().padding50]: h === "50",
                [s().padding100]: h === "100",
                [s().padding125]: h === "125",
                [s().paddingInlineStart250]: D === "250",
                [s().paddingInlineStart125]: D === "125",
                [s().paddingInline25]: n === "25",
                [s().paddingInline150]: n === "150",
                [s().paddingInline250]: n === "250",
                [s().paddingBlock100]: m === "100",
                [s().paddingBlockEnd150]: l === "150",
                [s().heightFill]: i === "fill",
                [s().inlineFlex]: a === "inline",
                [s().listStyleNone]: u === "li",
              }),
            },
            T
          );
        }, "Box");
        I.displayName = "Box";
      },
      2409757433: (W, g, e) => {
        "use strict";
        e.d(g, {
          E: () => I,
        });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(4614285233),
          s = e.n(P);
        const I = c((v) => {
          let {
            children: T,
            as: u = "span",
            size: h = "base",
            weight: D = "base",
            color: n = "Core/Content/Primary",
            isItalic: m,
          } = v;
          return t.createElement(
            u,
            {
              className: (0, O.A)(s().text, {
                [s().fontSizeMicro]: h === "micro",
                [s().fontSizeCaption]: h === "caption",
                [s().fontSizeBase]: h === "base",
                [s().fontSizeSubtitle]: h === "subtitle",
                [s().fontWeightBase]: D === "base",
                [s().fontWeightSemibold]: D === "semibold",
                [s().fontWeightBold]: D === "bold",
                [s().fontWeightBlack]: D === "black",
                [s().colorPrimary]: n === "Core/Content/Primary",
                [s().colorSecondary]: n === "Core/Content/Secondary",
                [s().colorTertiary]: n === "Core/Content/Tertiary",
                [s().colorThemeInversePrimary]:
                  n === "Theme/Content/Inverse primary",
                [s().colorHighlight2]: n === "Core/Content/Highlight 2",
                [s().colorHighlight3]: n === "Core/Content/Highlight 3",
                [s().colorCoreContentImportant]: n === "Core/Content/Important",
                italic: m,
              }),
            },
            T
          );
        }, "Text");
        I.displayName = "Text";
      },
      7205738127: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => p,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(5255740490),
          s = e(4481313819),
          I = e(2670882607),
          v = e(5267010247),
          T = e(8822892075),
          u = e(5519146941),
          h = e(7940058138),
          D = e(6084388622),
          n = e(6105929840),
          m = e(8683010724),
          l = e(8214116048),
          f = e(1224315998),
          k = e(735940183),
          E = e(2562405183),
          r = e(3328068409),
          i = e(2938177083),
          a = e(7003004874),
          _ = e(6259241484),
          o = e(2047021170),
          d = e(9776496806),
          A = e(2927254383),
          C = e(3193155968);
        const M = new k.Ay("lists"),
          y = c(
            () => () =>
              e
                .e("gantry-v2-async-lottie-lists-themed-sparkle.json")
                .then(e.t.bind(e, 3415497769, 23)),
            "getAnimationImport"
          ),
          x = {
            elementName: "target_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          N = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          U = c(() => {
            const Y = (0, O.wA)(),
              z = (0, E.d4)(r.to),
              Z = (0, E.d4)((J) => !!(0, o.ty)(J, "a11y_animations")),
              { activeTab: w } = (0, t.useContext)(u.A);
            (0, t.useEffect)(
              () => () => {
                Y(
                  (0, a.A)({
                    notificationName: _.ze.LISTS_WELCOME_TO_LISTS_HOME_BANNER,
                    action: _.hw.IMPRESSION,
                  })
                );
              },
              [Y]
            );
            const V = (0, t.useCallback)(() => {
                Y(
                  (0, i.A)({
                    spaceName: _.xu.SIDEBAR_MENU_HEADER,
                    action: _.hw.DISMISS,
                  })
                );
              }, [Y]),
              L = (0, t.useCallback)(() => {
                Y(
                  (0, A.E)({
                    tabName: C.k6.Lists,
                    value: !0,
                    reason: d.pU.Auto,
                  })
                ),
                  Y((0, v.o)((0, T.ZF)(h.c.BrowseLists))),
                  V();
              }, [Y, V]);
            return w === C.k6.Home
              ? t.createElement(
                  s.A,
                  {
                    eventId: f.EventId.SLACK_LISTS,
                    uiComponentName: f.UiComponentName.LISTS_NUX_WELCOME_BANNER,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: "p-lists_welcome_banner",
                    },
                    t.createElement(
                      D.jV,
                      {
                        onClick: L,
                        className: "p-lists_welcome_banner__button",
                        autoClogProps: x,
                        "aria-label": M.t("Introducing lists"),
                        "aria-describedby": "lists-welcome-banner-desc",
                      },
                      t.createElement(
                        "span",
                        {
                          className: "p-lists_welcome_banner__icon_background",
                        },
                        Z
                          ? t.createElement(I.e, {
                              className: (0, P.A)(
                                "p-lists_welcome_banner_icon",
                                {
                                  "p-lists_welcome_banner_icon--dark-mode":
                                    z === l.Sx.Dark,
                                }
                              ),
                              getAnimationImport: y(),
                              autoplay: !0,
                              loop: !1,
                            })
                          : t.createElement(
                              "div",
                              {
                                className:
                                  "p-lists_welcome_banner__static_icon",
                              },
                              t.createElement(m.A, {
                                name: "lists",
                                size: "24",
                              })
                            )
                      ),
                      t.createElement(
                        "div",
                        {
                          className: "p-lists_welcome_banner__description",
                        },
                        t.createElement(
                          "span",
                          {
                            className:
                              "p-lists_welcome_banner__description_title",
                          },
                          M.t("Introducing lists")
                        ),
                        t.createElement(
                          "span",
                          {
                            className:
                              "p-lists_welcome_banner__description_subtitle",
                            id: "lists-welcome-banner-desc",
                          },
                          M.t("Track work in Slack")
                        )
                      )
                    ),
                    t.createElement(
                      n.A,
                      {
                        "aria-label": M.t("Close tip", {
                          fallbackHash:
                            "8e5cf4e323045bac6bd4071976f5f80955c0e3d1",
                          fallbackHashNs: "huddles",
                        }),
                        onClick: V,
                        className: "p-lists_welcome_banner__close_button",
                        autoClogProps: N,
                      },
                      t.createElement(m.A, {
                        name: "close",
                        size: "16",
                      })
                    )
                  )
                )
              : null;
          }, "ListsWelcomeToListsHomeBanner");
        U.displayName = "ListsWelcomeToListsHomeBanner";
        const p = U;
      },
      7391266585: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseOpenMobileAppMenuItem: () => A,
            default: () => C,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(2562405183),
          s = e(735940183),
          I = e(2375333597),
          v = e(1031947056),
          T = e(1224315998),
          u = e(8467766508);
        const h = (0, v.Ay)(
          "Opens modal that informs the user a magic login email has been sent to them",
          (M, y) => {
            M(
              (0, I.q)({
                element: t.createElement(u.A, {
                  eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                }),
              })
            );
          }
        );
        h.meta = {
          name: "createThunk",
          key: "createThunkopenSentMagicLoginConfirmationModal",
          description:
            "Opens modal that informs the user a magic login email has been sent to them",
        };
        var D = e(7307373517),
          n = e(7019848462),
          m = e(4481313819),
          l = e(1610251172),
          f = e(8245211418),
          k = e(101973425),
          E = e(9074302729),
          r = e(4761125736);
        function i() {
          return (
            (i =
              Object.assign ||
              function (M) {
                for (var y = 1; y < arguments.length; y++) {
                  var x = arguments[y];
                  for (var N in x)
                    Object.prototype.hasOwnProperty.call(x, N) && (M[N] = x[N]);
                }
                return M;
              }),
            i.apply(this, arguments)
          );
        }
        c(i, "_extends");
        const a = new s.Ay("native_apps_entry_points"),
          _ = {
            onClick: {
              enableClogAction: !0,
            },
          },
          o = c((M) => {
            let { handleClick: y, ...x } = M;
            const N = a.rt("Get the mobile app"),
              U =
                T.UiComponentVariant.PERSISTENT_ENTRY_TREATMENT_MOBILE_DOWNLOAD,
              p = t.createElement(
                t.Fragment,
                null,
                t.createElement(
                  "span",
                  {
                    className: "p-ia__main_menu__open_native_app_copy",
                  },
                  N
                ),
                t.createElement(
                  "span",
                  {
                    className: "p-ia__main_menu__open_native_app_icon",
                  },
                  t.createElement(l.A, {
                    type: "mobile",
                  })
                )
              );
            return t.createElement(
              m.A,
              {
                eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                uiStep: T.UiStep.MAIN_MENU,
                uiComponentName: T.UiComponentName.MOBILE_ENTRY_POINT,
                uiComponentVariant: U,
                clogImpression: !0,
              },
              t.createElement(
                f.A,
                i({}, x, {
                  "data-qa": "open-mobile-app",
                  className: "p-ia__main_menu__open_slack_app_item",
                  onSelected: y,
                  label: p,
                  autoClogProps: _,
                })
              )
            );
          }, "OpenMobileAppMenuItem");
        o.displayName = "OpenMobileAppMenuItem";
        const d = c((M) => {
          let { handleClick: y, showExistingHumansMobileEntry: x, ...N } = M,
            U = a.rt("Get the mobile app"),
            p = T.UiComponentVariant.PERSISTENT_ENTRY_TREATMENT_MOBILE_DOWNLOAD;
          x &&
            ((U = a.rt("Email link to sign in")),
            (p =
              T.UiComponentVariant.PERSISTENT_ENTRY_TREATMENT_MOBILE_SIGN_IN));
          const Y = t.createElement(
            t.Fragment,
            null,
            t.createElement(
              "span",
              {
                className: "p-ia__main_menu__open_native_app_copy",
              },
              U
            ),
            !x &&
              t.createElement(
                "span",
                {
                  className: "p-ia__main_menu__open_native_app_icon",
                },
                t.createElement(l.A, {
                  type: "mobile",
                })
              )
          );
          return t.createElement(
            m.A,
            {
              eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
              uiStep: T.UiStep.MAIN_MENU,
              uiComponentName: T.UiComponentName.MOBILE_ENTRY_POINT,
              uiComponentVariant: p,
              clogImpression: !0,
            },
            t.createElement(
              f.A,
              i({}, N, {
                "data-qa": "open-mobile-app",
                className: "p-ia__main_menu__open_slack_app_item",
                onSelected: y,
                label: Y,
                autoClogProps: _,
              })
            )
          );
        }, "DeprecatedOpenMobileAppMenuItem");
        d.displayName = "DeprecatedOpenMobileAppMenuItem";
        const A = c((M) => {
          let { showExistingHumansMobileEntry: y, ...x } = M;
          const N = (0, O.wA)(),
            U = (0, P.d4)(
              (Z) => (0, r._Z)(Z, "deprecate_email_signin") === "on"
            ),
            p = (0, t.useCallback)(() => {
              N(
                (0, I.q)({
                  element: t.createElement(E.A, {
                    eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                  }),
                })
              ),
                N(
                  (0, D.f)({
                    reason: n.wr.TRIGGER_MOBILE_FALLBACK_EMAIL,
                    eventHandler: n.ch.MOBILE_PROMO_FALLBACK_EVENT_HANDLER,
                    subtype: n.YB.PERSISTENT_MOBILE_PROMO,
                  })
                );
            }, [N]),
            Y = (0, t.useCallback)(() => {
              N(h()),
                N(
                  (0, D.f)({
                    reason: n.wr.TRIGGER_MOBILE_MAGIC_LOGIN_EMAIL,
                    eventHandler: n.ch.MOBILE_PROMO_MAGIC_LOGIN_EVENT_HANDLER,
                    subtype: n.YB.PERSISTENT_MOBILE_PROMO,
                  })
                );
            }, [N]),
            z = y ? Y : p;
          return U
            ? t.createElement(
                o,
                i(
                  {
                    showExistingHumansMobileEntry: !1,
                    handleClick: p,
                  },
                  x
                )
              )
            : t.createElement(
                d,
                i(
                  {
                    handleClick: z,
                    showExistingHumansMobileEntry: y,
                  },
                  x
                )
              );
        }, "ConnectedOpenMobileAppMenuItem");
        A.displayName = "ConnectedOpenMobileAppMenuItem";
        const C = (0, k.Ay)(A);
      },
      629068863: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => N,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4509434386),
          s = e(5255740490),
          I = e(4481313819),
          v = e(1267040415),
          T = e(5267010247),
          u = e(8822892075),
          h = e(5519146941),
          D = e(7940058138),
          n = e(6839188756),
          m = e(6084388622),
          l = e(8683010724),
          f = e(8214116048),
          k = e(1224315998),
          E = e(735940183),
          r = e(2562405183),
          i = e(3328068409),
          a = e(2938177083),
          _ = e(6259241484),
          o = e(3677514771),
          d = e(3193155968);
        const A = new E.Ay("resurrected_user_welcome"),
          C = {
            elementName: "resurrected_user_sidebar_upgrade_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          M = {
            elementName: "resurrected_user_sidebar_entry_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          y = {
            elementName: "resurrected_user_sidebar_close_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          x = c(() => {
            const U = (0, O.wA)(),
              { activeTab: p } = (0, t.useContext)(h.A),
              Y = p === d.k6.Home,
              { getSiblingView: z } = (0, t.useContext)(h.A),
              Z = (0, r.d4)(o.H7),
              w = (0, n.tc)(Z),
              V = (0, r.d4)((G) => {
                var te;
                return (te = z(G, {
                  container: d.mq.Primary,
                })) === null || te === void 0
                  ? void 0
                  : te.id;
              }),
              L = (0, r.d4)(i.to),
              J = V === "Presurrected-user-welcome",
              se = (0, t.useCallback)(
                () => U((0, T.o)((0, u.ZF)(D.c.ResurrectedUserWelcome))),
                [U]
              ),
              j = (0, t.useCallback)(() => {
                U(
                  (0, a.A)({
                    spaceName: _.xu.SIDEBAR_MENU_HEADER,
                    action: _.hw.DISMISS,
                  })
                );
              }, [U]);
            return Y
              ? t.createElement(
                  I.A,
                  {
                    uiComponentName:
                      k.UiComponentName
                        .RESURRECTED_USER_WELCOME_SIDEBAR_ENTRY_CTA,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className:
                        "p-resurrected_user_welcome_entry_cta__upgrade_wrapper",
                    },
                    t.createElement(
                      "div",
                      {
                        className: (0, s.A)(
                          "p-resurrected_user_welcome_entry_cta__wrapper",
                          {
                            [P.A7]: L === f.Sx.Light,
                          }
                        ),
                      },
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-resurrected_user_welcome_entry_cta__wrapper_text_container",
                        },
                        t.createElement(l.A, {
                          size: "20",
                          name: "emoji",
                        }),
                        t.createElement(
                          "span",
                          {
                            className:
                              "p-resurrected_user_welcome_entry_cta__wrapper_text",
                          },
                          A.t("Welcome back")
                        )
                      ),
                      t.createElement(
                        m.Nm,
                        {
                          className: (0, s.A)({
                            "p-resurrected_user_welcome_entry_cta__button dt-hocus:theme-base-pry":
                              !J,
                            "p-resurrected_user_welcome_entry_cta__button_selected":
                              J,
                          }),
                          "data-qa": "resurrected-user-entry-cta-btn",
                          autoClogProps: M,
                          onClick: se,
                        },
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_badge__button_text_container",
                          },
                          A.t("Top things to check out")
                        ),
                        t.createElement(
                          "span",
                          null,
                          t.createElement(l.A, {
                            size: "24",
                            name: "caret-right",
                          })
                        )
                      ),
                      t.createElement(
                        m.Nm,
                        {
                          className:
                            "p-resurrected_user_welcome_entry_cta__close_cta",
                          onClick: j,
                          autoClogProps: y,
                          "data-qa": "resurrected-user-entry-close-btn",
                        },
                        t.createElement(l.A, {
                          name: "close",
                        })
                      )
                    ),
                    w &&
                      t.createElement(
                        v.A,
                        {
                          autoClogProps: C,
                          className: (0, s.A)(
                            "p-resurrected_user_welcome_entry_cta__upgrade_now_btn",
                            {
                              [P.Pn]: L === f.Sx.Light,
                            }
                          ),
                          "data-qa": "resurrected-user-entry-upgrade-button",
                          entryPoint: "resurructed-user-welcome-sidebar-entry",
                          type: "outline",
                        },
                        t.createElement(l.A, {
                          size: "20",
                          name: "rocket",
                        }),
                        t.createElement("span", null, A.t("Upgrade Plan"))
                      )
                  )
                )
              : null;
          }, "ResurrectedUserWelcomeEntryCta");
        x.displayName = "ResurrectedUserWelcomeEntryCta";
        const N = x;
      },
      1720631741: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseStraightToPaidSidebarMenuHeaderOfferCta: () => p,
            default: () => z,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4481313819),
          s = e(3405119017),
          I = e(3749988767),
          v = e(7878745420),
          T = e(5519146941),
          u = e(7115655993),
          h = e(6839188756),
          D = e(5510392579),
          n = e(2683115972),
          m = e(8683010724),
          l = e(2312625946),
          f = e(735940183),
          k = e(6323355797),
          E = e(2562405183),
          r = e(636674013),
          i = e(1960898919),
          a = e(1708049820),
          _ = e(2965336964),
          o = e(3474336343),
          d = e(2967538512),
          A = e(3677514771),
          C = e(3193155968),
          M = e(7429662208);
        function y() {
          return (
            (y =
              Object.assign ||
              function (Z) {
                for (var w = 1; w < arguments.length; w++) {
                  var V = arguments[w];
                  for (var L in V)
                    Object.prototype.hasOwnProperty.call(V, L) && (Z[L] = V[L]);
                }
                return Z;
              }),
            y.apply(this, arguments)
          );
        }
        c(y, "_extends");
        const x = v.g.STRAIGHT_TO_PAID_SIDEBAR_MENU_HEADER_OFFER_CTA,
          N = new f.Ay("setup_straight_to_paid"),
          U = "straight_to_paid_sidebar_menu_header",
          p = c((Z) => {
            let {
              discountPercent: w,
              discountExpirationTs: V = 0,
              isInSetup: L,
              onClick: J,
            } = Z;
            const se = (0, I.Q)(V),
              j = (0, E.d4)(M.e6),
              G = (0, E.d4)(d.PU),
              {
                eventId: te,
                uiStep: me,
                elementName: Re,
                stepVariant: Se,
              } = (0, t.useMemo)(() => (0, s.eq)(G), [G]),
              Te = (0, t.useMemo)(() => (0, s.NR)(G), [G]);
            if (L || j !== C.k6.Home) return null;
            const $e = N.t("Get {discountPercent}% Off Slack Pro", {
              discountPercent: w,
            });
            return t.createElement(
              P.A,
              {
                clogImpression: !0,
                eventId: te,
                uiStep: me,
                elementName: Re,
                stepVariant: Se,
              },
              t.createElement(
                "div",
                {
                  className:
                    "p-sidebar_menu_header_offer_cta p-sidebar_menu_header_offer_cta--ia4",
                },
                t.createElement(
                  n.z9,
                  {
                    className: "p-sidebar_menu_header_offer_cta__button",
                    type: "outline",
                    size: "medium",
                    onClick: J,
                    autoClogProps: Te,
                  },
                  t.createElement(
                    "span",
                    {
                      className: "p-sidebar_menu_header_offer_cta__button-icon",
                    },
                    t.createElement(m.A, {
                      name: "rocket",
                    })
                  ),
                  t.createElement(
                    l.Ay,
                    {
                      offsetX: -11,
                      automaticallyPositionTip: !1,
                      delay: l.PK,
                      tip: $e,
                      shouldOnlyShowWhenTruncated: !0,
                    },
                    t.createElement(
                      "span",
                      {
                        className:
                          "p-sidebar_menu_header_offer_cta__button-text",
                      },
                      $e
                    )
                  )
                ),
                t.createElement(
                  "p",
                  {
                    className:
                      "p-sidebar_menu_header_offer_cta__offer-countdown",
                  },
                  typeof se == "number" &&
                    N.t(
                      "{daysRemaining, plural, =1 {# day} other {# days}} left on this offer",
                      {
                        daysRemaining: se,
                      }
                    )
                )
              )
            );
          }, "StraightToPaidSidebarMenuHeaderOfferCta");
        p.displayName = "StraightToPaidSidebarMenuHeaderOfferCta";
        const Y = c((Z) => {
          const { getSiblingView: w } = (0, t.useContext)(T.A),
            V = (0, O.wA)(),
            L = (0, E.d4)(A.H7),
            J = (0, E.d4)(
              (Se) =>
                !!(0, o.Li)(Se, {
                  getSiblingView: w,
                })
            ),
            se = (0, E.d4)(o.mF),
            j = (0, E.d4)(d.aO),
            G = (0, E.d4)(r.S),
            te = (0, E.d4)((Se) => (0, i.ax)(Se, _.By)),
            me = (0, E.d4)(D.$G),
            Re = (0, t.useCallback)(() => {
              if (L) {
                const Se = (0, k.hZ)({
                  entryPoint: U,
                });
                (0, h.gC)(L, Se, "_self");
              }
            }, [L]);
          return (
            (0, u.A)(() => {
              !!G &&
                me &&
                !te &&
                !J &&
                j &&
                V(
                  (0, a.h)({
                    pref: _.By,
                    value: se,
                  })
                );
            }),
            t.createElement(
              p,
              y(
                {
                  isInSetup: J,
                  onClick: Re,
                },
                Z
              )
            )
          );
        }, "ConnectedStraightToPaidSidebarMenuHeaderOfferCta");
        Y.displayName = "ConnectedStraightToPaidSidebarMenuHeaderOfferCta";
        const z = Y;
      },
      3749988767: (W, g, e) => {
        "use strict";
        e.d(g, {
          Q: () => I,
        });
        var t = e(6122756707),
          O = e(2562405183),
          P = e(3263322402),
          s = e(3474336343);
        const I = c((v) => {
          const T = (0, t.wA)(),
            u = (0, O.d4)(s.hf);
          return (
            typeof u > "u" &&
              T(
                (0, P.pl)({
                  expirationTs: v * 1e3,
                  now: Date.now(),
                })
              ),
            u
          );
        }, "useStraightToPaidDaysRemaining");
      },
      2811650336: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => w,
          });
        var t = e(9706240641),
          O = e(5824283093),
          P = e(6122756707),
          s = e(4481313819),
          I = e(4502904940),
          v = e(1232649910),
          T = e(2558145408),
          u = e(1482809496),
          h = e(1224315998),
          D = e(735940183),
          n = e(2562405183),
          m = e(4761125736),
          l = e(6259241484);
        const f = new D.Ay("assistant"),
          k = c((V) => {
            let { children: L } = V;
            const se = (0, n.d4)(
                (Te) =>
                  (0, m._Z)(Te, "slack_ai_onboarding_modal_trial_copy") === "on"
              )
                ? f.t("You\u2019re on a Slack AI trial")
                : f.t("You\u2019re on a 30-day Slack AI trial"),
              {
                isOpen: j,
                closeCoachmark: G,
                renderCoachmark: te,
              } = (0, u.A)(l.ze.SLACK_AI_PERSISTENT_SIDEBAR_NFX_COACHMARK),
              me = (0, O.useMemo)(
                () => ({
                  eventId: h.EventId.NATIVE_AI,
                  uiStep: h.UiStep.SLACK_AI_PERSISTENT_SIDEBAR_NFX_COACHMARK,
                  elementName: I.H.NUX_COACHMARK,
                }),
                []
              ),
              Re = (0, O.useCallback)(() => {
                G();
              }, [G]),
              Se = te({
                className: "p-slack_ai_persistent_sidebar_nfx_coachmark",
                closeCoachmark: Re,
                icon: "/img/slack_ai/celebration.svg",
                offsetX: -20,
                offsetY: 16,
                title: se,
                ariaLabel: se,
                bodyText: f.t(
                  "Learn more in our help center about how you can get the most out of your day with Slack AI."
                ),
                autoClogProps: me,
              });
            return j
              ? O.createElement(
                  T.Ay,
                  {
                    coachmarkElement: Se,
                    orientation: "right",
                  },
                  O.createElement(
                    "div",
                    {
                      className: "p-slack_ai_persistent_sidebar_nfx_coachmark",
                    },
                    L
                  )
                )
              : L;
          }, "SlackAiPersistentSidebarNfxCoachmark");
        k.displayName = "SlackAiPersistentSidebarNfxCoachmark";
        const E = k;
        var r = e(7094978947),
          i = e(174977074),
          a = e(6084388622),
          _ = e(6105929840),
          o = e(8683010724),
          d = e(7274827479),
          A = e(2938177083),
          C = e(7003004874),
          M = e(2375333597),
          y = e(8483346214),
          x = e(3141349242);
        const N = {
            onClick: {
              enableClogAction: !0,
            },
            elementName: I.H.PERSISTENT_SIDEBAR_NFX_BANNER,
          },
          U = {
            onClick: {
              enableClogAction: !0,
            },
            elementName: I.H.PERSISTENT_SIDEBAR_NFX_BANNER_DISMISS,
          },
          p = new D.Ay("assistant"),
          Y = {
            SLACK_AI_TRIAL: "slack_ai_trial",
            SLACK_AI: "slack_ai",
          },
          z = {
            TAKE_TOUR: "take_tour",
          },
          Z = c(() => {
            const V = (0, P.wA)(),
              L = (0, n.d4)(d.TP),
              J = (0, n.d4)(y.xg),
              se = (0, n.d4)(x.Gj);
            (0, i.A)(l.ze.SIDEBAR_MENU_HEADER_SLACK_AI_NFX_CTA);
            const j = (0, O.useCallback)(() => {
                V(
                  (0, A.A)({
                    spaceName: l.xu.SIDEBAR_MENU_HEADER,
                    action: l.hw.DISMISS,
                  })
                );
              }, [V]),
              G = (0, O.useCallback)(
                (0, t.coroutine)(function* () {
                  yield V(
                    (0, C.A)({
                      notificationName:
                        l.ze.SIDEBAR_MENU_HEADER_SLACK_AI_NFX_CTA,
                      action: l.hw.CLICK,
                    })
                  ),
                    yield V(
                      (0, M.q)({
                        element: O.createElement(v.default, null),
                      })
                    );
                }),
                [V]
              ),
              te = (0, O.useCallback)(
                (me) => {
                  let { text: Re } = me;
                  return O.createElement(
                    a.jV,
                    {
                      onClick: G,
                      className: "p-slack_ai_persistent_sidebar_nfx_cta__link",
                      autoClogProps: N,
                    },
                    Re
                  );
                },
                [G]
              );
            return L
              ? O.createElement(
                  E,
                  null,
                  O.createElement(
                    s.A,
                    {
                      clogImpression: !0,
                      eventId: h.EventId.NATIVE_AI,
                      uiStep: h.UiStep.SLACK_AI_PERSISTENT_SIDEBAR_NFX_BANNER,
                      stepVariant: z.TAKE_TOUR,
                      slackAiLicenseType: J ? Y.SLACK_AI_TRIAL : Y.SLACK_AI,
                      displayName: se,
                    },
                    O.createElement(
                      "div",
                      {
                        className: "p-slack_ai_persistent_sidebar_nfx_cta",
                      },
                      O.createElement(
                        "div",
                        {
                          className:
                            "p-slack_ai_persistent_sidebar_nfx_cta__content",
                        },
                        O.createElement(
                          "span",
                          {
                            className:
                              "p-slack_ai_persistent_sidebar_nfx_cta__icon",
                          },
                          O.createElement(r.o, {
                            size: "16",
                            type: "sparkles",
                            variation: "filled",
                          })
                        ),
                        O.createElement(
                          "div",
                          {
                            className: "display_flex flex_direction_column",
                          },
                          O.createElement(
                            "div",
                            null,
                            p.rt("Try Slack AI. <a>Take a tour</a>", {
                              "<a>": te,
                            })
                          )
                        )
                      ),
                      O.createElement(
                        _.A,
                        {
                          "aria-label": p.t("Close"),
                          onClick: j,
                          className:
                            "p-slack_ai_persistent_sidebar_nfx_cta__close",
                          autoClogProps: U,
                        },
                        O.createElement(
                          "span",
                          {
                            className:
                              "p-slack_ai_persistent_sidebar_nfx_cta__close_icon",
                          },
                          O.createElement(o.A, {
                            name: "close",
                            size: "16",
                          })
                        )
                      )
                    )
                  )
                )
              : null;
          }, "SlackAiPersistentSidebarNfxCta");
        Z.displayName = "SlackAiPersistentSidebarNfxCta";
        const w = Z;
      },
      4061500210: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => Z,
          });
        var t = e(9706240641),
          O = e.n(t),
          P = e(5824283093),
          s = e(6122756707),
          I = e(2562405183),
          v = e(7115655993),
          T = e(4481313819),
          u = e(5267010247),
          h = e(8822892075),
          D = e(5519146941),
          n = e(6084388622),
          m = e(6105929840),
          l = e(8683010724),
          f = e(1224315998),
          k = e(735940183),
          E = e(2938177083),
          r = e(7003004874),
          i = e(6259241484),
          a = e(9776496806),
          _ = e(2927254383),
          o = e(3193155968),
          d = e(5868036555),
          A = e(1655938719),
          C = e(7949425452),
          M = e(229137923),
          y = e(3851004129),
          x = e(3715755184),
          N = e.n(x);
        const U = new k.Ay("solutions"),
          p = {
            elementName: "target_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          Y = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          z = c(() => {
            const w = (0, s.wA)(),
              V = (0, I.d4)(d.bK),
              L = (0, I.d4)(M.Ul),
              { activeTab: J } = (0, P.useContext)(D.A);
            (0, v.A)(() => {
              V &&
                w(
                  (0, r.A)({
                    notificationName:
                      i.ze.SOLUTIONS_WELCOME_TO_SOLUTIONS_HOME_SIDEBAR_BANNER,
                    action: i.hw.IMPRESSION,
                  })
                );
            });
            const se = (0, P.useCallback)(
                (0, t.coroutine)(function* () {
                  yield w(
                    (0, E.A)({
                      spaceName: i.xu.SIDEBAR_MENU_HEADER,
                      action: i.hw.DISMISS,
                    })
                  ),
                    w(
                      (0, A.iR)({
                        event: {
                          type: i.jo.SOLUTIONS_WELCOME_BANNER_DISMISSED,
                        },
                      })
                    );
                }),
                [w]
              ),
              j = (0, P.useCallback)(() => {
                w(
                  (0, y.xj)({
                    value: !0,
                  })
                ),
                  se();
              }, [se, w]),
              G = (0, P.useCallback)(() => {
                w(
                  (0, _.E)({
                    tabName: o.k6.Solutions,
                    value: !0,
                    reason: a.pU.Auto,
                  })
                ),
                  w((0, u.o)((0, h.Wy)())),
                  se();
              }, [w, se]);
            return V && J === o.k6.Home
              ? P.createElement(
                  T.A,
                  {
                    eventId: f.EventId.SOLUTIONS_NUX,
                    uiComponentName:
                      f.UiComponentName.SOLUTIONS_WELCOME_SIDEBAR_BANNER,
                    clogImpression: !0,
                  },
                  P.createElement(
                    "div",
                    {
                      className: N().container,
                    },
                    P.createElement(
                      "div",
                      {
                        className: N().inner_container,
                      },
                      P.createElement(
                        n.Nm,
                        {
                          onClick: G,
                          className: N().banner_button,
                          autoClogProps: p,
                          "aria-label": V ? U.t("Introducing templates") : "",
                          "aria-describedby": "templates-welcome-banner-desc",
                        },
                        P.createElement(
                          "div",
                          {
                            className: N().sub_container,
                          },
                          P.createElement(
                            "span",
                            {
                              className: N().icon_background,
                            },
                            P.createElement(
                              "div",
                              {
                                className: N().icon,
                              },
                              P.createElement(l.A, {
                                name: "tools",
                                size: "20",
                              })
                            )
                          ),
                          P.createElement(
                            "div",
                            {
                              className: N().label_container,
                            },
                            L && P.createElement(C.Ay, null),
                            P.createElement(
                              "div",
                              {
                                className: N().title,
                              },
                              V ? U.t("Introducing Templates") : ""
                            ),
                            P.createElement(
                              "div",
                              {
                                className: N().subtitle,
                                id: "templates-welcome-banner-desc",
                              },
                              V
                                ? U.t(
                                    "A new way to kickstart any project, process or problem."
                                  )
                                : U.t("Tools you need to get the job started")
                            )
                          )
                        )
                      ),
                      P.createElement(
                        m.A,
                        {
                          "aria-label": U.t("Close tip", {
                            fallbackHash:
                              "8e5cf4e323045bac6bd4071976f5f80955c0e3d1",
                            fallbackHashNs: "huddles",
                          }),
                          className: `${
                            N().close_button
                          } dt-hocus:theme-surf-pry dt-active:theme-surf-pry`,
                          onClick: j,
                          autoClogProps: Y,
                        },
                        P.createElement(l.A, {
                          name: "close",
                          size: "16",
                        })
                      )
                    )
                  )
                )
              : null;
          }, "SolutionsWelcomeSidebarBanner");
        z.displayName = "SolutionsWelcomeSidebarBanner";
        const Z = z;
      },
      8317025457: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => C,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4481313819),
          s = e(5519146941),
          I = e(174977074),
          v = e(6084388622),
          T = e(6105929840),
          u = e(8683010724),
          h = e(1224315998),
          D = e(735940183),
          n = e(2938177083),
          m = e(6259241484),
          l = e(3193155968),
          f = e(2375333597),
          k = e(6038992701),
          E = e(7094978947),
          r = e(7263142004),
          i = e.n(r);
        const a = new D.Ay("promotions"),
          _ = "sidebar_menu_header_slack_ai_cta",
          o = {
            elementName: "target_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          d = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          A = c((M) => {
            let {
              availableAddonId: y,
              availableAddonTerm: x,
              availableAddonUpfrontUnitCost: N,
              bauCount: U,
              canUserPurchase: p,
              availableAddonCurrency: Y,
            } = M;
            const z = (0, O.wA)(),
              { activeTab: Z } = (0, t.useContext)(s.A);
            (0, I.A)(m.ze.SLACK_AI_SIDEBAR_PURCHASE_CTA);
            const w = (0, t.useCallback)(() => {
                z(
                  (0, n.A)({
                    spaceName: m.xu.SIDEBAR_MENU_HEADER,
                    action: m.hw.DISMISS,
                  })
                );
              }, [z]),
              V = (0, t.useCallback)(() => {
                z(
                  (0, f.q)({
                    element: t.createElement(k.P, {
                      activeMembersCount: U,
                      availableAddonTerm: x,
                      availableAddonUpfrontUnitCost: N,
                      currency: Y,
                      checkoutEntryPoint: _,
                      addonId: y,
                      canUserPurchase: p,
                    }),
                  })
                );
              }, [z, U, x, N, Y, y, p]);
            return Z === l.k6.Home
              ? t.createElement(
                  P.A,
                  {
                    eventId: h.EventId.UPGRDEXP_SLACK_AI,
                    uiComponentName:
                      h.UiComponentName.SLACK_AI_SIDEBAR_PURCHASE_CTA,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: i().slackAiSidebarPurchaseCta,
                    },
                    t.createElement(
                      v.jV,
                      {
                        onClick: V,
                        className: i().button,
                        autoClogProps: o,
                      },
                      t.createElement(
                        "span",
                        {
                          className: i().iconBackground,
                        },
                        t.createElement(
                          "div",
                          {
                            className: i().icon,
                          },
                          t.createElement(E.o, {
                            size: "20",
                          })
                        )
                      ),
                      t.createElement(
                        "div",
                        {
                          className: i().description,
                        },
                        t.createElement(
                          "span",
                          {
                            className: i().descriptionTitle,
                          },
                          a.t("Get Slack AI")
                        ),
                        t.createElement(
                          "span",
                          {
                            className: i().descriptionSubtitle,
                          },
                          a.t("Work smarter, not harder")
                        )
                      )
                    ),
                    t.createElement(
                      T.A,
                      {
                        "aria-label": a.t("Close"),
                        onClick: w,
                        className: i().closeButton,
                        autoClogProps: d,
                      },
                      t.createElement(u.A, {
                        name: "close",
                        size: "16",
                      })
                    )
                  )
                )
              : null;
          }, "SlackAiSidebarPurchaseCta");
        A.displayName = "SlackAiSidebarPurchaseCta";
        const C = A;
      },
      3566375448: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => d,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(2562405183),
          s = e(5602423845),
          I = e(5255740490),
          v = e(735940183),
          T = e(529182726),
          u = e(1224315998),
          h = e(4481313819),
          D = e(1104747761),
          n = e(4509434386),
          m = e(8214116048),
          l = e(3328068409),
          f = e(6084388622),
          k = e(6259241484),
          E = e(2938177083),
          r = e(9225229866),
          i = e(8683010724);
        const a = new v.Ay("promotions"),
          _ = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          o = c((A) => {
            let { experimentRemainingDays: C } = A;
            const M = (0, s.A)(),
              y = (0, O.wA)(),
              x = (0, P.d4)(D.LJ),
              N = (0, P.d4)(l.to),
              U = (0, t.useCallback)(
                (Y) => {
                  Y.stopPropagation(),
                    y(
                      (0, E.A)({
                        spaceName: k.xu.SIDEBAR_MENU_HEADER,
                        action: k.hw.DISMISS,
                      })
                    );
                },
                [y]
              ),
              p = (0, t.useCallback)(() => {
                M.track(u.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES, {
                  contexts: {
                    ui_context: {
                      action: u.UiAction.CLICK,
                      ui_component:
                        u.UiComponentName
                          .DISCOUNT_SEAT_PROMO_HALFWAY_SIDEBAR_BANNER,
                      ui_properties: {
                        element_name:
                          "discount_seat_promo_halfway_sidebar_banner",
                        element_type: u.ElementType.BUTTON,
                      },
                    },
                  },
                }),
                  y(
                    (0, T.A)({
                      source: r.K3.DiscountSeatsPromo,
                    })
                  );
              }, [y, M]);
            return x
              ? t.createElement(
                  h.A,
                  {
                    clogImpression: !0,
                    eventId: u.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES,
                    uiComponentName:
                      u.UiComponentName
                        .DISCOUNT_SEAT_PROMO_HALFWAY_SIDEBAR_BANNER,
                  },
                  t.createElement(
                    "div",
                    {
                      role: "button",
                      tabIndex: 0,
                      className: (0, I.A)(
                        "p-discount_seat_promo_halfway_sidebar_banner__container",
                        {
                          [n.Pn]: N === m.Sx.Light,
                        }
                      ),
                      onClick: p,
                      "data-qa": "discount-seat-promo-halfway-sidebar-banner",
                    },
                    t.createElement(i.A, {
                      size: "20",
                      name: "emoji-celebration",
                    }),
                    t.createElement(
                      "div",
                      null,
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-discount_seat_promo_halfway_sidebar_banner__header",
                        },
                        a.t("New members get one month free")
                      ),
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-discount_seat_promo_halfway_sidebar_banner__subtitle",
                        },
                        a.rt(
                          "{daysRemaining} {daysRemaining, plural, =1 {day} other {days}} left for this offer",
                          {
                            daysRemaining: C,
                          }
                        )
                      )
                    ),
                    t.createElement(
                      f.Nm,
                      {
                        className:
                          "p-discount_seat_promo_halfway_sidebar_banner__close_icon",
                        onClick: U,
                        "aria-label": a.t("close"),
                        "data-qa":
                          "discount-seat-promo-halfway-sidebar-banner-close-btn",
                        autoClogProps: _,
                      },
                      t.createElement(i.A, {
                        size: "20",
                        name: "close",
                      })
                    )
                  )
                )
              : null;
          }, "DiscountSeatPromoHalfWaySidebarBanner");
        o.displayName = "DiscountSeatPromoHalfWaySidebarBanner";
        const d = o;
      },
      3540014338: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseTrialSidebarLinkForHeader: () => C,
            default: () => y,
          });
        var t = e(5824283093),
          O = e(2562405183),
          P = e(6122756707),
          s = e(5255740490),
          I = e(735940183),
          v = e(5519146941),
          T = e(3193155968),
          u = e(716227588),
          h = e(7715417323),
          D = e(1224315998),
          n = e(1655938719),
          m = e(8871937520),
          l = e(2938177083),
          f = e(6259241484),
          k = e(4481313819),
          E = e(1610251172),
          r = e(561803758),
          i = e(2525419272),
          a = e(6084388622),
          _ = e(2612353366),
          o = e(4469810895),
          d = e(2802517438);
        const A = new I.Ay("paid_onboarding"),
          C = c((x) => {
            let {
              trialExpirationDate: N,
              isAdmin: U,
              loadSidebarMenuMegaphoneNotification: p,
              paidBenefitsHandler: Y,
            } = x;
            const z = (0, m.qe)(N) || 0,
              Z = (0, O.d4)(o.dC),
              { getSiblingView: w, shouldUseNavigate: V } = (0, t.useContext)(
                v.A
              ),
              L = (0, P.wA)(),
              J = {
                elementType: D.ElementType.X,
                elementName: "close_sidebar_benefits",
                action: D.UiAction.CLOSE,
                onClick: {
                  enableClogAction: !0,
                },
              },
              se = (0, t.useCallback)(
                function (ve) {
                  let oe =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : h.A;
                  ve == null || ve.stopPropagation(),
                    L(
                      (0, l.A)({
                        spaceName: f.xu.SIDEBAR_MENU_HEADER,
                        action: f.hw.DISMISS,
                      })
                    ).then(oe);
                },
                [L]
              ),
              j = c(function () {
                let { className: ve, onDismissCallback: oe } =
                  arguments.length > 0 && arguments[0] !== void 0
                    ? arguments[0]
                    : {};
                const H = (0, s.A)(
                  ve,
                  "p-channel_sidebar__close_container",
                  "p-ia4_sidebar_header__icon_close"
                );
                return t.createElement(
                  a.Nm,
                  {
                    onClick: (X) => {
                      se(X, oe);
                    },
                    className: H,
                    tabIndex: -1,
                    "aria-hidden": !0,
                    "data-qa": "golden-gate-dismiss-cta",
                    autoClogProps: J,
                  },
                  t.createElement(E.A, {
                    type: "times",
                  })
                );
              }, "renderCloseButton");
            j.displayName = "renderCloseButton";
            const G = (0, s.A)("p-sidebar_link__icon", {
                "p-sidebar_link__icon--bold": Z,
              }),
              te = c(() => {
                const ve = (z / 14) * 100,
                  oe = (0, s.A)(
                    G,
                    "p-sidebar_link__icon--progress",
                    "flex_shrink_none"
                  );
                return t.createElement(i.A, {
                  containerClassName: oe,
                  containerSizeInPixels: 22,
                  progressBarWidthInPixels: 2,
                  progressPercentage: ve,
                  progressBarColor: "rgb(255, 255, 255)",
                  progressBarBackgroundColor: "rgb(255, 255, 255)",
                  progressBarBackgroundColorAlpha: 0.2,
                  progressBarLabel: `${z}`,
                });
              }, "renderDaysRemainingIcon");
            te.displayName = "renderDaysRemainingIcon";
            let me = "",
              Re = null,
              Se = "";
            z === 1
              ? ((Re = t.createElement(E.A, {
                  type: "exclamation-circle",
                  className: G,
                })),
                (me = A.t("Free trial ends today")))
              : z === 2
              ? ((Re = te()), (me = A.t("Free trial ending soon")))
              : ((me = A.t("Free trial in progress")),
                z < 14
                  ? ((Re = te()),
                    (Se = `${me} ${A.t(
                      "You have {trialDaysRemaining, plural, =1 {# day} other {# days}} remaining",
                      {
                        trialDaysRemaining: z,
                      }
                    )}`))
                  : (Re = t.createElement(E.A, {
                      type: "hourglass",
                      className: G,
                    })));
            const Te = t.createElement(
                t.Fragment,
                null,
                Re,
                t.createElement(r.A, {
                  displayName: me,
                  qaChannelName: me,
                  ariaLabel: Se,
                })
              ),
              xe =
                (0, O.d4)((ve) => {
                  var oe;
                  return V
                    ? (oe = w(ve, {
                        container: T.mq.Primary,
                      })) === null || oe === void 0
                      ? void 0
                      : oe.id
                    : (0, d.A)(ve);
                }) === "Ppaid-benefits";
            return t.createElement(
              k.A,
              {
                clogImpression: !0,
              },
              t.createElement(
                "div",
                {
                  className: (0, s.A)("p-ia4_sidebar_header__link_wrapper", {
                    "p-channel_sidebar__link--selected": xe,
                  }),
                },
                t.createElement(
                  a.Nm,
                  {
                    className: "p-ia4_sidebar_header__link_btn",
                    onClick: Y,
                  },
                  Te
                ),
                !U &&
                  j({
                    onDismissCallback: p,
                  })
              )
            );
          }, "TrialSidebarLinkForHeader");
        C.displayName = "TrialSidebarLinkForHeader";
        const M = c(() => {
          const x = (0, P.wA)(),
            { trialExpirationDate: N, isAdmin: U } = (0, O.d4)(u.Ak),
            p = (0, t.useCallback)(() => {
              x(
                (0, n.iR)({
                  event: {
                    type: f.jo.REQUEST_SPACES,
                    spaces: [f.xu.SIDEBAR_MENU_HEADER],
                  },
                })
              );
            }, [x]),
            Y = (0, t.useCallback)(() => {
              x((0, _.A)());
            }, [x]);
          return t.createElement(C, {
            trialExpirationDate: N,
            isAdmin: U,
            loadSidebarMenuMegaphoneNotification: p,
            paidBenefitsHandler: Y,
          });
        }, "ConnectedTrialSidebarLinkForHeader");
        M.displayName = "ConnectedTrialSidebarLinkForHeader";
        const y = M;
      },
      6962982910: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            PNPSidebarBadgeBanner: () => ve,
          });
        var t = e(5824283093),
          O = e(6449156268),
          P = e(3801841745),
          s = e(735940183),
          I = e(5255740490),
          v = e(4481313819),
          T = e(5946832122),
          u = e(6862327721),
          h = e(3506776591),
          D = e.n(h),
          n = e(8790440477),
          m = e.n(n),
          l = e(5519146941),
          f = e(3193155968),
          k = e(6122756707),
          E = e(8683010724),
          r = e(6084388622),
          i = e(6323355797),
          a = e(3677514771),
          _ = e(2562405183),
          o = e(8951118047),
          d = e(8004193929),
          A = e.n(d);
        const C = {
          elementName: "pnp_sidebar_banner_badge_cta",
          onClick: {
            enableClogAction: !0,
          },
        };
        function M(oe) {
          let {
            canUserPurchase: H,
            buttonText: X,
            className: pe,
            articleId: ee,
            daysRemaining: ze,
          } = oe;
          const we = (0, _.d4)(a.H7),
            Ue = (0, t.useMemo)(
              () =>
                (0, i.Qn)({
                  team: we,
                  entryPoint: "pnp_sidebar_badge",
                  productLevel: i.i6.standard.id,
                }),
              [we]
            );
          return H
            ? t.createElement(
                r.jV,
                {
                  autoClogProps: C,
                  className: `${A().cta} ${pe}`,
                  href: Ue,
                },
                t.createElement(E.A, {
                  name: "rocket",
                  size: "20",
                }),
                t.createElement(
                  "span",
                  {
                    className: A().cta_text,
                  },
                  X
                )
              )
            : t.createElement(
                o.A,
                {
                  articleId: ee,
                  className: `${A().cta} ${pe}`,
                },
                t.createElement(
                  r.Nm,
                  {
                    autoClogProps: C,
                    className:
                      "display_flex align_items_center justify_content_center",
                  },
                  ze > 3 &&
                    t.createElement(E.A, {
                      name: "info",
                      size: "20",
                    }),
                  t.createElement(
                    "span",
                    {
                      className: A().cta_text,
                    },
                    X
                  )
                )
              );
        }
        c(M, "PNPSidebarBadge"), (M.displayName = "PNPSidebarBadge");
        var y = e(3810478625),
          x = e(5597384299),
          N = e(2825630827),
          U = e(7239742441);
        const p = new s.Ay("pnp_notifications"),
          Y = c(
            (oe, H, X, pe, ee) =>
              oe
                ? X === 1
                  ? pe
                    ? ee && ee > 25
                      ? p.rt(
                          "<strong>Last day to upgrade and preserve {messageCount} messages and files.</strong>",
                          {
                            messageCount: (0, U.$k)(ee),
                            formattedDate: H,
                          }
                        )
                      : p.rt(
                          "<strong>Last day to upgrade and preserve message and file history.</strong>"
                        )
                    : ee && ee > 25
                    ? p.rt(
                        "<strong>Last day to preserve {messageCount} messages and files.</strong> Contact an admin to upgrade.",
                        {
                          messageCount: (0, U.$k)(ee),
                          formattedDate: H,
                        }
                      )
                    : p.rt(
                        "<strong>Last day to preserve message and file history.</strong> Contact an admin to upgrade."
                      )
                  : pe
                  ? ee && ee > 25
                    ? p.rt(
                        "<strong>Upgrade to preserve {messageCount} messages and files</strong> before plans change on {formattedDate}.",
                        {
                          messageCount: (0, U.$k)(ee),
                          formattedDate: H,
                        }
                      )
                    : p.rt(
                        "<strong>Upgrade to preserve message and file history</strong> before plans change on {formattedDate}.",
                        {
                          formattedDate: H,
                        }
                      )
                  : ee && ee > 25
                  ? p.rt(
                      "<strong>Preserve {messageCount} messages and files</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        messageCount: (0, U.$k)(ee),
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>Preserve message and file history</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    )
                : "",
            "getDataDeletionAlertBannerContent"
          ),
          z = c((oe, H, X, pe) => {
            if (!oe) return "";
            switch (pe) {
              case N.d.NO_IMPACT:
                return X > 7
                  ? p.rt(
                      "<strong>Changes are coming to the free version of Slack</strong> starting on {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days until plans change</strong> on {formattedDate}.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              case N.d.DATA_DELETION:
                return X > 7
                  ? p.rt(
                      "<strong>Preserve your message and file history</strong> before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days until content</strong> older than a year is permanently deleted.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              case N.d.PRICING_AND_PACKAGING:
                return X > 7
                  ? p.rt(
                      "<strong>Preserve access to features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days until plans change.</strong> Upgrade to preserve access to some features.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              case N.d.DELETION_AND_PNP:
                return X > 7
                  ? p.rt(
                      "<strong>Preserve your content and features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days until plans change.</strong> Upgrade to preserve content and features you use.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              default:
                return "";
            }
          }, "getSidebarNonPurchaserDescription"),
          Z = c((oe, H, X, pe, ee) => {
            if (!oe) return "";
            if (!ee) return z(oe, H, X, pe);
            switch (pe) {
              case N.d.NO_IMPACT:
                return X > 7
                  ? p.rt(
                      "<strong>Offer available until {formattedDate}</strong> when plans change.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Plans change on {formattedDate}.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              case N.d.DATA_DELETION:
                return X > 7
                  ? p.rt(
                      "<strong>Preserve your message and file history.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Upgrade to preserve your content.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              case N.d.PRICING_AND_PACKAGING:
                return X > 7
                  ? p.rt(
                      "<strong>Preserve access to features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Upgrade to preserve access to some features.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              case N.d.DELETION_AND_PNP:
                return X > 7
                  ? p.rt(
                      "<strong>Preserve your content and features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : p.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Upgrade to preserve content and features you use.",
                      {
                        formattedDate: H,
                        daysRemaining: X,
                      }
                    );
              default:
                return "";
            }
          }, "getSidebarDescription"),
          w = c((oe, H, X, pe) => {
            if (!oe) return "";
            const ee = pe === N.d.DATA_DELETION;
            return X <= 3
              ? ""
              : X <= 7 && X > 3
              ? ee
                ? p.t("{daysRemaining} days until content will be deleted", {
                    daysRemaining: X,
                  })
                : p.t("{daysRemaining} days until plans change", {
                    daysRemaining: X,
                  })
              : ee
              ? p.t("Content will be deleted on {formattedDate}", {
                  formattedDate: H,
                })
              : p.t("Plans change on {formattedDate}", {
                  formattedDate: H,
                });
          }, "getNonPurchaserPersistentSubText"),
          V = c(
            (oe, H, X, pe, ee) =>
              oe
                ? pe
                  ? X === 1
                    ? p.t("Last day to claim offer")
                    : X <= 7
                    ? p.t("{daysRemaining} days left", {
                        daysRemaining: X,
                      })
                    : p.t("Offer available through {formattedDate}", {
                        formattedDate: H,
                      })
                  : w(oe, H, X, ee)
                : "",
            "getPresistentSubText"
          ),
          L = c((oe, H, X, pe, ee) => {
            if (!oe) return "";
            switch (pe) {
              case N.d.NO_IMPACT:
                return X === 1
                  ? p.rt(
                      "<strong>Last day before your plan changes.</strong> Contact an admin to upgrade."
                    )
                  : p.rt(
                      "<strong>Changes to your plan start on {formattedDate}.</strong> Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    );
              case N.d.DATA_DELETION:
                return Y(oe, H, X, !1, ee);
              case N.d.PRICING_AND_PACKAGING:
                return X === 1
                  ? p.rt(
                      "<strong>Last day to preserve features you use.</strong> Contact an admin to upgrade."
                    )
                  : p.rt(
                      "<strong>Preserve features you use</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    );
              case N.d.DELETION_AND_PNP:
                return X === 1
                  ? p.rt(
                      "<strong>Last day to preserve your content and features you use.</strong> Contact an admin to upgrade."
                    )
                  : p.rt(
                      "<strong>Preserve your content and features you use</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    );
              default:
                return "";
            }
          }, "getNonPurchaserAlertBannerText"),
          J = c((oe, H, X, pe, ee, ze) => {
            if (!oe) return "";
            if (!ee) return L(oe, H, X, pe, ze);
            switch (pe) {
              case N.d.NO_IMPACT:
                return X === 1
                  ? p.rt("<strong>Last day before your plan changes</strong>")
                  : p.rt(
                      "<strong>Changes to your plan start on {formattedDate}</strong>",
                      {
                        formattedDate: H,
                      }
                    );
              case N.d.DATA_DELETION:
                return Y(oe, H, X, ee, ze);
              case N.d.PRICING_AND_PACKAGING:
                return X === 1
                  ? p.rt(
                      "<strong>Last day to upgrade and preserve features you use.</strong>"
                    )
                  : p.rt(
                      "<strong>Upgrade and preserve features you use</strong> before plans change on {formattedDate}",
                      {
                        formattedDate: H,
                      }
                    );
              case N.d.DELETION_AND_PNP:
                return X === 1
                  ? p.rt(
                      "<strong>Last day to upgrade and preserve your content and features you use.</strong>"
                    )
                  : p.rt(
                      "<strong>Upgrade to preserve your content and features you use</strong> before plans change on {formattedDate}",
                      {
                        formattedDate: H,
                      }
                    );
              default:
                return "";
            }
          }, "getAlertBannerText");
        var se = e(7003004874),
          j = e(6259241484),
          G = e(1224315998),
          te = e(8214116048),
          me = e(4509434386),
          Re = e(3328068409),
          Se = e(1655938719);
        const Te = new s.Ay("pnp_notifications"),
          $e = {
            elementName: "pnp_sidebar_banner_badge_close_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          xe = {
            elementName: "pnp_sidebar_banner_badge_compareplans_cta",
            onClick: {
              enableClogAction: !0,
            },
          };
        function ve(oe) {
          let {
            canUserPurchase: H,
            date: X,
            variant: pe,
            daysRemaining: ee,
            collapseState: ze,
            messageCount: we,
          } = oe;
          const [Ue, He] = (0, t.useState)(ze === "collapsed"),
            Xe = (0, k.wA)(),
            Be = (0, _.d4)(y.g),
            qe = (0, _.d4)(Re.to),
            { activeTab: ct } = (0, t.useContext)(l.A),
            It = ct === f.k6.Home;
          (0, t.useEffect)(() => {
            He(ze === "collapsed");
          }, [ze]);
          const st = (0, t.useMemo)(
              () =>
                X
                  ? (0, x.Yq)((0, O.A)(X, "YYYY/MM/DD").unix(), "{date_num}", {
                      customFormat: "MMM Do",
                    })
                  : "",
              [X]
            ),
            Mt = (0, t.useMemo)(
              () =>
                t.createElement("img", {
                  alt: Be ? Te.t("P&Psidebar banner hourglass image") : "",
                  src: m(),
                }),
              [Be]
            ),
            _t = (0, t.useMemo)(
              () =>
                t.createElement("img", {
                  alt: Be ? Te.t("P&Psidebar banner bell image") : "",
                  src: D(),
                }),
              [Be]
            ),
            q = (0, t.useCallback)(() => {
              let Et = Be ? Te.t("Get 75% off Slack Pro") : "";
              H ||
                ((Et = Be ? Te.t("About the new Slack plans") : ""),
                pe === N.d.DATA_DELETION &&
                  (Et = Be ? Te.t("About changes to storage") : ""));
              const Kt =
                pe === N.d.DATA_DELETION ? 29414264463635 : 30915393948051;
              return t.createElement(
                v.A,
                {
                  eventId: G.EventId.UPGRDEXP_PNP_NOTIFICATION,
                  uiComponentName: G.UiComponentName.PNP_SIDEBAR_UPGRADE_BUTTON,
                  uiStep: Ue ? G.UiStep.COLLAPSED : G.UiStep.EXPANDED,
                  uiComponentVariant: H
                    ? G.UiComponentVariant.PURCHASER
                    : G.UiComponentVariant.NON_PURCHASER,
                  clogImpression: !0,
                },
                t.createElement(M, {
                  className: Ue
                    ? (0, I.A)(A().persistantCTA, {
                        [me.A7]: qe === te.Sx.Light,
                      })
                    : "",
                  daysRemaining: ee,
                  canUserPurchase: H,
                  buttonText: Et,
                  articleId: Kt,
                })
              );
            }, [H, qe, ee, Be, Ue, pe]),
            ot = (0, t.useCallback)(() => {
              He(!0),
                Xe(
                  (0, se.A)({
                    notificationName: j.ze.PNP_SIDEBAR,
                    action: j.hw.CLICK,
                  })
                );
            }, [Xe]),
            At = (0, t.useCallback)(() => {
              Xe(
                (0, u.A)({
                  from: N.o.PNP_SIDEBAR_BADGE,
                  canUserPurchase: H,
                })
              );
            }, [H, Xe]),
            Ct = (0, t.useCallback)(() => {
              He(!0),
                Xe(
                  (0, se.A)({
                    notificationName: j.ze.PNP_SIDEBAR,
                    action: j.hw.CLICK,
                    step: "collapse",
                  })
                ).then(() => {
                  Xe(
                    (0, Se.iR)({
                      event: {
                        type: j.jo.REQUEST_SPACES,
                        spaces: [j.xu.SIDEBAR_MENU_HEADER],
                      },
                    })
                  );
                });
            }, [Xe]),
            nt = (0, t.useCallback)(() => {
              let Et = t.createElement(
                "div",
                {
                  className: A().subtext,
                },
                V(Be, st, ee, H, pe)
              );
              return (
                !Ue &&
                  ee &&
                  ee > 7 &&
                  (Et = t.createElement(
                    r.Nm,
                    {
                      autoClogProps: xe,
                      "data-qa": "pnp_sidebar_compare_plans_cta",
                      className: A().subtext,
                      onClick: At,
                    },
                    Be ? Te.t("Compare new plans") : ""
                  )),
                !H && !Ue ? null : Et
              );
            }, [H, ee, Be, st, Ue, At, pe]),
            Nt = (0, t.useCallback)(
              () =>
                !H && Ue
                  ? null
                  : ee && ee <= 3
                  ? t.createElement(
                      P.A,
                      {
                        className: (0, I.A)(A().alert, {
                          [me.A7]: qe === te.Sx.Light,
                        }),
                        gap: 8,
                      },
                      t.createElement(E.A, {
                        name: "warning",
                        size: "20",
                      }),
                      t.createElement("span", null, J(Be, st, ee, pe, H, we)),
                      !H &&
                        t.createElement(
                          T.A,
                          {
                            "aria-label": Be ? Te.t("close") : "",
                            onClick: ot,
                            className: A().alertCloseIcon,
                          },
                          t.createElement(E.A, {
                            name: "close",
                            size: "16",
                          })
                        )
                    )
                  : null,
              [Ue, ee, qe, Be, st, pe, H, we, ot]
            );
          return It
            ? Ue || (ee && ee <= 3)
              ? t.createElement(
                  P.A,
                  {
                    className: A().persistentContainer,
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 8,
                  },
                  Nt(),
                  t.createElement(
                    P.A,
                    {
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 8,
                      className: "full_width",
                    },
                    q(),
                    " ",
                    nt()
                  )
                )
              : t.createElement(
                  "div",
                  {
                    className: (0, I.A)(A().container, {
                      [me.A7]: qe === te.Sx.Light,
                    }),
                  },
                  t.createElement(
                    P.A,
                    {
                      flexDirection: "column",
                      gap: 4,
                      alignItems: "center",
                    },
                    t.createElement(
                      P.A,
                      {
                        gap: 8,
                        alignItems: "flex-start",
                        alignSelf: "flex-start",
                        justifyContent: "space-between",
                        className: A().innerContainer,
                      },
                      t.createElement(
                        "div",
                        {
                          className: A().expanded_text,
                        },
                        Z(Be, st, ee, pe, H)
                      ),
                      ee <= 7 ? Mt : _t,
                      t.createElement(
                        r.Nm,
                        {
                          autoClogProps: $e,
                          "data-qa": "pnp-sidebar-close-btn",
                          className: A().closeButton,
                          onClick: Ct,
                        },
                        t.createElement(E.A, {
                          name: "close",
                        })
                      )
                    ),
                    q(),
                    nt()
                  )
                )
            : null;
        }
        c(ve, "PNPSidebarBadgeBanner"),
          (ve.displayName = "PNPSidebarBadgeBanner");
      },
      2994893019: (W, g, e) => {
        "use strict";
        e.d(g, {
          M: () => v,
        });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(6084388622),
          s = e(8683010724);
        function I() {
          return (
            (I =
              Object.assign ||
              function (T) {
                for (var u = 1; u < arguments.length; u++) {
                  var h = arguments[u];
                  for (var D in h)
                    Object.prototype.hasOwnProperty.call(h, D) && (T[D] = h[D]);
                }
                return T;
              }),
            I.apply(this, arguments)
          );
        }
        c(I, "_extends");
        const v = c((T) => {
          let {
            isTrialFirstDay: u,
            isTrialLastDay: h,
            trialDaysRemaining: D,
            isSelected: n,
            showWrapper: m,
            autoClogProps: l,
            onClick: f,
            buttonText: k,
            svgIconProps: E,
            href: r,
            experimentFeatReverseTrialGroupTreatment: i,
          } = T;
          const a = c(() => {
            if (E) return t.createElement(s.A, I({}, E));
            let d = null;
            return (
              D > 2 && D <= 30
                ? (d = t.createElement(s.A, {
                    size: "20",
                    name: "hourglass",
                  }))
                : D === 2 &&
                  (d = t.createElement(s.A, {
                    size: "20",
                    name: i ? "warning" : "info",
                    variation: "filled",
                  })),
              d
            );
          }, "renderStartIcon");
          a.displayName = "renderStartIcon";
          const _ = (0, O.A)("p-sidebar_trial_badge__button", {
              "p-sidebar_trial_badge__button_generic": !h && !n,
              "p-sidebar_trial_badge__button_last_day": h && !n,
              "p-sidebar_trial_badge__button_first_day": u && m && !n,
              "p-sidebar_trial_badge__button_generic_selected": !m && n,
              "p-sidebar_trial_badge__button_with_wrapper_selected": m && n,
              "p-sidebar_trial_badge__button_with_wrapper_selected_border":
                m && n && h,
            }),
            o = t.createElement(
              t.Fragment,
              null,
              a(),
              t.createElement(
                "div",
                {
                  className: "p-sidebar_trial_badge__button_text_container",
                },
                k
              ),
              t.createElement(
                "span",
                null,
                t.createElement(s.A, {
                  size: "24",
                  name: "caret-right",
                })
              )
            );
          return r
            ? t.createElement(
                "span",
                {
                  className: "p-sidebar_trial_badge__link_wrapper",
                },
                t.createElement(
                  P.jV,
                  {
                    className: _,
                    "data-qa": "sidebar-trial-badge-btn",
                    autoClogProps: l,
                    href: r,
                  },
                  o
                )
              )
            : t.createElement(
                P.Nm,
                {
                  className: _,
                  "data-qa": "sidebar-trial-badge-btn",
                  autoClogProps: l,
                  onClick: f,
                },
                o
              );
        }, "SidebarBadge");
        v.displayName = "SidebarBadge";
      },
      3998269055: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            SlackAITrialAwarenessSidebarBadge: () => Te,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4481313819),
          s = e(4502904940),
          I = e(7094978947),
          v = e(2994893019),
          T = e(9706240641),
          u = e(8815100550),
          h = e(2603617615),
          D = e(9901906329),
          n = e(7053877048),
          m = e(267465465),
          l = e(8719380546),
          f = e(9240394198),
          k = e(3801841745),
          E = e(1495538422),
          r = e(6084388622),
          i = e(2755566931),
          a = e(1224315998),
          _ = e(735940183),
          o = e(1655938719),
          d = e(6259241484),
          A = e(9003400431),
          C = e(5060694341);
        const M = {
            onClick: {
              enableClogAction: !0,
            },
            elementName: s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_TOUR,
            uiStep: "non_purchaser",
            isPrimaryCTA: !0,
          },
          y = new _.Ay("assistant"),
          x = c(($e) => {
            let { numDaysLeft: xe } = $e;
            const ve = (0, O.wA)(),
              oe = (0, t.useCallback)(() => {
                ve((0, A.O)());
              }, [ve]),
              H = (0, t.useCallback)(
                (0, T.coroutine)(function* () {
                  yield ve(
                    (0, E.K)({
                      reason: "requesting-a-purchase",
                      featRequestCode: "slack_ai_trial_purchase",
                    })
                  )
                    .then(() => {
                      ve(
                        (0, C.M)({
                          element: t.createElement(
                            i.Ay,
                            {
                              svgIconProps: {
                                name: "paper-plane",
                              },
                            },
                            t.createElement("span", null, y.t("Request sent"))
                          ),
                        })
                      );
                    })
                    .catch(() => {
                      ve(
                        (0, C.M)({
                          element: t.createElement(
                            i.Ay,
                            {
                              svgIconProps: {
                                name: "warning",
                              },
                            },
                            t.createElement(
                              "span",
                              null,
                              t.createElement(
                                "span",
                                null,
                                y.t("Something went wrong")
                              )
                            )
                          ),
                        })
                      );
                    })
                    .finally(() => {
                      ve(
                        (0, o.iR)({
                          event: {
                            type: d.jo.REQUEST_SPACES,
                            spaces: [d.xu.SIDEBAR_MENU_HEADER],
                          },
                        })
                      ),
                        oe();
                    });
                }),
                [ve, oe]
              ),
              X = c((He) => {
                let { text: Xe } = He;
                return t.createElement(n.y, null, Xe);
              }, "renderGradient"),
              pe = y.rt(
                "{numDaysLeft, plural, =1 {# day} other {# days}} left in your <gradient>Slack AI</gradient> trial",
                {
                  numDaysLeft: xe,
                  "<gradient>": X,
                }
              ),
              ee = y.rt(
                "Preserve access to time-saving features by requesting to keep Slack AI."
              ),
              ze = (0, t.useCallback)(
                () =>
                  t.createElement(
                    k.A,
                    {
                      flexDirection: "column",
                      gap: 24,
                    },
                    t.createElement(D.E, null),
                    t.createElement(
                      "span",
                      null,
                      y.t(
                        "Enjoying Slack AI? We\u2019ll send a note to people on your team with permission to purchase."
                      )
                    )
                  ),
                []
              ),
              we = c(
                () =>
                  t.createElement(
                    k.A,
                    {
                      flexDirection: "column",
                      gap: 28,
                    },
                    t.createElement(
                      k.A,
                      {
                        flexDirection: "column",
                        gap: 12,
                      },
                      t.createElement(
                        r.$n,
                        {
                          onClick: H,
                          type: "primary",
                          size: "medium",
                          autoFocus: !0,
                          autoClogProps: M,
                        },
                        y.t("Request to Keep Slack AI")
                      )
                    )
                  ),
                "renderFooterContent"
              );
            we.displayName = "renderFooterContent";
            const Ue = (0, t.useMemo)(() => t.createElement(u.H, null), []);
            return t.createElement(
              P.A,
              {
                clogImpression: !0,
                eventId: a.EventId.UPGRDEXP_SLACK_AI,
                uiComponentName:
                  a.UiComponentName.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MODAL,
                uiComponentVariant: a.UiComponentVariant.NON_PURCHASER,
              },
              t.createElement(l.A, {
                closeButtonTheme: f.N.GRAY,
                bodyContent: ze(),
                footerContent: we(),
                showProBadge: !1,
                hero: Ue,
                onRequestClose: oe,
                title: pe,
                subtitle: ee,
                type: m.H.HORIZONTAL_BANNER,
                maxWidth: h.D,
              })
            );
          }, "NonPurchaserModal");
        x.displayName = "NonPurchaserModal";
        var N = e(8453174784),
          U = e(5519146941),
          p = e(8683010724),
          Y = e(6323355797),
          z = e(2562405183),
          Z = e(7003004874),
          w = e(2375333597),
          V = e(3677514771),
          L = e(3193155968),
          J = e(2455200396),
          se = e.n(J),
          j = e(5504232338),
          G = e.n(j);
        function te() {
          return (
            (te =
              Object.assign ||
              function ($e) {
                for (var xe = 1; xe < arguments.length; xe++) {
                  var ve = arguments[xe];
                  for (var oe in ve)
                    Object.prototype.hasOwnProperty.call(ve, oe) &&
                      ($e[oe] = ve[oe]);
                }
                return $e;
              }),
            te.apply(this, arguments)
          );
        }
        c(te, "_extends");
        const me = new _.Ay("assistant"),
          Re = {
            elementName: s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_SIDEBAR_BADGE,
            onClick: {
              enableClogAction: !0,
            },
          },
          Se = {
            elementName:
              s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_SIDEBAR_BADGE_CLOSE_BTN,
            onClick: {
              enableClogAction: !0,
            },
          },
          Te = c(($e) => {
            let {
              numDaysLeft: xe,
              collapseState: ve,
              collapsible: oe,
              canUserPurchase: H,
              addonId: X,
              availableAddonTerm: pe,
              availableAddonUpfrontUnitCost: ee,
              availableAddonCurrency: ze,
            } = $e;
            const [we, Ue] = (0, t.useState)(ve === "collapsed"),
              He = (0, O.wA)(),
              Xe = (0, z.d4)(V.H7),
              { activeTab: Be } = (0, t.useContext)(U.A),
              qe = Be === L.k6.Home,
              ct = xe <= 1 && H;
            (0, t.useEffect)(() => {
              Ue(ve === "collapsed");
            }, [ve]);
            const It = c(
                () =>
                  H
                    ? ct
                      ? me.rt("It\u2019s the last day of your Slack AI trial")
                      : me.rt("Save time with Slack AI")
                    : me.rt("There\u2019s still time to try Slack AI"),
                "getExpandedText"
              ),
              st = (0, t.useCallback)(() => {
                He(
                  H
                    ? (0, w.q)({
                        element: t.createElement(N.R, {
                          addonId: X,
                          availableAddonTerm: pe,
                          availableAddonUpfrontUnitCost: ee,
                          availableAddonCurrency: ze,
                          entryPoint:
                            d.ze.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER,
                        }),
                      })
                    : (0, w.q)({
                        element: t.createElement(x, {
                          numDaysLeft: xe,
                        }),
                      })
                );
              }, [X, ze, pe, ee, H, He, xe]),
              Mt = (0, t.useCallback)(() => {
                Ue(!0),
                  He(
                    (0, Z.A)({
                      notificationName:
                        d.ze.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER,
                      action: d.hw.CLICK,
                      step: "collapse",
                    })
                  ).then(() => {
                    He(
                      (0, o.iR)({
                        event: {
                          type: d.jo.REQUEST_SPACES,
                          spaces: [d.xu.SIDEBAR_MENU_HEADER],
                        },
                      })
                    );
                  });
              }, [He]),
              _t = (0, I.T)({
                type: "sparkles",
                variation: "filled",
              }),
              q = (0, t.useMemo)(() => {
                let ot = "";
                if (!H) ot = me.rt("Request to keep");
                else if (ct) ot = me.rt("Purchase Slack AI");
                else {
                  let Ct = xe;
                  Ct === 0 && (Ct = 1),
                    (ot = me.rt(
                      "{usefulNumDaysLeft} {usefulNumDaysLeft, plural, =1 {day} other {days}} left in trial",
                      {
                        usefulNumDaysLeft: Ct,
                      }
                    ));
                }
                let At = {
                  isTrialFirstDay: !1,
                  isTrialLastDay: !1,
                  trialDaysRemaining: xe,
                  isSelected: !1,
                  showWrapper: !1,
                  autoClogProps: Re,
                  onClick: st,
                  buttonText: ot,
                  svgIconProps: _t,
                };
                if (ct) {
                  const { onClick: Ct, ...nt } = At;
                  At = {
                    href: (0, Y.Qn)({
                      team: Xe,
                      entryPoint:
                        s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_SIDEBAR_BADGE,
                      addon: X,
                    }),
                    ...nt,
                  };
                }
                return t.createElement(
                  P.A,
                  {
                    eventId: a.EventId.UPGRDEXP_SLACK_AI,
                    uiComponentName:
                      a.UiComponentName
                        .SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER,
                    uiStep: we ? a.UiStep.COLLAPSED : a.UiStep.EXPANDED,
                    uiComponentVariant: H
                      ? a.UiComponentVariant.PURCHASER
                      : a.UiComponentVariant.NON_PURCHASER,
                    clogImpression: !0,
                  },
                  t.createElement(v.M, te({}, At))
                );
              }, [H, ct, xe, st, _t, we, Xe, X]);
            return qe
              ? we
                ? t.createElement(
                    "div",
                    {
                      className: G().collapsedContainer,
                    },
                    q
                  )
                : t.createElement(
                    "div",
                    {
                      className: G().container,
                    },
                    t.createElement(
                      k.A,
                      {
                        flexDirection: "column",
                        gap: 4,
                      },
                      t.createElement(
                        k.A,
                        {
                          gap: 8,
                          alignItems: "center",
                          justifyContent: "space-between",
                          className: G().innerContainer,
                        },
                        t.createElement(
                          "div",
                          {
                            className: G().expandedText,
                          },
                          It()
                        ),
                        t.createElement("img", {
                          src: se(),
                          alt: me.t("Slack AI sidebar banner image"),
                          width: 64,
                        }),
                        oe &&
                          t.createElement(
                            r.Nm,
                            {
                              className: G().closeButton,
                              onClick: Mt,
                              autoClogProps: Se,
                            },
                            t.createElement(p.A, {
                              name: "close",
                            })
                          )
                      ),
                      q
                    )
                  )
              : null;
          }, "SlackAITrialAwarenessSidebarBadge");
        Te.displayName = "SlackAITrialAwarenessSidebarBadge";
      },
      9949873423: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            SlackAiSidebarTrialOfferCta: () => C,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4481313819),
          s = e(6084388622),
          I = e(6105929840),
          v = e(8683010724),
          T = e(7094978947),
          u = e(1224315998),
          h = e(3193155968),
          D = e(735940183),
          n = e(5519146941),
          m = e(7263142004),
          l = e.n(m);
        const f = new D.Ay("promotions"),
          k = t.memo((M) => {
            let {
              handleClick: y,
              title: x,
              subtitle: N,
              handleDismiss: U,
              uiComponentName: p,
              targetButtonAutoClogProps: Y,
              cancelButtonAutoClogProps: z,
              autoClogDisplayName: Z,
            } = M;
            const { activeTab: w } = (0, t.useContext)(n.A);
            return w === h.k6.Home
              ? t.createElement(
                  P.A,
                  {
                    eventId: u.EventId.UPGRDEXP_SLACK_AI,
                    uiComponentName: p,
                    displayName: Z,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: l().slackAiSidebarPurchaseCta,
                    },
                    t.createElement(
                      s.jV,
                      {
                        onClick: y,
                        className: l().button,
                        autoClogProps: Y,
                      },
                      t.createElement(
                        "span",
                        {
                          className: l().iconBackground,
                        },
                        t.createElement(
                          "div",
                          {
                            className: l().icon,
                          },
                          t.createElement(T.o, {
                            size: "20",
                          })
                        )
                      ),
                      t.createElement(
                        "div",
                        {
                          className: l().description,
                        },
                        t.createElement(
                          "span",
                          {
                            className: l().descriptionTitle,
                          },
                          x
                        ),
                        t.createElement(
                          "span",
                          {
                            className: l().descriptionSubtitle,
                          },
                          N
                        )
                      )
                    ),
                    t.createElement(
                      I.A,
                      {
                        "aria-label": f.t("Close"),
                        onClick: U,
                        className: l().closeButton,
                        autoClogProps: z,
                      },
                      t.createElement(v.A, {
                        name: "close",
                        size: "16",
                      })
                    )
                  )
                )
              : null;
          });
        var E = e(9676597566),
          r = e(7115655993),
          i = e(2562405183),
          a = e(6259241484),
          _ = e(3141349242);
        const o = new D.Ay("assistant"),
          d = {
            elementName: "try_slack_ai_for_free",
            onClick: {
              enableClogAction: !0,
            },
            isPrimaryCTA: !0,
          },
          A = {
            elementName: "dismiss",
            onClick: {
              enableClogAction: !0,
            },
          },
          C = c((M) => {
            let {
              recordAndClearNotificationEvent: y,
              offerInfo: x,
              trialInfo: N,
              notificationName: U,
            } = M;
            const p = (0, O.wA)();
            (0, r.A)(() => {
              p((0, _.Md)());
            });
            const Y = (0, t.useCallback)(() => {
                y(a.hw.DISMISS);
              }, [y]),
              z = (0, t.useCallback)(() => {
                p(
                  (0, E.G)({
                    offerInfo: x,
                    trialInfo: N,
                    notificationName: U,
                  })
                );
              }, [p, x, N, U]),
              Z = (0, i.d4)(_.Gj);
            return t.createElement(k, {
              handleClick: z,
              title: o.t("Try Slack AI for free"),
              subtitle: o.t("Get a free 14-day trial"),
              handleDismiss: Y,
              uiComponentName:
                u.UiComponentName.SLACK_AI_SIDEBAR_TRIAL_START_CTA,
              targetButtonAutoClogProps: d,
              cancelButtonAutoClogProps: A,
              autoClogDisplayName: Z,
            });
          }, "SlackAiSidebarTrialOfferCta");
        C.displayName = "SlackAiSidebarTrialOfferCta";
      },
      784529096: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            TrialEndPromoDiscountSidebarCta: () => x,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4481313819),
          s = e(3801841745),
          I = e(7878745420),
          v = e(5519146941),
          T = e(6084388622),
          u = e(8683010724),
          h = e(1224315998),
          D = e(735940183),
          n = e(6323355797),
          m = e(2562405183),
          l = e(1655938719),
          f = e(7003004874),
          k = e(6259241484),
          E = e(8871937520),
          r = e(3677514771),
          i = e(3193155968),
          a = e(2121234563),
          _ = e.n(a),
          o = e(3281979720),
          d = e.n(o);
        const A = I.g.PROMOTIONAL_DISCOUNTS_SIDEBAR_MENU_HEADER_CTA,
          C = new D.Ay("trials"),
          M = {
            elementName: "trial_end_promo_discount_sidebar_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          y = {
            elementName: "trial_end_promo_discount_sidebar_cta_close_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          x = c((N) => {
            let {
              discountPercent: U,
              collapseState: p,
              collapsible: Y,
              discountExpirationTs: z,
            } = N;
            const [Z, w] = (0, t.useState)(p === "collapsed"),
              V = (0, O.wA)(),
              L = (0, m.d4)(r.H7),
              { activeTab: J } = (0, t.useContext)(v.A),
              se = J === i.k6.Home,
              j = (0, E.Zv)((z ?? 0) * 1e3);
            (0, t.useEffect)(() => {
              w(p === "collapsed");
            }, [p]);
            const G = (0, t.useCallback)(() => {
                w(!0),
                  V(
                    (0, f.A)({
                      notificationName: A,
                      action: k.hw.CLICK,
                      step: "collapse",
                    })
                  ).then(() => {
                    V(
                      (0, l.iR)({
                        event: {
                          type: k.jo.REQUEST_SPACES,
                          spaces: [k.xu.SIDEBAR_MENU_HEADER],
                        },
                      })
                    );
                  });
              }, [V]),
              te = (0, t.useMemo)(() => {
                const me = (0, n.Qn)({
                  team: L,
                  entryPoint: "trial_end_promo_discount_sidebar_cta",
                });
                return t.createElement(
                  P.A,
                  {
                    eventId: h.EventId.UPGRDEXP_TRIAL,
                    uiComponentName: "trial_end_promo_discount_sidebar_cta",
                    uiStep: Z ? h.UiStep.COLLAPSED : h.UiStep.EXPANDED,
                    clogImpression: !0,
                  },
                  Z
                    ? t.createElement(
                        T.z9,
                        {
                          "data-qa": "plans-at-glance-upgrade-now-btn",
                          className: d().collapsedCtaButton,
                          href: me,
                          autoClogProps: M,
                          type: "outline",
                        },
                        t.createElement(u.A, {
                          name: "rocket",
                          size: "20",
                        }),
                        t.createElement(
                          "span",
                          {
                            className: d().ctaButtonText,
                          },
                          C.rt("Get {discountPercent}% off Pro", {
                            discountPercent: U,
                          })
                        )
                      )
                    : t.createElement(
                        T.jV,
                        {
                          "data-qa": "trial-end-promo-upgrade-sidebar-cta",
                          className: d().ctaButton,
                          href: me,
                          autoClogProps: M,
                        },
                        t.createElement(u.A, {
                          name: "rocket",
                          size: "20",
                        }),
                        t.createElement(
                          "span",
                          {
                            className: d().ctaButtonText,
                          },
                          C.t("Upgrade to Pro", {
                            fallbackHash:
                              "24de9364ba974a2fa4662ac82b52b83095290bbb",
                            fallbackHashNs: "trial_expiration_modals",
                          })
                        )
                      )
                );
              }, [Z, L, U]);
            return se
              ? Z
                ? t.createElement(
                    "div",
                    {
                      className: d().collapsedContainer,
                    },
                    te,
                    t.createElement(
                      "div",
                      {
                        className: d().subText,
                      },
                      C.rt(
                        "{daysRemaining, plural, =1 {# day} other {# days}} left",
                        {
                          daysRemaining: j,
                        }
                      )
                    )
                  )
                : t.createElement(
                    "div",
                    {
                      className: d().container,
                    },
                    t.createElement(
                      s.A,
                      {
                        flexDirection: "column",
                        gap: 4,
                      },
                      t.createElement(
                        s.A,
                        {
                          gap: 8,
                          alignItems: "flex-start",
                          justifyContent: "space-between",
                          className: d().innerContainer,
                        },
                        t.createElement(
                          "div",
                          null,
                          t.createElement(
                            "div",
                            {
                              className: d().expandedText,
                            },
                            C.rt("Get {discountPercent}% off Slack Pro", {
                              discountPercent: U,
                            })
                          ),
                          t.createElement(
                            "div",
                            {
                              className: d().subText,
                            },
                            C.rt(
                              "{daysRemaining, plural, =1 {# day} other {# days}} left",
                              {
                                daysRemaining: j,
                              }
                            )
                          )
                        ),
                        t.createElement(
                          "div",
                          {
                            className: d().imgContainer,
                          },
                          t.createElement("img", {
                            src: _(),
                            alt: C.t("Image of gift box"),
                          }),
                          Y &&
                            t.createElement(
                              T.Nm,
                              {
                                className: d().closeButton,
                                onClick: G,
                                autoClogProps: y,
                              },
                              t.createElement(u.A, {
                                name: "close",
                              })
                            )
                        )
                      ),
                      te
                    )
                  )
              : null;
          }, "TrialEndPromoDiscountSidebarCta");
        x.displayName = "TrialEndPromoDiscountSidebarCta";
      },
      4698264567: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => i,
          });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(4481313819),
          s = e(1267040415),
          I = e(3245843483),
          v = e(5519146941),
          T = e(8683010724),
          u = e(2312625946),
          h = e(1224315998),
          D = e(735940183),
          n = e(2562405183),
          m = e(6259241484),
          l = e(3474336343),
          f = e(3193155968);
        const k = new D.Ay("plan_change"),
          E = {
            isPrimaryCTA: !0,
            onClick: {
              enableClogAction: !0,
            },
          },
          r = c((a) => {
            const {
                ctaLabel: _,
                action: o,
                productId: d,
                notificationName: A,
              } = a,
              C = _ ?? k.t("Upgrade Plan"),
              M = A === m.ze.SIDEBAR_MENU_HEADER_UPGRADE_CTA,
              { activeTab: y, getSiblingView: x } = (0, t.useContext)(v.A),
              N = y === f.k6.Home,
              U = (0, n.d4)((p) =>
                (0, l.Li)(p, {
                  getSiblingView: x,
                })
              );
            return (0, I.Z9F)() || !N || U
              ? null
              : t.createElement(
                  P.A,
                  {
                    uiComponentName: h.UiComponentName.UPGRADE_BUTTON,
                  },
                  t.createElement(
                    s.A,
                    {
                      autoClogProps: E,
                      className: (0, O.A)("p-upgrades_button", {
                        "p-upgrades_button--themed": M,
                      }),
                      "data-qa": "upgrades-kit-upgrade-button",
                      entryPoint: "upgrade-button",
                      type: "outline",
                      "aria-label": C,
                      action: o,
                      productId: d,
                    },
                    t.createElement(
                      "div",
                      {
                        className: "p-upgrades_button__rocket",
                      },
                      t.createElement(T.A, {
                        name: "rocket",
                      })
                    ),
                    t.createElement(
                      u.Ay,
                      {
                        offsetX: -15,
                        position: "bottom",
                        delay: u.PK,
                        tip: C,
                        shouldOnlyShowWhenTruncated: !0,
                      },
                      t.createElement(
                        "div",
                        {
                          className: "p-upgrades_button__label",
                        },
                        C
                      )
                    )
                  )
                );
          }, "UpgradeButton");
        r.displayName = "UpgradeButton";
        const i = r;
      },
      6807544879: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            AutoChargeFeatureTrialsManageTrialWorkspaceMenuCta: () => l,
            default: () => k,
          });
        var t = e(5824283093),
          O = e(735940183),
          P = e(6449156268),
          s = e(2562405183),
          I = e(7878745420),
          v = e(6323355797),
          T = e(4761125736),
          u = e(3699548628),
          h = e(1030162945);
        function D() {
          return (
            (D =
              Object.assign ||
              function (E) {
                for (var r = 1; r < arguments.length; r++) {
                  var i = arguments[r];
                  for (var a in i)
                    Object.prototype.hasOwnProperty.call(i, a) && (E[a] = i[a]);
                }
                return E;
              }),
            D.apply(this, arguments)
          );
        }
        c(D, "_extends");
        const n = new O.Ay("auto_charge_feature_trials"),
          m = I.g.AUTO_CHARGE_FEATURE_TRIALS_MANAGE_TRIAL_WORKSPACE_MENU_CTA,
          l = c((E) => {
            let {
              trialEndDate: r,
              planType: i,
              experimentPaidFeatureTrialAutoChargeTranslationGroupOn: a,
              ..._
            } = E;
            const o = a ? n.t("Slack Pro") : "",
              d = (0, P.A)(r).format("LL"),
              A = (0, t.useCallback)(
                () =>
                  t.createElement(
                    "span",
                    null,
                    t.createElement(h.Ay, {
                      text: "gift",
                      className: "margin_right_25",
                      emojiSize: h.lw.SMALL,
                    }),
                    a
                      ? n.rt(
                          "Your workspace is on a free {featureTrialLength} day trial through {trialThruDate}. Your first bill starts after your trial ends.",
                          {
                            featureTrialLength: v.ew.PAID_FEATURE_TRIAL,
                            trialThruDate: d,
                          }
                        )
                      : ""
                  ),
                [d, a]
              ),
              C = (0, t.useCallback)(
                () =>
                  t.createElement(
                    "span",
                    null,
                    a
                      ? n.rt("Manage your <strong>{planName}</strong> Plan", {
                          planName: o,
                        })
                      : ""
                  ),
                [o, a]
              );
            return t.createElement(
              u.A,
              D(
                {
                  bodyText: A(),
                  ctaHref: "admin/billing",
                  preText: C(),
                },
                _
              )
            );
          }, "AutoChargeFeatureTrialsManageTrialWorkspaceMenuCta");
        l.displayName = "AutoChargeFeatureTrialsManageTrialWorkspaceMenuCta";
        const f = c((E) => {
          const r = (0, s.d4)(
            (i) =>
              (0, T._Z)(i, "paid_feature_trial_auto_charge_translation", !1) ===
              "on"
          );
          return t.createElement(
            l,
            D(
              {
                experimentPaidFeatureTrialAutoChargeTranslationGroupOn: r,
              },
              E
            )
          );
        }, "ConnectedAutoChargeFeatureTrialsManageTrialWorkspaceMenuCta");
        f.displayName =
          "ConnectedAutoChargeFeatureTrialsManageTrialWorkspaceMenuCta";
        const k = f;
      },
      858410167: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => k,
          });
        var t = e(5824283093),
          O = e(5255740490),
          P = e(6449156268),
          s = e(735940183),
          I = e(6323355797),
          v = e(8871937520),
          T = e(3699548628),
          u = e(1030162945),
          h = e(4698264567),
          D = e(4761125736),
          n = e(2562405183);
        function m() {
          return (
            (m =
              Object.assign ||
              function (E) {
                for (var r = 1; r < arguments.length; r++) {
                  var i = arguments[r];
                  for (var a in i)
                    Object.prototype.hasOwnProperty.call(i, a) && (E[a] = i[a]);
                }
                return E;
              }),
            m.apply(this, arguments)
          );
        }
        c(m, "_extends");
        const l = new s.Ay("classic_nav"),
          f = c((E) => {
            let {
              discountExpirationTs: r,
              discountPercent: i,
              discountDuration: a,
              expirationTs: _,
              promoSubType: o,
              promoType: d,
              upgradeProductIds: A,
              ...C
            } = E;
            const M = _ || r;
            let y;
            const x = (0, n.d4)((L) => (0, D._Z)(L, "pnp_discounts") === "on"),
              N = (0, t.useMemo)(() => (A == null ? void 0 : A[0]), [A]);
            switch (d) {
              case I.k2.TenuredTeam:
              case I.k2.WfhBundle:
              case I.k2.PartnerGrowth:
              case I.k2.Atlassian2020:
                y = l.t(
                  "Ready to upgrade Slack? Here's {discountOfferPercent}% off.",
                  {
                    discountOfferPercent: i,
                  }
                );
                break;
              case I.k2.SmartDiscount:
              case I.k2.PaidAcquisitionSelfServe:
              case I.k2.NewYearDiscountV2:
              case I.k2.MilestoneTenuredTeamPromo:
                y = l.t(
                  "Get {discountOfferPercent}% off a premium plan for your first {discountDuration, plural, =1 {month} other {# months}}.",
                  {
                    discountOfferPercent: i,
                    discountDuration: a,
                  }
                );
                break;
              case I.k2.Local:
                y = l.t(
                  "Get {localDiscountOfferPercent}% off a paid plan, for a limited time.",
                  {
                    localDiscountOfferPercent: i,
                  }
                );
                break;
              case I.k2.PricingAndPackagingPromo:
                o === I.g0.Discount75Pct3Months
                  ? (y = x
                      ? l.t(
                          "Get {discountOfferPercent}% off your first three months of Slack Pro.",
                          {
                            discountOfferPercent: i,
                          }
                        )
                      : "")
                  : o === I.g0.Discount25Pct3Months
                  ? (y = x
                      ? l.t(
                          "Get {discountOfferPercent}% off your first three months of Business+.",
                          {
                            discountOfferPercent: i,
                          }
                        )
                      : "")
                  : o === I.g0.Discount15Pct12Months
                  ? (y = x
                      ? l.t(
                          "Get {discountOfferPercent}% off your first year of Business+.",
                          {
                            discountOfferPercent: i,
                          }
                        )
                      : "")
                  : o === I.g0.Discount41Pct12Months ||
                    o === I.g0.Discount42Pct12Months
                  ? (y = x
                      ? l.t(
                          "Get Business+ and pay close to the price you pay for Pro for one year.",
                          {
                            discountOfferPercent: i,
                          }
                        )
                      : "")
                  : (y = "");
                break;
              default:
                y = a
                  ? l.t(
                      "Get {discountOfferPercent}% off a premium plan for your first {discountDuration, plural, =1 {month} other {# months}}.",
                      {
                        discountOfferPercent: i,
                        discountDuration: a,
                      }
                    )
                  : l.t(
                      "Get {discountOfferPercent}% off a paid plan, for a limited time.",
                      {
                        localDiscountOfferPercent: i,
                        discountOfferPercent: i,
                        fallbackHash:
                          "68241b44ccbc2200c451557d8ed295e49e5a3f68",
                      }
                    );
            }
            let U = null;
            if (M && d !== I.k2.PricingAndPackagingPromo) {
              const L = (0, P.A)(M * 1e3).format("YYYY-MM-DD"),
                J = (0, v.qe)(L);
              U = l.rt(
                "{discountOfferNumDaysRemaining, plural, =1 {# day} other {# days}} left to get this offer",
                {
                  discountOfferNumDaysRemaining: J,
                }
              );
            }
            const p = `team_menu_discount_promo_${d}`,
              Y = (0, I.hZ)({
                entryPoint: o ? `${p}_${o}` : p,
              }),
              z = `team_plan_pricing_link_${d}`,
              Z = {
                elementName: o ? `${z}_${o}` : z,
                promoType: d,
                promoSubtype: o,
              },
              w = (0, O.A)(
                "p-discount_promo",
                `p-discount_promo--${d}`,
                `p-discount_promo--${d}${o ? `_${o}` : ""}`
              );
            let V = null;
            return (
              d !== I.k2.PricingAndPackagingPromo &&
                (V = t.createElement(
                  "div",
                  {
                    className: "p-discount_promo_offer_days_remaining",
                  },
                  t.createElement(u.Ay, {
                    text: "hourglass_flowing_sand",
                    emojiSize: u.lw.SMALL,
                  }),
                  U
                )),
              t.createElement(
                t.Fragment,
                null,
                t.createElement(
                  T.A,
                  m(
                    {
                      bodyText: y,
                      ctaText: x
                        ? l.t("Compare Plans")
                        : l.t("See plan details"),
                      ctaHref: Y,
                      preText: M ? V : null,
                      infoBlurbClasses: w,
                      autoClogProps: Z,
                    },
                    C
                  )
                ),
                t.createElement(h.default, {
                  ctaLabel: l.t("Upgrade Now"),
                  productId: N,
                  action: I.um.CHECKOUT,
                })
              )
            );
          }, "DiscountPromo");
        f.displayName = "DiscountPromo";
        const k = f;
      },
      3699548628: (W, g, e) => {
        "use strict";
        e.d(g, {
          A: () => r,
        });
        var t = e(5824283093),
          O = e(9391594207),
          P = e(7715417323),
          s = e(5255740490),
          I = e(3677514771),
          v = e(6839188756),
          T = e(4481313819),
          u = e(1224315998),
          h = e(8245211418),
          D = e(6355911212);
        function n() {
          return (
            (n =
              Object.assign ||
              function (i) {
                for (var a = 1; a < arguments.length; a++) {
                  var _ = arguments[a];
                  for (var o in _)
                    Object.prototype.hasOwnProperty.call(_, o) && (i[o] = _[o]);
                }
                return i;
              }),
            n.apply(this, arguments)
          );
        }
        c(n, "_extends");
        const m = {
            onClick: {
              elementType: u.ElementType.LINK,
              enableClogAction: !0,
            },
          },
          l = "team_plan_pricing_link";
        let f = c(
          class extends t.PureComponent {
            renderCtaLink() {
              const { ctaText: a, highlighted: _, ctaHref: o } = this.props,
                d = (0, s.A)("p-info_blurb__link", {
                  "p-info_blurb__link--highlighted": _,
                });
              return t.createElement(
                t.Fragment,
                null,
                " ",
                t.createElement(
                  "span",
                  {
                    className: d,
                    "data-qa": "info_blurb_link",
                    "data-qa-href": o,
                  },
                  a
                )
              );
            }
            render() {
              const {
                  bodyText: a,
                  subText: _,
                  ctaText: o,
                  preText: d,
                  autoClogProps: A,
                  infoBlurbClasses: C,
                  omitCTA: M,
                  team: y,
                  onMouseEnter: x,
                  highlighted: N,
                  showHelpArticleFlexpane: U,
                  ctaArticleId: p,
                  ctaHref: Y,
                } = this.props,
                z = (0, s.A)("p-info_blurb__container", C),
                Z = (0, s.A)("p-info_blurb", {
                  "p-info_blurb--clickable": !M,
                }),
                w = (0, s.A)("p-info_blurb__sub_text", {
                  "p-info_blurb__sub_text--highlighted": N,
                }),
                V = t.createElement(
                  "div",
                  {
                    className: Z,
                    "data-qa": M && "team-messages-limit-meter",
                    onMouseEnter: x,
                  },
                  t.createElement(
                    "div",
                    {
                      className: z,
                      "data-qa": "classic_nav__team_menu__plan_info",
                    },
                    a,
                    o && !M && this.renderCtaLink()
                  ),
                  _ &&
                    t.createElement(
                      "p",
                      {
                        className: w,
                      },
                      _
                    )
                ),
                L = c((J) => {
                  p
                    ? (J.preventDefault(),
                      U({
                        articleId: p,
                      }))
                    : Y && (0, v.gC)(y, Y);
                }, "onClick");
              return t.createElement(
                T.A,
                n(
                  {
                    eventId: u.EventId.GROWTH_PRICING,
                    uiStep: u.UiStep.SLACK_MENU,
                    elementType: u.ElementType.LINK,
                    elementName: l,
                    clogImpression: !0,
                  },
                  A
                ),
                M
                  ? V
                  : t.createElement(
                      h.A,
                      n(
                        {
                          "data-qa": "team-messages-limit-meter",
                          onSelected: L,
                        },
                        this.props,
                        {
                          autoClogProps: m,
                        }
                      ),
                      d,
                      V
                    )
              );
            }
          },
          "InfoBlurb"
        );
        (f.displayName = "InfoBlurb"),
          (f.defaultProps = {
            omitCTA: !1,
            ctaText: "",
            ctaHref: "",
            onClick: P.A,
            autoClogProps: {},
            infoBlurbClasses: "",
            highlighted: !1,
            onMouseEnter: P.A,
          });
        const k = c(
            (i, a) => ({
              team: (0, I.H7)(i),
            }),
            "mapStateToProps"
          ),
          E = c(
            (i) => ({
              showHelpArticleFlexpane: function () {
                for (
                  var a = arguments.length, _ = new Array(a), o = 0;
                  o < a;
                  o++
                )
                  _[o] = arguments[o];
                return i((0, D.a)(..._));
              },
            }),
            "mapDispatchToProps"
          ),
          r = (0, O.N)(k, E)(f);
      },
      8269938703: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseLimitedHistoryCountdown: () => a,
            default: () => o,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(5255740490),
          s = e(2562405183),
          I = e(6839188756),
          v = e(735940183),
          T = e(6323355797),
          u = e(2925999200),
          h = e(3677514771),
          D = e(1224315998),
          n = e(1030162945),
          m = e(8854221189),
          l = e(8245211418),
          f = e(4481313819),
          k = e(1884211172);
        function E() {
          return (
            (E =
              Object.assign ||
              function (d) {
                for (var A = 1; A < arguments.length; A++) {
                  var C = arguments[A];
                  for (var M in C)
                    Object.prototype.hasOwnProperty.call(C, M) && (d[M] = C[M]);
                }
                return d;
              }),
            E.apply(this, arguments)
          );
        }
        c(E, "_extends");
        const r = new v.Ay("classic_nav"),
          i = 7,
          a = c((d) => {
            let {
              daysRemaining: A,
              isEligibleForMessageLimitTrial: C,
              omitCTA: M,
              onPlansLinkClick: y,
              onStartTrialLinkClick: x,
              ...N
            } = d;
            const U = C && A <= i,
              { highlighted: p, onMouseEnter: Y } = N,
              z = (0, s.d4)(k.S),
              Z = c(
                () =>
                  t.createElement(
                    "div",
                    {
                      className: "display_flex",
                    },
                    t.createElement(n.Ay, {
                      text: "hourglass_flowing_sand",
                      emojiSize: n.lw.SMALL,
                    }),
                    t.createElement(
                      "strong",
                      {
                        className: "padding_left_25",
                        "data-qa": "limited_history_countdown_header",
                      },
                      z
                        ? r.t(
                            "{daysRemaining, plural, =1 {# day} other {# days}} left to view your history",
                            {
                              daysRemaining: A,
                            }
                          )
                        : r.t(
                            "{daysRemaining, plural, =1 {# day} other {# days}} left to view full history",
                            {
                              daysRemaining: A,
                            }
                          )
                    )
                  ),
                "renderHeading"
              );
            Z.displayName = "renderHeading";
            const w = (0, t.useCallback)(
                (G) => {
                  const te = (0, P.A)("p-limited_history_countdown__link", {
                    "p-limited_history_countdown__link--highlighted": p,
                  });
                  return t.createElement(
                    "span",
                    {
                      className: te,
                      "data-qa": "limited_history_countdown_link_text",
                    },
                    G
                  );
                },
                [p]
              ),
              V = (0, t.useMemo)(() => {
                const G = {
                    "<Link>": (Re) => {
                      let { text: Se } = Re;
                      return w(Se);
                    },
                    limitInDays: T.RF,
                  },
                  te = z
                    ? r.rt(
                        "On the free version of Slack, messages and files older than {limitInDays} days will be hidden. To access your history, <Link>try Pro for free.</Link>",
                        G
                      )
                    : "",
                  me = z
                    ? r.rt(
                        "On the free version of Slack, messages and files older than {limitInDays} days will be hidden. To access your history, <Link>upgrade now.</Link>",
                        G
                      )
                    : "";
                return U ? te : me;
              }, [z, w, U]),
              L = c(() => {
                const G = r.t(
                    "On the free version of Slack, messages and files sent more than {limitInDays} days ago will be hidden.",
                    {
                      limitInDays: T.RF,
                    }
                  ),
                  te = M
                    ? G
                    : t.createElement(
                        t.Fragment,
                        null,
                        G,
                        " ",
                        w(U ? r.t("Start trial") : r.t("See upgrade options"))
                      );
                return t.createElement(
                  "div",
                  {
                    className: "p-limited_history_countdown__body",
                    "data-qa": "limited_history_countdown__body",
                  },
                  z ? V : te
                );
              }, "renderBody");
            L.displayName = "renderBody";
            const J = (0, P.A)("p-limited_history_countdown", {
                "p-limited_history_countdown--clickable": !M,
              }),
              se = t.createElement(
                "div",
                {
                  className: J,
                  "data-qa": "limited_history_countdown_content",
                  onMouseEnter: Y,
                },
                Z(),
                L()
              ),
              j = M
                ? se
                : t.createElement(
                    l.A,
                    E(
                      {
                        "data-qa": "limited_history_countdown_menu_item",
                        onSelected: U ? x : y,
                        autoClogProps: {
                          elementName: U ? "start_trial" : "pricing",
                          isPrimaryCTA: !0,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      },
                      N
                    ),
                    se
                  );
            return t.createElement(
              f.A,
              {
                eventId: D.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES,
                uiComponentName: D.UiComponentName.LIMITED_HISTORY_COUNTDOWN,
                clogImpression: !0,
              },
              j
            );
          }, "LimitedHistoryCountdown");
        a.displayName = "LimitedHistoryCountdown";
        const _ = c((d) => {
          let { daysRemaining: A, ...C } = d;
          const M = (0, O.wA)(),
            y = (0, s.d4)(h.H7),
            x = (0, s.d4)(u.j),
            N = (0, t.useCallback)(() => {
              (0, I.gC)(
                y,
                (0, T.hZ)({
                  feature: T.c4.UNLIMITED_MESSAGES,
                })
              );
            }, [y]),
            U = (0, t.useCallback)(() => {
              M(
                (0, m.A)({
                  uiComponentVariant:
                    D.UiComponentVariant.LIMITED_HISTORY_COUNTDOWN,
                })
              );
            }, [M]);
          return !A || A <= 0
            ? null
            : t.createElement(
                a,
                E(
                  {
                    daysRemaining: A,
                    omitCTA: x,
                    onPlansLinkClick: N,
                    onStartTrialLinkClick: U,
                  },
                  C
                )
              );
        }, "ConnectedLimitedHistoryCountdown");
        _.displayName = "ConnectedLimitedHistoryCountdown";
        const o = _;
      },
      2249844134: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseLimitedHistoryCounter: () => a,
            default: () => o,
            test: () => d,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(5255740490),
          s = e(2562405183),
          I = e(6839188756),
          v = e(7239742441),
          T = e(735940183),
          u = e(6323355797),
          h = e(2925999200),
          D = e(3677514771),
          n = e(1224315998),
          m = e(8854221189),
          l = e(8245211418),
          f = e(4481313819),
          k = e(1884211172);
        function E() {
          return (
            (E =
              Object.assign ||
              function (A) {
                for (var C = 1; C < arguments.length; C++) {
                  var M = arguments[C];
                  for (var y in M)
                    Object.prototype.hasOwnProperty.call(M, y) && (A[y] = M[y]);
                }
                return A;
              }),
            E.apply(this, arguments)
          );
        }
        c(E, "_extends");
        const r = new T.Ay("classic_nav"),
          i = 100,
          a = c((A) => {
            let {
              messageAndFileCount: C,
              omitCTA: M,
              isEligibleForMessageLimitTrial: y,
              onPlansLinkClick: x,
              onStartTrialLinkClick: N,
              ...U
            } = A;
            const { highlighted: p, onMouseEnter: Y } = U,
              z = (0, s.d4)(k.S),
              Z = C >= i,
              w = c(() => {
                let te = Z
                  ? r.t(
                      "{messageAndFileCount} messages and files are hidden.",
                      {
                        messageAndFileCount: (0, v.$k)(C, {
                          noSpAbbr: !0,
                        }),
                      }
                    )
                  : r.t(
                      "Messages and files sent more than {limitInDays} days ago are hidden.",
                      {
                        limitInDays: u.RF,
                      }
                    );
                return (
                  z &&
                    (te = z
                      ? r.t(
                          "On the free version of Slack, messages and files older than {limitInDays} days will be hidden.",
                          {
                            limitInDays: u.RF,
                          }
                        )
                      : ""),
                  t.createElement("strong", null, te)
                );
              }, "renderHeading");
            w.displayName = "renderHeading";
            const V = (0, t.useCallback)(
                (te) => {
                  const me = (0, P.A)("p-limited_history_countdown__link", {
                    "p-limited_history_countdown__link--highlighted": p,
                  });
                  return t.createElement(
                    "span",
                    {
                      className: me,
                      "data-qa": "limited_history_counter_link_text",
                    },
                    te
                  );
                },
                [p]
              ),
              L = (0, t.useMemo)(() => {
                const te = {
                    "<Link>": (Se) => {
                      let { text: Te } = Se;
                      return V(Te);
                    },
                    limitInDays: u.RF,
                  },
                  me = z
                    ? r.rt(
                        "To access your history, <Link>try Pro for free.</Link>",
                        te
                      )
                    : "",
                  Re = z
                    ? r.rt(
                        "To access your history, <Link>upgrade now.</Link>",
                        te
                      )
                    : "";
                return y ? me : Re;
              }, [z, y, V]),
              J = c(() => {
                let te = r.t("Get unlimited access to your full history.");
                Z &&
                  (te = y
                    ? r.t(
                        "Get access to messages and files sent more than {limitInDays} days ago.",
                        {
                          limitInDays: u.RF,
                        }
                      )
                    : r.t(
                        "Messages and files sent more than {limitInDays} days ago are available on paid plans.",
                        {
                          limitInDays: u.RF,
                        }
                      ));
                const me = M
                  ? te
                  : t.createElement(
                      t.Fragment,
                      null,
                      te,
                      " ",
                      V(y ? r.t("Start trial") : r.t("See upgrade options"))
                    );
                return z ? L : me;
              }, "renderBody"),
              se = (0, P.A)("p-limited_history_countdown", {
                "p-limited_history_countdown--clickable": !M,
              }),
              j = t.createElement(
                "div",
                {
                  className: se,
                  "data-qa": "limited_history_counter_content",
                  onMouseEnter: Y,
                },
                w(),
                " ",
                J()
              ),
              G = M
                ? j
                : t.createElement(
                    l.A,
                    E(
                      {
                        "data-qa": "limited_history_counter_menu_item",
                        onSelected: y ? N : x,
                        autoClogProps: {
                          elementName: y ? "start_trial" : "pricing",
                          isPrimaryCTA: !0,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      },
                      U
                    ),
                    j
                  );
            return t.createElement(
              f.A,
              {
                eventId: n.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES,
                uiComponentName: n.UiComponentName.LIMITED_HISTORY_COUNTER,
                clogImpression: !0,
              },
              G
            );
          }, "LimitedHistoryCounter");
        a.displayName = "LimitedHistoryCounter";
        const _ = c((A) => {
          const C = (0, O.wA)(),
            M = (0, s.d4)(D.H7),
            y = (0, s.d4)(h.j),
            x = (0, t.useCallback)(() => {
              (0, I.gC)(
                M,
                (0, u.hZ)({
                  feature: u.c4.UNLIMITED_MESSAGES,
                })
              );
            }, [M]),
            N = (0, t.useCallback)(() => {
              C(
                (0, m.A)({
                  uiComponentVariant:
                    n.UiComponentVariant.LIMITED_HISTORY_COUNTER,
                })
              );
            }, [C]);
          return t.createElement(
            a,
            E(
              {
                omitCTA: y,
                onPlansLinkClick: x,
                onStartTrialLinkClick: N,
              },
              A
            )
          );
        }, "ConnectedLimitedHistoryCounter");
        _.displayName = "ConnectedLimitedHistoryCounter";
        const o = _,
          d = {
            MIN_NUMBER_MSGS_FILES_TO_DISPLAY_AMOUNT: i,
          };
      },
      381260222: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BasePlanInfo: () => k,
            default: () => r,
            test: () => i,
          });
        var t = e(5824283093),
          O = e(9391594207),
          P = e(735940183),
          s = e(6839188756),
          I = e(3745851802),
          v = e(3677514771),
          T = e(6323355797),
          u = e(3699548628),
          h = e(2925999200);
        function D() {
          return (
            (D =
              Object.assign ||
              function (a) {
                for (var _ = 1; _ < arguments.length; _++) {
                  var o = arguments[_];
                  for (var d in o)
                    Object.prototype.hasOwnProperty.call(o, d) && (a[d] = o[d]);
                }
                return a;
              }),
            D.apply(this, arguments)
          );
        }
        c(D, "_extends");
        const n = new P.Ay("classic_nav"),
          m = "team_plan_pricing_link",
          l = "team_menu_plan_info",
          f = {
            FREE: "free",
            STANDARD: "standard",
            PLUS: "plus",
            ENTERPRISE: "enterprise",
            COMPLIANCE: "compliance",
          };
        let k = c(
          class extends t.PureComponent {
            getPlanInfo() {
              const { team: _, orgName: o } = this.props;
              let d,
                A = n.t("Learn more"),
                C,
                M;
              return (
                (0, s.tc)(_)
                  ? ((d = n.t(
                      "Your workspace is currently on the free version of Slack."
                    )),
                    (A = n.t("See upgrade options")),
                    (C = (0, T.hZ)({
                      entryPoint: l,
                    })),
                    (M = f.FREE))
                  : (0, s.KJ)(_)
                  ? ((d = n.rt(
                      "Your workspace is currently on Slack\u2019s <strong>Pro Plan</strong>."
                    )),
                    (C = (0, T.hZ)({
                      planLevel: T.i6.standard.id,
                      entryPoint: l,
                    })),
                    (M = f.STANDARD))
                  : (0, s.NB)(_)
                  ? ((d = n.rt(
                      "Your workspace is currently on Slack\u2019s <strong>Business+ Plan</strong>."
                    )),
                    (C = (0, T.hZ)({
                      planLevel: T.i6.plus.id,
                      entryPoint: l,
                    })),
                    (M = f.PLUS))
                  : (0, s.r7)(_)
                  ? ((d = n.rt(
                      "This workspace is part of the <strong>{orgName}</strong> organization.",
                      {
                        orgName: o,
                      }
                    )),
                    (C = "account/workspace-settings"),
                    (M = f.ENTERPRISE))
                  : (0, s.Ah)(_) &&
                    ((d = n.rt(
                      "Your workspace is currently on Slack\u2019s <strong>Enterprise Select Plan</strong>."
                    )),
                    (A = ""),
                    (M = f.COMPLIANCE)),
                {
                  bodyText: d,
                  ctaText: A,
                  ctaHref: C,
                  stepVariant: M,
                }
              );
            }
            render() {
              const {
                bodyText: _,
                ctaText: o,
                ctaHref: d,
                stepVariant: A,
              } = this.getPlanInfo();
              return _
                ? t.createElement(
                    u.A,
                    D(
                      {
                        bodyText: _,
                        ctaText: o,
                        ctaHref: d,
                        autoClogProps: {
                          stepVariant: A,
                          elementName: m,
                        },
                      },
                      this.props
                    )
                  )
                : null;
            }
          },
          "PlanInfo"
        );
        k.displayName = "PlanInfo";
        const E = c((a) => {
            const _ = (0, v.H7)(a),
              o = (0, v.lp)(a),
              d = (0, I.v4)(o) || (_ == null ? void 0 : _.enterprise_name);
            return {
              team: _,
              orgName: d,
              omitCTA: (0, s._s)(_) || (0, h.j)(a) || (0, s.Ah)(_),
            };
          }, "mapStateToProps"),
          r = (0, O.N)(E)(k),
          i = {
            CLOG_ENTRY_POINT: l,
          };
      },
      6768452643: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => m,
          });
        var t = e(5824283093),
          O = e(735940183),
          P = e(7094978947),
          s = e(3801841745),
          I = e(3699548628),
          v = e(8871937520),
          T = e(1224315998);
        function u() {
          return (
            (u =
              Object.assign ||
              function (l) {
                for (var f = 1; f < arguments.length; f++) {
                  var k = arguments[f];
                  for (var E in k)
                    Object.prototype.hasOwnProperty.call(k, E) && (l[E] = k[E]);
                }
                return l;
              }),
            u.apply(this, arguments)
          );
        }
        c(u, "_extends");
        const h = new O.Ay("promotions"),
          D = {
            elementName:
              "slack_ai_auto_charge_manage_trial_workspace_menu_button",
            clogImpression: !0,
            onClick: {
              enableClogAction: !0,
            },
            displayName: T.UiPropertiesDisplayName.SLACK_AI_AUTO_CHARGE_TRIAL,
          },
          n = c((l) => {
            const { trialEndDate: f, highlighted: k } = l,
              E = (0, v.Pd)(f, !1),
              r = "admin/billing",
              i = t.createElement(
                s.A,
                {
                  gap: 12,
                },
                t.createElement(
                  "span",
                  null,
                  t.createElement(P.o, {
                    inline: !0,
                    variation: k ? "filled" : void 0,
                  })
                ),
                t.createElement("span", null, h.t("Manage your Slack AI trial"))
              ),
              a = h.rt(
                "Slack AI will be added to your bill at the end of your trial on <strong>{formattedTrialEndDate}</strong>.",
                {
                  formattedTrialEndDate: E,
                }
              );
            return t.createElement(
              I.A,
              u(
                {
                  bodyText: a,
                  preText: i,
                  ctaHref: r,
                  autoClogProps: D,
                },
                l
              )
            );
          }, "SlackAiManageTrialWorkspaceMenuCta");
        n.displayName = "SlackAiManageTrialWorkspaceMenuCta";
        const m = n;
      },
      7956527390: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseSlackAiTrialOfferWorkspaceMenuCta: () => E,
            ConnectedSlackAiTrialOfferWorkspaceMenuCta: () => r,
          });
        var t = e(5824283093),
          O = e(735940183),
          P = e(3514831633),
          s = e(6122756707),
          I = e(2562405183),
          v = e(7878745420),
          T = e(7094978947),
          u = e(3801841745),
          h = e(9676597566),
          D = e(3141349242),
          n = e(7115655993);
        function m() {
          return (
            (m =
              Object.assign ||
              function (i) {
                for (var a = 1; a < arguments.length; a++) {
                  var _ = arguments[a];
                  for (var o in _)
                    Object.prototype.hasOwnProperty.call(_, o) && (i[o] = _[o]);
                }
                return i;
              }),
            m.apply(this, arguments)
          );
        }
        c(m, "_extends");
        const l = v.g.SLACK_AI_TRIAL_OFFER_WORKSPACE_MENU_CTA,
          f = new O.Ay("promotions"),
          k = {
            elementName: "slack_ai_trial_offer_workspace_menu_button",
            clogImpression: !0,
            onClick: {
              enableClogAction: !0,
            },
          },
          E = c((i) => {
            const a = (0, s.wA)(),
              {
                offerInfo: _,
                trialInfo: o,
                highlighted: d,
                notificationName: A,
              } = i;
            (0, n.A)(() => {
              a((0, D.Md)());
            });
            const C = (0, t.useCallback)(() => {
                a(
                  (0, h.G)({
                    offerInfo: _,
                    trialInfo: o,
                    notificationName: A,
                  })
                );
              }, [a, _, o, A]),
              M = (0, I.d4)(D.Gj);
            return t.createElement(
              P.Dr,
              m({}, i, {
                onSelected: C,
                autoClogProps: {
                  displayName: M,
                  ...k,
                },
              }),
              t.createElement(
                u.A,
                {
                  gap: 12,
                },
                t.createElement(
                  "span",
                  null,
                  t.createElement(T.o, {
                    inline: !0,
                    variation: d ? "filled" : void 0,
                  })
                ),
                f.t("Try Slack AI for free")
              )
            );
          }, "SlackAiTrialOfferWorkspaceMenuCta");
        E.displayName = "SlackAiTrialOfferWorkspaceMenuCta";
        const r = c(
          (i) => t.createElement(E, m({}, i)),
          "ConnectedSlackAiTrialOfferWorkspaceMenuCta"
        );
        r.displayName = "ConnectedSlackAiTrialOfferWorkspaceMenuCta";
      },
      9590263900: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseSlackAiWorkspaceMenuCta: () => l,
            default: () => k,
          });
        var t = e(5824283093),
          O = e(735940183),
          P = e(6038992701),
          s = e(3514831633),
          I = e(2375333597),
          v = e(6122756707),
          T = e(7094978947),
          u = e(3801841745);
        function h() {
          return (
            (h =
              Object.assign ||
              function (E) {
                for (var r = 1; r < arguments.length; r++) {
                  var i = arguments[r];
                  for (var a in i)
                    Object.prototype.hasOwnProperty.call(i, a) && (E[a] = i[a]);
                }
                return E;
              }),
            h.apply(this, arguments)
          );
        }
        c(h, "_extends");
        const D = new O.Ay("promotions"),
          n = "slack_ai_workspace_menu",
          m = {
            elementName: "slack_ai_workspace_menu_button",
            clogImpression: !0,
            onClick: {
              enableClogAction: !0,
            },
          },
          l = c((E) => {
            const r = (0, v.wA)(),
              {
                bauCount: i,
                availableAddonUpfrontUnitCost: a,
                availableAddonTerm: _,
                availableAddonCurrency: o,
                availableAddonId: d,
                canUserPurchase: A,
              } = E,
              C = (0, t.useCallback)(() => {
                r(
                  (0, I.q)({
                    element: t.createElement(P.P, {
                      activeMembersCount: i,
                      availableAddonUpfrontUnitCost: a,
                      availableAddonTerm: _,
                      currency: o,
                      checkoutEntryPoint: n,
                      addonId: d,
                      canUserPurchase: A,
                    }),
                  })
                );
              }, [r, i, o, a, _, d, A]);
            return t.createElement(
              s.Dr,
              h({}, E, {
                onSelected: C,
                autoClogProps: m,
              }),
              t.createElement(
                u.A,
                {
                  gap: 12,
                },
                t.createElement(
                  "span",
                  null,
                  t.createElement(T.o, {
                    inline: !0,
                    variation: E.highlighted ? "filled" : void 0,
                  })
                ),
                D.t("Get Slack AI")
              )
            );
          }, "SlackAiWorkspaceMenuCta");
        l.displayName = "SlackAiWorkspaceMenuCta";
        const f = c(
          (E) => t.createElement(l, h({}, E)),
          "ConnectedSlackAiWorkspaceMenuCta"
        );
        f.displayName = "ConnectedSlackAiWorkspaceMenuCta";
        const k = f;
      },
      1017327448: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseStraightToPaidWorkspaceMenuPrimaryTimeLimit: () => l,
            default: () => k,
          });
        var t = e(5824283093),
          O = e(7878745420),
          P = e(735940183),
          s = e(6323355797),
          I = e(3699548628),
          v = e(1030162945),
          T = e(3749988767),
          u = e(3405119017);
        function h() {
          return (
            (h =
              Object.assign ||
              function (E) {
                for (var r = 1; r < arguments.length; r++) {
                  var i = arguments[r];
                  for (var a in i)
                    Object.prototype.hasOwnProperty.call(i, a) && (E[a] = i[a]);
                }
                return E;
              }),
            h.apply(this, arguments)
          );
        }
        c(h, "_extends");
        const D = O.g.STRAIGHT_TO_PAID_WORKSPACE_MENU_PRIMARY_TIME_LIMIT,
          n = "straight_to_paid_workspace_menu_primary",
          m = new P.Ay("setup_straight_to_paid"),
          l = c((E) => {
            const { discountPercent: r, discountExpirationTs: i = 0 } = E,
              a = (0, T.Q)(i),
              _ = (0, s.hZ)({
                entryPoint: n,
              }),
              o = (0, t.useCallback)(
                () =>
                  t.createElement(
                    t.Fragment,
                    null,
                    t.createElement(
                      "div",
                      {
                        className:
                          "p-straight_to_paid_workspace_menu_primary_time_limit__countdown",
                      },
                      t.createElement(
                        "span",
                        {
                          className:
                            "p-straight_to_paid_workspace_menu_primary_time_limit__timer",
                        },
                        t.createElement(v.Ay, {
                          text: "hourglass_flowing_sand",
                          emojiSize: v.lw.SMALL,
                        })
                      ),
                      typeof a == "number" &&
                        m.t(
                          "{daysRemaining, plural, =1 {# day} other {# days}} left on your Pro Offer",
                          {
                            daysRemaining: a,
                          }
                        )
                    ),
                    m.t(
                      "Get {discountPercent}% off Slack Pro on your first 3 months.",
                      {
                        discountPercent: r,
                      }
                    )
                  ),
                [a, r]
              );
            return t.createElement(
              I.A,
              h(
                {
                  bodyText: o(),
                  infoBlurbClasses:
                    "p-straight_to_paid_workspace_menu_primary_time_limit",
                  ctaText: m.t("See plan details"),
                  ctaHref: _,
                  autoClogProps: u.Ez,
                },
                E
              )
            );
          }, "StraightToPaidWorkspaceMenuPrimaryTimeLimit");
        l.displayName = "StraightToPaidWorkspaceMenuPrimaryTimeLimit";
        const f = c(
          (E) => t.createElement(l, h({}, E)),
          "ConnectedStraightToPaidWorkspaceMenuPrimaryTimeLimit"
        );
        f.displayName = "ConnectedStraightToPaidWorkspaceMenuPrimaryTimeLimit";
        const k = f;
      },
      6077046070: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseStraightToPaidWorkspaceMenuSecondaryUpgradeCta: () => E,
            default: () => i,
          });
        var t = e(5824283093),
          O = e(7878745420),
          P = e(735940183),
          s = e(6323355797),
          I = e(6839188756),
          v = e(2562405183),
          T = e(3677514771),
          u = e(8683010724),
          h = e(6084388622),
          D = e(3514831633),
          n = e(3405119017);
        function m() {
          return (
            (m =
              Object.assign ||
              function (a) {
                for (var _ = 1; _ < arguments.length; _++) {
                  var o = arguments[_];
                  for (var d in o)
                    Object.prototype.hasOwnProperty.call(o, d) && (a[d] = o[d]);
                }
                return a;
              }),
            m.apply(this, arguments)
          );
        }
        c(m, "_extends");
        const l = new P.Ay("setup_straight_to_paid"),
          f = "straight_to_paid_workspace_menu_secondary",
          k = O.g.STRAIGHT_TO_PAID_WORKSPACE_MENU_SECONDARY_UPGRADE_CTA,
          E = c((a) => {
            const { team: _ } = a,
              o = (0, t.useCallback)(() => {
                const d = (0, s.Qn)({
                  team: _,
                  entryPoint: f,
                  productLevel: s.i6.standard.id,
                  excludeDomain: !0,
                });
                _ && (0, I.gC)(_, d, "_self");
              }, [_]);
            return t.createElement(
              "div",
              {
                className:
                  "p-straight_to_paid_workspace_menu_secondary_upgrade_cta",
              },
              t.createElement(
                D.Dr,
                m({}, a, {
                  onSelected: o,
                  className:
                    "p-straight_to_paid_workspace_menu_secondary_upgrade_cta__upgrade-menu-button",
                  autoClogProps: n.MT,
                }),
                t.createElement(
                  h.Ay,
                  {
                    className:
                      "p-straight_to_paid_workspace_menu_secondary_upgrade_cta__upgrade-button",
                    type: "outline",
                    size: "small",
                    onClick: o,
                    autoClogProps: n.Mm,
                  },
                  t.createElement(
                    "span",
                    {
                      className:
                        "p-straight_to_paid_workspace_menu_secondary_upgrade_cta__rocket-icon",
                    },
                    t.createElement(u.A, {
                      name: "rocket",
                    })
                  ),
                  l.t("Upgrade Plan")
                )
              )
            );
          }, "StraightToPaidWorkspaceMenuSecondaryUpgradeCta");
        E.displayName = "StraightToPaidWorkspaceMenuSecondaryUpgradeCta";
        const r = c((a) => {
          const _ = (0, v.d4)(T.H7);
          return t.createElement(
            E,
            m({}, a, {
              team: _,
            })
          );
        }, "ConnectedStraightToPaidWorkspaceMenuSecondaryUpgradeCta");
        r.displayName =
          "ConnectedStraightToPaidWorkspaceMenuSecondaryUpgradeCta";
        const i = r;
      },
      3854710577: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            BaseTrialInfo: () => f,
            default: () => E,
          });
        var t = e(5824283093),
          O = e(4418517660),
          P = e.n(O),
          s = e(9391594207),
          I = e(735940183),
          v = e(9160454416),
          T = e(6323355797),
          u = e(2925999200),
          h = e(7268021173),
          D = e(3699548628);
        function n() {
          return (
            (n =
              Object.assign ||
              function (r) {
                for (var i = 1; i < arguments.length; i++) {
                  var a = arguments[i];
                  for (var _ in a)
                    Object.prototype.hasOwnProperty.call(a, _) && (r[_] = a[_]);
                }
                return r;
              }),
            n.apply(this, arguments)
          );
        }
        c(n, "_extends");
        const m = new I.Ay("classic_nav"),
          l = "team_plan_pricing_link_trial";
        let f = c(
          class extends t.PureComponent {
            render() {
              const {
                trialExpirationDate: i,
                trialPlanLevel: a,
                nextProductLevel: _,
              } = this.props;
              let o, d, A;
              if (_) {
                const M = P()(i),
                  y = (0, v.A)(M, {
                    shortenDay: !0,
                    excludeYear: !0,
                  });
                (o = m.t("Learn more")),
                  (d = (0, T.hZ)({
                    planLevel: _,
                    entryPoint: "team_menu_trial_info",
                  })),
                  (A =
                    _ === T.i6.standard.id
                      ? m.rt(
                          "Your team is scheduled to be upgraded to <strong>Pro</strong> once your trial ends on {trialExpirationDate}.",
                          {
                            trialExpirationDate: y,
                          }
                        )
                      : m.rt(
                          "Your team is scheduled to be upgraded to <strong>Business+</strong> once your trial ends on {trialExpirationDate}.",
                          {
                            trialExpirationDate: y,
                          }
                        ));
              } else {
                const M = P()(i).subtract(1, "day"),
                  y = (0, v.A)(M, {
                    shortenDay: !0,
                    excludeYear: !0,
                  });
                (o = m.t("See upgrade options")),
                  (d = (0, T.hZ)({
                    entryPoint: "team_menu_trial_info",
                  })),
                  (A =
                    a === T.i6.standard.id
                      ? m.rt(
                          "Your <strong>Pro trial</strong> lasts through {trialExpiryDate}.",
                          {
                            trialExpiryDate: y,
                          }
                        )
                      : m.rt(
                          "Your <strong>Business+ trial</strong> lasts through {trialExpiryDate}.",
                          {
                            trialExpiryDate: y,
                          }
                        ));
              }
              const C = `${a === T.i6.standard.id ? "standard" : "plus"}_trial`;
              return t.createElement(
                D.A,
                n(
                  {
                    infoBlurbClasses: "p-trial_info",
                    bodyText: A,
                    ctaText: o,
                    ctaHref: d,
                    autoClogProps: {
                      stepVariant: C,
                      elementName: l,
                    },
                  },
                  this.props
                )
              );
            }
          },
          "TrialInfo"
        );
        f.displayName = "TrialInfo";
        const k = c(
            (r) => ({
              nextProductLevel: (0, h.wM)(r),
              omitCTA: (0, u.j)(r),
            }),
            "mapStateToProps"
          ),
          E = (0, s.N)(k)(f);
      },
      2925999200: (W, g, e) => {
        "use strict";
        e.d(g, {
          j: () => t,
        });
        const t = c((O) => !1, "shouldOmitPrimaryCTA");
      },
      535424668: (W, g, e) => {
        "use strict";
        e.d(g, {
          n: () => D,
        });
        var t = e(9706240641),
          O = e.n(t),
          P = e(1031947056),
          s = e(9785228405),
          I = e(5201749224),
          v = e(8438703627);
        const T = (function () {
            var n = (0, t.coroutine)(function* (m, l) {
              const f = (function () {
                  var E = (0, t.coroutine)(function* (r) {
                    const {
                        app_id: i,
                        provider_key: a,
                        salesforce_org_id: _,
                      } = r,
                      o = yield m(
                        (0, I.d)({
                          appId: i,
                          providerKey: a,
                          salesforceOrgId: _,
                          reason: "salesforce-connections-silent-sign-in",
                        })
                      ),
                      d = o.ok && !o.authorization_url ? "ok" : "none";
                    return Promise.resolve({
                      salesforceOrgId: _,
                      auth: d,
                    });
                  });
                  return c(function (i) {
                    return E.apply(this, arguments);
                  }, "attemptToSignIntoSeamlessOrg");
                })(),
                k = l.map(f);
              return Promise.all(k);
            });
            return c(function (l, f) {
              return n.apply(this, arguments);
            }, "trySigningIntoSeamlessAuthOrgsSilently");
          })(),
          u = (function () {
            var n = (0, t.coroutine)(function* (m) {
              const l = yield m((0, v.l)()),
                f = (0, s.N)(l);
              if (f.length === 0) return l;
              const k = yield T(m, f);
              return l.map((r) => {
                const i = k.find((a) => {
                  let { salesforceOrgId: _ } = a;
                  return _ === r.salesforce_org_id;
                });
                return i
                  ? {
                      ...r,
                      auth: i.auth,
                    }
                  : r;
              });
            });
            return c(function (l) {
              return n.apply(this, arguments);
            }, "fetchOrgsAndSignInSilentlyHandler");
          })();
        let h = null;
        const D = (0, P.Ay)(
          "Fetches a list of Salesforce organizations from sfdc.integration.listOrgs and tries to sing in user into those with auth=none",
          (n) => (
            h === null && (h = u(n)),
            h.finally(() => {
              h = null;
            })
          )
        );
        D.meta = {
          name: "createThunk",
          key: "createThunkfetchOrgsAndSignInSilently",
          description:
            "Fetches a list of Salesforce organizations from sfdc.integration.listOrgs and tries to sing in user into those with auth=none",
        };
      },
      2140279507: (W, g, e) => {
        "use strict";
        e.d(g, {
          FK: () => I,
          QJ: () => T,
          gV: () => h,
        });
        var t = e(8161242485),
          O = e(1031947056),
          P = e(6209625934),
          s = e(4761125736);
        const I = (0, t.Ay)((m) => (0, s._Z)(m, "first_login_loader_copy", !1));
        I.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyGetAssignment",
          description: (m) => (0, s._Z)(m, "first_login_loader_copy", !1),
        };
        const v = (0, t.Ay)(
          (m) => (0, s._Z)(m, "first_login_loader_copy", !1) === "control"
        );
        v.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsControl",
          description: (m) =>
            (0, s._Z)(m, "first_login_loader_copy", !1) === "control",
        };
        const T = (0, t.Ay)(
          (m) => (0, s._Z)(m, "first_login_loader_copy", !1) === "treatment"
        );
        T.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsTreatment",
          description: (m) =>
            (0, s._Z)(m, "first_login_loader_copy", !1) === "treatment",
        };
        const u = (0, t.Ay)((m) => {
          var l;
          return ["treatment"].includes(
            (l = (0, s._Z)(m, "first_login_loader_copy", !1)) !== null &&
              l !== void 0
              ? l
              : ""
          );
        });
        u.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsAnyTreatment",
          description: (m) => {
            var l;
            return ["treatment"].includes(
              (l = (0, s._Z)(m, "first_login_loader_copy", !1)) !== null &&
                l !== void 0
                ? l
                : ""
            );
          },
        };
        const h = (0, t.Ay)((m) => v(m) || u(m));
        h.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsExposed",
          description: (m) => v(m) || u(m),
        };
        const D = c((m) => {
            const l = (0, s.KK)(m, "first_login_loader_copy");
            l && l.log_exposures && (0, P.K)("first_login_loader_copy", l, m);
          }, "firstLoginLoaderCopyLogExposure"),
          n = (0, O.Ay)(
            "Log exposure for the first_login_loader_copy experiment if it is exposed",
            (m, l) => {
              h(l()) && D(l());
            }
          );
        n.meta = {
          name: "createThunk",
          key: "createThunkfirstLoginLoaderCopyMaybeLogExposure",
          description:
            "Log exposure for the first_login_loader_copy experiment if it is exposed",
        };
      },
      5946234139: (W, g, e) => {
        "use strict";
        e.d(g, {
          w: () => o,
        });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4459831283),
          s = e(1063683520),
          I = e(6084388622),
          v = e(3514831633),
          T = e(8773153312),
          u = e(8683010724),
          h = e(1224315998),
          D = e(735940183),
          n = e(3841231120),
          m = e(5136495170),
          l = e(4517041377),
          f = e(6280700824),
          k = e(2562405183),
          E = e(4761125736);
        function r() {
          return (
            (r =
              Object.assign ||
              function (A) {
                for (var C = 1; C < arguments.length; C++) {
                  var M = arguments[C];
                  for (var y in M)
                    Object.prototype.hasOwnProperty.call(M, y) && (A[y] = M[y]);
                }
                return A;
              }),
            r.apply(this, arguments)
          );
        }
        c(r, "_extends");
        const i = new D.Ay("ia4"),
          a = {
            filterExternal: {
              eventId: h.EventId.DMS_TAB_FILTER_BY_EXTERNAL,
              elementName: "dms_tab_filter-external-button",
              uiStep: h.UiStep.DMS_TAB_FILTER_BY_EXTERNAL,
              action: h.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            filterInternal: {
              eventId: h.EventId.DMS_TAB_FILTER_BY_INTERNAL,
              elementName: "dms_tab_filter-internal-button",
              uiStep: h.UiStep.DMS_TAB_FILTER_BY_INTERNAL,
              action: h.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            filterAll: {
              eventId: h.EventId.DMS_TAB_FILTER_BY_ALL,
              elementName: "dms_tab_filter-all-button",
              uiStep: h.UiStep.DMS_TAB_FILTER_BY_ALL,
              action: h.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
          },
          _ = c((A) => {
            let { menuProps: C } = A;
            const M = (0, k.d4)(
                (w) =>
                  (0, E._Z)(w, "filter_conversations_menu_updates") === "on"
              ),
              y = (0, k.d4)(P.FT),
              x = (0, O.wA)(),
              N = (0, k.d4)(l.Q),
              U = (0, t.useCallback)(
                (w) => {
                  x((0, n.W)(w));
                },
                [x]
              ),
              p = (0, t.useCallback)(() => {
                x(
                  (0, f.A)({
                    activeSection: s._.vip,
                  })
                );
              }, [x]),
              Y = i.t("Filter conversations"),
              z = M ? i.t("Manage VIP") : "",
              Z = (0, t.useMemo)(
                () =>
                  [
                    {
                      label: z,
                      click: p,
                      key: "vip-preferences",
                      show: y,
                    },
                    {
                      label: Y,
                      type: T.y.submenu,
                      key: "filter-conversations",
                      show: !0,
                      template: [
                        {
                          label: M ? i.t("Everyone") : "",
                          click: () => U(m.I.ALL),
                          key: "filter-all",
                          type: T.A.radio,
                          checked: N === m.I.ALL,
                          autoClogProps: a.filterAll,
                          dataQa: "dms-page-filter-menu-filter-all",
                        },
                        {
                          label: M ? i.t("Only internal people") : "",
                          click: () => U(m.I.INTERNAL),
                          key: "filter-internal",
                          type: T.A.radio,
                          checked: N === m.I.INTERNAL,
                          autoClogProps: a.filterInternal,
                          dataQa: "dms-page-filter-menu-filter-internal-only",
                        },
                        {
                          label: M ? i.t("Only external people") : "",
                          click: () => U(m.I.EXTERNAL),
                          key: "filter-external",
                          type: T.A.radio,
                          checked: N === m.I.EXTERNAL,
                          autoClogProps: a.filterExternal,
                          dataQa: "dms-page-filter-menu-filter-external-only",
                        },
                      ],
                    },
                  ].filter((V) => ("show" in V ? V.show !== !1 : !0)),
                [M, N, U, Y, y, z, p]
              );
            return t.createElement(
              v.a,
              r({}, C, {
                menuClassNames: "p-ia4_home_header_menu__menu",
                template: Z,
              })
            );
          }, "DirectMessagesHeaderMenu");
        _.displayName = "DirectMessagesHeaderMenu";
        const o = c(() => {
          const A = (0, t.useCallback)(
            (C) =>
              t.createElement(_, {
                menuProps: C,
              }),
            []
          );
          return t.createElement(
            v.cQ,
            {
              renderMenu: A,
              position: "bottom-left",
            },
            t.createElement(
              I.Nm,
              {
                className: "p-ia4_home_header_menu__button ",
                "data-qa": "workspace_actions_button",
              },
              t.createElement(
                "span",
                {
                  className: "p-ia4_home_header_menu__team_name",
                },
                i.t("Direct messages")
              ),
              t.createElement(u.A, {
                name: "caret-down",
              })
            )
          );
        }, "DirectMessagesHeaderMenuTrigger");
        o.displayName = "DirectMessagesHeaderMenuTrigger";
        var d = null;
      },
      3686168196: (W, g, e) => {
        "use strict";
        e.d(g, {
          A: () => Bo,
        });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(5255740490),
          s = e(5946234139),
          I = e(5557117347),
          v = e(6839188756),
          T = e(6084388622),
          u = e(3514831633),
          h = e(8683010724),
          D = e(735940183),
          n = e(2562405183),
          m = e(3677514771);
        function l() {
          return (
            (l =
              Object.assign ||
              function (S) {
                for (var b = 1; b < arguments.length; b++) {
                  var R = arguments[b];
                  for (var B in R)
                    Object.prototype.hasOwnProperty.call(R, B) && (S[B] = R[B]);
                }
                return S;
              }),
            l.apply(this, arguments)
          );
        }
        c(l, "_extends");
        const f = new D.Ay("events"),
          k = c((S) => {
            let { menuProps: b, externalWorkspaceId: R } = S;
            const B = (0, n.d4)((ge) => (0, m._J)(ge, R)),
              ae = (0, v.F1)(B);
            return t.createElement(
              I.P,
              l(
                {
                  workspaceId: R,
                  isWorkspaceHeaderMenu: !0,
                  classNames: "p-event_header_menu__menu",
                },
                b,
                {
                  menuClassNames: "p-event_header_menu__menu",
                  ariaLabel: f.t("{teamDisplayName} Actions", {
                    teamDisplayName: ae,
                    fallbackHash: "dde3b41abdc106c7934277e6ce75b7165c603697",
                    fallbackHashNs: "ia4",
                  }),
                }
              )
            );
          }, "EventHeaderMenu");
        k.displayName = "EventHeaderMenu";
        const E = c((S) => {
          let { externalWorkspaceId: b } = S;
          const R = (0, t.useCallback)(
              (ae) =>
                t.createElement(k, {
                  menuProps: ae,
                  externalWorkspaceId: b,
                }),
              [b]
            ),
            B = (0, n.d4)((ae) => (0, v.F1)((0, m._J)(ae, b)));
          return t.createElement(
            u.cQ,
            {
              renderMenu: R,
              position: "bottom-left",
            },
            t.createElement(
              T.Nm,
              {
                className: "p-event_header_menu__button",
                "aria-label": f.t("{externalWorkspaceName} Actions", {
                  externalWorkspaceName: B,
                  fallbackHash: "dde3b41abdc106c7934277e6ce75b7165c603697",
                  fallbackHashNs: "ia4",
                }),
                "data-qa": "workspace_actions_button",
              },
              t.createElement(
                "span",
                {
                  className: "p-event_header_menu__team_name",
                },
                B
              ),
              t.createElement(h.A, {
                name: "caret-down",
                "aria-label": "caret-down",
              })
            )
          );
        }, "EventHeaderMenuTrigger");
        E.displayName = "EventHeaderMenuTrigger";
        var r = e(6879781695),
          i = e(6105929840),
          a = e(8773153312),
          _ = e(2312625946),
          o = e(1224315998),
          d = e(2112238546),
          A = e(2235302340),
          C = e(3943207487),
          M = e(2047021170),
          y = e(387484329);
        function x() {
          return (
            (x =
              Object.assign ||
              function (S) {
                for (var b = 1; b < arguments.length; b++) {
                  var R = arguments[b];
                  for (var B in R)
                    Object.prototype.hasOwnProperty.call(R, B) && (S[B] = R[B]);
                }
                return S;
              }),
            x.apply(this, arguments)
          );
        }
        c(x, "home_filter_menu_extends");
        const N = new D.Ay("ia4"),
          U = c((S) => {
            let { autoClogProps: b } = S;
            const R = (0, O.wA)(),
              B = (0, n.d4)(A.ce),
              ae = (0, n.d4)((Q) => (0, M.ty)(Q, "sidebar_behavior")),
              ge = (0, t.useCallback)(
                (Q) => {
                  R(
                    (0, y.AZ)({
                      pref: "sidebar_behavior",
                      value: Q,
                    })
                  );
                },
                [R]
              ),
              le = (0, t.useCallback)(function () {
                let Q =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : r.UN,
                  ue = null;
                switch (Q) {
                  case r.nU:
                    ue = N.t("Unreads only");
                    break;
                  case r.Ao:
                    ue = N.t("Mentions only");
                    break;
                  case r.eF:
                    ue = N.t("Custom by section");
                    break;
                  default:
                    ue = N.t("All activity");
                }
                return ue;
              }, []),
              Ce = (0, t.useCallback)(
                (Q) => {
                  R(
                    (0, d.UG)({
                      peopleFilter: {
                        type: Q,
                      },
                    })
                  );
                },
                [R]
              ),
              Pe = (0, t.useCallback)(function () {
                let Q =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : C.E7.All,
                  ue = null;
                switch (Q) {
                  case C.E7.Internal:
                    ue = N.t("Without external people");
                    break;
                  case C.E7.External:
                    ue = N.t("Including external people");
                    break;
                  default:
                    ue = N.t("Everyone");
                }
                return ue;
              }, []),
              re = (0, t.useMemo)(() => {
                const Q = [r.UN, r.nU, r.Ao, r.eF],
                  ue = [C.E7.All, C.E7.Internal, C.E7.External],
                  ke = c((Oe) => {
                    switch (Oe) {
                      case r.UN:
                        return o.EventId.HOME_FILTER_ALL_ACTIVITY;
                      case r.nU:
                        return o.EventId.HOME_FILTER_UNREADS_ONLY;
                      case r.Ao:
                        return o.EventId.HOME_FILTER_MENTIONS_ONLY;
                      case r.eF:
                        return o.EventId.HOME_FILTER_CUSTOM_BY_SECTION;
                      case C.E7.All:
                        return o.EventId.HOME_FILTER_EVERYONE;
                      case C.E7.Internal:
                        return o.EventId.HOME_FILTER_WITHOUT_EXTERNAL;
                      case C.E7.External:
                        return o.EventId.HOME_FILTER_INCLUDE_EXTERNAL;
                      default:
                        return "";
                    }
                  }, "getClogEventIdForEntry"),
                  Ke = B == null ? void 0 : B.type;
                return [
                  ...Q.map((Oe) => ({
                    label: le(Oe),
                    type: a.A.checkbox,
                    click: () => ge(Oe),
                    checked: (!ae && Oe === r.UN) || ae === Oe,
                    autoClogProps: {
                      onClick: {
                        enableClogAction: !0,
                      },
                      eventId: ke(Oe),
                    },
                  })),
                  {
                    type: a.A.separator,
                  },
                  ...ue.map((Oe) => ({
                    label: Pe(Oe),
                    type: a.A.checkbox,
                    click: () => Ce(Oe),
                    checked: (!Ke && Oe === C.E7.All) || Ke === Oe,
                    autoClogProps: {
                      onClick: {
                        enableClogAction: !0,
                      },
                      eventId: ke(Oe),
                    },
                  })),
                ];
              }, [ae, ge, le, Pe, Ce, B]),
              De = (0, t.useCallback)(
                (Q) =>
                  t.createElement(
                    u.a,
                    x({}, Q, {
                      template: re,
                    })
                  ),
                [re]
              );
            return t.createElement(
              u.cQ,
              {
                renderMenu: De,
                position: "bottom-left",
              },
              t.createElement(
                _.Ay,
                {
                  tip: N.t("Filter conversations"),
                  position: "bottom",
                },
                t.createElement(
                  i.A,
                  {
                    autoClogProps: b,
                    "data-qa": "home_filter_menu",
                    "aria-label": N.t("Home filter"),
                    className: "p-home_header_controls__filter_menu",
                  },
                  t.createElement(h.A, {
                    name: "refine",
                    "aria-label": "refine",
                    size: "20",
                  })
                )
              )
            );
          }, "HomeFilterMenu");
        U.displayName = "HomeFilterMenu";
        const p = U;
        var Y = e(7133181643),
          z = e(4626613428),
          Z = e(4481313819),
          w = e(219228829),
          V = e(485355941),
          L = e(1098894407),
          J = e(4761125736);
        const se = new D.Ay("drafts"),
          j = {
            elementName: "home_header_filter_menu_button",
            elementType: o.ElementType.BUTTON,
            eventId: o.EventId.HOME_FILTER_MENU,
            onClick: {
              enableClogAction: !0,
            },
            uiStep: o.UiStep.HOME_FILTER_MENU,
            stepVariant: "desktop_ia4_new_teams_v3__treatment_home_more",
          };
        function G(S) {
          let { isSetupPage: b } = S;
          const R = (0, n.d4)(
              (Q) => (0, J._Z)(Q, "filter_conversations_menu_updates") === "on"
            ),
            B = (0, O.wA)(),
            ae = (0, t.useRef)(),
            ge = (0, t.useCallback)((Q) => {
              ae.current = Q;
            }, []),
            le = (0, n.d4)(V.M2),
            Ce = (0, n.d4)((Q) => (0, M.ty)(Q, Y.V)),
            Pe = (0, n.d4)(Y.W),
            re = (0, n.d4)(z.Ty) && !R,
            De = (0, t.useCallback)(
              (Q) => {
                var ue;
                B(
                  (0, L.U)({
                    shouldOpenInTile: le && (0, w.A)(Q),
                  })
                ),
                  Pe &&
                    !Ce &&
                    B(
                      (0, y.AZ)({
                        pref: Y.V,
                        value: !0,
                      })
                    ),
                  (ue = ae.current) === null ||
                    ue === void 0 ||
                    ue.call(ae, {
                      action: o.UiAction.CLICK,
                    });
              },
              [le, B, Ce, Pe]
            );
          return b
            ? null
            : t.createElement(
                t.Fragment,
                null,
                re &&
                  t.createElement(p, {
                    autoClogProps: j,
                  }),
                t.createElement(
                  Z.A,
                  {
                    clogImpression: !0,
                    elementName: "home_header_composer_button",
                    elementType: o.ElementType.BUTTON,
                    eventId: o.EventId.COMPOSE_FLOW,
                    stepVariant:
                      "desktop_ia4_new_teams_v3__treatment_home_more",
                    trackClogRef: ge,
                    uiStep: o.UiStep.COMPOSE_FLOW_CREATE,
                  },
                  t.createElement(
                    _.Ay,
                    {
                      tip: se.t("New message"),
                      position: "bottom",
                    },
                    t.createElement(
                      i.A,
                      {
                        "aria-label": se.t("New message"),
                        className: (0, P.A)(
                          "p-home_header_controls__composer_button",
                          {
                            "p-home_header_controls__composer_button--highlight":
                              Pe,
                          }
                        ),
                        "data-qa": "composer_button",
                        onClick: De,
                        size: Pe ? "x-small" : "medium",
                      },
                      t.createElement(h.A, {
                        name: "compose",
                        size: "20",
                      })
                    )
                  )
                )
              );
        }
        c(G, "HomeHeaderControls"), (G.displayName = "HomeHeaderControls");
        const te = (0, t.memo)(G);
        var me = e(506684971),
          Re = e.n(me),
          Se = e(7715417323),
          Te = e(9948985554),
          $e = e(7043699030),
          xe = e(1031947056),
          ve = e(9190452268);
        const oe = (0, xe.Ay)(
          "Counts the number of times the Open App team menu item is selected",
          (S, b) => {
            (0, ve.Cy)({
              getState: b,
            }).count("team_menu_download_apps");
          }
        );
        oe.meta = {
          name: "createThunk",
          key: "createThunkcountOpenAppClick",
          description:
            "Counts the number of times the Open App team menu item is selected",
        };
        const H = oe;
        var X = e(301719806),
          pe = e.n(X),
          ee = e(8245211418),
          ze = e(101973425),
          we = e(8161242485),
          Ue = e(2995501183),
          He = e(2140279507),
          Xe = e(6827180593);
        const Be = (0, we.Ay)((S) => {
          const b = (0, He.QJ)(S),
            R = (0, Ue.Yx)(S),
            B = (0, Xe.H)(S) < 1;
          return b && R && B;
        });
        Be.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginIntoWorkspaceSelector",
          description: (S) => {
            const b = (0, He.QJ)(S),
              R = (0, Ue.Yx)(S),
              B = (0, Xe.H)(S) < 1;
            return b && R && B;
          },
        };
        function qe() {
          return (
            (qe =
              Object.assign ||
              function (S) {
                for (var b = 1; b < arguments.length; b++) {
                  var R = arguments[b];
                  for (var B in R)
                    Object.prototype.hasOwnProperty.call(R, B) && (S[B] = R[B]);
                }
                return S;
              }),
            qe.apply(this, arguments)
          );
        }
        c(qe, "open_desktop_app_menu_item_extends");
        const ct = new D.Ay("native_apps_entry_points"),
          It = {
            onClick: {
              enableClogAction: !0,
            },
          },
          st = c((S) => {
            let {
              showMobileEntryPoint: b,
              teamUrl: R,
              className: B,
              ...ae
            } = S;
            const ge = (0, O.wA)();
            let le = ct.rt("Open the Slack App", {
                fallbackHash: "3d3bf52716f61d19b7b9959018e54757226c17ca",
                fallbackHashNs: "classic_nav",
              }),
              Ce =
                o.UiComponentVariant
                  .PERSISTENT_ENTRY_CONTROL_DESKTOP_DEFAULT_COPY;
            b &&
              ((le = ct.rt("Open the desktop app", {
                fallbackHash: "f1ccafab17e31b70d527e3984ece02b6e92d9d25",
                fallbackHashNs: "classic_nav",
              })),
              (Ce =
                o.UiComponentVariant
                  .PERSISTENT_ENTRY_TREATMENT_DESKTOP_UPDATED_COPY));
            const Pe = t.createElement(
                t.Fragment,
                null,
                t.createElement(
                  "span",
                  {
                    className: "p-ia__main_menu__open_native_app_copy",
                  },
                  le
                ),
                t.createElement(
                  "span",
                  {
                    className: (0, P.A)(
                      "p-ia__main_menu__open_slack_app_icon",
                      "p-ia__main_menu__open_native_app_icon"
                    ),
                  },
                  t.createElement("img", {
                    src: pe(),
                    alt: "Slack app logo",
                  })
                )
              ),
              re = (0, t.useCallback)(() => ge(H()), [ge]),
              Q = (0, n.d4)(Be)
                ? `${R}ssb/redirect?open_desktop=1`
                : `${R}ssb/redirect`;
            return t.createElement(
              Z.A,
              {
                eventId: o.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                uiStep: o.UiStep.MAIN_MENU,
                uiComponentName: o.UiComponentName.DESKTOP_ENTRY_POINT,
                uiComponentVariant: Ce,
                clogImpression: !0,
              },
              t.createElement(
                ee.A,
                qe({}, ae, {
                  "data-qa": "open-desktop-app",
                  className: (0, P.A)(
                    "p-ia__main_menu__open_slack_app_item",
                    B
                  ),
                  onSelected: re,
                  href: Q,
                  showLinkIndicatorIcon: !1,
                  label: Pe,
                  autoClogProps: It,
                })
              )
            );
          }, "OpenDesktopAppMenuItem");
        st.displayName = "OpenDesktopAppMenuItem";
        const Mt = (0, ze.Ay)(st);
        var _t = e(4902318931),
          q = e(6259241484);
        const ot = {
            [q.ze.PERSISTENT_MOBILE_PROMO]: {
              component: t.lazy(() =>
                Promise.resolve().then(e.bind(e, 7391266585))
              ),
            },
          },
          At = t.lazy(() => Promise.resolve().then(e.bind(e, 381260222))),
          Ct = t.lazy(() => Promise.resolve().then(e.bind(e, 3854710577))),
          nt = t.lazy(() => Promise.resolve().then(e.bind(e, 8269938703))),
          Nt = t.lazy(() => Promise.resolve().then(e.bind(e, 2249844134))),
          Et = t.lazy(() => Promise.resolve().then(e.bind(e, 1017327448))),
          Kt = {
            spaceName: q.xu.WORKSPACE_MENU_PRIMARY_PLAN_INFO,
            notifications: {
              [q.ze.PLAN_INFO]: {
                component: At,
              },
              [q.ze.TRIAL_INFO]: {
                component: Ct,
              },
              [q.ze.STRAIGHT_TO_PAID_WORKSPACE_MENU_PRIMARY_TIME_LIMIT]: {
                component: Et,
              },
              [q.ze.LIMITED_HISTORY_COUNTDOWN]: {
                component: nt,
              },
              [q.ze.LIMITED_HISTORY_COUNTER]: {
                component: Nt,
              },
            },
          },
          dn = t.lazy(() => Promise.resolve().then(e.bind(e, 858410167))),
          Yt = t.lazy(() => Promise.resolve().then(e.bind(e, 6077046070))),
          qt = t.lazy(() => Promise.resolve().then(e.bind(e, 9590263900))),
          ce = t.lazy(() => Promise.resolve().then(e.bind(e, 6768452643))),
          Qe = t.lazy(() => Promise.resolve().then(e.bind(e, 6807544879))),
          ht = {
            spaceName: q.xu.WORKSPACE_MENU_SECONDARY_PLAN_INFO,
            notifications: {
              [q.ze.STRAIGHT_TO_PAID_WORKSPACE_MENU_SECONDARY_UPGRADE_CTA]: {
                component: Yt,
              },
              [q.ze.DISCOUNT_PROMO]: {
                component: dn,
              },
              [q.ze.SLACK_AI_WORKSPACE_MENU_CTA]: {
                component: qt,
              },
              [q.ze.SLACK_AI_TRIAL_OFFER_WORKSPACE_MENU_CTA]: {
                component: t.lazy(() =>
                  Promise.resolve()
                    .then(e.bind(e, 7956527390))
                    .then((S) => ({
                      default: S.ConnectedSlackAiTrialOfferWorkspaceMenuCta,
                    }))
                ),
              },
              [q.ze.SLACK_AI_AUTO_CHARGE_TRIAL_MANAGE_TRIAL_WORKSPACE_MENU_CTA]:
                {
                  component: ce,
                },
              [q.ze.AUTO_CHARGE_FEATURE_TRIALS_MANAGE_TRIAL_WORKSPACE_MENU_CTA]:
                {
                  component: Qe,
                },
            },
          };
        var $ = e(4979382452),
          K = e(9003400431),
          _e = e(980293773),
          de = e(9706240641),
          Ne = e(1138952178),
          he = e(6422693406),
          be = e(796111729);
        const Fe = c(
          (S) =>
            new he.S((b, R) => {
              if (!S) {
                R(new Error("Invalid params"));
                return;
              }
              try {
                b(Ne.toDataURL(`${S}`));
              } catch (B) {
                const ae = (0, be.Wo)();
                ae.warn("Error generating QR code"), ae.warn(B), R(B);
              }
            }),
          "generateQrCode"
        );
        var fe = e(5795074931),
          We = e(8847766420),
          Le = e(6308822),
          ye = e(5812641038),
          Ye = e(1942804440),
          et = e(9420092417),
          at = e.n(et),
          Ze = e(3715013583),
          Rt = e(1269227002),
          Tt = e(5257368278),
          Ae = e(5873468694);
        const Je = {
            Ratelimited: "ratelimited",
            NotAuthed: "not_authed",
            InvalidAuth: "invalid_auth",
          },
          dt = (0, Tt.A)(
            "auth.magicLogins.create generated fetcher",
            (S, b, R) =>
              new he.S((B, ae) => {
                const { reason: ge, ...le } = R,
                  Ce = (0, Ae.VA)(le);
                S(
                  (0, Rt.apiCall)({
                    method: "auth.magicLogins.create",
                    args: Ce,
                    reason: ge,
                  })
                )
                  .then((Pe) => {
                    B(Pe);
                  })
                  .catch((Pe) => {
                    (0, be.Ay)({
                      getState: b,
                    }).error(`API call to auth.magicLogins.create
						with reason ${ge} failed, initiated by generated fetcher`),
                      ae(Pe);
                  });
              })
          );
        dt.meta = {
          name: "createFetcher",
          key: "createFetcherauthMagicLoginsCreateFetcher",
          description: "auth.magicLogins.create generated fetcher",
        };
        const rt = new D.Ay("mobile_app_promos"),
          Lt = c((S) => {
            let { teamDisplayName: b, userEmail: R, onErrorCallback: B } = S;
            const [ae, ge] = (0, t.useState)(),
              le = (0, n.d4)(fe.WR),
              Ce = (0, n.d4)(We.ZT),
              {
                data: Pe,
                loading: re,
                error: De,
                refetch: Q,
              } = (0, Ze.L)({
                fetcher: dt,
                args: {
                  reason: "qr-code-signin",
                },
              }),
              ue = (Pe == null ? void 0 : Pe.magic_login_url) || "",
              ke = (0, t.useCallback)(
                (0, de.coroutine)(function* () {
                  const Oe = yield Fe(
                    `${ue}?src=qr_code&user_id=${le}&team_id=${Ce}`
                  );
                  ge(Oe);
                }),
                [ue, le, Ce]
              ),
              Ke = rt.rt(
                "You\u2019re signing in as <b>{userEmail}</b>.",
                {
                  userEmail: R,
                },
                (Oe) => {
                  let { tag: vt, text: pt } = Oe;
                  return vt === "b"
                    ? t.createElement("strong", null, pt)
                    : null;
                }
              );
            return (
              (0, t.useEffect)(() => {
                ue && ke();
              }, [ke, ue]),
              re
                ? t.createElement(
                    "div",
                    {
                      className: "p-qr_code_signin_modal__qr_code_wrapper",
                      "data-qa": "qr-code-signin-loading-wrapper",
                    },
                    t.createElement(Le.A, {
                      color: "blue",
                      size: "jumbo",
                      loadingMessage: "generating QR code",
                    })
                  )
                : De
                ? (B(),
                  t.createElement(
                    "div",
                    {
                      className:
                        "p-qr_code_signin_modal__qr_code_wrapper p-qr_code_signin_modal__qr_code--error",
                      "data-qa": "qr-code-signin-error-wrapper",
                    },
                    t.createElement(
                      Ye.A,
                      {
                        className: "p-qr_code_signin_modal__error_container",
                        size: "medium",
                      },
                      t.createElement(ye.A, {
                        className: "margin_auto",
                        title: rt.t("Error"),
                        primaryActionText: "Refresh QR code",
                        primaryActionDataQA: "refresh-qr-code",
                        onClickPrimaryAction: Q,
                        description: rt.t(
                          "Sorry, an error occurred while generating the QR code."
                        ),
                      })
                    ),
                    t.createElement("img", {
                      alt: "",
                      className: "p-mobile_download_modal__robot_img",
                      src: at(),
                    })
                  ))
                : t.createElement(
                    "div",
                    {
                      className: "p-qr_code_signin_modal__qr_code_wrapper",
                    },
                    ae &&
                      t.createElement(
                        t.Fragment,
                        null,
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-qr_code_signin_modal__qr_code_image--wrapper",
                          },
                          t.createElement("img", {
                            alt: rt.t(
                              "Quick Response (QR) code to sign in to workspace on the Slack mobile app"
                            ),
                            className: "p-qr_code_signin_modal__qr_code--image",
                            "data-qa": "qr-code-signin-link-image",
                            src: ae,
                          })
                        ),
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-qr_code_signin_modal__qr_code_workspace_name",
                          },
                          b
                        ),
                        R &&
                          t.createElement(
                            "div",
                            {
                              className: "margin_top_125",
                            },
                            Ke
                          )
                      )
                  )
            );
          }, "MagicLoginQrCode");
        Lt.displayName = "MagicLoginQrCode";
        const mn = Lt;
        var un = e(8276911661),
          En = e(8170643398);
        const yt = new D.Ay("mobile_app_promos"),
          pn = c(() => {
            const S = (0, O.wA)();
            let b = null;
            const [R, B] = (0, t.useState)(!1),
              ae = (0, t.useCallback)(() => {
                S((0, K.O)()),
                  b == null ||
                    b({
                      action: o.UiAction.CLOSE,
                      elementName: "close_qr_code_signin_modal",
                    });
              }, [S, b]),
              ge = (0, t.useCallback)(() => {
                B(!0);
              }, [B]),
              le = (0, n.d4)(m.H7),
              Ce = (0, v.F1)(le),
              Pe = (0, n.d4)(fe.WR),
              re = (0, n.d4)((ue) => (0, un.nv)(ue, Pe)),
              De = (0, En.zY)(re),
              Q = yt.t("Sign in to {teamDisplayName} on mobile", {
                teamDisplayName: Ce,
              });
            return t.createElement(
              Z.A,
              {
                eventId: o.EventId.EDUCATION_QR_CODE_SIGNIN,
                uiStep: o.UiStep.QR_CODE_SIGNIN_MODAL,
                trackClogRef: (ue) => {
                  b = ue;
                },
              },
              t.createElement(
                $.A,
                {
                  contentLabel: Q,
                  closeModal: ae,
                  isOpen: !0,
                  centered: !0,
                  dataQa: "qr-code-signin-modal",
                  className: "p-qr_code_signin_modal",
                  describedby: "qr-code-signin-modal-described-by-label",
                },
                t.createElement(
                  _e.rQ,
                  null,
                  t.createElement(mn, {
                    teamDisplayName: Ce,
                    onErrorCallback: ge,
                    userEmail: De,
                  })
                ),
                !R &&
                  t.createElement(
                    _e.$m,
                    null,
                    t.createElement(_e.Rc, {
                      title: Q,
                      className: "p-qr_code_signin_modal__title",
                    }),
                    t.createElement(
                      _e.qf,
                      {
                        className: "p-qr_code_signin_modal__content_section",
                      },
                      t.createElement(
                        "span",
                        {
                          hidden: !0,
                          id: "qr-code-signin-modal-described-by-label",
                        },
                        yt.t(
                          "Scan Quick Response (QR) code to sign in to workspace on mobile by following these 4 steps."
                        )
                      ),
                      t.createElement(
                        "p",
                        null,
                        yt.t("To access this workspace on your phone:")
                      ),
                      t.createElement(
                        "ol",
                        null,
                        t.createElement(
                          "li",
                          null,
                          yt.t(
                            "Open Slack on your mobile device. From the home tab, swipe right.",
                            {
                              fallbackHash:
                                "6d5c50550323dc0d497d39864b434da8a004e50e",
                            }
                          )
                        ),
                        t.createElement(
                          "li",
                          null,
                          yt.rt(
                            "Tap <strong>Add a workspace</strong> at the bottom of the pane."
                          )
                        ),
                        t.createElement(
                          "li",
                          null,
                          yt.rt(
                            "Tap <strong>Sign in to another workspace</strong> at the bottom of the list.",
                            {
                              fallbackHash:
                                "d07a17677cdcbc15745eb4eaceb7a02fe436ffe8",
                            }
                          )
                        ),
                        t.createElement(
                          "li",
                          null,
                          yt.rt("Tap <strong>Scan QR Code.</strong>")
                        )
                      )
                    )
                  )
              )
            );
          }, "QRCodeSigninModal");
        pn.displayName = "QRCodeSigninModal";
        const gn = pn;
        var lt = e(2375333597);
        function en() {
          return (
            (en =
              Object.assign ||
              function (S) {
                for (var b = 1; b < arguments.length; b++) {
                  var R = arguments[b];
                  for (var B in R)
                    Object.prototype.hasOwnProperty.call(R, B) && (S[B] = R[B]);
                }
                return S;
              }),
            en.apply(this, arguments)
          );
        }
        c(en, "open_qr_code_signin_menu_item_extends");
        const tn = new D.Ay("classic_nav"),
          nn = {
            onClick: {
              enableClogAction: !0,
            },
          },
          jt = c((S) => {
            let { teamDisplayName: b, showInSubMenu: R = !1, ...B } = S;
            const ae = (0, O.wA)();
            let ge = tn.rt("Sign in on mobile", {
              teamDisplayName: b,
            });
            return (
              R &&
                (ge = tn.rt("Scan QR code", {
                  fallbackHash: "e7d8c30678ab2dafeb1e17cf2c302dca8a218c36",
                  fallbackHashNs: "mobile_app_promos",
                })),
              t.createElement(
                Z.A,
                {
                  eventId: o.EventId.EDUCATION_QR_CODE_SIGNIN,
                  uiStep: o.UiStep.MAIN_MENU,
                  clogImpression: !0,
                },
                t.createElement(
                  ee.A,
                  en({}, B, {
                    "data-qa": "qr-code-signin-menu-item",
                    onSelected: () =>
                      ae(
                        (0, lt.q)({
                          element: t.createElement(gn, null),
                        })
                      ),
                    label: ge,
                    autoClogProps: nn,
                  })
                )
              )
            );
          }, "OpenQrCodeSigninMenuItem");
        jt.displayName = "OpenQrCodeSigninMenuItem";
        const yn = (0, ze.Ay)(jt);
        var Ie = e(3245843483),
          Ge = e(5267010247),
          an = e(8822892075),
          An = e(5603851674),
          sn = e(1206744593),
          Cn = e(7148679525),
          Dn = e(371109550),
          Dt = e(1632876296),
          ds = e(7763544542),
          ms = e(9026698167),
          us = e(7112191091),
          Es = e(7589743571),
          la = e(3559837422),
          ps = e(5169892262),
          gs = e(6693783993),
          As = e(235108050);
        const Cs = c((S) => {
          if ((0, la.sV)(S)) return [];
          const b = (0, gs.yw)(S),
            R = (0, ps.DH)(S, "stats_only_admins");
          return (0, As.A)([...R, ...b]);
        }, "getWorkspaceIdsOnWhichUserCanAccessWorkspaceAnalyticsInTeamSite");
        var hs = e(5651018374),
          Ps = e(1680890044),
          vs = e(9697101230),
          fs = e(7045483416),
          ia = e(5510392579),
          Os = e(7717529491),
          Is = e(5338283246),
          Ms = e(5934889916),
          Ts = e(9225229866),
          ca = e(2689960678),
          ys = e(5112543963),
          Sn = e(571104883),
          Ds = e(322597465),
          Ss = e(3707193570),
          _a = e(160660242),
          Ns = e(529182726),
          da = e(6280700824),
          Rs = e(9391594207),
          Ls = e(12753e4),
          ma = e(7138682671),
          ua = e(2219904496),
          ks = e(8739505998),
          Ea = e(3165300465),
          pa = e(581167618);
        const it = new D.Ay("rename_team_in_client"),
          Vt = {
            EditWorkspaceInfoModalContent: "edit_workspace_info_modal_content",
            EditWorkspaceInfoModalCancelButton:
              "edit_workspace_info_modal_cancel_button",
            EditWorkspaceInfoModalSaveButton:
              "edit_workspace_info_modal_save_button",
            EditWorkspaceInfoModalError: "edit_workspace_info_modal_error",
            EditWorkspaceInfoModalTeamNameInput:
              "edit_workspace_info_modal_team_name_input",
            EditWorkspaceInfoModalDomainInput:
              "edit_workspace_info_modal_domain_input",
          };
        var Ot;
        (function (S) {
          (S.OpenedEditWorkspaceInfoModal = "edit_workspace_info_opened_modal"),
            (S.RenamedTeam = "edit_workspace_info_renamed_team"),
            (S.ChangedUrl = "edit_workspace_info_changed_url"),
            (S.UpdatedBoth =
              "edit_workspace_info_renamed_team_and_changed_url"),
            (S.FailedRenameTeam = "edit_workspace_info_failed_rename_team"),
            (S.FailedChangeUrl = "edit_workspace_info_failed_change_url"),
            (S.FailedBoth =
              "edit_workspace_info_failed_rename_team_and_change_url"),
            (S.ClickedCustomizeIcon = "edit_workspace_info_click_change_icon");
        })(Ot || (Ot = {}));
        var wt;
        (function (S) {
          (S.EditWorkspaceInfoModal = "edit-workspace-info-modal"),
            (S.EditWorkspaceInfoEditUrlLink =
              "edit-workspace-info-edit-url-link"),
            (S.EditWorkspaceInfoModalSubmit = "edit-workspace-info-submit"),
            (S.EditWorkspaceInfoModalCancel = "edit-workspace-info-cancel");
        })(wt || (wt = {}));
        const Us = {
            elementName: wt.EditWorkspaceInfoEditUrlLink,
            onClick: {
              enableClogAction: !0,
            },
          },
          Bs = {
            elementName: wt.EditWorkspaceInfoModalCancel,
            onClick: {
              enableClogAction: !0,
            },
          },
          Nn = {
            elementName: wt.EditWorkspaceInfoModalSubmit,
            isPrimaryCTA: !0,
            onClick: {
              enableClogAction: !0,
            },
            isRenamingWorkspace: !1,
            isChangingUrl: !1,
          },
          bs = /^[a-z0-9-.-]*$/,
          Ws = /^[a-z0-9]/i,
          ga = 21,
          Aa = 50,
          Ca = c((S) => {
            let {
              updateWorkspaceInfo: b,
              closeModal: R,
              currentWorkspaceDomain: B,
              currentWorkspaceName: ae,
              teamRootDomain: ge,
              telemeter: le,
            } = S;
            const [Ce, Pe] = (0, t.useState)(""),
              [re, De] = (0, t.useState)(!1),
              [Q, ue] = (0, t.useState)(ae),
              [ke, Ke] = (0, t.useState)(B);
            (0, t.useEffect)(() => {
              le.count(Ot.OpenedEditWorkspaceInfoModal);
            }, [le]);
            const Oe = (0, t.useCallback)(
                (ut) => {
                  Ce && Pe(""), ue(ut);
                },
                [Ce, ue]
              ),
              vt = (0, t.useCallback)(
                (ut) => {
                  Ce && Pe(""), Ke(ut);
                },
                [Ce, Ke]
              ),
              pt = (0, t.useCallback)(() => {
                le.count(Ot.ClickedCustomizeIcon);
              }, [le]),
              mt = (0, t.useCallback)(() => {
                De(!0);
                const ut = Q !== ae ? Q : void 0,
                  Gt = ke !== B ? ke : void 0;
                let ft, Ut;
                ut && Gt
                  ? ((ft = Ot.UpdatedBoth), (Ut = Ot.FailedBoth))
                  : ut
                  ? ((ft = Ot.RenamedTeam), (Ut = Ot.FailedRenameTeam))
                  : ((ft = Ot.ChangedUrl), (Ut = Ot.FailedChangeUrl)),
                  b({
                    name: ut,
                    url: Gt,
                    reason: "rename_team_modal",
                  })
                    .then(() => {
                      le.count(ft), R();
                    })
                    .catch((ie) => {
                      var tt, gt, Bt;
                      le.count(Ut),
                        De(!1),
                        !(
                          ie == null ||
                          (tt = ie.message) === null ||
                          tt === void 0
                        ) && tt.includes("bad_url")
                          ? Pe(
                              it.t(
                                "Your workspace URL can only contain lowercase letters, numbers and dashes. It must contain at least one letter. It may not start or end with a dash."
                              )
                            )
                          : !(
                              ie == null ||
                              (gt = ie.message) === null ||
                              gt === void 0
                            ) && gt.includes("taken_url")
                          ? Pe(
                              it.t(
                                "That URL is unavailable. Please choose another."
                              )
                            )
                          : !(
                              ie == null ||
                              (Bt = ie.message) === null ||
                              Bt === void 0
                            ) && Bt.includes("team_name_too_long")
                          ? Pe(
                              it.t("That workspace name is too long. ", {
                                fallbackHash:
                                  "933690ea9d6ea311cd62c266cf3e6557da70df90",
                                fallbackHashNs: "message",
                              })
                            )
                          : Pe(
                              it.t(
                                "Something went wrong trying to update your workspace information. Please try again."
                              )
                            );
                    });
              }, [De, Q, ae, ke, B, R, b, le]);
            let Me;
            bs.test(ke)
              ? Ws.test(ke) ||
                (Me = it.t(
                  "Your workspace URL must start with a letter or number."
                ))
              : (Me = it.t(
                  "Your workspace URL can only contain lowercase letters, numbers and dashes."
                ));
            const Zt =
              !Q ||
              !ke ||
              (Q === ae && ke === B) ||
              ke.length > ga ||
              Q.length > Aa ||
              !!Me;
            (Nn.isRenamingWorkspace = Q !== ae && !!Q),
              (Nn.isChangingUrl = ke !== B && !!ke);
            const Ft = "edit_workspace_modal_title";
            return t.createElement(
              Z.A,
              {
                elementName: wt.EditWorkspaceInfoModal,
                elementType: o.ElementType.MODAL,
              },
              t.createElement(
                _e.dW,
                {
                  closeModal: R,
                  "data-qa": Vt.EditWorkspaceInfoModalContent,
                  labelledby: Ft,
                },
                t.createElement(
                  _e.rQ,
                  {
                    id: Ft,
                  },
                  t.createElement(_e.Rc, {
                    title: it.t("Edit workspace details"),
                  })
                ),
                t.createElement(
                  _e.$m,
                  null,
                  t.createElement(
                    _e.qf,
                    null,
                    t.createElement(
                      "div",
                      {
                        className: "margin_bottom_75",
                      },
                      it.t(
                        "Add a name to represent your company or organization. This name will also be shown to other organizations that you work with using Slack."
                      )
                    ),
                    t.createElement(
                      ma.A,
                      {
                        text: it.t("Workspace name"),
                        htmlFor: "desiredTeamName",
                      },
                      t.createElement(ua.A, {
                        id: "desiredTeamName",
                        name: "desiredTeamName",
                        value: Q,
                        onChange: Oe,
                        maxCharacterLimit: Aa,
                        "data-qa": Vt.EditWorkspaceInfoModalTeamNameInput,
                        autoFocus: !0,
                      })
                    ),
                    t.createElement(
                      ma.A,
                      {
                        text: it.t("URL"),
                        htmlFor: "desiredDomain",
                      },
                      t.createElement(ua.A, {
                        id: "desiredDomain",
                        name: "desiredDomain",
                        value: ke,
                        onChange: vt,
                        hintText: it.t(
                          "Your workspace URL can only contain lowercase letters, numbers and dashes. It must contain at least one letter. It may not start or end with a dash."
                        ),
                        prefix: "https://",
                        suffix: `.${ge}`,
                        maxCharacterLimit: ga,
                        errorText: Me,
                        "data-qa": Vt.EditWorkspaceInfoModalDomainInput,
                      })
                    ),
                    Ce &&
                      t.createElement(
                        pa.Ay,
                        {
                          level: "error",
                          "data-qa": Vt.EditWorkspaceInfoModalError,
                        },
                        Ce
                      )
                  )
                ),
                t.createElement(
                  _e.jl,
                  null,
                  t.createElement(
                    "div",
                    {
                      className: "p-rename_team_modal_edit_url_link",
                    },
                    t.createElement(
                      ks.A,
                      {
                        href: "/customize/icon",
                        autoClogProps: Us,
                        onClick: pt,
                      },
                      it.t("Edit Workspace Icon")
                    )
                  ),
                  t.createElement(
                    _e.ox,
                    {
                      className: "display_flex",
                    },
                    t.createElement(
                      T.Ay,
                      {
                        onClick: R,
                        type: "outline",
                        "data-qa": Vt.EditWorkspaceInfoModalCancelButton,
                        autoClogProps: Bs,
                      },
                      it.t("Cancel")
                    ),
                    t.createElement(
                      Ea.A,
                      {
                        loading: re,
                        "data-qa": Vt.EditWorkspaceInfoModalSaveButton,
                        disabled: Zt,
                        onClick: mt,
                        autoClogProps: Nn,
                        "aria-label": it.t("Save"),
                      },
                      it.t("Save")
                    )
                  )
                )
              )
            );
          }, "EditWorkspaceInfoModal");
        Ca.displayName = "EditWorkspaceInfoModal";
        const xs = c((S) => {
            const b = (0, m.H7)(S);
            var R;
            return {
              currentWorkspaceDomain:
                (R = (0, v.Ic)(b)) !== null && R !== void 0 ? R : "",
              currentWorkspaceName: (0, v.F1)(b),
              teamRootDomain: (0, v.S5)(b),
              telemeter: (0, ve.Cy)({
                state: S,
              }),
            };
          }, "mapStateToProps"),
          Ks = c(
            (S) => ({
              closeModal: () => S((0, K.O)()),
              updateWorkspaceInfo: (b) => S((0, Ls.j)(b)),
            }),
            "mapDispatchToProps"
          ),
          Hs = (0, Rs.N)(xs, Ks)(Ca),
          ha = (0, xe.Ay)("Opens the rename team modal in the client", (S) => {
            S(
              (0, lt.q)({
                element: t.createElement(Hs, null),
              })
            );
          });
        ha.meta = {
          name: "createThunk",
          key: "createThunkopenRenameTeamModal",
          description: "Opens the rename team modal in the client",
        };
        const Pa = ha;
        var Fs = e(6533394955),
          kt = e(716227588),
          Rn = e(6473974991);
        function on() {
          return (
            (on =
              Object.assign ||
              function (S) {
                for (var b = 1; b < arguments.length; b++) {
                  var R = arguments[b];
                  for (var B in R)
                    Object.prototype.hasOwnProperty.call(R, B) && (S[B] = R[B]);
                }
                return S;
              }),
            on.apply(this, arguments)
          );
        }
        c(on, "home_header_menu_extends");
        const ne = new D.Ay("ia4"),
          Gs = new D.Ay("classic_nav"),
          zs = {
            [q.ze.WORKSPACE_MENU_UPGRADE_ITEM]: {
              component: t.lazy(() =>
                Promise.resolve().then(e.bind(e, 6761947926))
              ),
            },
          },
          va = c((S) => {
            let { menuProps: b } = S;
            const R = (0, O.wA)(),
              B = (0, n.d4)(
                (F) =>
                  (0, J._Z)(F, "ia4_admin_and_settings_translations") === "on"
              ),
              ae = (0, n.d4)(
                (F) => (0, J._Z)(F, "idsc_exports_admin_role_fe") === "on"
              ),
              ge =
                (0, n.d4)((F) => (0, J._Z)(F, "idsc_exports_admin_role_fe")) ===
                "on",
              le =
                (0, n.d4)((F) => (0, J._Z)(F, "flag_message_admin_dash")) ===
                "on",
              Ce = (0, n.d4)((F) => (0, J._Z)(F, "native_dlp_canvas") === "on"),
              Pe = (0, n.d4)((F) => (0, J._Z)(F, "audit_logs_client") === "on"),
              re = (0, n.d4)(sn.NH),
              De = (0, n.d4)(sn.pV),
              Q = (0, n.d4)(
                (F) => (0, J._Z)(F, "integrations_admin_system_role") === "on"
              ),
              ue = (0, n.d4)(
                (F) => (0, J._Z)(F, "deprecate_email_signin") === "on"
              ),
              ke = (0, n.d4)(
                (F) => (0, J._Z)(F, "sfdc_seamless_auth_fe") === "on"
              ),
              Ke = (0, n.d4)(
                (F) =>
                  (0, J._Z)(F, "filter_conversations_menu_updates") === "on"
              ),
              Oe = (0, n.d4)(m.H7);
            var vt;
            const pt =
                (vt = (0, v.ZT)(Oe)) !== null && vt !== void 0 ? vt : void 0,
              mt = (0, v.F1)(Oe),
              Me = (0, v.Zl)(Oe),
              Zt = (0, n.d4)(Cn.Lz),
              Ft = (0, n.d4)(Ps.W),
              ut = (0, n.d4)(ia.PY),
              Gt = (0, n.Z2)(us.Fm),
              ft = (0, n.d4)(ia.p2),
              Ut = (0, n.d4)(Os.k),
              ie = (0, v.r7)(Oe),
              tt = (0, Ss.JV)(pt),
              gt = (0, n.d4)(Ms.t_),
              Bt = (0, n.d4)(Dn.U),
              fn = ut,
              Bn = (0, n.d4)(ms.U),
              Ve = (0, n.d4)(Is.IF),
              bo = (0, n.d4)(An.h),
              Wo = (0, n.d4)(Dt.xk),
              xo = (0, n.d4)(Dt.zi),
              Ko = (0, n.d4)(Dt.p4),
              Ho = (0, n.d4)(Dt.zd),
              Fo = (0, n.d4)(ds.S),
              Go = (0, n.d4)(Dt.oM),
              zo = (0, n.d4)(Dt.Ak),
              Yo = (0, v.qR)(Oe),
              jo = (0, n.d4)((F) => (0, M.ty)(F, "purchaser")),
              Fa = (0, n.d4)(v.FH),
              bn = (0, n.d4)(Es.N),
              Wn = (0, n.d4)(hs.g),
              xn = ie ? ut : Yo && (ft || jo),
              Ga = `https://app.${(0, v.S5)(Oe)}/apps-manage/${
                Oe == null ? void 0 : Oe.id
              }/`,
              $t = ft && !ie,
              On = (0, n.d4)(A.ce),
              Kn = (0, n.d4)((F) => (0, M.ty)(F, "sidebar_behavior")),
              Vo = (0, n.d4)(la.sV),
              Hn = (0, n.d4)(Dt.B9),
              wo = (0, n.d4)(Dt.wF),
              Xo = (0, n.d4)(Dt.lN),
              Fn = (0, n.Z2)(Cs),
              Gn = Fn.length > 0,
              zn = (0, n.d4)(fs._),
              za = ne.rt("Tools & settings"),
              Ya = ne.rt("Tools"),
              ja = ne.rt("Settings"),
              rn = Gt.length > 0,
              ln = rn || (ie && fn),
              Yn = !Vo && (rn || bn.length > 0 || Wn.length > 0),
              jn = Bt,
              Zo = (0, n.d4)(vs.M),
              Vn = Q && tt ? Zo : Ut,
              $o = Bn,
              wn = Ve,
              Xn = ae && bo,
              Zn = ge && Wo,
              $n = le && xo,
              Qn = Ce && Ko,
              Jn = Pe && Fo,
              qn = Ho,
              ea = (tt && Go) || (!tt && zo),
              ta =
                jn ||
                Vn ||
                xn ||
                $o ||
                wn ||
                Xn ||
                Zn ||
                $n ||
                zn ||
                Jn ||
                qn ||
                Qn ||
                ea,
              Va = ln || ta,
              na = !!(0, n.d4)((F) =>
                (0, kt.Hp)(F, q.xu.WORKSPACE_MENU_SECONDARY_PLAN_INFO)
              ),
              Qo = !!(0, n.d4)((F) =>
                (0, kt.Hp)(F, q.xu.WORKSPACE_MENU_PRIMARY_PLAN_INFO)
              ),
              aa = !ie && Qo,
              sa = !!(0, n.d4)(
                (F) =>
                  (0, kt.Hp)(F, q.xu.WORKSPACE_MENU_UPSELL) && !(0, Ie.Z9F)()
              ),
              Jo = (0, n.d4)((F) => (0, kt.Hp)(F, q.xu.MAIN_MENU)),
              oa = (0, n.d4)((F) => (0, kt.OL)(F, q.xu.MAIN_MENU)),
              In = Jo === q.ze.PERSISTENT_MOBILE_PROMO,
              cn = oa == null ? void 0 : oa.signedInMobileOtherTeam,
              wa =
                (0, n.d4)((F) =>
                  (0, kt.Hp)(F, q.xu.WORKSPACE_MENU_PRIMARY_PLAN_INFO)
                ) === q.ze.STRAIGHT_TO_PAID_WORKSPACE_MENU_PRIMARY_TIME_LIMIT,
              Xa = (0, t.useCallback)(() => {
                R((0, da.A)());
              }, [R]),
              Za = (0, t.useCallback)(() => {
                R(
                  (0, Ns.A)({
                    source: Ts.K3.TeamMenu,
                  })
                );
              }, [R]),
              $a = (0, t.useCallback)(() => {
                R((0, K.O)());
              }, [R]),
              qo = (0, t.useCallback)(
                (F, je, _n) => () => {
                  R(
                    (0, lt.q)({
                      element: t.createElement(Te.A, {
                        adminRoute: F,
                        closeModal: $a,
                        title: je,
                        workspaceIds: _n,
                      }),
                    })
                  );
                },
                [$a, R]
              ),
              bt = tt ? qo : Se.A,
              St = (0, t.useCallback)(
                (F) => (tt ? void 0 : `${Me}${F}`),
                [Me, tt]
              );
            let Mn = `${Me}manage/analytics`;
            Xo && !wo && (Mn = `${Mn}/canvas`);
            const Qa =
                "customize?utm_source=in-prod&utm_medium=inprod-customize_link-slack_menu-click",
              ra =
                "apps/manage?utm_source=in-prod&utm_medium=inprod-apps_link-slack_menu-click",
              Ja = (0, t.useCallback)(
                () =>
                  Q
                    ? ie
                      ? `${Me}manage/integrations?utm_source=in-prod&utm_medium=inprod-apps_link-slack_menu-click`
                      : `${Me}${ra}`
                    : St(ra),
                [Me, Q, St, ie]
              ),
              zt = (0, t.useMemo)(() => {
                if (!Yn && !gt && !Gn && !Hn) return ca.Ml;
                const F = ne.t("Customize workspace");
                return [
                  {
                    label: F,
                    show: Yn,
                    click: bt(Qa, F, [...bn, ...Wn]),
                    href: St(Qa),
                    key: "customize-workspace",
                    showLinkIndicatorIcon: !1,
                  },
                  {
                    click: () => {
                      R(
                        re
                          ? (0, Ge.o)((0, an.x6)())
                          : (0, _a.A)({
                              source: "workspace_menu",
                              subPath: "",
                            })
                      );
                    },
                    label: ne.t("Workflow Builder"),
                    key: "launch-workflow-builder",
                    showLinkIndicatorIcon: !re,
                    show: gt,
                  },
                  {
                    click: () =>
                      R(
                        (0, _a.A)({
                          source: "workspace_menu",
                          subPath: "/workflows-v1",
                        })
                      ),
                    label: re
                      ? ne.t("Legacy Workflow Management")
                      : "Legacy Workflow Management",
                    key: "launch-legacy-workflow-management",
                    showLinkIndicatorIcon: !0,
                    show: !De && re && gt,
                  },
                  {
                    key: "workspace-analytics",
                    label: ne.t("Workspace analytics"),
                    click: bt("stats", ne.t("Workspace analytics"), Fn),
                    href: St("stats"),
                    show: Gn,
                  },
                  {
                    key: "org-analytics",
                    label: ne.t("Organization analytics"),
                    href: `${Mn}`,
                    show: Hn,
                  },
                ].filter((je) => ("show" in je ? je.show !== !1 : !0));
              }, [Yn, gt, Gn, Hn, bt, bn, Wn, St, re, De, Fn, Mn, R]),
              Wt = (0, t.useMemo)(() => {
                if (!Va) return ca.Ml;
                const F = ne.rt("Workspace settings");
                return [
                  {
                    label: F,
                    click: bt("admin/settings", F),
                    href: St("admin/settings"),
                    key: "workspace-settings",
                    showLinkIndicatorIcon: !1,
                    show: rn,
                  },
                  {
                    label: ne.t("Edit workspace details", {
                      fallbackHash: "77c33adfdac1c3ccaa95abf3a1c1a42c99935e68",
                      fallbackHashNs: "classic_nav",
                    }),
                    show: $t,
                    click: () => R(Pa()),
                    key: "edit-workspace-details",
                  },
                  {
                    label: ne.rt(
                      "Organization settings \u2013 {teamDisplayName}",
                      {
                        fallbackHash:
                          "89a2060bc73faa1446542140fe7536e0d41b726b",
                        teamDisplayName: mt,
                      }
                    ),
                    href: `${Me}manage`,
                    key: "organization-settings",
                    showLinkIndicatorIcon: !1,
                    show: tt && ut,
                  },
                  {
                    type: a.y.separator,
                    key: "settings-administration-separator",
                    show: ln,
                  },
                  {
                    type: a.y.header,
                    label: ne.t("Administration"),
                    key: "administration",
                    show: ta,
                  },
                  {
                    label: ke
                      ? ne.t("Manage Salesforce Organizations")
                      : ne.t("Manage Salesforce organizations"),
                    href: ie
                      ? `${Me}manage/salesforce/organizations`
                      : `${Me}admin/salesforce-organizations`,
                    key: "manage-salesforce-organizations",
                    showLinkIndicatorIcon: !1,
                    show: ea,
                  },
                  {
                    label: ne.t("Manage Slack Connect Invitations"),
                    show: jn,
                    href:
                      ie && Ft
                        ? `${Me}manage/slack-connect/requests-pending-invites`
                        : `${Fa}admin/slack-connect-invitations`,
                    key: "manage-slack-connect-invitations",
                    dataQa:
                      "main_menu_settings_submenu_manage_slack_connect_invitations",
                    showLinkIndicatorIcon: !1,
                  },
                  {
                    label: ne.rt("Manage members"),
                    click: bt(
                      "admin",
                      B
                        ? ne.rt("Manage workspace members")
                        : ne.rt("Manage members")
                    ),
                    href: St("admin"),
                    key: "manage-members",
                    showLinkIndicatorIcon: !1,
                    show: rn,
                  },
                  {
                    label: B ? ne.rt("Manage roles") : ne.rt("Manage Roles"),
                    click: bt(
                      "admin/roles",
                      B
                        ? ne.rt("Manage workspace roles")
                        : ne.rt("Manage Roles")
                    ),
                    href: St("admin/roles"),
                    key: "manage-roles",
                    showLinkIndicatorIcon: !1,
                    show: wn,
                  },
                  {
                    label: ne.rt("Manage apps"),
                    click: Q
                      ? Se.A
                      : bt(
                          ra,
                          B
                            ? ne.rt("Manage workspace apps")
                            : ne.rt("Manage apps")
                        ),
                    href: Ja(),
                    key: "manage-apps",
                    showLinkIndicatorIcon: !1,
                    show: Vn,
                  },
                  {
                    label: ne.rt("Manage workflows"),
                    href: ie
                      ? `${Me}manage/integrations/workflows`
                      : `${Ga}integrations/workflows`,
                    key: "manage-workflows",
                    showLinkIndicatorIcon: !1,
                    show: zn,
                  },
                  {
                    label: ne.rt("Manage legal holds"),
                    href: `${Me}manage/security/legal-holds`,
                    key: "manage-legal-holds",
                    showLinkIndicatorIcon: !1,
                    show: qn,
                  },
                  {
                    label: ae ? ne.t("Manage exports") : "",
                    href: `${Me}manage/security/exports`,
                    key: "manage-exports-admin",
                    showLinkIndicatorIcon: !1,
                    show: Xn,
                  },
                  {
                    label: ge ? ne.t("Manage security") : "",
                    href: `${Me}manage/security`,
                    key: "manage-security-admin",
                    showLinkIndicatorIcon: !1,
                    show: Zn,
                  },
                  {
                    label: Pe ? ne.t("Manage Audit Logs") : "",
                    href: ie
                      ? `${Me}manage/security/audit-logs`
                      : `${Me}admin/audit_logs`,
                    key: "manage-audit-logs-admin",
                    showLinkIndicatorIcon: !1,
                    show: Jn,
                  },
                  {
                    label: Ce ? ne.t("Manage DLP") : "",
                    href: `${Me}manage/security/dlp`,
                    key: "manage-dlp-admin",
                    showLinkIndicatorIcon: !1,
                    show: Qn,
                  },
                  {
                    label: le ? ne.t("Manage content") : "",
                    href: `${Me}manage/security/flagged-content`,
                    key: "manage-content-admin",
                    showLinkIndicatorIcon: !1,
                    show: $n,
                  },
                  {
                    label: ne.rt("Billing"),
                    href: ie ? `${Me}manage/billing` : `${Me}admin/billing`,
                    key: "billing",
                    showLinkIndicatorIcon: !1,
                    show: xn,
                  },
                ];
              }, [
                Va,
                bt,
                St,
                rn,
                $t,
                mt,
                Me,
                tt,
                ut,
                ln,
                ta,
                jn,
                ie,
                Ft,
                B,
                wn,
                Q,
                Ja,
                Vn,
                Ga,
                zn,
                qn,
                ae,
                Xn,
                ge,
                Zn,
                Pe,
                Jn,
                Ce,
                Qn,
                le,
                $n,
                xn,
                R,
                ea,
                Fa,
                ke,
              ]),
              Qt = (0, t.useCallback)(() => {
                const F = "open-desktop-app";
                return [
                  {
                    type: a.y.custom,
                    ariaHidden: !1,
                    children: t.createElement(Mt, {
                      key: F,
                      showMobileEntryPoint: In,
                      teamUrl: Me,
                    }),
                    show: !(0, Sn.y3)() && !Re().chromeBook,
                    key: F,
                  },
                ];
              }, [Me, In]),
              Tn = (0, t.useCallback)(() => {
                if (ue) return [];
                const F = cn ? "sign-in-on-mobile" : "get-mobile-app";
                return [
                  {
                    type: a.y.custom,
                    ariaHidden: !1,
                    children: t.createElement(_t.Ay, {
                      spaceName: q.xu.MAIN_MENU,
                      notifications: ot,
                      key: F,
                      showExistingHumansMobileEntry: cn,
                    }),
                    show: !0,
                    key: F,
                  },
                ];
              }, [ue, cn]),
              Jt = (0, t.useCallback)(
                (F) => [
                  {
                    type: a.y.custom,
                    ariaHidden: !1,
                    children: t.createElement(yn, {
                      key: "qr-code-signin-mobile",
                      teamDisplayName: mt,
                      showInSubMenu: F,
                    }),
                    show: (0, Ds.O)(pt) !== ys.j.GOV,
                    key: "qr-code-signin-mobile",
                  },
                ],
                [mt, pt]
              ),
              qa = (0, t.useCallback)(
                () =>
                  ue
                    ? [
                        ...Qt(),
                        ...Tn(),
                        {
                          type: a.y.separator,
                          show: !0,
                          key: "sign-out-separator",
                        },
                        ...Jt(),
                      ]
                    : cn
                    ? [
                        ...Qt(),
                        {
                          label: Gs.rt("Sign in on mobile", {
                            fallbackHash:
                              "648468ff942deda0826e667407776fe77f12f76d",
                            teamDisplayName: mt,
                          }),
                          type: a.y.submenu,
                          key: "sign-in-mobile-submenu",
                          template: [...Jt(!0), ...Tn()],
                          show: !0,
                        },
                      ]
                    : [
                        ...Qt(),
                        ...Tn(),
                        {
                          type: a.y.separator,
                          show: !0,
                          key: "sign-out-separator",
                        },
                        ...Jt(),
                      ],
                [ue, cn, mt, Qt, Tn, Jt]
              ),
              es = c((F) => {
                switch (F) {
                  case r.UN:
                    return o.EventId.HOME_FILTER_ALL_ACTIVITY;
                  case r.nU:
                    return o.EventId.HOME_FILTER_UNREADS_ONLY;
                  case r.Ao:
                    return o.EventId.HOME_FILTER_MENTIONS_ONLY;
                  case r.eF:
                    return o.EventId.HOME_FILTER_CUSTOM_BY_SECTION;
                  case C.E7.All:
                    return o.EventId.HOME_FILTER_EVERYONE;
                  case C.E7.Internal:
                    return o.EventId.HOME_FILTER_WITHOUT_EXTERNAL;
                  case C.E7.External:
                    return o.EventId.HOME_FILTER_INCLUDE_EXTERNAL;
                  default:
                    return o.EventId.UNKNOWN;
                }
              }, "getClogEventIdForEntry"),
              ts = (0, t.useCallback)(function () {
                let F =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : C.E7.All,
                  je = null;
                switch (F) {
                  case C.E7.Internal:
                    je = ne.t("Without external people");
                    break;
                  case C.E7.External:
                    je = ne.t("Including external people");
                    break;
                  default:
                    je = ne.t("Everyone");
                }
                return je;
              }, []),
              ns = (0, t.useCallback)(
                (F) => {
                  R(
                    (0, d.UG)({
                      peopleFilter: {
                        type: F,
                      },
                    })
                  );
                },
                [R]
              ),
              as = (0, t.useMemo)(
                () => [C.E7.All, C.E7.Internal, C.E7.External],
                []
              ),
              ss = (0, t.useCallback)(() => {
                const F = On == null ? void 0 : On.type;
                return as.map((je) => ({
                  label: ts(je),
                  type: a.y.checkbox,
                  click: () => ns(je),
                  checked: (!F && je === C.E7.All) || F === je,
                  autoClogProps: {
                    onClick: {
                      enableClogAction: !0,
                    },
                    eventId: es(je),
                  },
                }));
              }, [ts, ns, On, as]),
              os = (0, t.useCallback)(
                (F) => {
                  R(
                    (0, y.AZ)({
                      pref: "sidebar_behavior",
                      value: F,
                    })
                  );
                },
                [R]
              ),
              rs = (0, t.useMemo)(() => [r.UN, r.nU, r.Ao, r.eF], []),
              ls = (0, t.useCallback)(function () {
                let F =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : r.UN,
                  je = null;
                switch (F) {
                  case r.nU:
                    je = ne.t("Unreads only");
                    break;
                  case r.Ao:
                    je = ne.t("Mentions only");
                    break;
                  case r.eF:
                    je = ne.t("Custom by section");
                    break;
                  default:
                    je = ne.t("All activity");
                }
                return je;
              }, []),
              is = (0, t.useCallback)(
                () => [
                  ...rs.map((F) => ({
                    label: ls(F),
                    type: a.y.checkbox,
                    click: () => os(F),
                    checked: (!Kn && F === r.UN) || Kn === F,
                    autoClogProps: {
                      onClick: {
                        enableClogAction: !0,
                      },
                      eventId: es(F),
                    },
                  })),
                ],
                [ls, os, Kn, rs]
              ),
              er = (0, t.useMemo)(() => {
                let F = za;
                zt.length && !Wt.length && (F = Ya),
                  !zt.length && Wt.length && (F = ja);
                const _n = [
                    {
                      children: t.createElement($e.A, {
                        key: "team-blurb-menu-item",
                        isMenuItem: $t,
                        ariaDescribedById: "team-blurb-text",
                      }),
                      type: $t ? void 0 : a.y.custom,
                      key: "team-blurb-menu-item",
                      click: () => ($t ? R(Pa()) : void 0),
                    },
                    {
                      type: a.y.separator,
                      key: "upsell-separator-top",
                      show: sa,
                    },
                    {
                      type: a.y.custom,
                      ariaHidden: !1,
                      children: t.createElement(_t.sl, {
                        key: "workspace-menu-upsell",
                        uiPage: o.UiPage.MAIN_MENU,
                        notifications: zs,
                        spaceName: q.xu.WORKSPACE_MENU_UPSELL,
                        showDescription: !0,
                      }),
                      key: "workspace-menu-upsell",
                      show: sa,
                    },
                    {
                      type: a.y.separator,
                      key: "primary-plan-info-separator-top",
                    },
                    {
                      type: a.y.custom,
                      ariaHidden: !1,
                      children: t.createElement(
                        _t.sl,
                        on(
                          {
                            key: "workspace-menu-primary-plan-info",
                          },
                          Kt
                        )
                      ),
                      key: "workspace-menu-primary-plan-info",
                      show: aa,
                    },
                    {
                      type: a.y.separator,
                      key: "primary-plan-info-separator-bottom",
                      show: aa && !wa,
                    },
                    {
                      type: a.y.custom,
                      ariaHidden: !1,
                      children: t.createElement(
                        _t.sl,
                        on(
                          {
                            key: "workspace-menu-secondary-plan-info",
                          },
                          ht
                        )
                      ),
                      key: "workspace-menu-secondary-plan-info",
                      show: na,
                    },
                    {
                      type: a.y.separator,
                      key: "secondary-plan-info-separator-bottom",
                      show: na,
                    },
                    {
                      label: ne.rt("Invite people to {teamDisplayName}", {
                        teamDisplayName: mt,
                      }),
                      click: Za,
                      show: Zt,
                      key: "invite-people",
                      autoClogProps: {
                        elementName: "team_menu_invite_people",
                        onClick: {
                          enableClogAction: !0,
                        },
                      },
                    },
                    {
                      type: a.y.separator,
                      show: Zt,
                      key: "invite-people-separator",
                    },
                    {
                      label: ne.rt("Preferences"),
                      click: Xa,
                      shortcut: (0, Sn.cX)() && (0, Sn.y3)() && "\u2318,",
                      key: "sidebar-preferences",
                    },
                    {
                      type: a.y.submenu,
                      label: Ke ? ne.rt("Filter sidebar") : "",
                      key: "filter-sidebar",
                      show: Ke,
                      template: [
                        {
                          type: a.y.submenu,
                          label: ne.rt("Activity"),
                          key: "filter-activity",
                          show: Ke,
                          template: is(),
                        },
                        {
                          type: a.y.submenu,
                          label: Ke ? ne.rt("People") : "",
                          key: "filter-people",
                          show: Ke,
                          template: ss(),
                        },
                      ].filter((xt) => ("show" in xt ? xt.show !== !1 : !0)),
                    },
                    {
                      label: F,
                      type: a.y.submenu,
                      show: zt.length > 0 || Wt.length > 0,
                      key: "tools-and-settings-submenu",
                      template: [
                        {
                          type: a.y.header,
                          label: ne.rt("Tools"),
                          show: zt.length > 0 && Wt.length > 0,
                          key: "tools-header",
                        },
                        ...zt,
                        {
                          type: a.y.separator,
                          show: zt.length > 0 && Wt.length > 0,
                          key: "tools-bottom-separator",
                        },
                        {
                          type: a.y.header,
                          label: ne.rt("Settings"),
                          show: ln && Wt.length > 0,
                          key: "settings-header",
                        },
                        ...Wt,
                      ].filter((xt) => ("show" in xt ? xt.show !== !1 : !0)),
                    },
                  ],
                  cs = {
                    label: ne.rt("Sign out"),
                    key: "sign-out",
                    shortcut: "",
                    click: () =>
                      (0, Fs.dispatchForClientStore)(
                        Rn.H === null || Rn.H === void 0
                          ? void 0
                          : (0, Rn.H)({
                              teamId: pt,
                            })
                      ),
                  },
                  _s = {
                    label: ne.rt("Join or leave workspaces", {
                      fallbackHash: "6f729817a58c0cb75dc807b9771f19119fced3cc",
                      fallbackHashNs: "enterprise_dashboard",
                    }),
                    show: ie,
                    key: "join-leave-workspaces",
                    href: Me,
                    click: () => {},
                  };
                return (
                  In
                    ? _n.push(
                        {
                          type: a.y.separator,
                          show: !0,
                          key: "native-apps-separator",
                        },
                        ...qa(),
                        _s,
                        cs
                      )
                    : _n.push(
                        {
                          type: a.y.separator,
                          key: "workspace-tools-separator",
                          show: !0,
                        },
                        ...Jt(),
                        _s,
                        cs,
                        ...Qt()
                      ),
                  _n.filter((xt) => ("show" in xt ? xt.show !== !1 : !0))
                );
              }, [
                za,
                zt,
                Wt,
                mt,
                sa,
                aa,
                na,
                Za,
                Zt,
                Xa,
                ln,
                In,
                Ya,
                ja,
                pt,
                qa,
                Jt,
                Qt,
                ie,
                Me,
                $t,
                R,
                wa,
                is,
                ss,
                Ke,
              ]);
            return t.createElement(
              u.a,
              on({}, b, {
                menuClassNames: "p-ia4_home_header_menu__menu",
                "aria-label": ne.t("{teamDisplayName} Actions", {
                  teamDisplayName: mt,
                  fallbackHash: "f0b9c8a7e7825e826adb6a5ac5e29ee7ae2281a2",
                }),
                template: er,
              })
            );
          }, "HomeHeaderMenu");
        va.displayName = "HomeHeaderMenu";
        const fa = c(() => {
          const S = (0, t.useCallback)(
              (B) =>
                t.createElement(va, {
                  menuProps: B,
                }),
              []
            ),
            b = (0, n.d4)(m.H7),
            R = (0, v.F1)(b);
          return t.createElement(
            u.cQ,
            {
              renderMenu: S,
              position: "bottom-left",
            },
            t.createElement(
              T.Nm,
              {
                className: "p-ia4_home_header_menu__button",
                "aria-label": ne.t("{teamDisplayName} Actions", {
                  teamDisplayName: R,
                  fallbackHash: "f0b9c8a7e7825e826adb6a5ac5e29ee7ae2281a2",
                }),
                "data-qa": "workspace_actions_button",
              },
              t.createElement(
                "span",
                {
                  className: "p-ia4_home_header_menu__team_name",
                },
                R
              ),
              t.createElement(h.A, {
                name: "caret-down",
                "aria-label": "caret-down",
              })
            )
          );
        }, "HomeHeaderMenuTrigger");
        fa.displayName = "HomeHeaderMenuTrigger";
        const nr = null;
        var Ys = e(5055839243),
          Ln = e(5734745215),
          js = e(1427522952),
          Vs = e(8029613601),
          Oa = e(4947127560),
          Ia = e(4636370173),
          Ma = e(8523371695),
          Ta = e(3606117573),
          ya = e(3602521375),
          Da = e(5737676300),
          ws = e(8285458961),
          hn = e(2409757433),
          Sa = e(320067417),
          Xs = e(6690200241),
          Zs = e(1320149267),
          $s = e(2683115972);
        const Xt = new Ln.Ay("salesforce_connections"),
          Na = c((S) => {
            let {
              orgs: b,
              mainText: R,
              closeDialog: B,
              setNextStep: ae,
              dismissSignInReminder: ge,
            } = S;
            const le = (0, n.d4)(
                (Ke) => (0, J._Z)(Ke, "sfdc_seamless_auth_fe") === "on"
              ),
              [Ce, Pe, re] = (0, Xs.q)(),
              [De, Q] = (0, t.useState)(""),
              ue = (0, t.useCallback)(() => {
                const {
                  salesforce_org_id: Ke = "",
                  name: Oe = "",
                  app_id: vt = "",
                  provider_key: pt = "",
                } = b.find((mt) => mt.salesforce_org_id === De) || {};
                re(
                  {
                    appId: vt,
                    providerKey: pt,
                    salesforceOrgId: Ke,
                  },
                  () =>
                    ae({
                      orgName: Oe,
                    })
                );
              }, [re, b, De, ae]),
              ke = (0, t.useCallback)(() => {
                ge(), B();
              }, [B, ge]);
            return t.createElement(
              t.Fragment,
              null,
              t.createElement(
                Vs.A,
                null,
                t.createElement(Oa.A, {
                  title: le
                    ? Xt.t("Sign in to a Salesforce org")
                    : "Sign in to a Salesforce org",
                })
              ),
              t.createElement(
                Ia.A,
                null,
                t.createElement(
                  Sa.a,
                  {
                    paddingInline: "150",
                  },
                  t.createElement(
                    Da.B,
                    {
                      space: "150",
                    },
                    Pe &&
                      t.createElement(
                        pa.Ay,
                        {
                          type: "boxed",
                          level: "error",
                          icon: "info-circle",
                          heading: le
                            ? Xt.t(
                                "There was a problem requesting your Salesforce connection"
                              )
                            : "There was a problem requesting your Salesforce connection",
                        },
                        (0, Zs.Q)()
                      ),
                    R &&
                      t.createElement(
                        hn.E,
                        {
                          as: "p",
                        },
                        R
                      ),
                    t.createElement(ws.v, {
                      defaultCheckedOrgId: De,
                      orgs: b,
                      onOrgSelect: Q,
                    }),
                    t.createElement(
                      hn.E,
                      {
                        color: "Core/Content/Secondary",
                        size: "caption",
                      },
                      le
                        ? Xt.t(
                            "To sign in to orgs not listed here, contact your admin."
                          )
                        : "To sign in to orgs not listed here, contact your admin."
                    )
                  )
                )
              ),
              t.createElement(
                Ma.A,
                null,
                t.createElement(
                  $s.Ay,
                  {
                    type: "outline",
                    onClick: ke,
                  },
                  le
                    ? Xt.t("Dismiss Sign In Reminder")
                    : "Dismiss Sign In Reminder"
                ),
                t.createElement(
                  Ta.A,
                  null,
                  t.createElement(
                    ya.A,
                    {
                      onClick: B,
                      type: "outline",
                    },
                    le ? Xt.t("Not Now") : "Not Now"
                  ),
                  t.createElement(
                    Ea.A,
                    {
                      loading: Ce,
                      type: "primary",
                      disabled: !De,
                      onClick: ue,
                    },
                    le ? Xt.t("Continue") : "Continue"
                  )
                )
              )
            );
          }, "SelectSalesforceOrg");
        Na.displayName = "SelectSalesforceOrg";
        var Qs = e(6044196829),
          Js = e(3579140003),
          qs = e.n(Js),
          eo = e(4829524689);
        const Pn = new Ln.Ay("salesforce_connections"),
          to = c(
            (S) => (b) => {
              let { text: R } = b;
              return t.createElement(
                Qs.A,
                {
                  onClick: S,
                },
                R
              );
            },
            "getManageUserSFConnectionsLink"
          ),
          Ra = c((S) => {
            let {
              orgName: b,
              isMoreOrgsToSignIn: R,
              closeDialog: B,
              setSelectSalesforceOrgStep: ae,
              openSalesforcePreferences: ge,
              experimentSfdcSeamlessAuthFeGroupOn: le,
            } = S;
            const Ce = (0, t.useCallback)(() => {
              R ? ae() : B();
            }, [B, R, ae]);
            return t.createElement(
              t.Fragment,
              null,
              t.createElement(
                Ia.A,
                null,
                t.createElement(eo.A, {
                  src: qs(),
                }),
                t.createElement(Oa.A, {
                  title: le
                    ? Pn.t("\u2705 You\u2019re all set")
                    : "\u2705 You\u2019re all set",
                }),
                t.createElement(
                  Sa.a,
                  {
                    paddingInline: "150",
                  },
                  t.createElement(
                    Da.B,
                    {
                      space: "75",
                    },
                    t.createElement(
                      hn.E,
                      {
                        as: "p",
                      },
                      le
                        ? Pn.t(
                            "Now that you\u2019re signed in to {orgName}, you can keep track of all the deals you care about \u2014 right in Slack.",
                            {
                              orgName: b,
                            }
                          )
                        : `Now that you\u2019re signed in to ${b}, you can keep track of all the deals you care about \u2014 right in Slack.`
                    ),
                    t.createElement(
                      hn.E,
                      {
                        as: "p",
                      },
                      le
                        ? Pn.rt(
                            "Manage your Salesforce account connections <link>here</link>.",
                            {
                              "<link>": to(ge),
                            }
                          )
                        : "Manage your Salesforce account connections here."
                    )
                  )
                )
              ),
              t.createElement(
                Ma.A,
                null,
                t.createElement(
                  Ta.A,
                  null,
                  t.createElement(
                    ya.A,
                    {
                      onClick: Ce,
                      type: "primary",
                    },
                    le ? Pn.t("Done") : "Done"
                  )
                )
              )
            );
          }, "SignInSuccess");
        Ra.displayName = "SignInSuccess";
        var no = e(1063683520),
          ao = e(3385422400),
          so = e(9785228405);
        const La = (0, we.Ay)((S) => S.salesforceConnections.organizations);
        La.meta = {
          name: "createSelector",
          key: "createSelectorselectSalesforceOrganizations",
          description: (S) => S.salesforceConnections.organizations,
        };
        const ka = (0, ao.Mz)(La, so.N),
          kn = new Ln.Ay("salesforce_connections"),
          Ua = "select-org",
          oo = "sign-in-success",
          Ba = c((S) => {
            let { dismissSignInReminder: b } = S;
            const R = (0, n.d4)(
                (De) => (0, J._Z)(De, "sfdc_seamless_auth_fe") === "on"
              ),
              B = (0, O.wA)(),
              ae = (0, n.d4)(ka),
              ge = (0, t.useCallback)(() => {
                B((0, K.O)());
              }, [B]),
              le = (0, t.useCallback)(() => {
                B(
                  (0, da.A)({
                    activeSection: no._.salesforce,
                  })
                );
              }, [B]),
              Ce = R
                ? kn.t(
                    "You have access to the Salesforce orgs listed here. Select an org you\u2019d like access to in Slack. After you sign in to the first org, you\u2019ll have the chance to sign in to another one."
                  )
                : "You have access to the Salesforce orgs listed here. Select an org you\u2019d like access to in Slack. After you sign in to the first org, you\u2019ll have the chance to sign in to another one.",
              Pe = R
                ? kn.t(
                    "Select the Salesforce org you\u2019d like access to in Slack."
                  )
                : "Select the Salesforce org you\u2019d like access to in Slack.",
              re = (0, t.useMemo)(() => {
                const De = R
                  ? kn.t("Sign in to a Salesforce org")
                  : "Sign in to a Salesforce org";
                return {
                  "select-org": {
                    render: (Q) => {
                      let { mainText: ue = Ce, switchPane: ke } = Q;
                      return t.createElement(Na, {
                        orgs: ae,
                        mainText: ue,
                        closeDialog: ge,
                        dismissSignInReminder: b,
                        setNextStep: (Ke) => ke(oo, Ke),
                      });
                    },
                    modalProps: {
                      centered: !0,
                      contentLabel: De,
                    },
                  },
                  "sign-in-success": {
                    render: (Q) => {
                      let { orgName: ue, switchPane: ke } = Q;
                      return t.createElement(Ra, {
                        orgName: ue,
                        isMoreOrgsToSignIn: ae.length > 0,
                        closeDialog: ge,
                        setSelectSalesforceOrgStep: () =>
                          ke(Ua, {
                            mainText: Pe,
                          }),
                        openSalesforcePreferences: le,
                        experimentSfdcSeamlessAuthFeGroupOn: R,
                      });
                    },
                    modalProps: {
                      closeButtonTone: "dark",
                      centered: !0,
                      contentLabel: De,
                    },
                  },
                };
              }, [R, Ce, ae, ge, b, le, Pe]);
            return t.createElement(js.A, {
              defaultPane: Ua,
              panes: re,
              closeModal: ge,
            });
          }, "SignIntoSalesforceOrgDialog");
        Ba.displayName = "SignIntoSalesforceOrgDialog";
        const ba = c(() => {
          const S = (0, O.wA)(),
            b = c((R) => {
              let { dismissSignInReminder: B } = R;
              S(
                (0, lt.q)({
                  element: t.createElement(Ba, {
                    dismissSignInReminder: B,
                  }),
                })
              );
            }, "openSalesforceSignInDialog");
          return (b.displayName = "openSalesforceSignInDialog"), b;
        }, "useOpenSalesforceSignInDialog");
        ba.displayName = "useOpenSalesforceSignInDialog";
        var ro = e(289112722),
          lo = e(8624014077),
          io = e(5071438952),
          co = e(535424668);
        const _o = c(() => {
            const S = (0, O.wA)(),
              b = (0, n.d4)(ka),
              R = (0, t.useCallback)(
                (0, de.coroutine)(function* () {
                  try {
                    const B = yield S((0, co.n)());
                    S((0, io.Z)(B));
                  } catch {
                    (0, be.Ay)({
                      label: "SALESFORCE-CONNECTIONS",
                    }).error(
                      new Error(
                        "Error thrown when executing calls to sfdc.integration.listOrgs and sfdc.integration.authUser from SalesforceSignIn "
                      )
                    );
                  }
                }),
                [S]
              );
            return (
              (0, t.useEffect)(() => {
                R();
              }, [R]),
              b
            );
          }, "useFetchOrgsAndSignInSilently"),
          Wa = c((S) => {
            let { experimentSfdcSeamlessAuthFeGroupOn: b } = S;
            const R = _o(),
              [B, ae] = (0, lo.r)(ro.A, "visible"),
              ge = (0, t.useCallback)(() => {
                ae("hidden");
              }, [ae]),
              le = ba(),
              Ce = (0, t.useCallback)(() => {
                le({
                  dismissSignInReminder: ge,
                });
              }, [le, ge]);
            return !R.length || B === "hidden"
              ? null
              : t.createElement(Ys._, {
                  onSignIn: Ce,
                  experimentSfdcSeamlessAuthFeGroupOn: b,
                });
          }, "SalesforceSignIn");
        Wa.displayName = "SalesforceSignIn";
        var xa = e(352142497),
          Ka = e(4899054948);
        const mo = t.lazy(() => Promise.resolve().then(e.bind(e, 4698264567))),
          uo = t.lazy(() => Promise.resolve().then(e.bind(e, 3540014338))),
          Eo = t.lazy(() => Promise.resolve().then(e.bind(e, 1720631741))),
          po = t.lazy(() => Promise.resolve().then(e.bind(e, 6046495019))),
          go = t.lazy(() => Promise.resolve().then(e.bind(e, 629068863))),
          Ao = t.lazy(() => Promise.resolve().then(e.bind(e, 2811650336))),
          Co = t.lazy(() => Promise.resolve().then(e.bind(e, 8317025457))),
          ho = t.lazy(() => Promise.resolve().then(e.bind(e, 7205738127))),
          Po = t.lazy(() => Promise.resolve().then(e.bind(e, 3566375448))),
          vo = t.lazy(() =>
            Promise.resolve()
              .then(e.bind(e, 9949873423))
              .then((S) => ({
                default: S.SlackAiSidebarTrialOfferCta,
              }))
          ),
          fo = t.lazy(() =>
            Promise.resolve()
              .then(e.bind(e, 6962982910))
              .then((S) => ({
                default: S.PNPSidebarBadgeBanner,
              }))
          ),
          Oo = t.lazy(() =>
            Promise.resolve()
              .then(e.bind(e, 784529096))
              .then((S) => ({
                default: S.TrialEndPromoDiscountSidebarCta,
              }))
          ),
          Io = t.lazy(() => Promise.resolve().then(e.bind(e, 5684595131))),
          Mo = t.lazy(() => Promise.resolve().then(e.bind(e, 7328268421))),
          To = t.lazy(() => Promise.resolve().then(e.bind(e, 4061500210))),
          yo = {
            spaceName: q.xu.SIDEBAR_MENU_HEADER,
            notifications: {
              [q.ze.STRAIGHT_TO_PAID_SIDEBAR_MENU_HEADER_OFFER_CTA]: {
                component: Eo,
              },
              [q.ze.SIDEBAR_BENEFITS_ACTIVE_TRIAL_TAB_MENU_HEADER]: {
                component: uo,
              },
              [q.ze.SIDEBAR_MENU_HEADER_UPGRADE_CTA]: {
                component: mo,
              },
              [q.ze.SUPPORT_UPGRADE_DECISION_TRIAL_USAGE_SIDEBAR_MENU_HEADER]: {
                component: po,
              },
              [q.ze.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER]: {
                component: t.lazy(() =>
                  Promise.resolve()
                    .then(e.bind(e, 3998269055))
                    .then((S) => ({
                      default: S.SlackAITrialAwarenessSidebarBadge,
                    }))
                ),
              },
              [q.ze.SIDEBAR_MENU_HEADER_SLACK_AI_NFX_CTA]: {
                component: Ao,
              },
              [q.ze.SLACK_AI_SIDEBAR_PURCHASE_CTA]: {
                component: Co,
              },
              [q.ze
                .JOINER_LAUNCHPAD_RESURRECTED_USER_WELCOME_SIDEBAR_MENU_HEADER]:
                {
                  component: go,
                },
              [q.ze.LISTS_WELCOME_TO_LISTS_HOME_BANNER]: {
                component: ho,
              },
              [q.ze.VOLUME_DISCOUNT_HALFWAY_PROMO_BANNER]: {
                component: Po,
              },
              [q.ze.SLACK_AI_TRIAL_OFFER_SIDEBAR_CTA]: {
                component: vo,
              },
              [q.ze.PNP_SIDEBAR]: {
                component: fo,
              },
              [q.ze.PROMOTIONAL_DISCOUNTS_SIDEBAR_MENU_HEADER_CTA]: {
                component: Oo,
              },
              [q.ze.EDUCATION_CREATE_CUSTOM_SECTIONS]: {
                component: Io,
              },
              [q.ze.EDUCATION_SIDEBAR_SWEEPER]: {
                component: Mo,
              },
              [q.ze.SOLUTIONS_WELCOME_TO_SOLUTIONS_HOME_SIDEBAR_BANNER]: {
                component: To,
              },
            },
          };
        var Do = e(5519146941),
          So = e(1931938858),
          Pt = e(4240442510),
          No = e(4469810895),
          vn = e(3474336343),
          Ro = e(5873629730),
          Ha = e(2832209848),
          Lo = e(5492559860),
          Ee = e(3193155968);
        function Un() {
          return (
            (Un =
              Object.assign ||
              function (S) {
                for (var b = 1; b < arguments.length; b++) {
                  var R = arguments[b];
                  for (var B in R)
                    Object.prototype.hasOwnProperty.call(R, B) && (S[B] = R[B]);
                }
                return S;
              }),
            Un.apply(this, arguments)
          );
        }
        c(Un, "sidebar_header_extends");
        const Ht = new D.Ay("ia4"),
          ko = [
            Ee.k6.Home,
            Ee.k6.DMs,
            Ee.k6.Activity,
            Ee.k6.Later,
            Ee.k6.SalesHome,
          ],
          Uo = c((S) => ko.includes(S), "isTopLevelTab");
        function Bo(S) {
          let { renderControls: b, isChannelListOverflowing: R } = S;
          const B = (0, O.wA)(),
            ae = (0, n.d4)(
              (Ve) => (0, J._Z)(Ve, "view_header_overflow_borders") === "on"
            ),
            ge = (0, n.d4)(
              (Ve) => (0, J._Z)(Ve, "files_explorer_prototype") === "on"
            ),
            le = (0, n.d4)(Ro.OT),
            Ce = (0, n.d4)(
              (Ve) => (0, J._Z)(Ve, "sfdc_seamless_auth_fe") === "on"
            ),
            {
              windowId: Pe,
              activeTab: re,
              getSiblingView: De,
            } = (0, t.useContext)(Do.A),
            Q = (0, n.d4)((Ve) =>
              De(Ve, {
                container: Ee.mq.Sidebar,
              })
            ),
            ue = Pe !== Ee.N2,
            ke = (0, n.d4)(m.H7),
            Ke = (0, n.d4)((Ve) =>
              (0, vn.Li)(Ve, {
                getSiblingView: De,
              })
            ),
            Oe = (0, n.d4)((Ve) =>
              (0, vn.N1)(Ve, {
                getSiblingView: De,
              })
            ),
            vt = (0, n.d4)((Ve) =>
              (0, vn.g6)(Ve, {
                getSiblingView: De,
              })
            ),
            pt = (0, n.d4)(vn.eF),
            Me = (le && vt) || Oe ? pt : (0, v.F1)(ke),
            Ft =
              (0, n.d4)((Ve) => (0, kt.Hp)(Ve, q.xu.SIDEBAR_MENU_HEADER)) ===
                q.ze.SIDEBAR_MENU_HEADER_UPGRADE_CTA || !(0, Ie.Z9F)(),
            ut = (0, n.d4)(
              (Ve) =>
                (0, kt.Hp)(Ve, q.xu.SIDEBAR_MENU_HEADER) ===
                q.ze.SUPPORT_UPGRADE_DECISION_TRIAL_USAGE_SIDEBAR_MENU_HEADER
            ),
            Gt = (0, n.d4)(No.mU),
            ft = (0, Ee.Zu)(re);
          (0, t.useEffect)(() => {
            Gt &&
              B(
                (0, Lo.b)({
                  interactions: [
                    {
                      component: Ha.G7.PaidBenefitsPage,
                      type: Ha.X8.Impression,
                    },
                  ],
                  reason: "benefits-sidebar-link",
                })
              );
          }, [B, Gt]);
          const Ut = (0, t.useCallback)(() => B((0, Ge.o)((0, an.JJ)())), [B]);
          let ie = null,
            tt,
            gt = b ? b() : null;
          switch (!0) {
            case re === Ee.k6.Home:
              (ie = Ke
                ? Me
                : t.createElement(
                    Ka.A,
                    {
                      subtype: "home-header-menu",
                    },
                    t.createElement(fa, null)
                  )),
                (gt = t.createElement(te, {
                  isSetupPage: Ke,
                }));
              break;
            case re === Ee.k6.DMs:
              ie = t.createElement(s.w, null);
              break;
            case re === Ee.k6.Activity:
              ie = Ht.t("Activity");
              break;
            case re === Ee.k6.Later:
              ie = Ht.t("Later");
              break;
            case re === Ee.k6.SalesHome:
              ie = Ht.t("Sales");
              break;
            case re === Ee.k6.Browse:
              ie = Ht.t("Browse");
              break;
            case re === Ee.k6.Search:
              ie = (0, Pt.A)({
                tab: Ee.k6.Search,
              });
              break;
            case re === Ee.k6.Files:
              ie = (0, Pt.A)({
                tab: Ee.k6.Files,
              });
              break;
            case re === Ee.k6.Lists:
              ie = (0, Pt.A)({
                tab: Ee.k6.Lists,
              });
              break;
            case re === Ee.k6.Todos:
            case ue && (Q == null ? void 0 : Q.id) === xa.D.MoreTodosSidebar:
              ie = (0, Pt.A)({
                tab: Ee.k6.Todos,
              });
              break;
            case re === Ee.k6.ExternalConnections:
              ie = Ht.t("External connections", {
                fallbackHash: "ffe740c3e742622ea4e92503c4f06ce40984d073",
              });
              break;
            case ft: {
              const Ve = (0, Ee.CI)(re);
              (ie = t.createElement(
                Ka.A,
                {
                  subtype: "event-header-menu",
                },
                t.createElement(E, {
                  externalWorkspaceId: Ve,
                })
              )),
                (tt = t.createElement(
                  T.Nm,
                  {
                    onClick: Ut,
                    className: "p-ia4_sidebar_header__subtitleLink",
                  },
                  Ht.t("All external connections", {
                    fallbackHash: "ffe740c3e742622ea4e92503c4f06ce40984d073",
                  })
                ));
              break;
            }
            case re === Ee.k6.Channels:
              ie = (0, Pt.A)({
                tab: Ee.k6.Channels,
              });
              break;
            case re === Ee.k6.People:
              ie = (0, Pt.A)({
                tab: Ee.k6.People,
              });
              break;
            case re === Ee.k6.Platform:
              ie = (0, Pt.A)({
                tab: Ee.k6.Platform,
              });
              break;
            case re === Ee.k6.Huddles:
              ie = (0, Pt.A)({
                tab: Ee.k6.Huddles,
              });
              break;
            case re === Ee.k6.Canvases:
            case ue && (Q == null ? void 0 : Q.id) === xa.D.MoreCanvasesSidebar:
              ie = (0, Pt.A)({
                tab: Ee.k6.Canvases,
              });
              break;
            case re === Ee.k6.FilesPrototype:
              ie = (0, Pt.A)({
                tab: Ee.k6.FilesPrototype,
                experimentFilesExplorerPrototypeGroupOn: ge,
              });
              break;
            case re === Ee.k6.Solutions:
              ie = (0, Pt.A)({
                tab: Ee.k6.Solutions,
              });
              break;
            default:
              ie = "";
          }
          const Bt = (0, P.A)("p-ia4_sidebar_header", {
              "p-ia4_home_header": re === Ee.k6.Home || re === Ee.k6.DMs,
              "p-event_header": ft,
              "p-ia4_home_header--setup": Ke,
              "p-ia4_home_header--with_upgrade": Ft,
              "p-ia4_sidebar_header--withControls": gt,
              "p-ia4_home_header--with_guided_trial_badge": ut,
              "p-ia4_sidebar_header--list_isnt_overflowing": ae && !R,
              "p-ia4_sidebar_header--withSubtitle": !!tt,
            }),
            fn = t.createElement(
              t.Fragment,
              null,
              t.createElement(
                "div",
                {
                  className: ft
                    ? "p-ia4_sidebar_header__title__event"
                    : "p-ia4_sidebar_header__title",
                },
                ie
              ),
              gt &&
                t.createElement(
                  "div",
                  {
                    className: "p-ia4_sidebar_header__controls",
                  },
                  gt
                )
            ),
            Bn = Uo(re)
              ? t.createElement(
                  So.A,
                  {
                    "aria-label": Ht.t("Actions"),
                    className: Bt,
                  },
                  fn
                )
              : t.createElement(
                  "div",
                  {
                    className: Bt,
                  },
                  fn
                );
          return t.createElement(
            t.Fragment,
            null,
            tt &&
              t.createElement(
                "div",
                {
                  className: "p-ia4_sidebar_header__subtitle",
                },
                tt
              ),
            Bn,
            t.createElement(_t.Ay, Un({}, yo)),
            Ce &&
              re === Ee.k6.Home &&
              t.createElement(Wa, {
                experimentSfdcSeamlessAuthFeGroupOn: Ce,
              })
          );
        }
        c(Bo, "SidebarHeader");
      },
      6046495019: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => qt,
          });
        var t = e(5824283093),
          O = e(6122756707),
          P = e(4509434386),
          s = e(5255740490),
          I = e(7618569952),
          v = e(4481313819),
          T = e(277750594),
          u = e(4330129149),
          h = e(3405119017),
          D = e(3749988767),
          n = e(1267040415),
          m = e(6862327721),
          l = e(5267010247),
          f = e(8822892075),
          k = e(5519146941),
          E = e(5602423845),
          r = e(7115655993),
          i = e(7940058138),
          a = e(6084388622),
          _ = e(3514831633),
          o = e(1959847761),
          d = e(8683010724),
          A = e(1224315998),
          C = e(7239742441),
          M = e(735940183),
          y = e(6323355797),
          x = e(9805895677),
          N = e(5928243913),
          U = e(3785575952),
          p = e(2562405183),
          Y = e(716227588),
          z = e(6259241484),
          Z = e(3810478625),
          w = e(2967538512),
          V = e(6814386530);
        const L = new M.Ay("guided_trials"),
          J = new M.Ay("setup_straight_to_paid");
        var se;
        (function (ce) {
          (ce.UPGRADE_NOW = "upgrade_now_cta"),
            (ce.PLANS_AT_GLANCE = "plans_at_glance_cta"),
            (ce.SEE_UPGRADE_OPTIONS = "see_upgrade_options_cta");
        })(se || (se = {}));
        var j;
        (function (ce) {
          (ce.MESSAGES = "messages"),
            (ce.SLACK_CONNECT_CHANNELS = "slack-connect-channels"),
            (ce.HUDDLES = "huddles"),
            (ce.HUDDLES_OVER_30_MINUTES = "huddles_over_30_minutes"),
            (ce.CANVASES = "canvases"),
            (ce.APPS_INTEGRATIONS = "apps-integrations"),
            (ce.LISTS = "lists"),
            (ce.APPS = "apps"),
            (ce.WORKFLOWS = "workflows");
        })(j || (j = {}));
        const G = {
            elementName: se.UPGRADE_NOW,
            onClick: {
              enableClogAction: !0,
            },
          },
          te = {
            elementName: se.SEE_UPGRADE_OPTIONS,
            onClick: {
              enableClogAction: !0,
            },
          },
          me = {
            elementName: se.PLANS_AT_GLANCE,
            onClick: {
              enableClogAction: !0,
            },
          },
          Re = c(() => {
            const ce = (0, O.wA)(),
              Qe = (0, E.A)(),
              { shouldUseNavigate: ht } = (0, t.useContext)(k.A),
              { maybeClosePeek: $ } = (0, t.useContext)(u.Z),
              K = (0, p.d4)(Z.g),
              _e = (0, p.d4)(w.u0),
              de = (0, p.d4)(w.PU),
              Ne = (0, t.useMemo)(
                () => ({
                  ...G,
                  stepVariant: de,
                }),
                [de]
              ),
              he = (0, p.d4)((Ie) => (0, Y.OL)(Ie, z.xu.SIDEBAR_MENU_HEADER)),
              {
                appsAndIntegrations: be,
                filesAndMessages: Fe,
                sharedChannels: fe,
                huddles: We,
                canvases: Le,
                apps: ye = {
                  checked: !1,
                },
                lists: Ye = {
                  checked: !1,
                },
                workflows: et = {
                  checked: !1,
                },
                huddlesOver30M: at = {
                  checked: !1,
                },
              } = he,
              Ze = (0, t.useMemo)(
                () => [
                  ...fe.privateSharedChannels.map((Ie) => ({
                    ...Ie,
                    isPrivate: !0,
                  })),
                  ...fe.publicSharedChannels.map((Ie) => ({
                    ...Ie,
                    isPrivate: !1,
                  })),
                ],
                [fe]
              ),
              Rt = c(
                () =>
                  t.createElement(
                    "div",
                    {
                      className:
                        "p-sidebar_trial_peek_view__section__check_icon_wrapper",
                    },
                    t.createElement(d.A, {
                      name: "check",
                      variation: "filled",
                      size: "20",
                    })
                  ),
                "renderCheckIcon"
              ),
              Tt = c(
                (Ie) =>
                  t.createElement(
                    "div",
                    {
                      className: (0, s.A)(
                        "p-sidebar_trial_peek_view__section__icon_wrapper",
                        {
                          "p-sidebar_trial_peek_view__section__icon_wrapper_gray":
                            K,
                        }
                      ),
                    },
                    t.createElement(d.A, {
                      name: Ie,
                      size: "20",
                    })
                  ),
                "renderIcon"
              ),
              Ae = (0, t.useCallback)(() => {
                $({
                  forceClose: !0,
                });
              }, [$]),
              Je = (0, t.useCallback)(() => {
                Ae(), ce((0, U.XO)());
              }, [ce, Ae]),
              dt = (0, t.useCallback)(() => {
                Ae(), ce((0, x.R)());
              }, [ce, Ae]),
              rt = (0, t.useCallback)(() => ce((0, l.o)((0, f.CR)())), [ce]),
              Lt = (0, t.useCallback)(() => ce((0, N.A)()), [ce]),
              mn = (0, t.useCallback)(() => {
                Ae(), ce((0, T.A)());
              }, [ce, Ae]),
              un = (0, t.useCallback)(
                (Ie) => () => {
                  Ae(),
                    ce(
                      ht
                        ? (0, l.o)((0, f.pr)(Ie))
                        : (0, V.A)({
                            id: Ie,
                          })
                    );
                },
                [ht, ce, Ae]
              ),
              En = (0, t.useCallback)(() => {
                Ae(),
                  ce(
                    (0, m.A)({
                      canUserPurchase: he.canUserPurchase,
                    })
                  );
              }, [Ae, ce, he.canUserPurchase]),
              yt = c(
                (Ie) =>
                  t.createElement(
                    "span",
                    {
                      className: "p-sidebar_trial_peek_view__sub_menu_text",
                    },
                    t.createElement(d.A, {
                      name: Ie.isPrivate ? "lock" : "channel",
                    }),
                    Ie.channelName
                  ),
                "renderChannelSubMenuText"
              ),
              pn = c(
                () =>
                  t.createElement(
                    _.Ay,
                    {
                      width: 244,
                      menuClassNames: "p-sidebar_trial_peek_view__wrapper",
                    },
                    Ze.map((Ie) =>
                      t.createElement(_.Dr, {
                        "data-qa": `${Ie.channelName}-menu-item`,
                        disableHoverStyling: !0,
                        key: Ie.encodedId,
                        label: yt(Ie),
                        className: "p-sidebar_trial_peek_view__section",
                        onSelected: un(Ie.encodedId),
                        autoClogProps: {
                          elementName: `peek_view_row_${j.SLACK_CONNECT_CHANNELS}`,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      })
                    )
                  ),
                "renderChannelSubMenu"
              ),
              gn = c((Ie) => {
                let {
                  key: Ge,
                  title: an,
                  description: An,
                  checked: sn,
                  icon: Cn,
                  handleClick: Dn,
                } = Ie;
                return Ge === j.SLACK_CONNECT_CHANNELS &&
                  fe.checked &&
                  Ze.length > 1
                  ? t.createElement(
                      o.A,
                      {
                        key: Ge,
                        showFullCarat: !0,
                        disableHoverStyling: !0,
                        "data-qa": `${Ge}-menu-item`,
                        renderSubmenu: pn,
                        className: "p-sidebar_trial_peek_view__section",
                        classNameListItem: "p-sidebar_trial_peek_view__item",
                      },
                      sn ? Rt() : Tt(Cn),
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-sidebar_trial_peek_view__section_text_container",
                        },
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_title",
                          },
                          an
                        ),
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_sub_title",
                          },
                          An
                        )
                      )
                    )
                  : t.createElement(
                      _.Dr,
                      {
                        className: "p-sidebar_trial_peek_view__section",
                        classNameListItem: "p-sidebar_trial_peek_view__item",
                        disableHoverStyling: !0,
                        onSelected: Dn,
                        key: Ge,
                        "data-qa": `${Ge}-menu-item`,
                        autoClogProps: {
                          elementName: `peek_view_row_${Ge}`,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      },
                      sn ? Rt() : Tt(Cn),
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-sidebar_trial_peek_view__section_text_container",
                        },
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_title",
                          },
                          an
                        ),
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_sub_title",
                          },
                          An
                        )
                      )
                    );
              }, "renderMenuItem");
            gn.displayName = "renderMenuItem";
            const lt = c((Ie) => {
              switch (Ie) {
                case j.MESSAGES:
                  return K
                    ? L.t("Searched messages older than 90 days")
                    : Fe.lockedMessagesCount > 0
                    ? L.rt(
                        "Search {messageCount} messages older than <div>90 days</div>",
                        {
                          messageCount: (0, C.$k)(Fe.lockedMessagesCount),
                        }
                      )
                    : L.t("Search messages older than 90 days");
                case j.SLACK_CONNECT_CHANNELS: {
                  let Ge = "";
                  return (
                    !fe.checked || Ze.length === 0
                      ? (Ge = K
                          ? L.t("Message someone outside your company")
                          : L.t("Work with people outside your company"))
                      : K
                      ? (Ge = L.rt(
                          "Your team has {channelCount} external {channelCount, plural, =1 {conversation} other {conversations}}",
                          {
                            channelCount: Ze.length,
                          }
                        ))
                      : Ze.length === 1
                      ? (Ge = t.createElement(
                          "span",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_sub_title_channel",
                          },
                          L.rt("View <span>{icon}</span>{channelName}", {
                            channelName: Ze[0].channelName,
                            icon: t.createElement(d.A, {
                              name: Ze[0].isPrivate ? "lock" : "channel",
                            }),
                          })
                        ))
                      : Ze.length > 1 &&
                        (Ge = L.rt(
                          "View {channelCount} channels with external people",
                          {
                            channelCount: Ze.length,
                          }
                        )),
                    Ge
                  );
                }
                case j.HUDDLES:
                  return We.checked && We.count > 0
                    ? L.rt(
                        "Your team has completed {count} group {count, plural, =1 {call} other {calls}}",
                        {
                          count: We.count,
                        }
                      )
                    : L.t("Initiate video calls with screen sharing");
                case j.HUDDLES_OVER_30_MINUTES:
                  return K
                    ? at != null && at.checked && at.count > 0
                      ? L.rt(
                          "Your team has completed {count} {count, plural, =1 {huddle} other {huddles}}",
                          {
                            count: at.count,
                          }
                        )
                      : L.t("Huddles can now be longer than 30 minutes")
                    : "";
                case j.CANVASES:
                  return Le.checked && Le.count > 0
                    ? K
                      ? L.rt(
                          "Your team has created {count} {count, plural, =1 {canvas} other {canvases}}",
                          {
                            count: Le.count,
                          }
                        )
                      : L.rt(
                          "Your team has created {count} {count, plural, =1 {document} other {documents}}",
                          {
                            count: Le.count,
                          }
                        )
                    : L.t("Document and share ideas and knowledge");
                case j.APPS_INTEGRATIONS: {
                  let Ge = "";
                  return (
                    !be.checked || be.count === 0
                      ? (Ge = L.t("Integrate tools and services into Slack"))
                      : (Ge = L.rt(
                          "Your team has installed {count} {count, plural, =1 {app} other {apps}}",
                          {
                            count: be.count,
                          }
                        )),
                    Ge
                  );
                }
                case j.LISTS:
                  return K
                    ? Ye != null && Ye.checked && Ye.count > 0
                      ? L.t(
                          "Your team has created {count} {count, plural, =1 {list} other {lists}}",
                          {
                            count: Ye.count,
                          }
                        )
                      : L.t("Plan, track or manage projects")
                    : "";
                case j.APPS:
                  return K
                    ? ye != null && ye.checked && ye.count > 0
                      ? L.t(
                          "Your team has added {count} {count, plural, =1 {app} other {apps}}",
                          {
                            count: ye.count,
                          }
                        )
                      : L.t("Access tools you use every day in Slack")
                    : "";
                case j.WORKFLOWS:
                  return K
                    ? et != null && et.checked && et.count > 0
                      ? L.t(
                          "Your team has published {count} {count, plural, =1 {workflow} other {workflows}}",
                          {
                            count: et.count,
                          }
                        )
                      : L.t("Work faster by automating tasks")
                    : "";
                default:
                  return "";
              }
            }, "getSectionDescription");
            lt.displayName = "getSectionDescription";
            const en = [
                {
                  key: j.MESSAGES,
                  title: K
                    ? L.t("Message and file history")
                    : L.t("Message & file history"),
                  description: lt(j.MESSAGES),
                  checked: !0,
                  handleClick: Je,
                  icon: "check",
                  altText: L.t("Message icon"),
                  shouldRender: !0,
                },
                {
                  key: j.SLACK_CONNECT_CHANNELS,
                  title: K
                    ? L.t("Start a Slack Connect conversation")
                    : L.t("Slack Connect channels"),
                  description: lt(j.SLACK_CONNECT_CHANNELS),
                  checked: fe.checked,
                  handleClick:
                    Ze.length > 0 && fe.checked ? un(Ze[0].encodedId) : dt,
                  icon: "shared-channel",
                  altText: L.t("Shared channels icon"),
                  shouldRender: !0,
                },
                {
                  key: j.HUDDLES,
                  title: L.t("Huddles"),
                  description: lt(j.HUDDLES),
                  checked: We.checked,
                  handleClick: mn,
                  icon: "headphones",
                  altText: L.t("Huddle icon"),
                  shouldRender: !K,
                },
                {
                  key: j.HUDDLES_OVER_30_MINUTES,
                  title: K ? L.t("Start a huddle without a time limit") : "",
                  description: lt(j.HUDDLES_OVER_30_MINUTES),
                  checked: at == null ? void 0 : at.checked,
                  handleClick: mn,
                  icon: "headphones",
                  altText: L.t("Huddle icon"),
                  shouldRender: K,
                },
                {
                  key: j.CANVASES,
                  title: K ? L.t("Create a canvas") : L.t("Canvas"),
                  description: lt(j.CANVASES),
                  handleClick: rt,
                  checked: Le.checked,
                  icon: "canvas-browser",
                  altText: L.t("Canvas browser icon"),
                  shouldRender: !0,
                },
                {
                  key: j.APPS_INTEGRATIONS,
                  title: L.t("Apps & automations"),
                  description: lt(j.APPS_INTEGRATIONS),
                  checked: be.checked,
                  handleClick: Lt,
                  icon: "bolt",
                  altText: L.t("Bolt icon"),
                  shouldRender: !K,
                },
                {
                  key: j.LISTS,
                  title: K ? L.t("Create a list") : "",
                  description: lt(j.LISTS),
                  checked: Ye == null ? void 0 : Ye.checked,
                  handleClick: () => ce((0, l.o)((0, f.ZF)(i.c.BrowseLists))),
                  icon: "lists",
                  altText: K ? L.t("Lists icon") : "",
                  shouldRender: K,
                },
                {
                  key: j.APPS,
                  title: K ? L.t("Add an app") : "",
                  description: lt(j.APPS),
                  checked: ye == null ? void 0 : ye.checked,
                  handleClick: Lt,
                  icon: "apps",
                  altText: K ? L.t("Apps icon") : "",
                  shouldRender: K,
                },
                {
                  key: j.WORKFLOWS,
                  title: K ? L.t("Publish a workflow") : "",
                  description: lt(j.WORKFLOWS),
                  checked: et == null ? void 0 : et.checked,
                  handleClick: () => ce((0, l.o)((0, f.ZF)(i.c.Shortcuts))),
                  icon: "bolt",
                  altText: L.t("Bolt icon"),
                  shouldRender: K,
                },
              ],
              tn = (0, p.d4)((Ie) =>
                (0, y.m6)(Ie, {
                  action: y.um.CHECKOUT,
                  productLevel: y.i6.standard.id,
                  entryPoint: "guided_trials_peek_upgrade_cta",
                })
              ),
              nn =
                _e && he.promoType === "straight_to_paid" && he.discountPercent,
              jt = (0, D.Q)(he.discountExpirationTs);
            (0, r.A)(() => {
              if (nn) {
                const { eventId: Ie, contexts: Ge } = (0, h.wy)(de);
                Qe.track(Ie, {
                  contexts: Ge,
                });
              }
            });
            const yn = t.createElement(
              "div",
              {
                className: "p-sidebar_trial_peek_view__stp_wrapper",
              },
              t.createElement(
                a.z9,
                {
                  autoClogProps: Ne,
                  href: tn,
                  className: "p-sidebar_trial_peek_view__cta_upgrade",
                  "data-qa": "peek-view-upgrade-now-cta",
                },
                J.t("Get {discountPercent}% Off Slack Pro", {
                  discountPercent: he.discountPercent,
                })
              ),
              t.createElement(
                "p",
                {
                  className: "p-sidebar_trial_peek_view__stp_subtext",
                },
                typeof jt == "number" &&
                  jt >= 0 &&
                  J.t(
                    "{daysRemaining, plural, =1 {# day} other {# days}} left on this offer",
                    {
                      daysRemaining: jt,
                    }
                  )
              )
            );
            return t.createElement(
              v.A,
              {
                uiComponentName:
                  A.UiComponentName.GUIDED_TRIAL_SIDEBAR_PEEK_VIEW,
                clogImpression: !0,
              },
              t.createElement(
                _.Ay,
                {
                  width: 355,
                  menuClassNames: "p-sidebar_trial_peek_view__wrapper",
                },
                t.createElement(_.c$, {
                  label: K
                    ? L.t("Make the most of Pro")
                    : L.t("How you and your team are using Pro features"),
                  className: "p-sidebar_trial_peek_view__header_text",
                }),
                en
                  .filter((Ie) => {
                    let { shouldRender: Ge } = Ie;
                    return Ge;
                  })
                  .map((Ie) => gn(Ie)),
                t.createElement(_.bX, {
                  className: "p-sidebar_trial_peek_view__section_sperator",
                }),
                t.createElement(
                  "div",
                  {
                    className: (0, s.A)(
                      "p-sidebar_trial_peek_view__cta_wrapper",
                      {
                        padding_bottom_25: nn,
                      }
                    ),
                  },
                  he.canUserPurchase &&
                    (nn
                      ? yn
                      : t.createElement(
                          a.z9,
                          {
                            autoClogProps: G,
                            href: tn,
                            className: "p-sidebar_trial_peek_view__cta_upgrade",
                            "data-qa": "peek-view-upgrade-now-cta",
                          },
                          K ? L.t("Upgrade to Pro") : L.t("Upgrade Now")
                        )),
                  !he.canUserPurchase &&
                    !K &&
                    t.createElement(
                      n.A,
                      {
                        "data-qa": "peek-view-upgrade-now-cta",
                        className: "p-sidebar_trial_peek_view__cta_upgrade",
                        entryPoint: "guided_trials_peek_upgrade_cta",
                        autoClogProps: te,
                      },
                      L.t("See Upgrade Options")
                    ),
                  !he.canUserPurchase &&
                    K &&
                    t.createElement(
                      a.z9,
                      {
                        autoClogProps: G,
                        onClick: En,
                        className: "p-sidebar_trial_peek_view__cta_upgrade",
                        "data-qa": "peek-view-compare-plans-primary-cta",
                      },
                      K ? L.t("Compare Plans") : ""
                    ),
                  (!K || he.canUserPurchase) &&
                    t.createElement(
                      a.Nm,
                      {
                        autoClogProps: me,
                        onClick: En,
                        className: "p-sidebar_trial_peek_view__cta_compare",
                        "data-qa": "peek-view-compare-plans-cta",
                      },
                      t.createElement(d.A, {
                        name: K ? "open-in-window" : "help",
                      }),
                      K
                        ? L.t("Compare plans")
                        : L.t("Compare free vs. paid", {
                            fallbackHash:
                              "a9e8db275411da93383d650ea5f5f2c3022f2f01",
                          })
                    )
                )
              )
            );
          }, "SidebarTrialPeekView");
        Re.displayName = "SidebarTrialPeekView";
        const Se = Re;
        var Te = e(8214116048);
        const $e = -10,
          xe = c((ce) => {
            let { children: Qe } = ce;
            const ht = (0, t.useCallback)(() => t.createElement(Se, null), []);
            return t.createElement(
              I.A,
              {
                position: Te.yX.RightBottom,
                renderContent: ht,
                offsetY: $e,
              },
              Qe
            );
          }, "SidebarTrialPeekTrigger");
        xe.displayName = "SidebarTrialPeekTrigger";
        const ve = xe;
        var oe = e(7512049997),
          H = e(9137628070),
          X = e(2994893019),
          pe = e(8871937520),
          ee = e(2047021170),
          ze = e(3451446614),
          we = e(3193155968),
          Ue = e(2802517438);
        const He = new M.Ay("guided_trials"),
          Xe = {
            elementName: "sidebar_trial_badge_paid_benfits_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          Be = c(() => {
            const ce = (0, O.wA)(),
              { shouldUseNavigate: Qe, getSiblingView: ht } = (0, t.useContext)(
                k.A
              ),
              $ = (0, p.d4)(ze.Y),
              K = (0, p.d4)((ye) => (0, Y.OL)(ye, z.xu.SIDEBAR_MENU_HEADER)),
              _e = (0, p.d4)((ye) => {
                var Ye;
                return Qe
                  ? (Ye = ht(ye, {
                      container: we.mq.Primary,
                    })) === null || Ye === void 0
                    ? void 0
                    : Ye.id
                  : (0, Ue.A)(ye);
              }),
              de = (0, p.d4)(
                (ye) =>
                  (0, ee.ty)(ye, "trials_sidebar_banner_wrapper_dismissed") ===
                  !1
              ),
              Ne = _e === "Ppaid-benefits",
              he = (0, pe.qe)(K.trialEndDate) || 0,
              be = he === y.ew.PAID_FEATURE_TRIAL,
              Fe = he === 1,
              fe = (be && de) || Fe,
              We = (0, t.useCallback)(() => {
                ce(
                  Qe
                    ? (0, l.o)((0, f.ZF)(i.c.PaidBenefits))
                    : (0, V.A)({
                        id: H.IN,
                      })
                );
              }, [ce, Qe]),
              Le = c(
                () =>
                  Fe
                    ? He.t("View Paid Benefits")
                    : He.rt(
                        "{trialDaysRemaining} {trialDaysRemaining, plural, =1 {day} other {days}} left in trial",
                        {
                          trialDaysRemaining: he,
                        }
                      ),
                "getButtonText"
              );
            return t.createElement(X.M, {
              isTrialFirstDay: be,
              isTrialLastDay: Fe,
              trialDaysRemaining: he,
              isSelected: Ne,
              showWrapper: fe,
              autoClogProps: Xe,
              onClick: We,
              buttonText: Le(),
              experimentFeatReverseTrialGroupTreatment: $,
            });
          }, "SideBarTrialBadge");
        Be.displayName = "SideBarTrialBadge";
        const qe = Be;
        var ct = e(1641606663),
          It = e(7878745420),
          st = e(3328068409),
          Mt = e(387484329),
          _t = e(3677514771),
          q = e(7531383956),
          ot = e.n(q),
          At = e(3758927666),
          Ct = e.n(At);
        const nt = new M.Ay("guided_trials"),
          Nt = {
            elementName: "sidebar_trial_badge_upgrade_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          Et = {
            elementName: "sidebar_trial_badge_see_upgrade_options_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          Kt = {
            elementName: "sidebar_trial_badge_wrapper_close_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          dn = It.g.SUPPORT_UPGRADE_DECISION_TRIAL_USAGE_SIDEBAR_MENU_HEADER,
          Yt = c((ce) => {
            let { canUserPurchase: Qe, trialEndDate: ht } = ce;
            const $ = (0, O.wA)(),
              { activeTab: K } = (0, t.useContext)(k.A),
              _e = K === we.k6.Home,
              { windowRef: de } = (0, t.useContext)(ct.Mn),
              Ne = (0, p.d4)(st.to),
              he = (0, p.d4)(_t.H7),
              be = (0, p.d4)(
                (dt) =>
                  (0, ee.ty)(dt, "trials_sidebar_banner_wrapper_dismissed") ===
                  !1
              ),
              Fe = (0, p.d4)(Z.g),
              fe = (0, p.d4)(ze.Y),
              We = (0, pe.qe)(ht) || 0,
              Le = We === y.ew.PAID_FEATURE_TRIAL,
              ye = We === 1,
              Ye = fe && We <= y.ew.PAID_FEATURE_TRIAL - 7 && We > 1,
              et = (Le && be) || ye || (Ye && be),
              at = (0, t.useCallback)(() => {
                $(
                  (0, Mt.AZ)({
                    pref: "trials_sidebar_banner_wrapper_dismissed",
                    value: !0,
                  })
                );
              }, [$]),
              Ze = (0, p.d4)((dt) =>
                (0, y.m6)(dt, {
                  action: y.um.CHECKOUT,
                  productLevel: y.i6.standard.id,
                  entryPoint: "guided_trials_peek_upgrade_cta",
                })
              ),
              Rt = (0, t.useCallback)(() => {
                var dt;
                const rt = Qe
                  ? Ze
                  : (0, y.hZ)({
                      team: he,
                      entryPoint: "guided_trials_sidebar_upgrade_cta",
                    });
                (dt = de.deref()) === null || dt === void 0 || dt.open(rt);
              }, [he, de, Qe, Ze]),
              Tt = (0, t.useMemo)(
                () =>
                  Qe
                    ? Fe
                      ? nt.t("Upgrade to Pro")
                      : nt.t("Upgrade Now")
                    : nt.t("See Upgrade Options"),
                [Qe, Fe]
              ),
              Ae = c(
                () =>
                  Le
                    ? nt.t("Get started with your Pro trial")
                    : ye
                    ? nt.t("It\u2019s the last day of your Pro trial")
                    : Ye
                    ? nt.t("Take advantage of Slack Pro")
                    : "",
                "getWrapperText"
              ),
              Je = c(() => {
                if (fe) {
                  if (ye) return "last_day";
                  if (We === 2) return "second_to_last_day";
                }
              }, "getUiStep");
            return !_e || We <= 0
              ? null
              : t.createElement(
                  v.A,
                  {
                    uiComponentName:
                      A.UiComponentName.GUIDED_TRIAL_SIDEBAR_BADGE,
                    uiStep: Je(),
                    stepVariant: fe ? "reverse_trial" : void 0,
                    clogImpression: !0,
                  },
                  t.createElement(
                    oe.A,
                    null,
                    t.createElement(
                      "div",
                      {
                        className: (0, s.A)({
                          "p-sidebar_trial_badge_wrapper": fe,
                        }),
                      },
                      et &&
                        t.createElement(
                          "div",
                          {
                            className: (0, s.A)(
                              "p-sidebar_trial_badge_wrapper__wrapper",
                              {
                                "p-sidebar_trial_badge_wrapper__wrapper--reverse_trial":
                                  fe,
                                [P.A7]: Ne === Te.Sx.Light,
                              }
                            ),
                          },
                          t.createElement(
                            "div",
                            {
                              className:
                                "p-sidebar_trial_badge_wrapper__wrapper_header",
                            },
                            t.createElement(
                              "div",
                              {
                                className:
                                  "p-sidebar_trial_badge_wrapper__wrapper_text",
                              },
                              Ae()
                            ),
                            t.createElement(
                              "div",
                              {
                                className:
                                  "p-sidebar_trial_badge_wrapper__wrapper_header_image_container",
                              },
                              (Le || Ye) &&
                                t.createElement("img", {
                                  src: Ct(),
                                  alt: "gift",
                                }),
                              ye &&
                                t.createElement("img", {
                                  src: ot(),
                                  alt: "clock",
                                }),
                              (Le || Ye) &&
                                t.createElement(
                                  a.Nm,
                                  {
                                    className:
                                      "p-sidebar_trial_badge_wrapper__wrapper_header_close_btn",
                                    onClick: at,
                                    autoClogProps: Kt,
                                    "data-qa":
                                      "sidebar-badge-wrapper-close-btn",
                                  },
                                  t.createElement(d.A, {
                                    name: "close",
                                  })
                                )
                            )
                          ),
                          ye &&
                            t.createElement(
                              a.Nm,
                              {
                                onClick: Rt,
                                autoClogProps: Qe ? Nt : Et,
                                className:
                                  "p-sidebar_trial_badge_wrapper__upgrade_now_btn dt-hocus:theme-base-pry",
                                "data-qa":
                                  "sidebar-badge-wrapper-upgrade-now-btn",
                              },
                              Qe &&
                                t.createElement(d.A, {
                                  size: "20",
                                  name: "rocket",
                                }),
                              t.createElement("span", null, Tt)
                            )
                        ),
                      t.createElement(
                        "div",
                        {
                          className: (0, s.A)(
                            "p-sidebar_trial_badge_wrapper__button_wrapper",
                            {
                              "p-sidebar_trial_badge_wrapper__button_wrapper_bg":
                                et,
                              "p-sidebar_trial_badge_wrapper__button_wrapper--reverse_trial":
                                fe,
                              "p-sidebar_trial_badge_wrapper__button_wrapper--no_padding":
                                fe && !et,
                              [P.A7]: Ne === Te.Sx.Light,
                            }
                          ),
                        },
                        t.createElement(
                          ve,
                          null,
                          t.createElement(
                            "div",
                            null,
                            t.createElement(qe, null)
                          )
                        )
                      )
                    )
                  )
                );
          }, "SideBarTrialBadgeWrapper");
        Yt.displayName = "SideBarTrialBadgeWrapper";
        const qt = Yt;
      },
      3326504786: (W, g, e) => {
        "use strict";
        e.r(g),
          e.d(g, {
            default: () => ht,
          });
        var t = e(5824283093),
          O = e(4459831283),
          P = e(6122756707),
          s = e(5255740490),
          I = e(6084388622),
          v = e(4460213392),
          T = e(6795500641),
          u = e(2562405183);
        const h = c(() => {
          const $ = (0, P.wA)(),
            K = (0, u.d4)(O.ag),
            _e = (0, u.d4)(O.NP),
            de = K || _e,
            Ne = (0, u.d4)(T.vT),
            he = (0, t.useCallback)(() => {
              de && $((0, v.Cy)(!1));
            }, [$, de]),
            be = (0, t.useCallback)(() => {
              de && $((0, v.Cy)(!0));
            }, [$, de]),
            Fe = t.createElement(
              I.Nm,
              {
                className: (0, s.A)(
                  "p-priority_prototype_sidebar_toggle_button p-priority_prototype_sidebar_toggle_button--all",
                  {
                    "p-priority_prototype_sidebar_toggle_button--selected": !Ne,
                  }
                ),
                onClick: he,
              },
              "Everything"
            ),
            fe = t.createElement(
              I.Nm,
              {
                className: (0, s.A)(
                  "p-priority_prototype_sidebar_toggle_button p-priority_prototype_sidebar_toggle_button--priority",
                  {
                    "p-priority_prototype_sidebar_toggle_button--selected": Ne,
                  }
                ),
                onClick: be,
              },
              "Priority"
            );
          return t.createElement(
            "div",
            {
              className: "p-priority_prototype_sidebar_toggle_container",
            },
            t.createElement(
              "div",
              {
                className: "p-priority_prototype_sidebar_toggle_background",
              },
              Fe,
              fe
            )
          );
        }, "PrioritySidebarToggle");
        h.displayName = "PrioritySidebarToggle";
        const D = h;
        var n = e(3686168196),
          m = e(5946832122),
          l = e(8683010724),
          f = e(735940183),
          k = e(3821598679);
        const E = new f.Ay("channel_sidebar"),
          r = c(($) => {
            let { onDismiss: K, children: _e } = $;
            const de = `sidebar-filter-label-${(0, k.A)()}`,
              Ne = `sidebar-filter-button-${(0, k.A)()}`;
            return t.createElement(
              "div",
              {
                className: "p-channel_sidebar_filter_pill__container",
              },
              t.createElement(
                "div",
                {
                  className: "p-channel_sidebar_filter_pill",
                  "data-qa": "channel_sidebar_filter_pill",
                },
                t.createElement(
                  "span",
                  {
                    id: de,
                  },
                  _e
                ),
                t.createElement(
                  m.A,
                  {
                    id: Ne,
                    "aria-labelledby": `${de} ${Ne}`,
                    className: "p-channel_sidebar_filter_pill__dismiss",
                    "aria-label": E.t("Remove filter"),
                    onClick: K,
                    size: "small",
                  },
                  t.createElement(l.A, {
                    name: "close",
                    size: "18",
                  })
                )
              )
            );
          }, "ChannelSidebarFilterPill");
        r.displayName = "ChannelSidebarFilterPill";
        const i = r;
        var a = e(2527782504),
          _ = e(9053431150),
          o = e(2112238546),
          d = e(2235302340),
          A = e(3943207487);
        const C = new f.Ay("ia4"),
          M = c(() => {
            const $ = (0, P.wA)(),
              K = (0, u.d4)(d.ce),
              { transitionFocusTo: _e } = (0, t.useContext)(_.Ay),
              de = (0, t.useCallback)(() => {
                $(
                  (0, o.UG)({
                    peopleFilter: {
                      type: A.E7.All,
                    },
                  })
                ),
                  _e({
                    focusKey: a.Ay.SIDEBAR_CURRENT_CHANNEL,
                  });
              }, [$, _e]),
              Ne = (0, t.useCallback)(() => {
                let he = null;
                switch (K == null ? void 0 : K.type) {
                  case A.E7.Internal:
                    he = C.rt(
                      "Showing only conversations <strong>without external people</strong>"
                    );
                    break;
                  case A.E7.External:
                    he = C.rt(
                      "Showing only conversations that <strong>include external people</strong>"
                    );
                    break;
                  default:
                }
                return he;
              }, [K == null ? void 0 : K.type]);
            return (K == null ? void 0 : K.type) !== A.E7.Internal &&
              (K == null ? void 0 : K.type) !== A.E7.External
              ? null
              : t.createElement(
                  i,
                  {
                    onDismiss: de,
                  },
                  t.createElement(
                    "div",
                    {
                      className: "p-people_filter_pill_description",
                    },
                    Ne()
                  )
                );
          }, "PeopleFilterPill");
        M.displayName = "PeopleFilterPill";
        const y = M;
        var x = e(4046595612),
          N = e(5200353308),
          U = e(5999193850),
          p = e(7956678849),
          Y = e(9884588328),
          z = e(893266994),
          Z = e(4001737397),
          w = e(9950739645),
          V = e(9101533895),
          L = e(3683482182);
        function J($) {
          const K = (0, u.d4)((fe) => (0, w.B)(fe, $)),
            _e = (0, t.useCallback)(
              (fe) =>
                (0, V.DM)(fe)
                  .filter((Le) => {
                    var ye;
                    return K
                      ? (0, z.c)(Le) === $
                      : ((ye = (0, Y.Si)(Le)) === null || ye === void 0
                          ? void 0
                          : ye.includes($)) && !(0, Z.O)(Le);
                  })
                  .map((Le) => Le.id),
              [K, $]
            ),
            de = (0, u.Z2)(_e),
            Ne = (0, u.d4)(L.ty),
            he = (0, t.useMemo)(
              () =>
                de.some((fe) => {
                  var We;
                  return (We = Ne[fe]) === null || We === void 0
                    ? void 0
                    : We.unreadCnt;
                }),
              [de, Ne]
            );
          var be;
          const Fe = (0, t.useMemo)(
            () =>
              de.reduce((fe, We) => {
                var Le;
                return (
                  fe +
                  ((be =
                    (Le = Ne[We]) === null || Le === void 0
                      ? void 0
                      : Le.unreadHighlightCnt) !== null && be !== void 0
                    ? be
                    : 0)
                );
              }, 0),
            [de, Ne]
          );
          return (0, t.useMemo)(
            () => ({
              hasUnreads: he,
              mentionCount: Fe,
            }),
            [he, Fe]
          );
        }
        c(J, "useWorkspaceBadgeCounts");
        var se = e(9163962844);
        function j($) {
          let { teamId: K } = $;
          const { hasUnreads: _e, mentionCount: de } = J(K);
          return de
            ? t.createElement(se.A, {
                count: de,
                style: se.r.themed,
                className: "p-workspace_filter_menu__item__badge",
              })
            : _e
            ? t.createElement("div", {
                className: "p-workspace_filter_menu__item__dot",
              })
            : null;
        }
        c(j, "WorkspaceFilterMenuItemBadge");
        function G($) {
          let { teamId: K, icon: _e, label: de, description: Ne } = $;
          return t.createElement(
            "div",
            {
              className: "p-workspace_filter_menu__item",
            },
            _e &&
              t.createElement(
                "div",
                {
                  className: "p-workspace_filter_menu__item__icon",
                },
                _e
              ),
            t.createElement(
              "span",
              {
                className: "inline_flex flex_direction_column",
              },
              t.createElement(
                "span",
                {
                  className: "overflow_ellipsis",
                },
                de
              ),
              Ne
                ? t.createElement(
                    "span",
                    {
                      className: "c-menu_item__description",
                    },
                    Ne
                  )
                : null
            ),
            K &&
              t.createElement(j, {
                teamId: K,
              })
          );
        }
        c(G, "WorkspaceFilterMenuItem");
        var te = e(4308550795),
          me = e(3837503631),
          Re = e(7412620280),
          Se = e(3514831633),
          Te = e(8773153312),
          $e = e(698013937),
          xe = e(6695353875),
          ve = e(3040624063),
          oe = e(5304329924),
          H = e(2375333597),
          X = e(387484329),
          pe = e(4813703725),
          ee = e(4804990235),
          ze = e(3677514771);
        const we = (0, pe.$j)(
          ($) => (0, ze.DK)($, (0, ee.Ml)($)),
          ($) => $
        );
        function Ue() {
          return (
            (Ue =
              Object.assign ||
              function ($) {
                for (var K = 1; K < arguments.length; K++) {
                  var _e = arguments[K];
                  for (var de in _e)
                    Object.prototype.hasOwnProperty.call(_e, de) &&
                      ($[de] = _e[de]);
                }
                return $;
              }),
            Ue.apply(this, arguments)
          );
        }
        c(Ue, "_extends");
        const He = new f.Ay("ia4");
        function Xe($) {
          return !(0, x.B)($);
        }
        c(Xe, "isWorkspaceMenuItem");
        function Be($) {
          return (0, A.Ac)($) ? $.type : $.workspace.id;
        }
        c(Be, "workspaceFilterToMenuItemKey");
        function qe($) {
          let { className: K, teamIconClassName: _e } =
            arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          if ((0, x.B)($)) return null;
          const de = K ?? _e;
          return $.meta.workspaceType === A.SX.External
            ? t.createElement(te.A, {
                workspaceId: $.key,
                className: (0, s.A)(de, "margin_top_25_negative"),
              })
            : t.createElement($e.U, {
                className: de,
                icon: $.meta.icon,
                size: 20,
                teamName: $.meta.label,
              });
        }
        c(qe, "makeMenuItemIcon"), (qe.displayName = "makeMenuItemIcon");
        const ct = c(() => {
          const $ = (0, P.wA)(),
            K = (0, u.d4)(ze.FR),
            _e = (0, u.d4)(we),
            de = (0, u.d4)(ve.Z),
            Ne = (0, u.d4)(xe.Zg),
            he = (0, u.wz)(oe.U),
            be = (0, t.useCallback)(
              (Ae) => {
                $(
                  Ne
                    ? (0, X.AZ)({
                        pref: "workspace_filter_selected",
                        value: Ae.key,
                      })
                    : (0, o.IQ)({
                        workspaceFilter: (0, N.B)(Ae),
                      })
                );
              },
              [$, Ne]
            ),
            Fe = (0, t.useCallback)(() => {
              $(
                (0, H.q)({
                  element: t.createElement(Re.S, null),
                  isStackable: !0,
                })
              );
            }, [$]),
            fe = (0, t.useMemo)(
              () =>
                (0, U.n)({
                  label: He.t("All workspaces"),
                  key: A.MR.All,
                  icon: "workspace",
                }),
              []
            ),
            {
              workspacesMenuItems: We,
              externalWorkspaceMenuItems: Le,
              workspacesMenuItemsByKey: ye,
            } = (0, t.useMemo)(() => {
              const Ae = [fe, ...K.map((rt) => (0, p.I)(rt, A.SX.Internal))],
                Je = [..._e.map((rt) => (0, p.I)(rt, A.SX.External))],
                dt = Ae.concat(Je);
              return {
                workspacesMenuItems: Ae,
                externalWorkspaceMenuItems: Je,
                workspacesMenuItemsByKey: dt.reduce(
                  (rt, Lt) => ((rt[Lt.key] = Lt), rt),
                  {}
                ),
              };
            }, [fe, _e, K]),
            { selectedKey: Ye, selectedItem: et } = (0, t.useMemo)(() => {
              const Ae = he ? Be(he) : void 0,
                Je = Ae ? ye[Ae] : void 0;
              return Je
                ? {
                    selectedKey: Ae,
                    selectedItem: Je,
                  }
                : {
                    selectedKey: fe.key,
                    selectedItem: fe,
                  };
            }, [he, ye, fe]),
            at = (0, t.useCallback)(
              (Ae) => ({
                type: Te.A.checkbox,
                checked: Ae.key === Ye,
                key: Ae.key,
                click: () => be(Ae),
                className: "p-workspace_filter_menu__item_container",
                classNameListItem: "p-workspace_filter_menu__item_label",
                ariaRole: "menuitemradio",
                children: t.createElement(G, {
                  teamId: Xe(Ae) ? Ae.key : void 0,
                  label: Ae.meta.label,
                  description: Xe(Ae) ? Ae.meta.description : void 0,
                  icon: qe(Ae),
                }),
              }),
              [be, Ye]
            ),
            Ze = (0, t.useMemo)(() => {
              const Ae = Le.length > 0 && [
                {
                  type: Te.A.default,
                  key: "slack-connect-spaces",
                  label: He.t("Slack Connect spaces", {
                    fallbackHash: "c2ef892d18673591cdb460cfc5a7298217f32824",
                  }),
                  disabled: !0,
                },
                ...Le.map((Je) => at(Je)),
                {
                  type: Te.A.separator,
                  key: "separator",
                },
              ];
              return [
                ...We.map((Je) => at(Je)),
                {
                  type: Te.A.separator,
                  key: "separator",
                },
                ...(Ae || []),
                {
                  type: Te.A.default,
                  key: "edit-or-reorder",
                  label: He.t("Edit and reorder workspaces"),
                  click: () => Fe(),
                },
              ];
            }, [We, Le, at, Fe]),
            Rt = (0, t.useCallback)(
              (Ae) => {
                var Je;
                return t.createElement(
                  Se.a,
                  Ue({}, Ae, {
                    width:
                      (Je = Ae.targetBounds) === null || Je === void 0
                        ? void 0
                        : Je.width,
                    menuClassNames: "p-workspace_filter_menu__menu",
                    template: Ze,
                  })
                );
              },
              [Ze]
            );
          if (K.length <= 1 && !de) return null;
          const Tt = qe(et);
          return t.createElement(
            me.A,
            {
              subtype: "workspace_filter_menu",
            },
            t.createElement(
              "div",
              {
                className: "p-workspace_filter_menu__pill_container",
              },
              t.createElement(
                Se.cQ,
                {
                  renderMenu: Rt,
                  position: "bottom-left",
                  offsetY: 4,
                },
                t.createElement(
                  I.Nm,
                  {
                    className: "p-workspace_filter_menu__pill",
                    "data-qa": "workspace_filter_menu",
                    "aria-label": He.t("Workspace filter"),
                  },
                  Tt,
                  t.createElement(
                    "div",
                    {
                      className: (0, s.A)(
                        "p-workspace_filter_menu__pill_name",
                        {
                          "p-workspace_filter_menu__pill_name--no-icon": !Tt,
                        }
                      ),
                    },
                    et.meta.label
                  ),
                  t.createElement(
                    "div",
                    {
                      className: "p-workspace_filter_menu__pill_caret",
                    },
                    t.createElement(l.A, {
                      name: "caret-down",
                      size: "18",
                    })
                  )
                )
              )
            )
          );
        }, "WorkspaceFilterMenu");
        ct.displayName = "WorkspaceFilterMenu";
        const It = ct;
        var st = e(4481313819),
          Mt = e(7027996684),
          _t = e(5617110048),
          q = e(8011352381),
          ot = e(1224315998),
          At = e(571104883),
          Ct = e(3785575952),
          nt = e(4761125736),
          Nt = e(3565677134),
          Et = e.n(Nt);
        const Kt = new f.Ay("search"),
          dn = {
            onClick: {
              action: ot.UiAction.CLICK,
            },
          },
          Yt = {
            eventId: ot.EventId.SEARCH_QUICKSWITCHER_BUTTON_OPEN,
            elementName: "search_quickswitcher_button_entry",
            onClick: {
              enableClogAction: !0,
            },
          },
          qt = {
            marginRight: "8px",
          },
          ce = c(() => {
            const $ = (0, P.wA)(),
              K = (0, u.d4)(
                (de) => (0, nt._Z)(de, "switchy_new_entry") === "treatment"
              ),
              _e = (0, t.useCallback)(() => {
                $((0, Ct.T_)());
              }, [$]);
            return t.createElement(
              _t.A,
              {
                autoClogProps: Yt,
                actionProps: dn,
              },
              t.createElement(
                I.Nm,
                {
                  className: `${Et().button} dt-hocus:theme-surf-inv-ter`,
                  onClick: _e,
                },
                t.createElement(
                  "div",
                  {
                    className: Et().textContainer,
                  },
                  t.createElement(l.A, {
                    name: "quick-switch",
                    size: "20",
                    style: qt,
                  }),
                  t.createElement(
                    q.A,
                    {
                      lines: 1,
                    },
                    K ? Kt.t("Jump to\u2026") : "Jump to\u2026"
                  )
                ),
                t.createElement(
                  "span",
                  null,
                  (0, At.cX)() ? "\u2318K" : "Ctrl+K"
                )
              )
            );
          }, "SearchQuickswitcherButton");
        ce.displayName = "SearchQuickswitcherButton";
        const Qe = ce,
          ht = t.memo(() => {
            const [$, K] = (0, t.useState)(!1),
              _e = (0, u.d4)(O.ag),
              de = (0, u.d4)(O.NP),
              Ne = (0, u.d4)(
                (Fe) => (0, nt._Z)(Fe, "switchy_new_entry") === "treatment"
              ),
              he = _e || de,
              be = (0, t.useCallback)((Fe) => {
                K(Fe);
              }, []);
            return t.createElement(
              st.A,
              {
                eventId: ot.EventId.HOME_VIEW_OPEN,
                clogImpression: !0,
                enableClogImpressionOffScreen: !1,
                clogImpressionDuration: !0,
              },
              t.createElement(
                "div",
                {
                  className: "p-ia4_channel_list",
                },
                t.createElement(n.A, {
                  isChannelListOverflowing: $,
                }),
                Ne ? t.createElement(Qe, null) : t.createElement(It, null),
                t.createElement(y, null),
                he && t.createElement(D, null),
                t.createElement(Mt.a, {
                  onOverflow: be,
                })
              )
            );
          });
      },
      7133181643: (W, g, e) => {
        "use strict";
        e.d(g, {
          V: () => s,
          W: () => I,
        });
        var t = e(8161242485),
          O = e(2047021170),
          P = e(6827180593);
        const s = "has_clicked_highlighted_header_compose_button",
          I = (0, t.Ay)((v) => ((0, O.ty)(v, s) ? !1 : (0, P.H)(v) < 5));
        I.meta = {
          name: "createSelector",
          key: "createSelectorshouldShowHighlightedComposeButton",
          description: (v) => ((0, O.ty)(v, s) ? !1 : (0, P.H)(v) < 5),
        };
      },
      289112722: (W, g, e) => {
        "use strict";
        e.d(g, {
          A: () => t,
        });
        const t = "SALESFORCE_LOGIN_WIDGET:v2";
      },
      5055839243: (W, g, e) => {
        "use strict";
        e.d(g, {
          _: () => E,
        });
        var t = e(5824283093),
          O = e(2683115972),
          P = e(8683010724),
          s = e(2539163284),
          I = e(2409757433),
          v = e(7925057078),
          T = e.n(v),
          u = e(735940183),
          h = e(5946832122),
          D = e(8624014077),
          n = e(289112722),
          m = e(6065326583),
          l = e.n(m);
        const f = new u.Ay("salesforce_connections"),
          k = c((r) => {
            let { onClick: i, experimentSfdcSeamlessAuthFeGroupOn: a } = r;
            return t.createElement(
              O.Ay,
              {
                type: "outline",
                onClick: i,
              },
              t.createElement(
                "span",
                {
                  className: l().buttonContent,
                },
                t.createElement(
                  s.c,
                  {
                    space: "25",
                  },
                  t.createElement(P.A, {
                    name: "sf-cloud",
                    size: "20",
                  }),
                  t.createElement(
                    I.E,
                    {
                      weight: "bold",
                    },
                    a ? f.t("Sign in to Salesforce") : "Sign in to Salesforce"
                  )
                ),
                t.createElement(P.A, {
                  name: "caret-right",
                  size: "20",
                })
              )
            );
          }, "SalesforceSignInButton");
        k.displayName = "SalesforceSignInButton";
        const E = c((r) => {
          let { experimentSfdcSeamlessAuthFeGroupOn: i, onSignIn: a } = r;
          const [_, o] = (0, D.r)(n.A, "visible"),
            d = (0, t.useCallback)(() => {
              o("collapsed");
            }, [o]);
          return t.createElement(
            t.Fragment,
            null,
            _ === "collapsed" &&
              t.createElement(
                "div",
                {
                  className: l().collapsed,
                },
                t.createElement(k, {
                  onClick: a,
                  experimentSfdcSeamlessAuthFeGroupOn: i,
                })
              ),
            _ === "visible" &&
              t.createElement(
                "div",
                {
                  className: l().widget,
                },
                t.createElement(
                  "div",
                  {
                    className: l().header,
                  },
                  t.createElement(
                    I.E,
                    {
                      weight: "black",
                      size: "subtitle",
                      color: "Theme/Content/Inverse primary",
                    },
                    i
                      ? f.t("Bring Salesforce data into Slack")
                      : "Bring Salesforce data into Slack"
                  ),
                  t.createElement(
                    s.c,
                    {
                      space: "75",
                      alignY: "start",
                    },
                    t.createElement("img", {
                      className: l().icon,
                      src: T(),
                      alt: "ladder to the cloud",
                    }),
                    t.createElement(
                      h.A,
                      {
                        onClick: d,
                        "aria-label": i
                          ? f.t("Collapse this widget")
                          : "Collapse this widget",
                      },
                      t.createElement(P.A, {
                        name: "close",
                      })
                    )
                  )
                ),
                t.createElement(k, {
                  onClick: a,
                  experimentSfdcSeamlessAuthFeGroupOn: i,
                })
              )
          );
        }, "SalesforceSignInWidget");
        E.displayName = "SalesforceSignInWidget";
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-client-channel-list-view.a5c1c6bf92b39da2d853.min.js.map
