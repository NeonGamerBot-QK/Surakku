"use strict";
(() => {
  var R = Object.defineProperty;
  var M = (c, s) =>
    R(c, "name", {
      value: s,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-async-client-thread-view"],
    {
      2093672580: (c, s, e) => {
        e.r(s),
          e.d(s, {
            default: () => C,
          });
        var t = e(5824283093),
          O = e(2052624953),
          A = e(7098679063),
          p = e(4587082424),
          D = e(5519146941),
          u = e(3275490582),
          h = e(3110884894),
          d = e(2562405183),
          I = e(2284446909);
        const E = M((w) => {
          let { view: a } = w;
          var i, r;
          const { isMainWindow: K, windowId: f } = (0, t.useContext)(D.A),
            v = (0, d.d4)(O.tc),
            W = K ? "main" : f,
            T =
              a == null || (i = a.params) === null || i === void 0
                ? void 0
                : i.threadId;
          if (!T) throw new Error("thread ID missing from thread view");
          const {
              channelId: _,
              threadTs: l,
              quipCommentThreadId: y,
            } = (0, h.Sb)(T),
            B = `thread-${W}-${_}-${l}`,
            n = (0, d.d4)((o) => ((0, p.TN)(o, _) ? (0, p.tC)(o, _) : void 0)),
            m = (0, d.d4)((o) => {
              const P = (0, h.Iu)(_, l);
              return P ? (0, I.MO)(o, P) : !1;
            }),
            L = (0, t.useMemo)(() => {
              if (!(!v || !n))
                return {
                  hasShimmer: m,
                  appId: n == null ? void 0 : n.app_id,
                };
            }, [v, m, n]);
          return t.createElement(A.A, {
            threadTs: l,
            quipCommentThreadId: y,
            replyTs:
              a == null || (r = a.params) === null || r === void 0
                ? void 0
                : r.replyTs,
            channelId: _,
            serializationKey: B,
            aiApps: L,
          });
        }, "ThreadView");
        E.displayName = "ThreadView";
        const C = t.memo((0, u.A)(E));
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-client-thread-view.4d6e075708025fa47a16.min.js.map
