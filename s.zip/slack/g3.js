"use strict";
(() => {
  var Mo = Object.defineProperty;
  var i = (Q, F) =>
    Mo(Q, "name", {
      value: F,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-async-client-boot-deferred"],
    {
      4893422024: (Q, F, r) => {
        r.r(F),
          r.d(F, {
            register: () => Ao,
          });
        var d = r(9706240641),
          h = r(796111729),
          g = r(9012396182),
          m = r(6533394955),
          Ct = r(6766954308);
        function Bt() {
          try {
            const o = (0, m.getClientStoreInstance)();
            if (!o) return;
            const t = (0, g.getFocusedWorkspace)(
              o == null ? void 0 : o.getState()
            );
            if (!t) return;
            const e = (0, m.getStoreInstanceByTeamId)(t);
            if (!e) return;
            (0, Ct.B0)(e);
          } catch (o) {
            (0, h.Wo)().warn(
              "BOOT-CLIENT",
              "trying to set default accessibility preferences failed",
              o
            );
          }
        }
        i(Bt, "updateA11yPreferences");
        var N = r(4798756512),
          $ = r(3855029223);
        function Et() {
          const t = (0, m.getClientStoreInstance)().getState(),
            e = (0, g.getBootedWorkspaces)(t),
            n = (0, g.getFocusedWorkspace)(t),
            l = (0, m.getStoreInstanceByTeamId)(n).getState(),
            s = (0, $.E)({
              state: l,
            }),
            c = s.createSpan({
              name: "workspaces:booted",
              samplingOptions: {
                sampleType: N.tS.ALWAYS,
              },
              options: {
                tags: {
                  count: e.length,
                },
              },
            });
          c.close(), s.reportSpans([c]);
        }
        i(Et, "beaconWorkspacesCount");
        var wt = r(1361861974),
          Ot = r(1319016163);
        function kt() {
          return D.apply(this, arguments);
        }
        i(kt, "cleanUpOldPersistedData");
        function D() {
          return (
            (D = (0, d.coroutine)(function* () {
              const o = (0, Ot.Ay)();
              yield (0, wt.Z)(o);
            })),
            D.apply(this, arguments)
          );
        }
        i(D, "_cleanUpOldPersistedData");
        var C = r(7031360717),
          E = r(4724591729),
          Ft = r(2786906754);
        const Lt = [
          "force_cold_boot",
          "force_build_version",
          "recommended_build_version",
          "build_manifest_last_modified",
        ];
        function Wt() {
          !(0, E.KV)() ||
            (0, E.b3)() ||
            window.isReloading ||
            Lt.forEach((o) => {
              if (!window.location.search.match(o)) return;
              const t = (0, Ft.qy)(window.location.href, o);
              window.history.replaceState(window.history.state, "", t),
                (0, C.pq)("BOOT", `cleared ${o} flag`);
            });
        }
        i(Wt, "clearReloadURLState");
        var q = r(8414054597),
          Pt = r(6191669412),
          Vt = r(6698148269);
        function _t() {
          try {
            (0, Pt.b)(), (0, Vt.F)(), (0, q._7)();
          } catch (o) {
            (0, h.Wo)().error("Failed to report client metrics", o);
          }
        }
        i(_t, "reportClientMetrics");
        var S = r(3245843483),
          Nt = r(1583163054),
          B = r(571104883);
        const $t = 1e3 * 60 * 30;
        function Dt(o) {
          const t = i(() => {
            const e = o.createSpan({
              name: "desktop_dogfood:active",
              samplingOptions: {
                sampleType: N.tS.ALWAYS,
              },
              options: {
                tags: {
                  ssb_version: (0, S.CmU)(),
                  ssb_instance_id: (0, S.sST)(),
                  ssb_platform: (0, S.uVy)(),
                  unrefined: !0,
                },
              },
            });
            e.close(), o.reportSpans([e]);
          }, "report");
          setInterval(t, $t), t();
        }
        i(Dt, "queueDesktopDogfoodActivityInterval");
        function xt() {
          if ((0, B.y3)() && (0, S.NjF)() === Nt.zS)
            try {
              const t = (0, m.getClientStoreInstance)().getState(),
                e = (0, g.getFocusedWorkspace)(t),
                a = (0, m.getStoreInstanceByTeamId)(e).getState(),
                l = (0, $.E)({
                  state: a,
                }),
                s = l.createSpan({
                  name: "desktop_dogfood:booted",
                  samplingOptions: {
                    sampleType: N.tS.ALWAYS,
                  },
                  options: {
                    tags: {
                      ssb_version: (0, S.CmU)(),
                      ssb_instance_id: (0, S.sST)(),
                      ssb_platform: (0, S.uVy)(),
                      unrefined: !0,
                    },
                  },
                });
              s.close(), l.reportSpans([s]), Dt(l);
            } catch (o) {
              (0, h.Wo)().error("Failed to report dogfood boot", o);
            }
        }
        i(xt, "setupDesktopDogfoodMetricReporter");
        var Ut = r(2409168529),
          tt = r(5534420337),
          Gt = r(4900557724),
          et = r(4949104520),
          ot = r(1031947056),
          jt = r(6634003941);
        const nt = 4,
          Yt = i(
            (o) => (0, et.A)(40 * 1e3 * 2.5 ** (o - 1), o > 1 ? -0.2 : -1, 0.2),
            "getDelayForAttempt"
          ),
          x = (0, ot.Ay)("Preload Collab SDK after boot", function (o, t) {
            let { attempt: e = 1 } =
              arguments.length > 2 && arguments[2] !== void 0
                ? arguments[2]
                : {};
            return new Promise((n) => {
              setTimeout(() => {
                o(
                  (0, jt.A)({
                    isPreload: !0,
                  })
                )
                  .then((a) => {
                    if (
                      navigator &&
                      navigator.serviceWorker &&
                      navigator.serviceWorker.controller
                    ) {
                      var s, c;
                      navigator == null ||
                        (s = navigator.serviceWorker) === null ||
                        s === void 0 ||
                        (c = s.controller) === null ||
                        c === void 0 ||
                        c.postMessage({
                          type: "canvas_prefetch",
                          urls: a.controllerModuleUrls(),
                        });
                    } else a.preload();
                  })
                  .catch((a) => {
                    (0, tt.Ay)({
                      getState: t,
                    }).error(a, `Error preloading Quip SDK (${e} / ${nt})`),
                      e < nt &&
                        o(
                          x({
                            attempt: e + 1,
                          })
                        );
                  })
                  .finally(() => {
                    n();
                  });
              }, Yt(e));
            });
          });
        x.meta = {
          name: "createThunk",
          key: "createThunkpreloadQuip",
          description: "Preload Collab SDK after boot",
        };
        function zt() {
          const o = (0, m.getStateForClientStore)(),
            t = (0, g.getBootedWorkspaces)(o) || [];
          try {
            const e = t.find((n) => {
              const a = (0, m.getStateByTeamId)(n);
              return (0, Ut.y)(a);
            });
            if (!e) return;
            (0, Gt.BB)(
              () => {
                (0, m.dispatchForTeamId)(e, x());
              },
              {
                timeout: 2e3,
              }
            );
          } catch (e) {
            (0, tt.ph)().error(e, "Error preloading Quip SDK");
          }
        }
        i(zt, "initPreloadQuip");
        var w = r(9190452268),
          Kt = r(1535672935);
        function Ht() {
          (0, m.getClientStoreInstance)().dispatch(
            (0, Kt.setDidBootAllWorkspaces)()
          ),
            (0, h.Wo)().info("BOOT", "Client boot completed"),
            (0, w.rh)().count("sonic_boot_completed");
        }
        i(Ht, "markBootComplete");
        var Jt = r(4780055684);
        function Xt() {
          const o = (0, m.getClientStoreInstance)();
          if (o)
            try {
              const t = o.getState(),
                e = (0, g.getFocusedWorkspace)(t);
              (0, m.getStoreInstanceByTeamId)(e).dispatch((0, Jt.O)());
            } catch (t) {
              (0, h.Wo)().error(
                "BOOT",
                "Failed to show Day 1 Creator welcome modal",
                t
              );
            }
        }
        i(Xt, "maybeShowDay1CreatorWelcomeModalAtBoot");
        var Zt = r(8187930033),
          rt = r(8847766420),
          Qt = r(4914127094),
          qt = r(876239864);
        const at = (0, ot.Ay)(
          "Signal to the desktop that all delegates are ready",
          (o, t) => {
            (0, S.zu0)(), ee(t);
          }
        );
        at.meta = {
          name: "createThunk",
          key: "createThunkonWebappBooted",
          description: "Signal to the desktop that all delegates are ready",
        };
        const te = at,
          st = new Set();
        function ee(o) {
          setTimeout(
            (0, d.coroutine)(function* () {
              var t;
              const e = o(),
                n = "ssb",
                a = (0, Qt.F)(e),
                l = (0, rt.ZT)(e),
                s = (0, rt.jV)(e);
              if (s) {
                if (st.has(s)) return;
                st.add(s);
              }
              const c = yield Zt.Ay.fetch({
                  method: "api.features",
                  args: {
                    token: a,
                    platform: n,
                  },
                  teamId: l,
                }),
                u =
                  c == null || (t = c.features) === null || t === void 0
                    ? void 0
                    : t.desktop_diagnostics_timestamp;
              if (u) {
                const p = (0, h.Ay)({
                  teamId: l,
                  label: "CLIENT-LOGS",
                });
                p.info(
                  `Received request ${u} for logs ON BOOT; sending them up...`
                );
                try {
                  yield (0, q.cs)();
                } catch (f) {
                  p.warn(
                    `Error running client metrics ON BOOT for request ${u}: ${f}`
                  );
                }
                (0, qt.A)(l);
              }
            }),
            6e4
          );
        }
        i(ee, "maybeUploadLogs");
        const oe = "SIGNAL-TO-DESKTOP";
        function ne() {
          if (!(0, B.y3)()) return;
          const t = (0, m.getClientStoreInstance)().getState(),
            e = (0, g.getFocusedWorkspace)(t);
          (e
            ? (0, h.Ay)({
                teamId: e,
              })
            : (0, h.Wo)()
          ).info(oe, "Attempted boot for all workspaces, signaling desktop");
          for (const a of (0, g.getBootedWorkspaces)(t) || [])
            (0, m.dispatchForTeamId)(a, te());
        }
        i(ne, "maybeSignalBootedToDesktop");
        var re = r(8197462216);
        function ae() {
          const o = (0, m.getClientStoreInstance)();
          (0, g.getBootedWorkspaces)(o.getState()).forEach((e) => {
            const n = (0, m.getStoreInstanceByTeamId)(e);
            (0, re.Al)({
              teamId: e,
              store: n,
            });
          });
        }
        i(ae, "persistNewData");
        var se = r(9733150292),
          ie = r(6508028729),
          le = r(8895181018),
          ce = r(4496040127);
        const ue = "recentlyUsedTeamIds",
          de = "mostRecentlyUsedDate",
          it = 10;
        function me() {
          if (!(0, ce.VA)()) return;
          const o = (0, se.W6)(ue) || [];
          if ((o == null ? void 0 : o.length) <= it) return;
          const t = o.slice(it),
            e = (0, ie.A)();
          t.forEach((n) => {
            const a = e[n];
            if (!a) return;
            const l = a[de];
            if (!l) return;
            const s = (0, le.A)(new Date(), new Date(l));
            (0, w.Cy)({
              teamOrEnterpriseId: n,
            }).store("least_recently_used_workspaces_last_use", s);
          });
        }
        i(me, "reportLongTailTeamUsage");
        const fe = 3 * 60 * 1e3,
          lt = 60 * 60 * 1e3,
          ct = 10 * 60 * 1e3,
          pe = "ssb-memory-stats";
        var L = r(6422693406),
          ut = r(8665296019),
          W = r(1033764764),
          dt = r(4423055085),
          he = r(7239742441);
        const mt = (0, h.Wo)();
        function ge(o) {
          return ft(o);
        }
        i(ge, "fetchMemoryStats");
        const U = "workingSetSize";
        function ft(o) {
          return (S.vkf.isAvailable() ? (0, S.vkf)() : (0, S.rc_)())
            .then((t) => {
              const e = {},
                n = t.processMetrics || t;
              if (!n || n.length === 0)
                return (
                  mt.warn(
                    "STATS",
                    `No memory stats collected getAppMetrics:${n}`,
                    {
                      subtype: "stats_no_memory",
                    }
                  ),
                  e
                );
              if (navigator && navigator.hardwareConcurrency) {
                const a = (0, ut.A)(n, (l) => {
                  let { cpu: s } = l;
                  return s.percentCPUUsage * navigator.hardwareConcurrency;
                });
                e[`cpu_v5_app_${o}_teams`] = (0, he.GB)(a, 2);
              }
              return (
                n.forEach((a) => {
                  let { type: l, memory: s } = a;
                  if (U in s) {
                    const c = `memory_v5_app_mb_${o}_teams_${l.toLowerCase()}_process`;
                    c in e || (e[c] = 0), (e[c] += Math.round((0, W.UK)(s[U])));
                  }
                }),
                (e[`memory_v5_app_mb_${o}_teams`] = Se(n, U)),
                ve(e, 5, o),
                e
              );
            })
            .catch((t) =>
              mt.error("STATS", `getAppMetrics failed: ${t.message}`)
            );
        }
        i(ft, "fetchMemoryStatsV5");
        function Se(o, t) {
          const e = (0, ut.A)(o, (n) => {
            let { memory: a } = n;
            return a[t];
          });
          return Math.ceil((0, W.UK)(e));
        }
        i(Se, "sumMemoryMetricsByKey");
        function ve(o, t, e) {
          window.performance &&
            window.performance.memory &&
            ((o[`heap_v${t}_used_mb_${e}_teams`] = (0, W.hZ)(
              performance.memory.usedJSHeapSize
            )),
            (o[`heap_v${t}_total_mb_${e}_teams`] = (0, W.hZ)(
              performance.memory.totalJSHeapSize
            )));
        }
        i(ve, "addJSHeapMetrics"),
          (0, dt.ul)("ssbMetrics", {
            fetchMemoryStatsV5: ft,
          });
        var G = r(2250002584);
        function ye() {
          if (!(0, B.y3)()) return L.S.resolve();
          const o = (0, w.rh)(),
            t = (0, G.F)(),
            e = t.createMetricsTrace({
              label: pe,
            });
          function n() {
            const l = (0, m.getStateForClientStore)(),
              s = (0, g.getBootedWorkspaces)(l),
              c = s ? s.length : 0;
            return ge(c).then((u) =>
              u
                ? (Object.keys(u).forEach((f) => {
                    o.store(f, u[f], {
                      allow_negative: f.indexOf("delta") !== -1,
                    });
                    const v = /_\d+?_teams/;
                    e.store({
                      name: f.replace(v, ""),
                      value: u[f],
                    }).addTags({
                      num_teams: c,
                    });
                  }),
                  t.reportTrace(e),
                  u)
                : null
            );
          }
          i(n, "fetchStatsAndBeacon");
          const a = lt + Math.floor(Math.random() * ct);
          return (
            setInterval(() => n(), a), setTimeout(() => n(), fe), L.S.resolve()
          );
        }
        i(ye, "storeSSBMemoryStatsOnAnInterval");
        var Te = r(7823346015),
          Ie = r(8086952004),
          Ae = r(6273911963),
          I = r(8445020572),
          O = r(4096483543),
          be = r(9283444310);
        const Me = {
            is_expired: !1,
            ok: !0,
          },
          Re = {
            is_expired: !1,
            ok: !1,
          };
        function Ce(o) {
          return j.apply(this, arguments);
        }
        i(Ce, "clientCheckVersion");
        function j() {
          return (
            (j = (0, d.coroutine)(function* (o) {
              let { teamIds: t, enterpriseIds: e } = o;
              if ((0, E.b3)())
                return (
                  (0, h.Wo)().warn(
                    "MIN-VERSION",
                    "Cannot check whether to reload when using js_path. Skipping client.checkVersion call."
                  ),
                  Me
                );
              if (!(0, O.A)())
                throw new Error(
                  "client.checkVersion should only be used in the client."
                );
              try {
                var n;
                const a = {
                    team_ids: t,
                    enterprise_ids: e,
                    build_version_ts: parseInt(
                      (n = (0, I.xb)()) !== null && n !== void 0 ? n : "",
                      10
                    ),
                    build_manifest_last_modified: (0, I.z8)(),
                  },
                  l = (0, I.Cy)();
                l && (a.config_version_ts = l);
                const s = Be(a),
                  c = yield Ae.A.fetch({
                    url: "/api/client.checkVersion",
                    httpMethod: "POST",
                    payload: s,
                  });
                return JSON.parse(c);
              } catch (a) {
                return (
                  (0, h.Wo)().error(
                    "Failed to fetch/parse client.checkVersion response",
                    a
                  ),
                  Re
                );
              }
            })),
            j.apply(this, arguments)
          );
        }
        i(j, "_clientCheckVersion");
        function Be(o) {
          return (0, be.t)(o, "client.checkVersion");
        }
        i(Be, "getClientCheckVersionPayload");
        var Ee = r(9113979368),
          we = r(4015010068),
          Oe = r(5257368278),
          ke = r(7204143202);
        const Y = (0, Oe.A)(
          "Check to see whether we need to reload",
          (function () {
            var o = (0, d.coroutine)(function* (t, e, n) {
              let {
                reason: a = "unknown",
                teamIds: l = [],
                skipExpiryCheck: s = !1,
              } = n;
              const c = (0, h.Wo)();
              if ((0, E.b3)())
                return (
                  c.warn(
                    "MIN-VERSION",
                    "Cannot check whether to reload when using js_path. Skipping client.shouldReload call."
                  ),
                  {
                    should_reload: !1,
                    reason: "js_path",
                  }
                );
              if (!(0, O.A)())
                throw new Error(
                  "client.shouldReload should only be used in the client."
                );
              const u = (0, I.fj)();
              if (!u)
                throw new Error(
                  "Cannot check whether to reload if we\u2019re missing versionTs"
                );
              const p = (0, I.z8)(),
                f = (0, I.xb)(),
                v = parseInt(f ?? "", 10),
                y = {
                  versionTs: u,
                  reason: a,
                  buildVersionTs: v,
                  skipExpiryCheck: s,
                  buildManifestLastModified: p,
                };
              (0, Ee.A)(l) || (y.teamIds = l),
                (0, we.A)(v) &&
                  (0, h.Wo)().error(
                    "MIN-VERSION",
                    `Invalid build version timestamp: ${f}`
                  );
              const M = (0, I.Cy)();
              M && (y.configVersionTs = M),
                (0, h.Wo)().info(
                  "MIN-VERSION",
                  `teamIds: ${
                    (l == null ? void 0 : l.join(",")) || "NONE"
                  }; versionTs: ${u}; buildVersionTs: ${v}; buildManifestLastModified: ${p}; configVersionTs: ${M}; All config versions: ${(0,
                  I.r6)()}`
                );
              try {
                return t((0, ke.t)(y));
              } catch (b) {
                var T;
                throw (
                  ((b == null || (T = b.data) === null || T === void 0
                    ? void 0
                    : T.error) === "invalid_arguments" &&
                    (0, h.Wo)().error(
                      `client.shouldReload failed with invalid arguments: team_ids=${l.join(
                        ","
                      )}; version=${
                        y.buildVersionTs
                      } buildManifestLastModified=${
                        y.buildManifestLastModified
                      }`,
                      b
                    ),
                  b)
                );
              }
            });
            return function (t, e, n) {
              return o.apply(this, arguments);
            };
          })()
        );
        Y.meta = {
          name: "createFetcher",
          key: "createFetcherclientShouldReloadImmediately",
          description: "Check to see whether we need to reload",
        };
        var pt = r(2872463257),
          Fe = r(504058561),
          Le = r(322597465);
        const ht = "MIN-VERSION";
        function We(o) {
          return z.apply(this, arguments);
        }
        i(We, "checkForMinVersionBump");
        function z() {
          return (
            (z = (0, d.coroutine)(function* (o) {
              const t = (0, m.getClientStoreInstance)();
              if ((0, Fe.z$)()) return Pe(o);
              const e = (0, g.getFocusedWorkspace)(t.getState()),
                n = (0, m.getStoreInstanceByTeamId)(e),
                a = (0, g.getBootedWorkspaces)(t.getState());
              return n.dispatch(
                Y({
                  teamIds: a,
                  reason: o,
                })
              );
            })),
            z.apply(this, arguments)
          );
        }
        i(z, "_checkForMinVersionBump");
        function Pe(o) {
          return K.apply(this, arguments);
        }
        i(Pe, "checkForMinVersionBumpInGovClients");
        function K() {
          return (
            (K = (0, d.coroutine)(function* (o) {
              const t = (0, m.getClientStoreInstance)();
              var e;
              const n =
                  (e = (0, g.getBootedWorkspaces)(t.getState())) !== null &&
                  e !== void 0
                    ? e
                    : [],
                a = (0, g.getBootedOrgs)(t.getState()),
                {
                  is_expired: l,
                  client_min_build_version: s,
                  recommended_build_version: c,
                  build_manifest_last_modified: u,
                } = yield Ce({
                  teamIds: n,
                  enterpriseIds: a,
                });
              if (!l)
                return {
                  should_reload: !1,
                  client_min_version: s,
                  recommended_build_version: c,
                  build_manifest_last_modified: u,
                };
              const p = (0, G.F)(),
                f = p.createMetricsTrace({
                  label: "gov_mvb",
                  samplingOptions: {
                    sampleType: pt.nl.ALWAYS,
                  },
                }),
                [v, y] = (0, Te.A)(n, (bo) => (0, Le.H)(bo));
              f.addTags({
                client_min_version: s,
                recommended_build_version: c,
                build_manifest_last_modified: u,
                has_gov_teams: !!v.length,
                has_commercial_teams: !!y.length,
              });
              const { should_reload: M, reason: T } = yield gt({
                teamIds: v,
                reason: o,
              });
              if (!M)
                return (
                  f
                    .count({
                      name: "prevent",
                    })
                    .addTags({
                      environment: "gov",
                      reason: T ?? "none",
                    }),
                  p.reportTrace(f),
                  (0, h.Wo)().info(
                    ht,
                    `Gov teams failed rate limit check with reason ${
                      T ?? "none"
                    }; Preventing reload. teams: (${v.join(",")}) `
                  ),
                  {
                    should_reload: !1,
                    client_min_version: s,
                    recommended_build_version: c,
                    build_manifest_last_modified: u,
                    reason: T,
                  }
                );
              const { should_reload: b, reason: R } = yield gt({
                teamIds: y,
                reason: o,
              });
              return b
                ? (f.count({
                    name: "reload",
                  }),
                  p.reportTrace(f),
                  {
                    should_reload: !0,
                    client_min_version: s,
                    recommended_build_version: c,
                    build_manifest_last_modified: u,
                  })
                : (f
                    .count({
                      name: "prevent",
                    })
                    .addTags({
                      environment: "commercial",
                      reason: R ?? "none",
                    }),
                  p.reportTrace(f),
                  (0, h.Wo)().info(
                    ht,
                    `Commercial teams failed rate limit check with reason ${
                      R ?? "none"
                    }; Preventing reload. teams: (${y.join(",")})`
                  ),
                  {
                    should_reload: !1,
                    client_min_version: s,
                    recommended_build_version: c,
                    build_manifest_last_modified: u,
                    reason: R,
                  });
            })),
            K.apply(this, arguments)
          );
        }
        i(K, "_checkForMinVersionBumpInGovClients");
        function gt(o) {
          return H.apply(this, arguments);
        }
        i(gt, "shouldClientReloadForTeams");
        function H() {
          return (
            (H = (0, d.coroutine)(function* (o) {
              let { teamIds: t, reason: e } = o;
              const n = Ve(t);
              return n
                ? n.dispatch(
                    Y({
                      teamIds: t,
                      reason: e,
                      skipExpiryCheck: !0,
                    })
                  )
                : {
                    should_reload: !0,
                  };
            })),
            H.apply(this, arguments)
          );
        }
        i(H, "_shouldClientReloadForTeams");
        function Ve(o) {
          const t = (0, Ie.A)(o, (e) => !!(0, m.getStoreInstanceByTeamId)(e));
          if (t) return (0, m.getStoreInstanceByTeamId)(t);
        }
        i(Ve, "findAnyStoreInstanceForTeamIds");
        var _e = r(6775756969),
          St = r(1658558415),
          vt = r(8003339552),
          Ne = r(9272190578),
          $e = r(5378147939);
        function De() {
          return (0, $e.A)().waitForHuddleToEnd();
        }
        i(De, "waitForHuddleToEnd");
        var yt = r(5286203919);
        const xe = 45 * 60 * 1e3,
          J = 2e4,
          Tt = 3 * 60 * 60 * 1e3,
          Ue = "MIN-VERSION",
          A = "mvp",
          Ge = "mvb:stale",
          je = "mvb:prev_poll_interval",
          Ye = "mvb:check",
          ze = "mvb:prevent",
          Ke = "mvb:defer",
          He = "mvb:defer:await_blur",
          Je = "mvb:defer:await_online",
          Xe = 0.1,
          Ze = 1;
        var Qe = r(4625941948),
          It = r(8233775522);
        function k() {
          const o = (0, m.getStateForClientStore)();
          return !!((0, It.OD)(o) || ((0, O.A)() && (0, yt.Ak)(o)));
        }
        i(k, "isClientActive");
        var qe = r(6440202463);
        let P = !1;
        const to = A;
        function X(o) {
          const t = (0, I.P2)();
          return t ? parseInt(t, 10) < o : !1;
        }
        i(X, "isVersionStale");
        let eo = i(
          class {
            start() {
              if (this.pollTimer) {
                this.logger.error("MinVersionPoll can only be started once");
                return;
              }
              if (!P && ((0, St.A)() || (0, vt.A)())) return;
              this.logger.info("Starting client min-version poll.");
              const t = (0, et.A)(xe, 0.8, 1.2);
              (this.pollTimer = window.setInterval(
                () => this.checkForMinVersionBumpAndMaybeReload(),
                t
              )),
                this.initDebugger();
            }
            checkForMinVersionBumpAndMaybeReload() {
              var t = this;
              return (0, d.coroutine)(function* () {
                const e = t.logger,
                  n = t.telemeter;
                (t.lastPollTs = Date.now()),
                  e.info("Checking to see if we should reload"),
                  n.count(`${A}_check`);
                try {
                  const a = "polling",
                    l = yield t.checkForMinVersionBump(a);
                  if (!l) {
                    e.info(
                      "Missing client.shouldReload response. No need to reload"
                    );
                    return;
                  }
                  const {
                    client_min_version: s,
                    should_reload: c,
                    reason: u,
                    recommended_build_version: p,
                    build_manifest_last_modified: f,
                  } = l;
                  if (
                    (t.maybeStartTrace(s), t.maybeStartPreventReloadSpan(s), !c)
                  ) {
                    e.info("No need to reload"),
                      n.count(`${A}_shouldreload_prevent_api`),
                      t.maybeIncrementPreventReloadReason(s, u);
                    return;
                  }
                  if (!(0, Qe.RY)(p)) {
                    n.count(`${A}_shouldreload_prevent_client`),
                      t.maybeIncrementPreventReloadReason(s, "client");
                    return;
                  }
                  t.maybeClosePreventReloadSpan(),
                    e.info(
                      "Time to reload! Waiting until the client is online and unfocused."
                    ),
                    t.isSafeToReloadRightNow()
                      ? n.count(`${A}_shouldreload_immediate`)
                      : (n.count(`${A}_shouldreload_will_defer`),
                        t.isClientOnline() ||
                          n.count(`${A}_shouldreload_will_defer_offline`),
                        t.maybeStartAwaitSafeTimeToReloadSpan(),
                        yield t.awaitSafeTimeForReload(),
                        t.maybeCloseAwaitSafeTimeToReloadSpan());
                  const v =
                    "client.shouldReload told us to reload earlier; we are now unfocused and online";
                  e.info(v), t.maybeCloseAndReportTrace();
                  try {
                    t.beforeReloadCallback();
                  } catch (y) {
                    t.logger.error(
                      "MinVersionPoll: beforeReloadCallback failed with error",
                      y
                    );
                  }
                  (0, Ne.As)({
                    reason: v,
                    reasonKey: "client_should_reload",
                    recommendedBuildVersion: p,
                    buildManifestLastModified: f,
                  });
                } catch (a) {
                  e.error("client.shouldReload check failed", a);
                }
              })();
            }
            awaitSafeTimeForReload() {
              let t =
                arguments.length > 0 && arguments[0] !== void 0
                  ? arguments[0]
                  : 0;
              var e = this;
              return (0, d.coroutine)(function* () {
                const n = e.telemeter,
                  a = e.logger;
                return (
                  e.maybeIncrementRetryAttempts(t),
                  L.S.all([e.awaitOnline(), e.awaitBlur()])
                    .tap(() => {
                      a.info(
                        `Online and unfocused, will wait ${J}ms to reload`
                      );
                    })
                    .delay(J)
                    .then(() =>
                      e.isSafeToReloadRightNow()
                        ? (n.count(`${A}_shouldreload_did_defer`), !0)
                        : (a.info(
                            `Waited ${J} ms but now it is no longer safe to reload. Trying again...`
                          ),
                          a.info(
                            `Online: ${e.isClientOnline()}; Inactive: ${
                              !k() || e.hasWaitedTooLongForBlur
                            }; Retry attempts: ${t}`
                          ),
                          e.awaitSafeTimeForReload(t + 1))
                    )
                );
              })();
            }
            isSafeToReloadRightNow() {
              return (
                this.isClientOnline() && (!k() || this.hasWaitedTooLongForBlur)
              );
            }
            awaitBlur() {
              var t = this;
              return (0, d.coroutine)(function* () {
                if (!k() || t.hasWaitedTooLongForBlur) return;
                const e = t.logger,
                  n = t.telemeter;
                t.awaitBlurPromise ||
                  (t.awaitBlurPromise = L.S.delay(Tt).then(() => {
                    e.info(`Waited the max ${Tt}ms for a blur event`),
                      n.count(`${A}_shouldreload_waited_too_long_for_blur`),
                      (t.hasWaitedTooLongForBlur = !0);
                  })),
                  t.maybeStartAwaitBlurSpan();
                const a = (0, m.getClientStoreInstance)(),
                  l = a.getState(),
                  s = [];
                (0, It.OD)(l) &&
                  (e.info("Waiting for blur event to reload"),
                  s.push(a.dispatch((0, qe.H)()))),
                  (0, O.A)() &&
                    (0, yt.Ak)(l) &&
                    (e.info("Waiting for huddle to end to reload"),
                    s.push(De()));
                const c = Promise.all(s);
                return Promise.race([c, t.awaitBlurPromise]).then(() => {
                  t.maybeCloseAwaitBlurSpan();
                });
              })();
            }
            awaitOnline() {
              var t = this;
              return (0, d.coroutine)(function* () {
                return t.isClientOnline()
                  ? !0
                  : (t.logger.info("Waiting to come back online to reload"),
                    t.maybeStartAwaitOnlineSpan(),
                    (0, _e.A)("online").tap(() => {
                      t.maybeCloseAwaitOnlineSpan();
                    }));
              })();
            }
            initDebugger() {
              (0, dt.ul)("minVersionPoll", {
                checkAndMaybeReloadNow: () =>
                  this.checkForMinVersionBumpAndMaybeReload(),
                checkNow: () => this.checkForMinVersionBump("slackdebug"),
                getLastPollTime: () => this.lastPollTs,
                timer: this.pollTimer,
              });
            }
            maybeStartTrace() {
              let t =
                arguments.length > 0 && arguments[0] !== void 0
                  ? arguments[0]
                  : 0;
              try {
                var e, n, a, l;
                if (!X(t) || this.trace) return;
                const s = {
                    client_min_version: t,
                    last_poll_ts: this.lastPollTs,
                    method: "client.shouldReload",
                    reason: "polling",
                    metric_version: Ze,
                  },
                  c = t * 1e3,
                  u = this.getLastSocketConnection(),
                  p = Math.max(c, u);
                this.rootSpan = this.tracer.createSpan({
                  name: Ge,
                  options: {
                    startTime: p,
                    tags: s,
                  },
                  samplingOptions: {
                    sampleType: pt.nl.SESSION,
                    sampleRate: Xe,
                  },
                });
                const f = this.tracer.createSpan({
                  name: je,
                  options: {
                    startTime: p,
                    tags: s,
                    traceId:
                      (e = this.rootSpan) === null || e === void 0
                        ? void 0
                        : e.getTraceId(),
                    parentSpanId:
                      (n = this.rootSpan) === null || n === void 0
                        ? void 0
                        : n.getId(),
                  },
                });
                f.close(),
                  this.tracer.reportSpans([f]),
                  (this.trace = this.tracer.createTrace({
                    traceName: Ye,
                    traceId:
                      (a = this.rootSpan) === null || a === void 0
                        ? void 0
                        : a.getTraceId(),
                    parentSpanId:
                      (l = this.rootSpan) === null || l === void 0
                        ? void 0
                        : l.getId(),
                    tags: s,
                  }));
              } catch {}
            }
            maybeStartPreventReloadSpan() {
              let t =
                arguments.length > 0 && arguments[0] !== void 0
                  ? arguments[0]
                  : 0;
              try {
                if (!this.trace || !X(t) || this.preventSpan) return;
                this.preventSpan = this.trace.startSpan(ze);
              } catch {}
            }
            maybeClosePreventReloadSpan() {
              try {
                if (!this.trace || !this.preventSpan) return;
                this.preventSpan.close(), (this.preventSpan = null);
              } catch {}
            }
            maybeIncrementPreventReloadReason() {
              let t =
                  arguments.length > 0 && arguments[0] !== void 0
                    ? arguments[0]
                    : 0,
                e = arguments.length > 1 ? arguments[1] : void 0;
              try {
                if (!this.trace || !X(t) || !this.preventSpan) return;
                const n = `reason:${e || "unknown"}`,
                  a = this.preventSpan.getTag(n) || 0;
                this.preventSpan.setTag(n, a + 1);
              } catch {}
            }
            maybeStartAwaitSafeTimeToReloadSpan() {
              try {
                if (!this.trace || this.awaitSafeTimeForReloadSpan) return;
                this.awaitSafeTimeForReloadSpan = this.trace.startSpan(Ke, {
                  tags: {
                    is_online: this.isClientOnline(),
                    is_blurred: !k(),
                    has_waited_too_long_for_blur: this.hasWaitedTooLongForBlur,
                  },
                });
              } catch {}
            }
            maybeCloseAwaitSafeTimeToReloadSpan() {
              try {
                if (!this.trace || !this.awaitSafeTimeForReloadSpan) return;
                this.awaitSafeTimeForReloadSpan.close(),
                  (this.awaitSafeTimeForReloadSpan = null);
              } catch {}
            }
            maybeStartAwaitOnlineSpan() {
              try {
                var t;
                if (!this.trace || this.awaitOnlineSpan) return;
                (this.awaitOnlineSpan = this.trace.startSpan(Je, {
                  parentSpanId:
                    (t = this.awaitSafeTimeForReloadSpan) === null ||
                    t === void 0
                      ? void 0
                      : t.getId(),
                })),
                  this.maybeIncrementAwaitOnlineAttempts();
              } catch {}
            }
            maybeCloseAwaitOnlineSpan() {
              try {
                if (!this.trace || !this.awaitOnlineSpan) return;
                this.awaitOnlineSpan.close(), (this.awaitOnlineSpan = null);
              } catch {}
            }
            maybeStartAwaitBlurSpan() {
              try {
                var t;
                if (!this.trace || this.awaitBlurSpan) return;
                (this.awaitBlurSpan = this.trace.startSpan(He, {
                  parentSpanId:
                    (t = this.awaitSafeTimeForReloadSpan) === null ||
                    t === void 0
                      ? void 0
                      : t.getId(),
                })),
                  this.maybeIncrementAwaitBlurAttempts();
              } catch {}
            }
            maybeCloseAwaitBlurSpan() {
              try {
                if (!this.trace || !this.awaitBlurSpan) return;
                this.awaitBlurSpan.addTags({
                  is_blurred: !k(),
                  has_waited_too_long_for_blur: this.hasWaitedTooLongForBlur,
                }),
                  this.awaitBlurSpan.close(),
                  (this.awaitBlurSpan = null);
              } catch {}
            }
            maybeIncrementRetryAttempts(t) {
              try {
                if (!this.trace || !this.awaitSafeTimeForReloadSpan) return;
                this.awaitSafeTimeForReloadSpan.setTag(
                  "total_retry_attempts",
                  t
                );
              } catch {}
            }
            maybeIncrementAwaitOnlineAttempts() {
              try {
                if (!this.trace || !this.awaitSafeTimeForReloadSpan) return;
                const t = "await_online_attempts",
                  e = this.awaitSafeTimeForReloadSpan.getTag(t) || 0;
                this.awaitSafeTimeForReloadSpan.setTag(t, e + 1);
              } catch {}
            }
            maybeIncrementAwaitBlurAttempts() {
              try {
                if (!this.trace || !this.awaitSafeTimeForReloadSpan) return;
                const t = "await_blur_attempts",
                  e = this.awaitSafeTimeForReloadSpan.getTag(t) || 0;
                this.awaitSafeTimeForReloadSpan.setTag(t, e + 1);
              } catch {}
            }
            maybeCloseAndReportTrace() {
              try {
                var t;
                if (!this.trace || !this.trace || !this.rootSpan) return;
                (t = this.rootSpan) === null || t === void 0 || t.close(),
                  this.tracer.reportTrace(this.trace),
                  this.tracer.reportSpans([this.rootSpan]),
                  (this.trace = null),
                  (this.rootSpan = null);
              } catch {}
            }
            testOnlyReset() {
              if (!(0, St.A)() && !(0, vt.A)())
                throw new Error(
                  "MinVersionPoll.reset should only be called in test files!"
                );
              clearInterval(this.pollTimer),
                (this.pollTimer = null),
                this.awaitBlurPromise &&
                  (this.awaitBlurPromise.cancel(),
                  (this.awaitBlurPromise = null)),
                (this.lastPollTs = null),
                (this.hasWaitedTooLongForBlur = !1);
            }
            constructor({
              checkForMinVersionBump: t,
              beforeReloadCallback: e,
              getLastSocketConnection: n,
              isClientOnline: a,
              logger: l = (0, h.Wo)({
                label: Ue,
              }),
              telemeter: s = (0, w.rh)(),
              tracer: c = (0, G.F)(),
            }) {
              (this.hasWaitedTooLongForBlur = !1),
                (this.awaitBlurPromise = null),
                (this.pollTimer = null),
                (this.lastPollTs = null),
                (this.rootSpan = null),
                (this.trace = null),
                (this.preventSpan = null),
                (this.awaitSafeTimeForReloadSpan = null),
                (this.awaitOnlineSpan = null),
                (this.awaitBlurSpan = null),
                (this.checkForMinVersionBump = t),
                (this.beforeReloadCallback = e),
                (this.getLastSocketConnection = n),
                (this.logger = l),
                (this.telemeter = s),
                (this.tracer = c),
                (this.isClientOnline = a);
            }
          },
          "MinVersionPoll"
        );
        Object.defineProperty(
          {
            forceStartMinVersionPollInTests: P,
          },
          "forceStartMinVersionPollInTests",
          {
            get: () => P,
            set: (o) => {
              P = o;
            },
          }
        );
        var oo = r(735940183),
          no = r(8439865561),
          At = r(6728717861);
        const ro = new oo.Ay("min-version-poll");
        let bt = !1;
        function ao() {
          const o = (0, m.getClientStoreInstance)();
          var t;
          const e = new eo({
            isClientOnline: () => !!(0, At.Pb)(o.getState()),
            checkForMinVersionBump: We,
            getLastSocketConnection: () =>
              (t = (0, At.cf)(o.getState())) !== null && t !== void 0 ? t : 0,
            beforeReloadCallback: () => {
              Mt();
            },
          });
          if (bt) {
            (0, C.R8)("MinVersionPoll can\u2019t be started more than once!");
            return;
          }
          e.start(), (bt = !0), (0, w.rh)().count(`${to}_start_2`);
        }
        i(ao, "registerMinVersionPoll");
        function Mt() {
          if (!(0, O.A)()) return;
          const o = (0, m.getClientStoreInstance)(),
            t = (0, g.getFocusedWorkspace)(o.getState());
          (0, m.getStoreInstanceByTeamId)(t).dispatch(
            (0, no.rl)({
              message: ro.t("Reloading Slack\u2026"),
              assertive: !0,
            })
          );
        }
        i(Mt, "notifyAboutReloadAccessibly");
        const Co = {
          notifyAboutReloadAccessibly: Mt,
        };
        var so = r(6338445630);
        const io = i(() => {
          if (!(0, B.pc)()) {
            (0, C.pq)(
              "BOOT",
              "Service Worker unavailable; Skipping registration."
            );
            return;
          }
          (0, so.Lz)();
        }, "registerServiceWorkerOnBoot");
        var lo = r(7002741921);
        function co() {
          if (!(0, B.y3)() || !(0, B.cX)()) return;
          const o = (0, lo.A)("squirrel_mac_direct_contents_write", "on");
          S.Ez7.isAvailable()
            ? ((0, C.pq)(
                "BOOT",
                `Setting Squirrel Mac Direct Contents Write = ${
                  o ? "enabled" : "disabled"
                }`
              ),
              (0, S.Ez7)(o))
            : (0, C.pq)(
                "BOOT",
                "setSquirrelMacDirectContentsWriteEnabled not available"
              );
        }
        i(co, "setUpSquirrelMacDirectContentsWrite");
        var uo = r(268083624),
          Z = r(6968387112);
        function mo() {
          (0, S.g9M)() &&
            (0, uo.n0)(
              "ssb_instance_id",
              (0, S.sST)(),
              365 * 10,
              `.${(0, Z.qF)()}`
            );
        }
        i(mo, "setUpSSBInstanceCookie");
        function fo(o) {
          let t = "";
          for (let e = 0; e < o.classList.length; e++)
            t += `.${o.classList[e]}`;
          return t;
        }
        i(fo, "describeClasses");
        function po(o) {
          return o.id ? `#${o.id}` : "";
        }
        i(po, "describeId");
        function Rt(o) {
          return [o.tagName.toLowerCase(), fo(o), po(o)].join("");
        }
        i(Rt, "describeDomElement");
        function ho(o) {
          let t = Rt(o),
            e = o;
          for (; e.parentElement; )
            (e = e.parentElement), (t = `${Rt(e)} > ${t}`);
          return t;
        }
        i(ho, "describeDomLocation");
        function go() {
          if (!("ReportingObserver" in window)) return;
          const o = (0, E.Cu)()
            ? `https://${(0, Z.Sw)()}/events/report`
            : `https://${(0, Z.c5)()}/events/report`;
          try {
            new window.ReportingObserver(
              (t) => {
                const e = [];
                for (const n of t)
                  if (n.type === "coep" && n.body) {
                    const a = n.body.toJSON(),
                      { blockedURL: l, destination: s } = a;
                    if (s === "image" && l) {
                      const c = document.querySelector(
                        `img[src=${CSS.escape(l)}]`
                      );
                      if (c) {
                        a.html = c.outerHTML;
                        try {
                          a.domLocation = ho(c);
                        } catch (u) {
                          a.domLocationError = u.message;
                        }
                        e.push({
                          type: "coep-enriched",
                          url: n.url,
                          body: a,
                        });
                      }
                    }
                  }
                e.length &&
                  fetch(o, {
                    method: "POST",
                    body: JSON.stringify(e),
                  });
              },
              {
                buffered: !0,
              }
            ).observe();
          } catch (t) {
            (0, C.R8)("BOOT", "Error creating ReportingObserver", t);
          }
        }
        i(go, "enrichCoepReports");
        var So = r(1400384301),
          V = r(3783303734),
          vo = r(6313685253),
          _ = r(2420858174),
          yo = r(8276911661),
          To = r(2158760218);
        function Io() {
          const o = "store_metrics_v3";
          function t() {
            const n = (0, m.getStateForClientStore)(),
              a = (0, g.getBootedWorkspaces)(n);
            a &&
              a.forEach((l) => {
                const s = (0, m.getStateByTeamId)(l);
                if (!s) return;
                const c = (0, $.E)({
                    state: s,
                  }),
                  u = c.createMetricsTrace({
                    label: o,
                  }),
                  p = u.startSpan(`${o}:size_compute_time`),
                  f = (0, V.A)(s.files);
                u.store({
                  name: `${o}:files:count`,
                  value: f,
                });
                const v = (0, V.A)((0, _.xH)((0, yo.Zo)(s)));
                u.store({
                  name: `${o}:members:count`,
                  value: v,
                });
                const y = (0, V.A)((0, _.xH)(s.channels));
                u.store({
                  name: `${o}:channels:count`,
                  value: y,
                });
                const M = (0, vo.A)(
                  (0, _.xH)((0, To.e)(s)),
                  (T, b) => T + (0, V.A)((0, _.xH)(b)),
                  0
                );
                u.store({
                  name: `${o}:messages:count`,
                  value: M,
                }),
                  u.store({
                    name: `${o}:total:count`,
                    value: f + v + y + M,
                  }),
                  p.close(),
                  c.reportTrace(u);
              });
          }
          i(t, "fetchStatsAndBeacon");
          const e = lt + Math.floor(Math.random() * ct);
          setInterval(() => t(), e);
        }
        i(Io, "storeReduxStoreStatsOnAnInterval");
        function Ao(o) {
          o.hooks.bootComplete.tap(
            "Begin min version polling",
            (function () {
              var t = (0, d.coroutine)(function* (e) {
                let { contextualInfo: n } = e;
                return (
                  ao(),
                  {
                    contextualInfo: n,
                  }
                );
              });
              return function (e) {
                return t.apply(this, arguments);
              };
            })()
          ),
            o.hooks.bootComplete.tap(
              "Prepare to record SSB memory usage stats on an interval",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    ye(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Prepare to record Redux store size stats on an interval",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    Io(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Update accessibility preferences",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    Bt(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Set-up a cookie with the SSB instance ID to send along with API requests",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    mo(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Register the service worker",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    io(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Clear unwanted params from URL",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    Wt(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Clean up old persisted data for expired teams",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    yield kt(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Persist data for all booted teams",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    ae(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Enable the direct-contents-write feature of Squirrel.Mac on Mac SSB",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    co(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Collect data on how long it's been since people have used their least active teams",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    me(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Mark the client boot as complete",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    Ht(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "(Desktop only) Signal to desktop that all teams have booted",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    ne(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Preload quip assets",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    zt(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Maybe show Day 1 creator welcome modal",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    Xt(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Collect client metrics on an interval",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    _t(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Record a count of booted teams",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    Et(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Install a ReportingObserver to enrich COEP reports",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    go(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Report dogfood metrics",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    xt(),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            o.hooks.bootComplete.tap(
              "Collect PerformanceResourceTiming data",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: n } = e;
                  return (
                    (0, So.U)(n.getTraceMeta().getTracer()),
                    {
                      contextualInfo: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            );
        }
        i(Ao, "register");
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-client-boot-deferred.5cbcb7a6c79eda287002.min.js.map
