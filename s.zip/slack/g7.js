(() => {
  var tr = Object.defineProperty;
  var c = (x, A) =>
    tr(x, "name", {
      value: A,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-async-client-dms-list-view"],
    {
      3506776591: (x, A, e) => {
        x.exports = e.p + "pnp-bell-notification-bd530cc.png";
      },
      8790440477: (x, A, e) => {
        x.exports = e.p + "pnp-hour-glass-notification-b4dc7aa.png";
      },
      9420092417: (x, A, e) => {
        x.exports = e.p + "robot-373d319.png";
      },
      7925057078: (x, A, e) => {
        x.exports = e.p + "cloud-ladder-95ff829.svg";
      },
      3579140003: (x, A, e) => {
        x.exports = e.p + "handshake-6655502.svg";
      },
      301719806: (x, A, e) => {
        x.exports = e.p + "slack_hash_128-004f20c.png";
      },
      2121234563: (x, A, e) => {
        x.exports = e.p + "after-trial-upgrade-sidebar-gift-box-e737cf5.svg";
      },
      7531383956: (x, A, e) => {
        x.exports = e.p + "clock-eaf8850.svg";
      },
      3758927666: (x, A, e) => {
        x.exports = e.p + "gift-917e797.svg";
      },
      2455200396: (x, A, e) => {
        x.exports = e.p + "sidebar-banner-877c5f6.svg";
      },
      3680131132: (x) => {
        x.exports = {
          inline: "inline__cbb1W",
          space_25: "space_25__be1Qb",
          space_50: "space_50__PD0Bx",
          space_75: "space_75__O2LED",
          space_100: "space_100__V8NFO",
          space_150: "space_150__cGvSB",
          align_inherit: "align_inherit__nSnrm",
          align_start: "align_start__Q8jCq",
          align_center: "align_center__hCbrl",
          alignY_inherit: "alignY_inherit__eSXgq",
          alignY_start: "alignY_start__B3min",
          alignY_center: "alignY_center__VSkk_",
          alignY_end: "alignY_end__NHbzb",
          alignY_baseline: "alignY_baseline__NetmO",
        };
      },
      4593063573: (x) => {
        x.exports = {
          bannerContainer: "bannerContainer__EHIJs",
          bannerContent: "bannerContent__PWOnv",
          closeButton: "closeButton__g7AbN",
          tidyUpButton: "tidyUpButton__CELCg",
          laterButton: "laterButton__qgLJG",
          buttonsContainer: "buttonsContainer__e6qxA",
        };
      },
      3123300647: (x) => {
        x.exports = {
          sidebarSweeperSectionCreationCta:
            "sidebarSweeperSectionCreationCta__WaetD",
          descriptionBox: "descriptionBox__ktBxy",
          descriptionText: "descriptionText__oQP0a",
          sweeperIcon: "sweeperIcon__dZvud",
          goButton: "goButton__ruoRp",
          closeButton: "closeButton__XYRmF",
        };
      },
      6870134753: (x) => {
        x.exports = {
          box: "box__BbYzd",
          listStyleNone: "listStyleNone__fGPrE",
          padding50: "padding50__KTivo",
          padding100: "padding100__FO4Df",
          padding125: "padding125__wPCLi",
          paddingInlineStart125: "paddingInlineStart125__AHXRJ",
          paddingInlineStart250: "paddingInlineStart250__ryMsp",
          paddingInline25: "paddingInline25__QlxnG",
          paddingInline150: "paddingInline150__qtcbG",
          paddingInline250: "paddingInline250__ZeMZ7",
          paddingBlock100: "paddingBlock100__DVwcw",
          paddingBlockEnd150: "paddingBlockEnd150__rGDet",
          backgroundColorCoreBaseSecondary:
            "backgroundColorCoreBaseSecondary__UAaW_",
          backgroundColorCoreSurfacePrimary:
            "backgroundColorCoreSurfacePrimary__Z8_oG",
          backgroundColorCoreSurfaceHighlight3:
            "backgroundColorCoreSurfaceHighlight3__RTwhL",
          borderRadiusXLarge: "borderRadiusXLarge__Do4ag",
          borderRadiusRounded: "borderRadiusRounded__B28WR",
          borderRadiusBase: "borderRadiusBase__LrHG9",
          borderColorCoreSurfaceSecondary:
            "borderColorCoreSurfaceSecondary__wMLkW",
          borderRegular: "borderRegular__gW1CN",
          heightFill: "heightFill__XbzxW",
          inlineFlex: "inlineFlex__r7dDr",
        };
      },
      4614285233: (x) => {
        x.exports = {
          text: "text__8Y5Z3",
          fontSizeMicro: "fontSizeMicro__i1v3T",
          fontSizeCaption: "fontSizeCaption__eWVEq",
          fontSizeBase: "fontSizeBase__rD2Si",
          fontSizeSubtitle: "fontSizeSubtitle__mWX8_",
          fontWeightBase: "fontWeightBase__QRyM3",
          fontWeightSemibold: "fontWeightSemibold__bSPf1",
          fontWeightBold: "fontWeightBold__IDZui",
          fontWeightBlack: "fontWeightBlack__Kctwq",
          colorPrimary: "colorPrimary__yRXNV",
          colorSecondary: "colorSecondary__eKIeh",
          colorTertiary: "colorTertiary__i99aD",
          colorThemeInversePrimary: "colorThemeInversePrimary___hfF7",
          colorHighlight2: "colorHighlight2__RcD38",
          colorHighlight3: "colorHighlight3__r_SMh",
          colorCoreContentImportant: "colorCoreContentImportant__Wo2dH",
        };
      },
      3715755184: (x) => {
        x.exports = {
          container: "container__LoO3e",
          inner_container: "inner_container__b2Zyj",
          banner_button: "banner_button__ree8Y",
          sub_container: "sub_container__nxXoN",
          icon_background: "icon_background__kU4VG",
          icon: "icon__YxqSM",
          label_container: "label_container__HyEKa",
          title: "title__a0oTV",
          subtitle: "subtitle__o2aMc",
          close_button: "close_button__C3Lax",
        };
      },
      7263142004: (x) => {
        x.exports = {
          slackAiSidebarPurchaseCta: "slackAiSidebarPurchaseCta__usw5i",
          button: "button__X6nxq",
          description: "description__xWRja",
          descriptionTitle: "descriptionTitle__LwQB6",
          descriptionSubtitle: "descriptionSubtitle___GLYM",
          icon: "icon__i9CDQ",
          closeButton: "closeButton__ghgM0",
          iconBackground: "iconBackground__yhWc9",
        };
      },
      8004193929: (x) => {
        x.exports = {
          container: "container__eqSHO",
          persistentContainer: "persistentContainer__yMvkO",
          closeButton: "closeButton__unPRO",
          innerContainer: "innerContainer__V8TNv",
          cta: "cta__aGjwQ",
          cta_text: "cta_text__Ajm6l",
          expanded_text: "expanded_text__YHhNN",
          subtext: "subtext__xb97G",
          persistantCTA: "persistantCTA__jfu_4",
          alert: "alert__TEQOp",
          alertCloseIcon: "alertCloseIcon__cJ5bS",
        };
      },
      5504232338: (x) => {
        x.exports = {
          container: "container__imOBe",
          innerContainer: "innerContainer__PFSGL",
          collapsedContainer: "collapsedContainer__dc8cy",
          expandedText: "expandedText___QOj6",
          closeButton: "closeButton__f0hua",
        };
      },
      3281979720: (x) => {
        x.exports = {
          container: "container__csEMW",
          innerContainer: "innerContainer__sdwaP",
          subText: "subText__NRdPp",
          collapsedContainer: "collapsedContainer__Nqqur",
          expandedText: "expandedText__TMxRv",
          imgContainer: "imgContainer__dS80d",
          ctaButton: "ctaButton__JuRiY",
          ctaButtonText: "ctaButtonText__ehWAG",
          collapsedCtaButton: "collapsedCtaButton__UvTHp",
          closeButton: "closeButton__Y0fni",
        };
      },
      6065326583: (x) => {
        x.exports = {
          collapsed: "collapsed__OPDLU",
          widget: "widget__fdMfC",
          header: "header__RJyRD",
          buttonContent: "buttonContent__gQmqJ",
          icon: "icon__MoD8d",
        };
      },
      2539163284: (x, A, e) => {
        "use strict";
        e.d(A, {
          c: () => v,
        });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(3680131132),
          s = e.n(p);
        const v = c((g) => {
          let {
            children: T,
            space: h,
            as: E = "span",
            align: O = "inherit",
            alignY: a = "center",
          } = g;
          return t.createElement(
            E,
            {
              className: (0, f.A)(s().inline, {
                [s().space_25]: h === "25",
                [s().space_50]: h === "50",
                [s().space_75]: h === "75",
                [s().space_100]: h === "100",
                [s().space_150]: h === "150",
                [s().align_inherit]: O === "inherit",
                [s().align_start]: O === "start",
                [s().align_center]: O === "center",
                [s().alignY_inherit]: a === "inherit",
                [s().alignY_start]: a === "start",
                [s().alignY_center]: a === "center",
                [s().alignY_end]: a === "end",
                [s().alignY_baseline]: a === "baseline",
              }),
            },
            T
          );
        }, "Inline");
        v.displayName = "Inline";
      },
      7328268421: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => y,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(735940183),
          s = e(2375333597),
          v = e(4481313819),
          g = e(1224315998),
          T = e(4761125736),
          h = e(2562405183),
          E = e(8683010724),
          O = e(6105929840),
          a = e(2683115972),
          u = e(7451808829),
          _ = e(6259241484),
          I = e(7003004874),
          b = e(2938177083),
          i = e(8011352381),
          o = e(5519146941),
          l = e(3193155968),
          n = e(4593063573),
          d = e.n(n);
        const r = new p.Ay("sidebar_sweeper"),
          m = {
            eventId: g.EventId.SIDEBAR_SWEEPER_MEGAPHONE_CLICK,
            uiStep: g.UiStep.SIDEBAR_SWEEPER_BANNER,
            action: g.UiAction.CLICK,
            onClick: {
              enableClogAction: !0,
            },
          },
          M = {
            eventId: g.EventId.SIDEBAR_SWEEPER_MEGAPHONE_LATER,
            uiStep: g.UiStep.SIDEBAR_SWEEPER_BANNER,
            action: g.UiAction.CLICK,
            onClick: {
              enableClogAction: !0,
            },
          },
          P = {
            eventId: g.EventId.SIDEBAR_SWEEPER_MEGAPHONE_BANNER_CLOSE,
            uiStep: g.UiStep.SIDEBAR_SWEEPER_BANNER,
            action: g.UiAction.CLICK,
            onClick: {
              enableClogAction: !0,
            },
          },
          D = c(() => {
            const [K, S] = (0, t.useState)(!1),
              k = (0, f.wA)(),
              C = (0, h.d4)((G) => (0, T._Z)(G, "sidebar_sweeper") === "on"),
              { activeTab: Z } = (0, t.useContext)(o.A),
              Y = (0, t.useCallback)(() => {
                k(
                  (0, b.A)({
                    spaceName: _.xu.SIDEBAR_MENU_HEADER,
                    action: _.hw.DISMISS,
                  })
                );
              }, [k]),
              $ = (0, t.useCallback)(() => {
                k(
                  (0, s.q)({
                    element: t.createElement(u.n, null),
                  })
                );
              }, [k]),
              X = (0, t.useCallback)(() => {
                k(
                  (0, I.A)({
                    notificationName: _.ze.EDUCATION_SIDEBAR_SWEEPER,
                    action: _.hw.CLICK,
                  })
                ),
                  S(!0);
              }, [k]);
            return !C || Z !== l.k6.Home || K
              ? null
              : t.createElement(
                  v.A,
                  {
                    eventId: g.EventId.SIDEBAR_SWEEPER_BANNER_IMPRESSION,
                    uiStep: g.UiStep.SIDEBAR_SWEEPER_BANNER,
                    action: g.UiAction.IMPRESSION,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: d().bannerContainer,
                    },
                    t.createElement(
                      "div",
                      {
                        className: d().bannerContent,
                      },
                      t.createElement(
                        i.A,
                        {
                          lines: 4,
                          breakWords: !1,
                          withTooltip: !0,
                        },
                        C
                          ? r.t(
                              "\u2728 Want personalized suggestions for tidying up your channel list? \u2728"
                            )
                          : ""
                      ),
                      t.createElement(
                        O.A,
                        {
                          "aria-label": r.t("Close"),
                          onClick: Y,
                          className: d().closeButton,
                          autoClogProps: P,
                        },
                        t.createElement(E.A, {
                          name: "close",
                          size: "16",
                        })
                      )
                    ),
                    t.createElement(
                      "div",
                      {
                        className: d().buttonsContainer,
                      },
                      t.createElement(
                        a.Ay,
                        {
                          onClick: X,
                          className: d().laterButton,
                          type: "outline",
                          size: "small",
                          autoClogProps: M,
                        },
                        r.t("Later", {
                          fallbackHash:
                            "a2a8a8e7cfb75f54a65fe5ac0ba1e240d6359641",
                        })
                      ),
                      t.createElement(
                        a.Ay,
                        {
                          onClick: $,
                          className: d().tidyUpButton,
                          type: "primary",
                          size: "small",
                          autoClogProps: m,
                        },
                        C ? r.t("Tidy Up!") : ""
                      )
                    )
                  )
                );
          }, "SidebarSweeperLaunchBanner");
        D.displayName = "SidebarSweeperLaunchBanner";
        const y = D;
      },
      5684595131: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => d,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(735940183),
          s = e(2375333597),
          v = e(2938177083),
          g = e(6259241484),
          T = e(4761125736),
          h = e(2562405183),
          E = e(8683010724),
          O = e(7648061476),
          a = e(6084388622),
          u = e(6105929840),
          _ = e(1224315998),
          I = e(4481313819),
          b = e(3123300647),
          i = e.n(b);
        const o = new p.Ay("sidebar_sweeper"),
          l = {
            eventId: _.EventId.SIDEBAR_SWEEPER_BANNER_CLICK,
            elementType: _.ElementType.BUTTON,
            elementName: "sidebar_sweeper_banner_go_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          n = c(() => {
            const r = (0, f.wA)(),
              m = (0, h.d4)(
                (D) =>
                  (0, T._Z)(
                    D,
                    "sidebar_sweeper_custom_sidebar_sections_cta"
                  ) === "treatment"
              ),
              M = (0, t.useCallback)(() => {
                r(
                  (0, v.A)({
                    spaceName: g.xu.SIDEBAR_MENU_HEADER,
                    action: g.hw.DISMISS,
                  })
                );
              }, [r]),
              P = (0, t.useCallback)(() => {
                r(
                  (0, s.q)({
                    element: t.createElement(O.Ay, {
                      action: O.TH.CREATE,
                    }),
                  })
                ),
                  M();
              }, [M, r]);
            return m
              ? t.createElement(
                  I.A,
                  {
                    eventId: _.EventId.SIDEBAR_SWEEPER_BANNER_IMPRESSION,
                    elementName: "sidebar_sweeper_banner",
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: `${
                        i().sidebarSweeperSectionCreationCta
                      } dt-hocus:theme-base-pry`,
                    },
                    t.createElement(
                      "div",
                      {
                        className: i().descriptionBox,
                      },
                      t.createElement(
                        "div",
                        {
                          className: i().sweeperIcon,
                        },
                        t.createElement(E.A, {
                          name: "clear",
                          size: "20",
                        })
                      ),
                      t.createElement(
                        "span",
                        {
                          className: i().descriptionText,
                          id: "banner-description",
                        },
                        m
                          ? o.t(
                              "Create a custom section to tidy up your channel list."
                            )
                          : "Create a custom section to tidy up your channel list."
                      ),
                      t.createElement(
                        u.A,
                        {
                          "aria-label": o.t("Close"),
                          onClick: M,
                          className: i().closeButton,
                        },
                        t.createElement(E.A, {
                          name: "close",
                          size: "20",
                        })
                      )
                    ),
                    t.createElement(
                      a.Nm,
                      {
                        onClick: P,
                        className: i().goButton,
                        "aria-describedby": "banner-description",
                        autoClogProps: l,
                      },
                      t.createElement(
                        "span",
                        null,
                        m ? o.t("Let\u2019s Go!") : "Let\u2019s Go!"
                      )
                    )
                  )
                )
              : null;
          }, "SidebarSweeperSectionCreationCta");
        n.displayName = "SidebarSweeperSectionCreationCta";
        const d = n;
      },
      5557117347: (x, A, e) => {
        "use strict";
        e.d(A, {
          P: () => d,
        });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(7043699030),
          s = e(3086269805),
          v = e(7112009473),
          g = e(8288042117),
          T = e(1983217662),
          h = e(1507833885),
          E = e(6684249197),
          O = e(3924251130),
          a = e(3514831633),
          u = e(8773153312),
          _ = e(735940183),
          I = e(2562405183),
          b = e(4804990235),
          i = e(6146942550),
          o = e(3677514771);
        function l() {
          return (
            (l =
              Object.assign ||
              function (r) {
                for (var m = 1; m < arguments.length; m++) {
                  var M = arguments[m];
                  for (var P in M)
                    Object.prototype.hasOwnProperty.call(M, P) && (r[P] = M[P]);
                }
                return r;
              }),
            l.apply(this, arguments)
          );
        }
        c(l, "_extends");
        const n = new _.Ay("events"),
          d = c((r) => {
            let {
              workspaceId: m,
              isViewingFromHome: M = !1,
              isWorkspaceHeaderMenu: P = !1,
              classNames: D,
              ariaLabel: y,
              ...K
            } = r;
            const S = (0, f.wA)(),
              k = (0, I.d4)((F) => (0, E.o)(F, m)),
              C = (0, I.d4)((F) => (0, O.VW)(F, m)),
              Z = (0, I.d4)((F) => (0, T.F)(F, m)),
              Y = (0, I.d4)((F) => (0, i.i)(F, m)),
              $ = (0, I.d4)((F) => (0, h.Uq)(F, [m])),
              X = (0, I.d4)((F) => (0, b.fF)(F, m)),
              [G] = (0, g.A)((F) => {
                let { closeModal: z } = F;
                return {
                  element: t.createElement(s.i, {
                    onClose: z,
                    workspaceId: m,
                  }),
                };
              }),
              L = !$ && !C && !Z && (!k || !Y),
              ee = (0, I.d4)((F) => (0, o._J)(F, m)),
              te = v.n7
                .map((F) =>
                  (0, v.wN)({
                    item: F,
                    dispatch: S,
                    externalWorkspace: ee,
                    isViewingFromHome: M,
                    canCurrentUserOpenCommunityAdminDashboard: k,
                    canUserCreateSlackConnectWorkspaceInvites: C,
                    canUserCreatePinnedCanvasItem: Z,
                    canCreateChannelsInExternalWorkspace: $,
                    communityAdminDashboardUrl: Y,
                    shouldRemoveSeparators: L,
                    openAddToHomeConfirmationModal: G,
                    isWorkspaceAddedToHome: X,
                    isWorkspaceHeaderMenu: P,
                  })
                )
                .flat(),
              W = (0, t.useMemo)(() => {
                const F = {
                  children: t.createElement(p.A, {
                    customTeam: ee,
                    key: "team-blurb-menu-item",
                    isMenuItem: k,
                    ariaDescribedById: "team-blurb-text",
                    customSubtitle: n.t("External workspace"),
                  }),
                  type: k ? void 0 : u.A.custom,
                  key: "team-blurb-menu-item",
                };
                return P && te.length === 2
                  ? [F, ...te]
                  : P && te.length > 2
                  ? [
                      F,
                      {
                        type: u.A.separator,
                      },
                      ...te,
                    ]
                  : L
                  ? [...te]
                  : te;
              }, [k, ee, L, P, te]);
            return t.createElement(
              a.a,
              l({}, K, {
                template: W,
                menuClassNames: D,
                "aria-label": y,
              })
            );
          }, "ExternalWorkspaceActionsMenu");
        d.displayName = "ExternalWorkspaceActionsMenu";
      },
      7043699030: (x, A, e) => {
        "use strict";
        e.d(A, {
          A: () => b,
        });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(7715417323),
          s = e(3677514771),
          v = e(6839188756),
          g = e(698013937),
          T = e(1610251172),
          h = e(5510392579),
          E = e(636674013),
          O = e(135069931),
          a = e(6334717308),
          u = e(3328068409),
          _ = e(2562405183);
        const I = c((i) => {
          let {
            customTeam: o,
            customSubtitle: l,
            onMouseEnter: n = p.A,
            isMenuItem: d = !1,
            ariaDescribedById: r,
            dataQa: m,
          } = i;
          const M = (0, _.d4)(s.H7),
            P = o ?? M,
            D = (0, v.F1)(P),
            y = (0, v.Zl)(P, "", !0),
            K = (0, _.d4)(E.S),
            S = (0, _.d4)(a.c),
            k = (0, _.d4)(u.to),
            C = (0, _.d4)(
              (Y) =>
                (K === O.S.SharedChannelInvite || K === O.S.SharedDmInvite) &&
                ((0, h.Zo)(Y) || (0, h.p2)(Y))
            ),
            Z = (0, f.A)(
              "p-classic_nav__team_menu__blurb--team classic_nav__team_menu__blurb p-classic_nav__team_menu__blurb--ia4",
              {
                "p-classic_nav__team_menu__blurb_submenu": d || C,
                "p-classic_nav__team_menu__blurb": !(d || C),
              }
            );
          return t.createElement(
            "div",
            {
              onMouseEnter: n,
            },
            t.createElement(
              "div",
              {
                className: Z,
                "data-qa": m,
              },
              t.createElement(g.A, {
                id: P.id,
                size: 36,
                className: "p-classic_nav__team_menu__blurb__icon",
              }),
              t.createElement(
                "div",
                {
                  className: "p-classic_nav__team_menu__blurb__right",
                },
                t.createElement(
                  "div",
                  {
                    className: "p-classic_nav__team_menu__blurb__name",
                  },
                  S
                    ? t.createElement(T.A, {
                        type: "gov-slack",
                        size: "inherit",
                        inline: !0,
                        className: (0, f.A)(
                          "p-classic_nav__team_menu__blurb__name--gov_slack_icon",
                          `p-classic_nav__team_menu__blurb__name--gov_slack_icon--${k}`
                        ),
                      })
                    : null,
                  D
                ),
                t.createElement(
                  "div",
                  {
                    className: "p-classic_nav__team_menu__blurb__sub",
                    id: r,
                  },
                  l ?? y
                )
              )
            )
          );
        }, "TeamBlurb");
        I.displayName = "TeamBlurb";
        const b = I;
      },
      320067417: (x, A, e) => {
        "use strict";
        e.d(A, {
          a: () => v,
        });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(6870134753),
          s = e.n(p);
        const v = c((g) => {
          let {
            children: T,
            as: h = "div",
            padding: E,
            paddingInlineStart: O,
            paddingInline: a,
            paddingBlock: u,
            paddingBlockEnd: _,
            backgroundColor: I,
            border: b,
            borderColor: i,
            borderRadius: o,
            height: l,
            flex: n,
          } = g;
          return t.createElement(
            h,
            {
              className: (0, f.A)(s().box, {
                [s().backgroundColorCoreBaseSecondary]:
                  I === "Core/Base/Secondary",
                [s().backgroundColorCoreSurfacePrimary]:
                  I === "Core/Surface/Primary",
                [s().backgroundColorCoreSurfaceHighlight3]:
                  I === "Core/Surface/Highlight 3",
                [s().borderRegular]: b === "regular",
                [s().borderColorCoreSurfaceSecondary]:
                  i === "Core/Surface/Secondary",
                [s().borderRadiusXLarge]: o === "x-large",
                [s().borderRadiusRounded]: o === "rounded",
                [s().borderRadiusBase]: o === "base",
                [s().padding50]: E === "50",
                [s().padding100]: E === "100",
                [s().padding125]: E === "125",
                [s().paddingInlineStart250]: O === "250",
                [s().paddingInlineStart125]: O === "125",
                [s().paddingInline25]: a === "25",
                [s().paddingInline150]: a === "150",
                [s().paddingInline250]: a === "250",
                [s().paddingBlock100]: u === "100",
                [s().paddingBlockEnd150]: _ === "150",
                [s().heightFill]: l === "fill",
                [s().inlineFlex]: n === "inline",
                [s().listStyleNone]: h === "li",
              }),
            },
            T
          );
        }, "Box");
        v.displayName = "Box";
      },
      2409757433: (x, A, e) => {
        "use strict";
        e.d(A, {
          E: () => v,
        });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(4614285233),
          s = e.n(p);
        const v = c((g) => {
          let {
            children: T,
            as: h = "span",
            size: E = "base",
            weight: O = "base",
            color: a = "Core/Content/Primary",
            isItalic: u,
          } = g;
          return t.createElement(
            h,
            {
              className: (0, f.A)(s().text, {
                [s().fontSizeMicro]: E === "micro",
                [s().fontSizeCaption]: E === "caption",
                [s().fontSizeBase]: E === "base",
                [s().fontSizeSubtitle]: E === "subtitle",
                [s().fontWeightBase]: O === "base",
                [s().fontWeightSemibold]: O === "semibold",
                [s().fontWeightBold]: O === "bold",
                [s().fontWeightBlack]: O === "black",
                [s().colorPrimary]: a === "Core/Content/Primary",
                [s().colorSecondary]: a === "Core/Content/Secondary",
                [s().colorTertiary]: a === "Core/Content/Tertiary",
                [s().colorThemeInversePrimary]:
                  a === "Theme/Content/Inverse primary",
                [s().colorHighlight2]: a === "Core/Content/Highlight 2",
                [s().colorHighlight3]: a === "Core/Content/Highlight 3",
                [s().colorCoreContentImportant]: a === "Core/Content/Important",
                italic: u,
              }),
            },
            T
          );
        }, "Text");
        v.displayName = "Text";
      },
      7205738127: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => C,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(5255740490),
          s = e(4481313819),
          v = e(2670882607),
          g = e(5267010247),
          T = e(8822892075),
          h = e(5519146941),
          E = e(7940058138),
          O = e(6084388622),
          a = e(6105929840),
          u = e(8683010724),
          _ = e(8214116048),
          I = e(1224315998),
          b = e(735940183),
          i = e(2562405183),
          o = e(3328068409),
          l = e(2938177083),
          n = e(7003004874),
          d = e(6259241484),
          r = e(2047021170),
          m = e(9776496806),
          M = e(2927254383),
          P = e(3193155968);
        const D = new b.Ay("lists"),
          y = c(
            () => () =>
              e
                .e("gantry-v2-async-lottie-lists-themed-sparkle.json")
                .then(e.t.bind(e, 3415497769, 23)),
            "getAnimationImport"
          ),
          K = {
            elementName: "target_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          S = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          k = c(() => {
            const Z = (0, f.wA)(),
              Y = (0, i.d4)(o.to),
              $ = (0, i.d4)((ee) => !!(0, r.ty)(ee, "a11y_animations")),
              { activeTab: X } = (0, t.useContext)(h.A);
            (0, t.useEffect)(
              () => () => {
                Z(
                  (0, n.A)({
                    notificationName: d.ze.LISTS_WELCOME_TO_LISTS_HOME_BANNER,
                    action: d.hw.IMPRESSION,
                  })
                );
              },
              [Z]
            );
            const G = (0, t.useCallback)(() => {
                Z(
                  (0, l.A)({
                    spaceName: d.xu.SIDEBAR_MENU_HEADER,
                    action: d.hw.DISMISS,
                  })
                );
              }, [Z]),
              L = (0, t.useCallback)(() => {
                Z(
                  (0, M.E)({
                    tabName: P.k6.Lists,
                    value: !0,
                    reason: m.pU.Auto,
                  })
                ),
                  Z((0, g.o)((0, T.ZF)(E.c.BrowseLists))),
                  G();
              }, [Z, G]);
            return X === P.k6.Home
              ? t.createElement(
                  s.A,
                  {
                    eventId: I.EventId.SLACK_LISTS,
                    uiComponentName: I.UiComponentName.LISTS_NUX_WELCOME_BANNER,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: "p-lists_welcome_banner",
                    },
                    t.createElement(
                      O.jV,
                      {
                        onClick: L,
                        className: "p-lists_welcome_banner__button",
                        autoClogProps: K,
                        "aria-label": D.t("Introducing lists"),
                        "aria-describedby": "lists-welcome-banner-desc",
                      },
                      t.createElement(
                        "span",
                        {
                          className: "p-lists_welcome_banner__icon_background",
                        },
                        $
                          ? t.createElement(v.e, {
                              className: (0, p.A)(
                                "p-lists_welcome_banner_icon",
                                {
                                  "p-lists_welcome_banner_icon--dark-mode":
                                    Y === _.Sx.Dark,
                                }
                              ),
                              getAnimationImport: y(),
                              autoplay: !0,
                              loop: !1,
                            })
                          : t.createElement(
                              "div",
                              {
                                className:
                                  "p-lists_welcome_banner__static_icon",
                              },
                              t.createElement(u.A, {
                                name: "lists",
                                size: "24",
                              })
                            )
                      ),
                      t.createElement(
                        "div",
                        {
                          className: "p-lists_welcome_banner__description",
                        },
                        t.createElement(
                          "span",
                          {
                            className:
                              "p-lists_welcome_banner__description_title",
                          },
                          D.t("Introducing lists")
                        ),
                        t.createElement(
                          "span",
                          {
                            className:
                              "p-lists_welcome_banner__description_subtitle",
                            id: "lists-welcome-banner-desc",
                          },
                          D.t("Track work in Slack")
                        )
                      )
                    ),
                    t.createElement(
                      a.A,
                      {
                        "aria-label": D.t("Close tip", {
                          fallbackHash:
                            "8e5cf4e323045bac6bd4071976f5f80955c0e3d1",
                          fallbackHashNs: "huddles",
                        }),
                        onClick: G,
                        className: "p-lists_welcome_banner__close_button",
                        autoClogProps: S,
                      },
                      t.createElement(u.A, {
                        name: "close",
                        size: "16",
                      })
                    )
                  )
                )
              : null;
          }, "ListsWelcomeToListsHomeBanner");
        k.displayName = "ListsWelcomeToListsHomeBanner";
        const C = k;
      },
      4630993086: (x, A, e) => {
        "use strict";
        e.d(A, {
          M: () => f,
        });
        var t = e(5824283093);
        const f = (0, t.createContext)({
          shouldUseLeadingEmojiForIcon: !0,
          stopAnimations: !1,
          disableSelection: !1,
          disableHighlights: !1,
        });
      },
      7391266585: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseOpenMobileAppMenuItem: () => M,
            default: () => P,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(2562405183),
          s = e(735940183),
          v = e(2375333597),
          g = e(1031947056),
          T = e(1224315998),
          h = e(8467766508);
        const E = (0, g.Ay)(
          "Opens modal that informs the user a magic login email has been sent to them",
          (D, y) => {
            D(
              (0, v.q)({
                element: t.createElement(h.A, {
                  eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                }),
              })
            );
          }
        );
        E.meta = {
          name: "createThunk",
          key: "createThunkopenSentMagicLoginConfirmationModal",
          description:
            "Opens modal that informs the user a magic login email has been sent to them",
        };
        var O = e(7307373517),
          a = e(7019848462),
          u = e(4481313819),
          _ = e(1610251172),
          I = e(8245211418),
          b = e(101973425),
          i = e(9074302729),
          o = e(4761125736);
        function l() {
          return (
            (l =
              Object.assign ||
              function (D) {
                for (var y = 1; y < arguments.length; y++) {
                  var K = arguments[y];
                  for (var S in K)
                    Object.prototype.hasOwnProperty.call(K, S) && (D[S] = K[S]);
                }
                return D;
              }),
            l.apply(this, arguments)
          );
        }
        c(l, "_extends");
        const n = new s.Ay("native_apps_entry_points"),
          d = {
            onClick: {
              enableClogAction: !0,
            },
          },
          r = c((D) => {
            let { handleClick: y, ...K } = D;
            const S = n.rt("Get the mobile app"),
              k =
                T.UiComponentVariant.PERSISTENT_ENTRY_TREATMENT_MOBILE_DOWNLOAD,
              C = t.createElement(
                t.Fragment,
                null,
                t.createElement(
                  "span",
                  {
                    className: "p-ia__main_menu__open_native_app_copy",
                  },
                  S
                ),
                t.createElement(
                  "span",
                  {
                    className: "p-ia__main_menu__open_native_app_icon",
                  },
                  t.createElement(_.A, {
                    type: "mobile",
                  })
                )
              );
            return t.createElement(
              u.A,
              {
                eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                uiStep: T.UiStep.MAIN_MENU,
                uiComponentName: T.UiComponentName.MOBILE_ENTRY_POINT,
                uiComponentVariant: k,
                clogImpression: !0,
              },
              t.createElement(
                I.A,
                l({}, K, {
                  "data-qa": "open-mobile-app",
                  className: "p-ia__main_menu__open_slack_app_item",
                  onSelected: y,
                  label: C,
                  autoClogProps: d,
                })
              )
            );
          }, "OpenMobileAppMenuItem");
        r.displayName = "OpenMobileAppMenuItem";
        const m = c((D) => {
          let { handleClick: y, showExistingHumansMobileEntry: K, ...S } = D,
            k = n.rt("Get the mobile app"),
            C = T.UiComponentVariant.PERSISTENT_ENTRY_TREATMENT_MOBILE_DOWNLOAD;
          K &&
            ((k = n.rt("Email link to sign in")),
            (C =
              T.UiComponentVariant.PERSISTENT_ENTRY_TREATMENT_MOBILE_SIGN_IN));
          const Z = t.createElement(
            t.Fragment,
            null,
            t.createElement(
              "span",
              {
                className: "p-ia__main_menu__open_native_app_copy",
              },
              k
            ),
            !K &&
              t.createElement(
                "span",
                {
                  className: "p-ia__main_menu__open_native_app_icon",
                },
                t.createElement(_.A, {
                  type: "mobile",
                })
              )
          );
          return t.createElement(
            u.A,
            {
              eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
              uiStep: T.UiStep.MAIN_MENU,
              uiComponentName: T.UiComponentName.MOBILE_ENTRY_POINT,
              uiComponentVariant: C,
              clogImpression: !0,
            },
            t.createElement(
              I.A,
              l({}, S, {
                "data-qa": "open-mobile-app",
                className: "p-ia__main_menu__open_slack_app_item",
                onSelected: y,
                label: Z,
                autoClogProps: d,
              })
            )
          );
        }, "DeprecatedOpenMobileAppMenuItem");
        m.displayName = "DeprecatedOpenMobileAppMenuItem";
        const M = c((D) => {
          let { showExistingHumansMobileEntry: y, ...K } = D;
          const S = (0, f.wA)(),
            k = (0, p.d4)(
              ($) => (0, o._Z)($, "deprecate_email_signin") === "on"
            ),
            C = (0, t.useCallback)(() => {
              S(
                (0, v.q)({
                  element: t.createElement(i.A, {
                    eventId: T.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                  }),
                })
              ),
                S(
                  (0, O.f)({
                    reason: a.wr.TRIGGER_MOBILE_FALLBACK_EMAIL,
                    eventHandler: a.ch.MOBILE_PROMO_FALLBACK_EVENT_HANDLER,
                    subtype: a.YB.PERSISTENT_MOBILE_PROMO,
                  })
                );
            }, [S]),
            Z = (0, t.useCallback)(() => {
              S(E()),
                S(
                  (0, O.f)({
                    reason: a.wr.TRIGGER_MOBILE_MAGIC_LOGIN_EMAIL,
                    eventHandler: a.ch.MOBILE_PROMO_MAGIC_LOGIN_EVENT_HANDLER,
                    subtype: a.YB.PERSISTENT_MOBILE_PROMO,
                  })
                );
            }, [S]),
            Y = y ? Z : C;
          return k
            ? t.createElement(
                r,
                l(
                  {
                    showExistingHumansMobileEntry: !1,
                    handleClick: C,
                  },
                  K
                )
              )
            : t.createElement(
                m,
                l(
                  {
                    handleClick: Y,
                    showExistingHumansMobileEntry: y,
                  },
                  K
                )
              );
        }, "ConnectedOpenMobileAppMenuItem");
        M.displayName = "ConnectedOpenMobileAppMenuItem";
        const P = (0, b.Ay)(M);
      },
      629068863: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => S,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4509434386),
          s = e(5255740490),
          v = e(4481313819),
          g = e(1267040415),
          T = e(5267010247),
          h = e(8822892075),
          E = e(5519146941),
          O = e(7940058138),
          a = e(6839188756),
          u = e(6084388622),
          _ = e(8683010724),
          I = e(8214116048),
          b = e(1224315998),
          i = e(735940183),
          o = e(2562405183),
          l = e(3328068409),
          n = e(2938177083),
          d = e(6259241484),
          r = e(3677514771),
          m = e(3193155968);
        const M = new i.Ay("resurrected_user_welcome"),
          P = {
            elementName: "resurrected_user_sidebar_upgrade_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          D = {
            elementName: "resurrected_user_sidebar_entry_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          y = {
            elementName: "resurrected_user_sidebar_close_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          K = c(() => {
            const k = (0, f.wA)(),
              { activeTab: C } = (0, t.useContext)(E.A),
              Z = C === m.k6.Home,
              { getSiblingView: Y } = (0, t.useContext)(E.A),
              $ = (0, o.d4)(r.H7),
              X = (0, a.tc)($),
              G = (0, o.d4)((F) => {
                var z;
                return (z = Y(F, {
                  container: m.mq.Primary,
                })) === null || z === void 0
                  ? void 0
                  : z.id;
              }),
              L = (0, o.d4)(l.to),
              ee = G === "Presurrected-user-welcome",
              te = (0, t.useCallback)(
                () => k((0, T.o)((0, h.ZF)(O.c.ResurrectedUserWelcome))),
                [k]
              ),
              W = (0, t.useCallback)(() => {
                k(
                  (0, n.A)({
                    spaceName: d.xu.SIDEBAR_MENU_HEADER,
                    action: d.hw.DISMISS,
                  })
                );
              }, [k]);
            return Z
              ? t.createElement(
                  v.A,
                  {
                    uiComponentName:
                      b.UiComponentName
                        .RESURRECTED_USER_WELCOME_SIDEBAR_ENTRY_CTA,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className:
                        "p-resurrected_user_welcome_entry_cta__upgrade_wrapper",
                    },
                    t.createElement(
                      "div",
                      {
                        className: (0, s.A)(
                          "p-resurrected_user_welcome_entry_cta__wrapper",
                          {
                            [p.A7]: L === I.Sx.Light,
                          }
                        ),
                      },
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-resurrected_user_welcome_entry_cta__wrapper_text_container",
                        },
                        t.createElement(_.A, {
                          size: "20",
                          name: "emoji",
                        }),
                        t.createElement(
                          "span",
                          {
                            className:
                              "p-resurrected_user_welcome_entry_cta__wrapper_text",
                          },
                          M.t("Welcome back")
                        )
                      ),
                      t.createElement(
                        u.Nm,
                        {
                          className: (0, s.A)({
                            "p-resurrected_user_welcome_entry_cta__button dt-hocus:theme-base-pry":
                              !ee,
                            "p-resurrected_user_welcome_entry_cta__button_selected":
                              ee,
                          }),
                          "data-qa": "resurrected-user-entry-cta-btn",
                          autoClogProps: D,
                          onClick: te,
                        },
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_badge__button_text_container",
                          },
                          M.t("Top things to check out")
                        ),
                        t.createElement(
                          "span",
                          null,
                          t.createElement(_.A, {
                            size: "24",
                            name: "caret-right",
                          })
                        )
                      ),
                      t.createElement(
                        u.Nm,
                        {
                          className:
                            "p-resurrected_user_welcome_entry_cta__close_cta",
                          onClick: W,
                          autoClogProps: y,
                          "data-qa": "resurrected-user-entry-close-btn",
                        },
                        t.createElement(_.A, {
                          name: "close",
                        })
                      )
                    ),
                    X &&
                      t.createElement(
                        g.A,
                        {
                          autoClogProps: P,
                          className: (0, s.A)(
                            "p-resurrected_user_welcome_entry_cta__upgrade_now_btn",
                            {
                              [p.Pn]: L === I.Sx.Light,
                            }
                          ),
                          "data-qa": "resurrected-user-entry-upgrade-button",
                          entryPoint: "resurructed-user-welcome-sidebar-entry",
                          type: "outline",
                        },
                        t.createElement(_.A, {
                          size: "20",
                          name: "rocket",
                        }),
                        t.createElement("span", null, M.t("Upgrade Plan"))
                      )
                  )
                )
              : null;
          }, "ResurrectedUserWelcomeEntryCta");
        K.displayName = "ResurrectedUserWelcomeEntryCta";
        const S = K;
      },
      1720631741: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseStraightToPaidSidebarMenuHeaderOfferCta: () => C,
            default: () => Y,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4481313819),
          s = e(3405119017),
          v = e(3749988767),
          g = e(7878745420),
          T = e(5519146941),
          h = e(7115655993),
          E = e(6839188756),
          O = e(5510392579),
          a = e(2683115972),
          u = e(8683010724),
          _ = e(2312625946),
          I = e(735940183),
          b = e(6323355797),
          i = e(2562405183),
          o = e(636674013),
          l = e(1960898919),
          n = e(1708049820),
          d = e(2965336964),
          r = e(3474336343),
          m = e(2967538512),
          M = e(3677514771),
          P = e(3193155968),
          D = e(7429662208);
        function y() {
          return (
            (y =
              Object.assign ||
              function ($) {
                for (var X = 1; X < arguments.length; X++) {
                  var G = arguments[X];
                  for (var L in G)
                    Object.prototype.hasOwnProperty.call(G, L) && ($[L] = G[L]);
                }
                return $;
              }),
            y.apply(this, arguments)
          );
        }
        c(y, "_extends");
        const K = g.g.STRAIGHT_TO_PAID_SIDEBAR_MENU_HEADER_OFFER_CTA,
          S = new I.Ay("setup_straight_to_paid"),
          k = "straight_to_paid_sidebar_menu_header",
          C = c(($) => {
            let {
              discountPercent: X,
              discountExpirationTs: G = 0,
              isInSetup: L,
              onClick: ee,
            } = $;
            const te = (0, v.Q)(G),
              W = (0, i.d4)(D.e6),
              F = (0, i.d4)(m.PU),
              {
                eventId: z,
                uiStep: oe,
                elementName: fe,
                stepVariant: Me,
              } = (0, t.useMemo)(() => (0, s.eq)(F), [F]),
              Re = (0, t.useMemo)(() => (0, s.NR)(F), [F]);
            if (L || W !== P.k6.Home) return null;
            const Ye = S.t("Get {discountPercent}% Off Slack Pro", {
              discountPercent: X,
            });
            return t.createElement(
              p.A,
              {
                clogImpression: !0,
                eventId: z,
                uiStep: oe,
                elementName: fe,
                stepVariant: Me,
              },
              t.createElement(
                "div",
                {
                  className:
                    "p-sidebar_menu_header_offer_cta p-sidebar_menu_header_offer_cta--ia4",
                },
                t.createElement(
                  a.z9,
                  {
                    className: "p-sidebar_menu_header_offer_cta__button",
                    type: "outline",
                    size: "medium",
                    onClick: ee,
                    autoClogProps: Re,
                  },
                  t.createElement(
                    "span",
                    {
                      className: "p-sidebar_menu_header_offer_cta__button-icon",
                    },
                    t.createElement(u.A, {
                      name: "rocket",
                    })
                  ),
                  t.createElement(
                    _.Ay,
                    {
                      offsetX: -11,
                      automaticallyPositionTip: !1,
                      delay: _.PK,
                      tip: Ye,
                      shouldOnlyShowWhenTruncated: !0,
                    },
                    t.createElement(
                      "span",
                      {
                        className:
                          "p-sidebar_menu_header_offer_cta__button-text",
                      },
                      Ye
                    )
                  )
                ),
                t.createElement(
                  "p",
                  {
                    className:
                      "p-sidebar_menu_header_offer_cta__offer-countdown",
                  },
                  typeof te == "number" &&
                    S.t(
                      "{daysRemaining, plural, =1 {# day} other {# days}} left on this offer",
                      {
                        daysRemaining: te,
                      }
                    )
                )
              )
            );
          }, "StraightToPaidSidebarMenuHeaderOfferCta");
        C.displayName = "StraightToPaidSidebarMenuHeaderOfferCta";
        const Z = c(($) => {
          const { getSiblingView: X } = (0, t.useContext)(T.A),
            G = (0, f.wA)(),
            L = (0, i.d4)(M.H7),
            ee = (0, i.d4)(
              (Me) =>
                !!(0, r.Li)(Me, {
                  getSiblingView: X,
                })
            ),
            te = (0, i.d4)(r.mF),
            W = (0, i.d4)(m.aO),
            F = (0, i.d4)(o.S),
            z = (0, i.d4)((Me) => (0, l.ax)(Me, d.By)),
            oe = (0, i.d4)(O.$G),
            fe = (0, t.useCallback)(() => {
              if (L) {
                const Me = (0, b.hZ)({
                  entryPoint: k,
                });
                (0, E.gC)(L, Me, "_self");
              }
            }, [L]);
          return (
            (0, h.A)(() => {
              !!F &&
                oe &&
                !z &&
                !ee &&
                W &&
                G(
                  (0, n.h)({
                    pref: d.By,
                    value: te,
                  })
                );
            }),
            t.createElement(
              C,
              y(
                {
                  isInSetup: ee,
                  onClick: fe,
                },
                $
              )
            )
          );
        }, "ConnectedStraightToPaidSidebarMenuHeaderOfferCta");
        Z.displayName = "ConnectedStraightToPaidSidebarMenuHeaderOfferCta";
        const Y = Z;
      },
      3749988767: (x, A, e) => {
        "use strict";
        e.d(A, {
          Q: () => v,
        });
        var t = e(6122756707),
          f = e(2562405183),
          p = e(3263322402),
          s = e(3474336343);
        const v = c((g) => {
          const T = (0, t.wA)(),
            h = (0, f.d4)(s.hf);
          return (
            typeof h > "u" &&
              T(
                (0, p.pl)({
                  expirationTs: g * 1e3,
                  now: Date.now(),
                })
              ),
            h
          );
        }, "useStraightToPaidDaysRemaining");
      },
      2811650336: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => X,
          });
        var t = e(9706240641),
          f = e(5824283093),
          p = e(6122756707),
          s = e(4481313819),
          v = e(4502904940),
          g = e(1232649910),
          T = e(2558145408),
          h = e(1482809496),
          E = e(1224315998),
          O = e(735940183),
          a = e(2562405183),
          u = e(4761125736),
          _ = e(6259241484);
        const I = new O.Ay("assistant"),
          b = c((G) => {
            let { children: L } = G;
            const te = (0, a.d4)(
                (Re) =>
                  (0, u._Z)(Re, "slack_ai_onboarding_modal_trial_copy") === "on"
              )
                ? I.t("You\u2019re on a Slack AI trial")
                : I.t("You\u2019re on a 30-day Slack AI trial"),
              {
                isOpen: W,
                closeCoachmark: F,
                renderCoachmark: z,
              } = (0, h.A)(_.ze.SLACK_AI_PERSISTENT_SIDEBAR_NFX_COACHMARK),
              oe = (0, f.useMemo)(
                () => ({
                  eventId: E.EventId.NATIVE_AI,
                  uiStep: E.UiStep.SLACK_AI_PERSISTENT_SIDEBAR_NFX_COACHMARK,
                  elementName: v.H.NUX_COACHMARK,
                }),
                []
              ),
              fe = (0, f.useCallback)(() => {
                F();
              }, [F]),
              Me = z({
                className: "p-slack_ai_persistent_sidebar_nfx_coachmark",
                closeCoachmark: fe,
                icon: "/img/slack_ai/celebration.svg",
                offsetX: -20,
                offsetY: 16,
                title: te,
                ariaLabel: te,
                bodyText: I.t(
                  "Learn more in our help center about how you can get the most out of your day with Slack AI."
                ),
                autoClogProps: oe,
              });
            return W
              ? f.createElement(
                  T.Ay,
                  {
                    coachmarkElement: Me,
                    orientation: "right",
                  },
                  f.createElement(
                    "div",
                    {
                      className: "p-slack_ai_persistent_sidebar_nfx_coachmark",
                    },
                    L
                  )
                )
              : L;
          }, "SlackAiPersistentSidebarNfxCoachmark");
        b.displayName = "SlackAiPersistentSidebarNfxCoachmark";
        const i = b;
        var o = e(7094978947),
          l = e(174977074),
          n = e(6084388622),
          d = e(6105929840),
          r = e(8683010724),
          m = e(7274827479),
          M = e(2938177083),
          P = e(7003004874),
          D = e(2375333597),
          y = e(8483346214),
          K = e(3141349242);
        const S = {
            onClick: {
              enableClogAction: !0,
            },
            elementName: v.H.PERSISTENT_SIDEBAR_NFX_BANNER,
          },
          k = {
            onClick: {
              enableClogAction: !0,
            },
            elementName: v.H.PERSISTENT_SIDEBAR_NFX_BANNER_DISMISS,
          },
          C = new O.Ay("assistant"),
          Z = {
            SLACK_AI_TRIAL: "slack_ai_trial",
            SLACK_AI: "slack_ai",
          },
          Y = {
            TAKE_TOUR: "take_tour",
          },
          $ = c(() => {
            const G = (0, p.wA)(),
              L = (0, a.d4)(m.TP),
              ee = (0, a.d4)(y.xg),
              te = (0, a.d4)(K.Gj);
            (0, l.A)(_.ze.SIDEBAR_MENU_HEADER_SLACK_AI_NFX_CTA);
            const W = (0, f.useCallback)(() => {
                G(
                  (0, M.A)({
                    spaceName: _.xu.SIDEBAR_MENU_HEADER,
                    action: _.hw.DISMISS,
                  })
                );
              }, [G]),
              F = (0, f.useCallback)(
                (0, t.coroutine)(function* () {
                  yield G(
                    (0, P.A)({
                      notificationName:
                        _.ze.SIDEBAR_MENU_HEADER_SLACK_AI_NFX_CTA,
                      action: _.hw.CLICK,
                    })
                  ),
                    yield G(
                      (0, D.q)({
                        element: f.createElement(g.default, null),
                      })
                    );
                }),
                [G]
              ),
              z = (0, f.useCallback)(
                (oe) => {
                  let { text: fe } = oe;
                  return f.createElement(
                    n.jV,
                    {
                      onClick: F,
                      className: "p-slack_ai_persistent_sidebar_nfx_cta__link",
                      autoClogProps: S,
                    },
                    fe
                  );
                },
                [F]
              );
            return L
              ? f.createElement(
                  i,
                  null,
                  f.createElement(
                    s.A,
                    {
                      clogImpression: !0,
                      eventId: E.EventId.NATIVE_AI,
                      uiStep: E.UiStep.SLACK_AI_PERSISTENT_SIDEBAR_NFX_BANNER,
                      stepVariant: Y.TAKE_TOUR,
                      slackAiLicenseType: ee ? Z.SLACK_AI_TRIAL : Z.SLACK_AI,
                      displayName: te,
                    },
                    f.createElement(
                      "div",
                      {
                        className: "p-slack_ai_persistent_sidebar_nfx_cta",
                      },
                      f.createElement(
                        "div",
                        {
                          className:
                            "p-slack_ai_persistent_sidebar_nfx_cta__content",
                        },
                        f.createElement(
                          "span",
                          {
                            className:
                              "p-slack_ai_persistent_sidebar_nfx_cta__icon",
                          },
                          f.createElement(o.o, {
                            size: "16",
                            type: "sparkles",
                            variation: "filled",
                          })
                        ),
                        f.createElement(
                          "div",
                          {
                            className: "display_flex flex_direction_column",
                          },
                          f.createElement(
                            "div",
                            null,
                            C.rt("Try Slack AI. <a>Take a tour</a>", {
                              "<a>": z,
                            })
                          )
                        )
                      ),
                      f.createElement(
                        d.A,
                        {
                          "aria-label": C.t("Close"),
                          onClick: W,
                          className:
                            "p-slack_ai_persistent_sidebar_nfx_cta__close",
                          autoClogProps: k,
                        },
                        f.createElement(
                          "span",
                          {
                            className:
                              "p-slack_ai_persistent_sidebar_nfx_cta__close_icon",
                          },
                          f.createElement(r.A, {
                            name: "close",
                            size: "16",
                          })
                        )
                      )
                    )
                  )
                )
              : null;
          }, "SlackAiPersistentSidebarNfxCta");
        $.displayName = "SlackAiPersistentSidebarNfxCta";
        const X = $;
      },
      4061500210: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => $,
          });
        var t = e(9706240641),
          f = e.n(t),
          p = e(5824283093),
          s = e(6122756707),
          v = e(2562405183),
          g = e(7115655993),
          T = e(4481313819),
          h = e(5267010247),
          E = e(8822892075),
          O = e(5519146941),
          a = e(6084388622),
          u = e(6105929840),
          _ = e(8683010724),
          I = e(1224315998),
          b = e(735940183),
          i = e(2938177083),
          o = e(7003004874),
          l = e(6259241484),
          n = e(9776496806),
          d = e(2927254383),
          r = e(3193155968),
          m = e(5868036555),
          M = e(1655938719),
          P = e(7949425452),
          D = e(229137923),
          y = e(3851004129),
          K = e(3715755184),
          S = e.n(K);
        const k = new b.Ay("solutions"),
          C = {
            elementName: "target_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          Z = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          Y = c(() => {
            const X = (0, s.wA)(),
              G = (0, v.d4)(m.bK),
              L = (0, v.d4)(D.Ul),
              { activeTab: ee } = (0, p.useContext)(O.A);
            (0, g.A)(() => {
              G &&
                X(
                  (0, o.A)({
                    notificationName:
                      l.ze.SOLUTIONS_WELCOME_TO_SOLUTIONS_HOME_SIDEBAR_BANNER,
                    action: l.hw.IMPRESSION,
                  })
                );
            });
            const te = (0, p.useCallback)(
                (0, t.coroutine)(function* () {
                  yield X(
                    (0, i.A)({
                      spaceName: l.xu.SIDEBAR_MENU_HEADER,
                      action: l.hw.DISMISS,
                    })
                  ),
                    X(
                      (0, M.iR)({
                        event: {
                          type: l.jo.SOLUTIONS_WELCOME_BANNER_DISMISSED,
                        },
                      })
                    );
                }),
                [X]
              ),
              W = (0, p.useCallback)(() => {
                X(
                  (0, y.xj)({
                    value: !0,
                  })
                ),
                  te();
              }, [te, X]),
              F = (0, p.useCallback)(() => {
                X(
                  (0, d.E)({
                    tabName: r.k6.Solutions,
                    value: !0,
                    reason: n.pU.Auto,
                  })
                ),
                  X((0, h.o)((0, E.Wy)())),
                  te();
              }, [X, te]);
            return G && ee === r.k6.Home
              ? p.createElement(
                  T.A,
                  {
                    eventId: I.EventId.SOLUTIONS_NUX,
                    uiComponentName:
                      I.UiComponentName.SOLUTIONS_WELCOME_SIDEBAR_BANNER,
                    clogImpression: !0,
                  },
                  p.createElement(
                    "div",
                    {
                      className: S().container,
                    },
                    p.createElement(
                      "div",
                      {
                        className: S().inner_container,
                      },
                      p.createElement(
                        a.Nm,
                        {
                          onClick: F,
                          className: S().banner_button,
                          autoClogProps: C,
                          "aria-label": G ? k.t("Introducing templates") : "",
                          "aria-describedby": "templates-welcome-banner-desc",
                        },
                        p.createElement(
                          "div",
                          {
                            className: S().sub_container,
                          },
                          p.createElement(
                            "span",
                            {
                              className: S().icon_background,
                            },
                            p.createElement(
                              "div",
                              {
                                className: S().icon,
                              },
                              p.createElement(_.A, {
                                name: "tools",
                                size: "20",
                              })
                            )
                          ),
                          p.createElement(
                            "div",
                            {
                              className: S().label_container,
                            },
                            L && p.createElement(P.Ay, null),
                            p.createElement(
                              "div",
                              {
                                className: S().title,
                              },
                              G ? k.t("Introducing Templates") : ""
                            ),
                            p.createElement(
                              "div",
                              {
                                className: S().subtitle,
                                id: "templates-welcome-banner-desc",
                              },
                              G
                                ? k.t(
                                    "A new way to kickstart any project, process or problem."
                                  )
                                : k.t("Tools you need to get the job started")
                            )
                          )
                        )
                      ),
                      p.createElement(
                        u.A,
                        {
                          "aria-label": k.t("Close tip", {
                            fallbackHash:
                              "8e5cf4e323045bac6bd4071976f5f80955c0e3d1",
                            fallbackHashNs: "huddles",
                          }),
                          className: `${
                            S().close_button
                          } dt-hocus:theme-surf-pry dt-active:theme-surf-pry`,
                          onClick: W,
                          autoClogProps: Z,
                        },
                        p.createElement(_.A, {
                          name: "close",
                          size: "16",
                        })
                      )
                    )
                  )
                )
              : null;
          }, "SolutionsWelcomeSidebarBanner");
        Y.displayName = "SolutionsWelcomeSidebarBanner";
        const $ = Y;
      },
      8317025457: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => P,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4481313819),
          s = e(5519146941),
          v = e(174977074),
          g = e(6084388622),
          T = e(6105929840),
          h = e(8683010724),
          E = e(1224315998),
          O = e(735940183),
          a = e(2938177083),
          u = e(6259241484),
          _ = e(3193155968),
          I = e(2375333597),
          b = e(6038992701),
          i = e(7094978947),
          o = e(7263142004),
          l = e.n(o);
        const n = new O.Ay("promotions"),
          d = "sidebar_menu_header_slack_ai_cta",
          r = {
            elementName: "target_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          m = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          M = c((D) => {
            let {
              availableAddonId: y,
              availableAddonTerm: K,
              availableAddonUpfrontUnitCost: S,
              bauCount: k,
              canUserPurchase: C,
              availableAddonCurrency: Z,
            } = D;
            const Y = (0, f.wA)(),
              { activeTab: $ } = (0, t.useContext)(s.A);
            (0, v.A)(u.ze.SLACK_AI_SIDEBAR_PURCHASE_CTA);
            const X = (0, t.useCallback)(() => {
                Y(
                  (0, a.A)({
                    spaceName: u.xu.SIDEBAR_MENU_HEADER,
                    action: u.hw.DISMISS,
                  })
                );
              }, [Y]),
              G = (0, t.useCallback)(() => {
                Y(
                  (0, I.q)({
                    element: t.createElement(b.P, {
                      activeMembersCount: k,
                      availableAddonTerm: K,
                      availableAddonUpfrontUnitCost: S,
                      currency: Z,
                      checkoutEntryPoint: d,
                      addonId: y,
                      canUserPurchase: C,
                    }),
                  })
                );
              }, [Y, k, K, S, Z, y, C]);
            return $ === _.k6.Home
              ? t.createElement(
                  p.A,
                  {
                    eventId: E.EventId.UPGRDEXP_SLACK_AI,
                    uiComponentName:
                      E.UiComponentName.SLACK_AI_SIDEBAR_PURCHASE_CTA,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: l().slackAiSidebarPurchaseCta,
                    },
                    t.createElement(
                      g.jV,
                      {
                        onClick: G,
                        className: l().button,
                        autoClogProps: r,
                      },
                      t.createElement(
                        "span",
                        {
                          className: l().iconBackground,
                        },
                        t.createElement(
                          "div",
                          {
                            className: l().icon,
                          },
                          t.createElement(i.o, {
                            size: "20",
                          })
                        )
                      ),
                      t.createElement(
                        "div",
                        {
                          className: l().description,
                        },
                        t.createElement(
                          "span",
                          {
                            className: l().descriptionTitle,
                          },
                          n.t("Get Slack AI")
                        ),
                        t.createElement(
                          "span",
                          {
                            className: l().descriptionSubtitle,
                          },
                          n.t("Work smarter, not harder")
                        )
                      )
                    ),
                    t.createElement(
                      T.A,
                      {
                        "aria-label": n.t("Close"),
                        onClick: X,
                        className: l().closeButton,
                        autoClogProps: m,
                      },
                      t.createElement(h.A, {
                        name: "close",
                        size: "16",
                      })
                    )
                  )
                )
              : null;
          }, "SlackAiSidebarPurchaseCta");
        M.displayName = "SlackAiSidebarPurchaseCta";
        const P = M;
      },
      3566375448: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => m,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(2562405183),
          s = e(5602423845),
          v = e(5255740490),
          g = e(735940183),
          T = e(529182726),
          h = e(1224315998),
          E = e(4481313819),
          O = e(1104747761),
          a = e(4509434386),
          u = e(8214116048),
          _ = e(3328068409),
          I = e(6084388622),
          b = e(6259241484),
          i = e(2938177083),
          o = e(9225229866),
          l = e(8683010724);
        const n = new g.Ay("promotions"),
          d = {
            elementName: "close_button",
            onClick: {
              enableClogAction: !0,
            },
          },
          r = c((M) => {
            let { experimentRemainingDays: P } = M;
            const D = (0, s.A)(),
              y = (0, f.wA)(),
              K = (0, p.d4)(O.LJ),
              S = (0, p.d4)(_.to),
              k = (0, t.useCallback)(
                (Z) => {
                  Z.stopPropagation(),
                    y(
                      (0, i.A)({
                        spaceName: b.xu.SIDEBAR_MENU_HEADER,
                        action: b.hw.DISMISS,
                      })
                    );
                },
                [y]
              ),
              C = (0, t.useCallback)(() => {
                D.track(h.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES, {
                  contexts: {
                    ui_context: {
                      action: h.UiAction.CLICK,
                      ui_component:
                        h.UiComponentName
                          .DISCOUNT_SEAT_PROMO_HALFWAY_SIDEBAR_BANNER,
                      ui_properties: {
                        element_name:
                          "discount_seat_promo_halfway_sidebar_banner",
                        element_type: h.ElementType.BUTTON,
                      },
                    },
                  },
                }),
                  y(
                    (0, T.A)({
                      source: o.K3.DiscountSeatsPromo,
                    })
                  );
              }, [y, D]);
            return K
              ? t.createElement(
                  E.A,
                  {
                    clogImpression: !0,
                    eventId: h.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES,
                    uiComponentName:
                      h.UiComponentName
                        .DISCOUNT_SEAT_PROMO_HALFWAY_SIDEBAR_BANNER,
                  },
                  t.createElement(
                    "div",
                    {
                      role: "button",
                      tabIndex: 0,
                      className: (0, v.A)(
                        "p-discount_seat_promo_halfway_sidebar_banner__container",
                        {
                          [a.Pn]: S === u.Sx.Light,
                        }
                      ),
                      onClick: C,
                      "data-qa": "discount-seat-promo-halfway-sidebar-banner",
                    },
                    t.createElement(l.A, {
                      size: "20",
                      name: "emoji-celebration",
                    }),
                    t.createElement(
                      "div",
                      null,
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-discount_seat_promo_halfway_sidebar_banner__header",
                        },
                        n.t("New members get one month free")
                      ),
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-discount_seat_promo_halfway_sidebar_banner__subtitle",
                        },
                        n.rt(
                          "{daysRemaining} {daysRemaining, plural, =1 {day} other {days}} left for this offer",
                          {
                            daysRemaining: P,
                          }
                        )
                      )
                    ),
                    t.createElement(
                      I.Nm,
                      {
                        className:
                          "p-discount_seat_promo_halfway_sidebar_banner__close_icon",
                        onClick: k,
                        "aria-label": n.t("close"),
                        "data-qa":
                          "discount-seat-promo-halfway-sidebar-banner-close-btn",
                        autoClogProps: d,
                      },
                      t.createElement(l.A, {
                        size: "20",
                        name: "close",
                      })
                    )
                  )
                )
              : null;
          }, "DiscountSeatPromoHalfWaySidebarBanner");
        r.displayName = "DiscountSeatPromoHalfWaySidebarBanner";
        const m = r;
      },
      3540014338: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseTrialSidebarLinkForHeader: () => P,
            default: () => y,
          });
        var t = e(5824283093),
          f = e(2562405183),
          p = e(6122756707),
          s = e(5255740490),
          v = e(735940183),
          g = e(5519146941),
          T = e(3193155968),
          h = e(716227588),
          E = e(7715417323),
          O = e(1224315998),
          a = e(1655938719),
          u = e(8871937520),
          _ = e(2938177083),
          I = e(6259241484),
          b = e(4481313819),
          i = e(1610251172),
          o = e(561803758),
          l = e(2525419272),
          n = e(6084388622),
          d = e(2612353366),
          r = e(4469810895),
          m = e(2802517438);
        const M = new v.Ay("paid_onboarding"),
          P = c((K) => {
            let {
              trialExpirationDate: S,
              isAdmin: k,
              loadSidebarMenuMegaphoneNotification: C,
              paidBenefitsHandler: Z,
            } = K;
            const Y = (0, u.qe)(S) || 0,
              $ = (0, f.d4)(r.dC),
              { getSiblingView: X, shouldUseNavigate: G } = (0, t.useContext)(
                g.A
              ),
              L = (0, p.wA)(),
              ee = {
                elementType: O.ElementType.X,
                elementName: "close_sidebar_benefits",
                action: O.UiAction.CLOSE,
                onClick: {
                  enableClogAction: !0,
                },
              },
              te = (0, t.useCallback)(
                function (he) {
                  let se =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : E.A;
                  he == null || he.stopPropagation(),
                    L(
                      (0, _.A)({
                        spaceName: I.xu.SIDEBAR_MENU_HEADER,
                        action: I.hw.DISMISS,
                      })
                    ).then(se);
                },
                [L]
              ),
              W = c(function () {
                let { className: he, onDismissCallback: se } =
                  arguments.length > 0 && arguments[0] !== void 0
                    ? arguments[0]
                    : {};
                const H = (0, s.A)(
                  he,
                  "p-channel_sidebar__close_container",
                  "p-ia4_sidebar_header__icon_close"
                );
                return t.createElement(
                  n.Nm,
                  {
                    onClick: (Q) => {
                      te(Q, se);
                    },
                    className: H,
                    tabIndex: -1,
                    "aria-hidden": !0,
                    "data-qa": "golden-gate-dismiss-cta",
                    autoClogProps: ee,
                  },
                  t.createElement(i.A, {
                    type: "times",
                  })
                );
              }, "renderCloseButton");
            W.displayName = "renderCloseButton";
            const F = (0, s.A)("p-sidebar_link__icon", {
                "p-sidebar_link__icon--bold": $,
              }),
              z = c(() => {
                const he = (Y / 14) * 100,
                  se = (0, s.A)(
                    F,
                    "p-sidebar_link__icon--progress",
                    "flex_shrink_none"
                  );
                return t.createElement(l.A, {
                  containerClassName: se,
                  containerSizeInPixels: 22,
                  progressBarWidthInPixels: 2,
                  progressPercentage: he,
                  progressBarColor: "rgb(255, 255, 255)",
                  progressBarBackgroundColor: "rgb(255, 255, 255)",
                  progressBarBackgroundColorAlpha: 0.2,
                  progressBarLabel: `${Y}`,
                });
              }, "renderDaysRemainingIcon");
            z.displayName = "renderDaysRemainingIcon";
            let oe = "",
              fe = null,
              Me = "";
            Y === 1
              ? ((fe = t.createElement(i.A, {
                  type: "exclamation-circle",
                  className: F,
                })),
                (oe = M.t("Free trial ends today")))
              : Y === 2
              ? ((fe = z()), (oe = M.t("Free trial ending soon")))
              : ((oe = M.t("Free trial in progress")),
                Y < 14
                  ? ((fe = z()),
                    (Me = `${oe} ${M.t(
                      "You have {trialDaysRemaining, plural, =1 {# day} other {# days}} remaining",
                      {
                        trialDaysRemaining: Y,
                      }
                    )}`))
                  : (fe = t.createElement(i.A, {
                      type: "hourglass",
                      className: F,
                    })));
            const Re = t.createElement(
                t.Fragment,
                null,
                fe,
                t.createElement(o.A, {
                  displayName: oe,
                  qaChannelName: oe,
                  ariaLabel: Me,
                })
              ),
              Se =
                (0, f.d4)((he) => {
                  var se;
                  return G
                    ? (se = X(he, {
                        container: T.mq.Primary,
                      })) === null || se === void 0
                      ? void 0
                      : se.id
                    : (0, m.A)(he);
                }) === "Ppaid-benefits";
            return t.createElement(
              b.A,
              {
                clogImpression: !0,
              },
              t.createElement(
                "div",
                {
                  className: (0, s.A)("p-ia4_sidebar_header__link_wrapper", {
                    "p-channel_sidebar__link--selected": Se,
                  }),
                },
                t.createElement(
                  n.Nm,
                  {
                    className: "p-ia4_sidebar_header__link_btn",
                    onClick: Z,
                  },
                  Re
                ),
                !k &&
                  W({
                    onDismissCallback: C,
                  })
              )
            );
          }, "TrialSidebarLinkForHeader");
        P.displayName = "TrialSidebarLinkForHeader";
        const D = c(() => {
          const K = (0, p.wA)(),
            { trialExpirationDate: S, isAdmin: k } = (0, f.d4)(h.Ak),
            C = (0, t.useCallback)(() => {
              K(
                (0, a.iR)({
                  event: {
                    type: I.jo.REQUEST_SPACES,
                    spaces: [I.xu.SIDEBAR_MENU_HEADER],
                  },
                })
              );
            }, [K]),
            Z = (0, t.useCallback)(() => {
              K((0, d.A)());
            }, [K]);
          return t.createElement(P, {
            trialExpirationDate: S,
            isAdmin: k,
            loadSidebarMenuMegaphoneNotification: C,
            paidBenefitsHandler: Z,
          });
        }, "ConnectedTrialSidebarLinkForHeader");
        D.displayName = "ConnectedTrialSidebarLinkForHeader";
        const y = D;
      },
      6962982910: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            PNPSidebarBadgeBanner: () => he,
          });
        var t = e(5824283093),
          f = e(6449156268),
          p = e(3801841745),
          s = e(735940183),
          v = e(5255740490),
          g = e(4481313819),
          T = e(5946832122),
          h = e(6862327721),
          E = e(3506776591),
          O = e.n(E),
          a = e(8790440477),
          u = e.n(a),
          _ = e(5519146941),
          I = e(3193155968),
          b = e(6122756707),
          i = e(8683010724),
          o = e(6084388622),
          l = e(6323355797),
          n = e(3677514771),
          d = e(2562405183),
          r = e(8951118047),
          m = e(8004193929),
          M = e.n(m);
        const P = {
          elementName: "pnp_sidebar_banner_badge_cta",
          onClick: {
            enableClogAction: !0,
          },
        };
        function D(se) {
          let {
            canUserPurchase: H,
            buttonText: Q,
            className: re,
            articleId: J,
            daysRemaining: Fe,
          } = se;
          const We = (0, d.d4)(n.H7),
            Be = (0, t.useMemo)(
              () =>
                (0, l.Qn)({
                  team: We,
                  entryPoint: "pnp_sidebar_badge",
                  productLevel: l.i6.standard.id,
                }),
              [We]
            );
          return H
            ? t.createElement(
                o.jV,
                {
                  autoClogProps: P,
                  className: `${M().cta} ${re}`,
                  href: Be,
                },
                t.createElement(i.A, {
                  name: "rocket",
                  size: "20",
                }),
                t.createElement(
                  "span",
                  {
                    className: M().cta_text,
                  },
                  Q
                )
              )
            : t.createElement(
                r.A,
                {
                  articleId: J,
                  className: `${M().cta} ${re}`,
                },
                t.createElement(
                  o.Nm,
                  {
                    autoClogProps: P,
                    className:
                      "display_flex align_items_center justify_content_center",
                  },
                  Fe > 3 &&
                    t.createElement(i.A, {
                      name: "info",
                      size: "20",
                    }),
                  t.createElement(
                    "span",
                    {
                      className: M().cta_text,
                    },
                    Q
                  )
                )
              );
        }
        c(D, "PNPSidebarBadge"), (D.displayName = "PNPSidebarBadge");
        var y = e(3810478625),
          K = e(5597384299),
          S = e(2825630827),
          k = e(7239742441);
        const C = new s.Ay("pnp_notifications"),
          Z = c(
            (se, H, Q, re, J) =>
              se
                ? Q === 1
                  ? re
                    ? J && J > 25
                      ? C.rt(
                          "<strong>Last day to upgrade and preserve {messageCount} messages and files.</strong>",
                          {
                            messageCount: (0, k.$k)(J),
                            formattedDate: H,
                          }
                        )
                      : C.rt(
                          "<strong>Last day to upgrade and preserve message and file history.</strong>"
                        )
                    : J && J > 25
                    ? C.rt(
                        "<strong>Last day to preserve {messageCount} messages and files.</strong> Contact an admin to upgrade.",
                        {
                          messageCount: (0, k.$k)(J),
                          formattedDate: H,
                        }
                      )
                    : C.rt(
                        "<strong>Last day to preserve message and file history.</strong> Contact an admin to upgrade."
                      )
                  : re
                  ? J && J > 25
                    ? C.rt(
                        "<strong>Upgrade to preserve {messageCount} messages and files</strong> before plans change on {formattedDate}.",
                        {
                          messageCount: (0, k.$k)(J),
                          formattedDate: H,
                        }
                      )
                    : C.rt(
                        "<strong>Upgrade to preserve message and file history</strong> before plans change on {formattedDate}.",
                        {
                          formattedDate: H,
                        }
                      )
                  : J && J > 25
                  ? C.rt(
                      "<strong>Preserve {messageCount} messages and files</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        messageCount: (0, k.$k)(J),
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>Preserve message and file history</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    )
                : "",
            "getDataDeletionAlertBannerContent"
          ),
          Y = c((se, H, Q, re) => {
            if (!se) return "";
            switch (re) {
              case S.d.NO_IMPACT:
                return Q > 7
                  ? C.rt(
                      "<strong>Changes are coming to the free version of Slack</strong> starting on {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days until plans change</strong> on {formattedDate}.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              case S.d.DATA_DELETION:
                return Q > 7
                  ? C.rt(
                      "<strong>Preserve your message and file history</strong> before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days until content</strong> older than a year is permanently deleted.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              case S.d.PRICING_AND_PACKAGING:
                return Q > 7
                  ? C.rt(
                      "<strong>Preserve access to features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days until plans change.</strong> Upgrade to preserve access to some features.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              case S.d.DELETION_AND_PNP:
                return Q > 7
                  ? C.rt(
                      "<strong>Preserve your content and features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days until plans change.</strong> Upgrade to preserve content and features you use.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              default:
                return "";
            }
          }, "getSidebarNonPurchaserDescription"),
          $ = c((se, H, Q, re, J) => {
            if (!se) return "";
            if (!J) return Y(se, H, Q, re);
            switch (re) {
              case S.d.NO_IMPACT:
                return Q > 7
                  ? C.rt(
                      "<strong>Offer available until {formattedDate}</strong> when plans change.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Plans change on {formattedDate}.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              case S.d.DATA_DELETION:
                return Q > 7
                  ? C.rt(
                      "<strong>Preserve your message and file history.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Upgrade to preserve your content.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              case S.d.PRICING_AND_PACKAGING:
                return Q > 7
                  ? C.rt(
                      "<strong>Preserve access to features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Upgrade to preserve access to some features.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              case S.d.DELETION_AND_PNP:
                return Q > 7
                  ? C.rt(
                      "<strong>Preserve your content and features you use.</strong> Upgrade before {formattedDate}.",
                      {
                        formattedDate: H,
                      }
                    )
                  : C.rt(
                      "<strong>{daysRemaining} days left for this offer.</strong> Upgrade to preserve content and features you use.",
                      {
                        formattedDate: H,
                        daysRemaining: Q,
                      }
                    );
              default:
                return "";
            }
          }, "getSidebarDescription"),
          X = c((se, H, Q, re) => {
            if (!se) return "";
            const J = re === S.d.DATA_DELETION;
            return Q <= 3
              ? ""
              : Q <= 7 && Q > 3
              ? J
                ? C.t("{daysRemaining} days until content will be deleted", {
                    daysRemaining: Q,
                  })
                : C.t("{daysRemaining} days until plans change", {
                    daysRemaining: Q,
                  })
              : J
              ? C.t("Content will be deleted on {formattedDate}", {
                  formattedDate: H,
                })
              : C.t("Plans change on {formattedDate}", {
                  formattedDate: H,
                });
          }, "getNonPurchaserPersistentSubText"),
          G = c(
            (se, H, Q, re, J) =>
              se
                ? re
                  ? Q === 1
                    ? C.t("Last day to claim offer")
                    : Q <= 7
                    ? C.t("{daysRemaining} days left", {
                        daysRemaining: Q,
                      })
                    : C.t("Offer available through {formattedDate}", {
                        formattedDate: H,
                      })
                  : X(se, H, Q, J)
                : "",
            "getPresistentSubText"
          ),
          L = c((se, H, Q, re, J) => {
            if (!se) return "";
            switch (re) {
              case S.d.NO_IMPACT:
                return Q === 1
                  ? C.rt(
                      "<strong>Last day before your plan changes.</strong> Contact an admin to upgrade."
                    )
                  : C.rt(
                      "<strong>Changes to your plan start on {formattedDate}.</strong> Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    );
              case S.d.DATA_DELETION:
                return Z(se, H, Q, !1, J);
              case S.d.PRICING_AND_PACKAGING:
                return Q === 1
                  ? C.rt(
                      "<strong>Last day to preserve features you use.</strong> Contact an admin to upgrade."
                    )
                  : C.rt(
                      "<strong>Preserve features you use</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    );
              case S.d.DELETION_AND_PNP:
                return Q === 1
                  ? C.rt(
                      "<strong>Last day to preserve your content and features you use.</strong> Contact an admin to upgrade."
                    )
                  : C.rt(
                      "<strong>Preserve your content and features you use</strong> before plans change on {formattedDate}. Contact an admin to upgrade.",
                      {
                        formattedDate: H,
                      }
                    );
              default:
                return "";
            }
          }, "getNonPurchaserAlertBannerText"),
          ee = c((se, H, Q, re, J, Fe) => {
            if (!se) return "";
            if (!J) return L(se, H, Q, re, Fe);
            switch (re) {
              case S.d.NO_IMPACT:
                return Q === 1
                  ? C.rt("<strong>Last day before your plan changes</strong>")
                  : C.rt(
                      "<strong>Changes to your plan start on {formattedDate}</strong>",
                      {
                        formattedDate: H,
                      }
                    );
              case S.d.DATA_DELETION:
                return Z(se, H, Q, J, Fe);
              case S.d.PRICING_AND_PACKAGING:
                return Q === 1
                  ? C.rt(
                      "<strong>Last day to upgrade and preserve features you use.</strong>"
                    )
                  : C.rt(
                      "<strong>Upgrade and preserve features you use</strong> before plans change on {formattedDate}",
                      {
                        formattedDate: H,
                      }
                    );
              case S.d.DELETION_AND_PNP:
                return Q === 1
                  ? C.rt(
                      "<strong>Last day to upgrade and preserve your content and features you use.</strong>"
                    )
                  : C.rt(
                      "<strong>Upgrade to preserve your content and features you use</strong> before plans change on {formattedDate}",
                      {
                        formattedDate: H,
                      }
                    );
              default:
                return "";
            }
          }, "getAlertBannerText");
        var te = e(7003004874),
          W = e(6259241484),
          F = e(1224315998),
          z = e(8214116048),
          oe = e(4509434386),
          fe = e(3328068409),
          Me = e(1655938719);
        const Re = new s.Ay("pnp_notifications"),
          Ye = {
            elementName: "pnp_sidebar_banner_badge_close_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          Se = {
            elementName: "pnp_sidebar_banner_badge_compareplans_cta",
            onClick: {
              enableClogAction: !0,
            },
          };
        function he(se) {
          let {
            canUserPurchase: H,
            date: Q,
            variant: re,
            daysRemaining: J,
            collapseState: Fe,
            messageCount: We,
          } = se;
          const [Be, Ze] = (0, t.useState)(Fe === "collapsed"),
            Ge = (0, b.wA)(),
            V = (0, d.d4)(y.g),
            ae = (0, d.d4)(fe.to),
            { activeTab: Ee } = (0, t.useContext)(_.A),
            we = Ee === I.k6.Home;
          (0, t.useEffect)(() => {
            Ze(Fe === "collapsed");
          }, [Fe]);
          const et = (0, t.useMemo)(
              () =>
                Q
                  ? (0, K.Yq)((0, f.A)(Q, "YYYY/MM/DD").unix(), "{date_num}", {
                      customFormat: "MMM Do",
                    })
                  : "",
              [Q]
            ),
            pt = (0, t.useMemo)(
              () =>
                t.createElement("img", {
                  alt: V ? Re.t("P&Psidebar banner hourglass image") : "",
                  src: u(),
                }),
              [V]
            ),
            it = (0, t.useMemo)(
              () =>
                t.createElement("img", {
                  alt: V ? Re.t("P&Psidebar banner bell image") : "",
                  src: O(),
                }),
              [V]
            ),
            w = (0, t.useCallback)(() => {
              let Te = V ? Re.t("Get 75% off Slack Pro") : "";
              H ||
                ((Te = V ? Re.t("About the new Slack plans") : ""),
                re === S.d.DATA_DELETION &&
                  (Te = V ? Re.t("About changes to storage") : ""));
              const Je =
                re === S.d.DATA_DELETION ? 29414264463635 : 30915393948051;
              return t.createElement(
                g.A,
                {
                  eventId: F.EventId.UPGRDEXP_PNP_NOTIFICATION,
                  uiComponentName: F.UiComponentName.PNP_SIDEBAR_UPGRADE_BUTTON,
                  uiStep: Be ? F.UiStep.COLLAPSED : F.UiStep.EXPANDED,
                  uiComponentVariant: H
                    ? F.UiComponentVariant.PURCHASER
                    : F.UiComponentVariant.NON_PURCHASER,
                  clogImpression: !0,
                },
                t.createElement(D, {
                  className: Be
                    ? (0, v.A)(M().persistantCTA, {
                        [oe.A7]: ae === z.Sx.Light,
                      })
                    : "",
                  daysRemaining: J,
                  canUserPurchase: H,
                  buttonText: Te,
                  articleId: Je,
                })
              );
            }, [H, ae, J, V, Be, re]),
            ge = (0, t.useCallback)(() => {
              Ze(!0),
                Ge(
                  (0, te.A)({
                    notificationName: W.ze.PNP_SIDEBAR,
                    action: W.hw.CLICK,
                  })
                );
            }, [Ge]),
            le = (0, t.useCallback)(() => {
              Ge(
                (0, h.A)({
                  from: S.o.PNP_SIDEBAR_BADGE,
                  canUserPurchase: H,
                })
              );
            }, [H, Ge]),
            ie = (0, t.useCallback)(() => {
              Ze(!0),
                Ge(
                  (0, te.A)({
                    notificationName: W.ze.PNP_SIDEBAR,
                    action: W.hw.CLICK,
                    step: "collapse",
                  })
                ).then(() => {
                  Ge(
                    (0, Me.iR)({
                      event: {
                        type: W.jo.REQUEST_SPACES,
                        spaces: [W.xu.SIDEBAR_MENU_HEADER],
                      },
                    })
                  );
                });
            }, [Ge]),
            Ae = (0, t.useCallback)(() => {
              let Te = t.createElement(
                "div",
                {
                  className: M().subtext,
                },
                G(V, et, J, H, re)
              );
              return (
                !Be &&
                  J &&
                  J > 7 &&
                  (Te = t.createElement(
                    o.Nm,
                    {
                      autoClogProps: Se,
                      "data-qa": "pnp_sidebar_compare_plans_cta",
                      className: M().subtext,
                      onClick: le,
                    },
                    V ? Re.t("Compare new plans") : ""
                  )),
                !H && !Be ? null : Te
              );
            }, [H, J, V, et, Be, le, re]),
            Xe = (0, t.useCallback)(
              () =>
                !H && Be
                  ? null
                  : J && J <= 3
                  ? t.createElement(
                      p.A,
                      {
                        className: (0, v.A)(M().alert, {
                          [oe.A7]: ae === z.Sx.Light,
                        }),
                        gap: 8,
                      },
                      t.createElement(i.A, {
                        name: "warning",
                        size: "20",
                      }),
                      t.createElement("span", null, ee(V, et, J, re, H, We)),
                      !H &&
                        t.createElement(
                          T.A,
                          {
                            "aria-label": V ? Re.t("close") : "",
                            onClick: ge,
                            className: M().alertCloseIcon,
                          },
                          t.createElement(i.A, {
                            name: "close",
                            size: "16",
                          })
                        )
                    )
                  : null,
              [Be, J, ae, V, et, re, H, We, ge]
            );
          return we
            ? Be || (J && J <= 3)
              ? t.createElement(
                  p.A,
                  {
                    className: M().persistentContainer,
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 8,
                  },
                  Xe(),
                  t.createElement(
                    p.A,
                    {
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 8,
                      className: "full_width",
                    },
                    w(),
                    " ",
                    Ae()
                  )
                )
              : t.createElement(
                  "div",
                  {
                    className: (0, v.A)(M().container, {
                      [oe.A7]: ae === z.Sx.Light,
                    }),
                  },
                  t.createElement(
                    p.A,
                    {
                      flexDirection: "column",
                      gap: 4,
                      alignItems: "center",
                    },
                    t.createElement(
                      p.A,
                      {
                        gap: 8,
                        alignItems: "flex-start",
                        alignSelf: "flex-start",
                        justifyContent: "space-between",
                        className: M().innerContainer,
                      },
                      t.createElement(
                        "div",
                        {
                          className: M().expanded_text,
                        },
                        $(V, et, J, re, H)
                      ),
                      J <= 7 ? pt : it,
                      t.createElement(
                        o.Nm,
                        {
                          autoClogProps: Ye,
                          "data-qa": "pnp-sidebar-close-btn",
                          className: M().closeButton,
                          onClick: ie,
                        },
                        t.createElement(i.A, {
                          name: "close",
                        })
                      )
                    ),
                    w(),
                    Ae()
                  )
                )
            : null;
        }
        c(he, "PNPSidebarBadgeBanner"),
          (he.displayName = "PNPSidebarBadgeBanner");
      },
      2994893019: (x, A, e) => {
        "use strict";
        e.d(A, {
          M: () => g,
        });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(6084388622),
          s = e(8683010724);
        function v() {
          return (
            (v =
              Object.assign ||
              function (T) {
                for (var h = 1; h < arguments.length; h++) {
                  var E = arguments[h];
                  for (var O in E)
                    Object.prototype.hasOwnProperty.call(E, O) && (T[O] = E[O]);
                }
                return T;
              }),
            v.apply(this, arguments)
          );
        }
        c(v, "_extends");
        const g = c((T) => {
          let {
            isTrialFirstDay: h,
            isTrialLastDay: E,
            trialDaysRemaining: O,
            isSelected: a,
            showWrapper: u,
            autoClogProps: _,
            onClick: I,
            buttonText: b,
            svgIconProps: i,
            href: o,
            experimentFeatReverseTrialGroupTreatment: l,
          } = T;
          const n = c(() => {
            if (i) return t.createElement(s.A, v({}, i));
            let m = null;
            return (
              O > 2 && O <= 30
                ? (m = t.createElement(s.A, {
                    size: "20",
                    name: "hourglass",
                  }))
                : O === 2 &&
                  (m = t.createElement(s.A, {
                    size: "20",
                    name: l ? "warning" : "info",
                    variation: "filled",
                  })),
              m
            );
          }, "renderStartIcon");
          n.displayName = "renderStartIcon";
          const d = (0, f.A)("p-sidebar_trial_badge__button", {
              "p-sidebar_trial_badge__button_generic": !E && !a,
              "p-sidebar_trial_badge__button_last_day": E && !a,
              "p-sidebar_trial_badge__button_first_day": h && u && !a,
              "p-sidebar_trial_badge__button_generic_selected": !u && a,
              "p-sidebar_trial_badge__button_with_wrapper_selected": u && a,
              "p-sidebar_trial_badge__button_with_wrapper_selected_border":
                u && a && E,
            }),
            r = t.createElement(
              t.Fragment,
              null,
              n(),
              t.createElement(
                "div",
                {
                  className: "p-sidebar_trial_badge__button_text_container",
                },
                b
              ),
              t.createElement(
                "span",
                null,
                t.createElement(s.A, {
                  size: "24",
                  name: "caret-right",
                })
              )
            );
          return o
            ? t.createElement(
                "span",
                {
                  className: "p-sidebar_trial_badge__link_wrapper",
                },
                t.createElement(
                  p.jV,
                  {
                    className: d,
                    "data-qa": "sidebar-trial-badge-btn",
                    autoClogProps: _,
                    href: o,
                  },
                  r
                )
              )
            : t.createElement(
                p.Nm,
                {
                  className: d,
                  "data-qa": "sidebar-trial-badge-btn",
                  autoClogProps: _,
                  onClick: I,
                },
                r
              );
        }, "SidebarBadge");
        g.displayName = "SidebarBadge";
      },
      3998269055: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            SlackAITrialAwarenessSidebarBadge: () => Re,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4481313819),
          s = e(4502904940),
          v = e(7094978947),
          g = e(2994893019),
          T = e(9706240641),
          h = e(8815100550),
          E = e(2603617615),
          O = e(9901906329),
          a = e(7053877048),
          u = e(267465465),
          _ = e(8719380546),
          I = e(9240394198),
          b = e(3801841745),
          i = e(1495538422),
          o = e(6084388622),
          l = e(2755566931),
          n = e(1224315998),
          d = e(735940183),
          r = e(1655938719),
          m = e(6259241484),
          M = e(9003400431),
          P = e(5060694341);
        const D = {
            onClick: {
              enableClogAction: !0,
            },
            elementName: s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_TOUR,
            uiStep: "non_purchaser",
            isPrimaryCTA: !0,
          },
          y = new d.Ay("assistant"),
          K = c((Ye) => {
            let { numDaysLeft: Se } = Ye;
            const he = (0, f.wA)(),
              se = (0, t.useCallback)(() => {
                he((0, M.O)());
              }, [he]),
              H = (0, t.useCallback)(
                (0, T.coroutine)(function* () {
                  yield he(
                    (0, i.K)({
                      reason: "requesting-a-purchase",
                      featRequestCode: "slack_ai_trial_purchase",
                    })
                  )
                    .then(() => {
                      he(
                        (0, P.M)({
                          element: t.createElement(
                            l.Ay,
                            {
                              svgIconProps: {
                                name: "paper-plane",
                              },
                            },
                            t.createElement("span", null, y.t("Request sent"))
                          ),
                        })
                      );
                    })
                    .catch(() => {
                      he(
                        (0, P.M)({
                          element: t.createElement(
                            l.Ay,
                            {
                              svgIconProps: {
                                name: "warning",
                              },
                            },
                            t.createElement(
                              "span",
                              null,
                              t.createElement(
                                "span",
                                null,
                                y.t("Something went wrong")
                              )
                            )
                          ),
                        })
                      );
                    })
                    .finally(() => {
                      he(
                        (0, r.iR)({
                          event: {
                            type: m.jo.REQUEST_SPACES,
                            spaces: [m.xu.SIDEBAR_MENU_HEADER],
                          },
                        })
                      ),
                        se();
                    });
                }),
                [he, se]
              ),
              Q = c((Ze) => {
                let { text: Ge } = Ze;
                return t.createElement(a.y, null, Ge);
              }, "renderGradient"),
              re = y.rt(
                "{numDaysLeft, plural, =1 {# day} other {# days}} left in your <gradient>Slack AI</gradient> trial",
                {
                  numDaysLeft: Se,
                  "<gradient>": Q,
                }
              ),
              J = y.rt(
                "Preserve access to time-saving features by requesting to keep Slack AI."
              ),
              Fe = (0, t.useCallback)(
                () =>
                  t.createElement(
                    b.A,
                    {
                      flexDirection: "column",
                      gap: 24,
                    },
                    t.createElement(O.E, null),
                    t.createElement(
                      "span",
                      null,
                      y.t(
                        "Enjoying Slack AI? We\u2019ll send a note to people on your team with permission to purchase."
                      )
                    )
                  ),
                []
              ),
              We = c(
                () =>
                  t.createElement(
                    b.A,
                    {
                      flexDirection: "column",
                      gap: 28,
                    },
                    t.createElement(
                      b.A,
                      {
                        flexDirection: "column",
                        gap: 12,
                      },
                      t.createElement(
                        o.$n,
                        {
                          onClick: H,
                          type: "primary",
                          size: "medium",
                          autoFocus: !0,
                          autoClogProps: D,
                        },
                        y.t("Request to Keep Slack AI")
                      )
                    )
                  ),
                "renderFooterContent"
              );
            We.displayName = "renderFooterContent";
            const Be = (0, t.useMemo)(() => t.createElement(h.H, null), []);
            return t.createElement(
              p.A,
              {
                clogImpression: !0,
                eventId: n.EventId.UPGRDEXP_SLACK_AI,
                uiComponentName:
                  n.UiComponentName.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MODAL,
                uiComponentVariant: n.UiComponentVariant.NON_PURCHASER,
              },
              t.createElement(_.A, {
                closeButtonTheme: I.N.GRAY,
                bodyContent: Fe(),
                footerContent: We(),
                showProBadge: !1,
                hero: Be,
                onRequestClose: se,
                title: re,
                subtitle: J,
                type: u.H.HORIZONTAL_BANNER,
                maxWidth: E.D,
              })
            );
          }, "NonPurchaserModal");
        K.displayName = "NonPurchaserModal";
        var S = e(8453174784),
          k = e(5519146941),
          C = e(8683010724),
          Z = e(6323355797),
          Y = e(2562405183),
          $ = e(7003004874),
          X = e(2375333597),
          G = e(3677514771),
          L = e(3193155968),
          ee = e(2455200396),
          te = e.n(ee),
          W = e(5504232338),
          F = e.n(W);
        function z() {
          return (
            (z =
              Object.assign ||
              function (Ye) {
                for (var Se = 1; Se < arguments.length; Se++) {
                  var he = arguments[Se];
                  for (var se in he)
                    Object.prototype.hasOwnProperty.call(he, se) &&
                      (Ye[se] = he[se]);
                }
                return Ye;
              }),
            z.apply(this, arguments)
          );
        }
        c(z, "_extends");
        const oe = new d.Ay("assistant"),
          fe = {
            elementName: s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_SIDEBAR_BADGE,
            onClick: {
              enableClogAction: !0,
            },
          },
          Me = {
            elementName:
              s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_SIDEBAR_BADGE_CLOSE_BTN,
            onClick: {
              enableClogAction: !0,
            },
          },
          Re = c((Ye) => {
            let {
              numDaysLeft: Se,
              collapseState: he,
              collapsible: se,
              canUserPurchase: H,
              addonId: Q,
              availableAddonTerm: re,
              availableAddonUpfrontUnitCost: J,
              availableAddonCurrency: Fe,
            } = Ye;
            const [We, Be] = (0, t.useState)(he === "collapsed"),
              Ze = (0, f.wA)(),
              Ge = (0, Y.d4)(G.H7),
              { activeTab: V } = (0, t.useContext)(k.A),
              ae = V === L.k6.Home,
              Ee = Se <= 1 && H;
            (0, t.useEffect)(() => {
              Be(he === "collapsed");
            }, [he]);
            const we = c(
                () =>
                  H
                    ? Ee
                      ? oe.rt("It\u2019s the last day of your Slack AI trial")
                      : oe.rt("Save time with Slack AI")
                    : oe.rt("There\u2019s still time to try Slack AI"),
                "getExpandedText"
              ),
              et = (0, t.useCallback)(() => {
                Ze(
                  H
                    ? (0, X.q)({
                        element: t.createElement(S.R, {
                          addonId: Q,
                          availableAddonTerm: re,
                          availableAddonUpfrontUnitCost: J,
                          availableAddonCurrency: Fe,
                          entryPoint:
                            m.ze.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER,
                        }),
                      })
                    : (0, X.q)({
                        element: t.createElement(K, {
                          numDaysLeft: Se,
                        }),
                      })
                );
              }, [Q, Fe, re, J, H, Ze, Se]),
              pt = (0, t.useCallback)(() => {
                Be(!0),
                  Ze(
                    (0, $.A)({
                      notificationName:
                        m.ze.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER,
                      action: m.hw.CLICK,
                      step: "collapse",
                    })
                  ).then(() => {
                    Ze(
                      (0, r.iR)({
                        event: {
                          type: m.jo.REQUEST_SPACES,
                          spaces: [m.xu.SIDEBAR_MENU_HEADER],
                        },
                      })
                    );
                  });
              }, [Ze]),
              it = (0, v.T)({
                type: "sparkles",
                variation: "filled",
              }),
              w = (0, t.useMemo)(() => {
                let ge = "";
                if (!H) ge = oe.rt("Request to keep");
                else if (Ee) ge = oe.rt("Purchase Slack AI");
                else {
                  let ie = Se;
                  ie === 0 && (ie = 1),
                    (ge = oe.rt(
                      "{usefulNumDaysLeft} {usefulNumDaysLeft, plural, =1 {day} other {days}} left in trial",
                      {
                        usefulNumDaysLeft: ie,
                      }
                    ));
                }
                let le = {
                  isTrialFirstDay: !1,
                  isTrialLastDay: !1,
                  trialDaysRemaining: Se,
                  isSelected: !1,
                  showWrapper: !1,
                  autoClogProps: fe,
                  onClick: et,
                  buttonText: ge,
                  svgIconProps: it,
                };
                if (Ee) {
                  const { onClick: ie, ...Ae } = le;
                  le = {
                    href: (0, Z.Qn)({
                      team: Ge,
                      entryPoint:
                        s.H.SLACK_AI_TRIAL_AWARENESS_IN_TRIAL_SIDEBAR_BADGE,
                      addon: Q,
                    }),
                    ...Ae,
                  };
                }
                return t.createElement(
                  p.A,
                  {
                    eventId: n.EventId.UPGRDEXP_SLACK_AI,
                    uiComponentName:
                      n.UiComponentName
                        .SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER,
                    uiStep: We ? n.UiStep.COLLAPSED : n.UiStep.EXPANDED,
                    uiComponentVariant: H
                      ? n.UiComponentVariant.PURCHASER
                      : n.UiComponentVariant.NON_PURCHASER,
                    clogImpression: !0,
                  },
                  t.createElement(g.M, z({}, le))
                );
              }, [H, Ee, Se, et, it, We, Ge, Q]);
            return ae
              ? We
                ? t.createElement(
                    "div",
                    {
                      className: F().collapsedContainer,
                    },
                    w
                  )
                : t.createElement(
                    "div",
                    {
                      className: F().container,
                    },
                    t.createElement(
                      b.A,
                      {
                        flexDirection: "column",
                        gap: 4,
                      },
                      t.createElement(
                        b.A,
                        {
                          gap: 8,
                          alignItems: "center",
                          justifyContent: "space-between",
                          className: F().innerContainer,
                        },
                        t.createElement(
                          "div",
                          {
                            className: F().expandedText,
                          },
                          we()
                        ),
                        t.createElement("img", {
                          src: te(),
                          alt: oe.t("Slack AI sidebar banner image"),
                          width: 64,
                        }),
                        se &&
                          t.createElement(
                            o.Nm,
                            {
                              className: F().closeButton,
                              onClick: pt,
                              autoClogProps: Me,
                            },
                            t.createElement(C.A, {
                              name: "close",
                            })
                          )
                      ),
                      w
                    )
                  )
              : null;
          }, "SlackAITrialAwarenessSidebarBadge");
        Re.displayName = "SlackAITrialAwarenessSidebarBadge";
      },
      9949873423: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            SlackAiSidebarTrialOfferCta: () => P,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4481313819),
          s = e(6084388622),
          v = e(6105929840),
          g = e(8683010724),
          T = e(7094978947),
          h = e(1224315998),
          E = e(3193155968),
          O = e(735940183),
          a = e(5519146941),
          u = e(7263142004),
          _ = e.n(u);
        const I = new O.Ay("promotions"),
          b = t.memo((D) => {
            let {
              handleClick: y,
              title: K,
              subtitle: S,
              handleDismiss: k,
              uiComponentName: C,
              targetButtonAutoClogProps: Z,
              cancelButtonAutoClogProps: Y,
              autoClogDisplayName: $,
            } = D;
            const { activeTab: X } = (0, t.useContext)(a.A);
            return X === E.k6.Home
              ? t.createElement(
                  p.A,
                  {
                    eventId: h.EventId.UPGRDEXP_SLACK_AI,
                    uiComponentName: C,
                    displayName: $,
                    clogImpression: !0,
                  },
                  t.createElement(
                    "div",
                    {
                      className: _().slackAiSidebarPurchaseCta,
                    },
                    t.createElement(
                      s.jV,
                      {
                        onClick: y,
                        className: _().button,
                        autoClogProps: Z,
                      },
                      t.createElement(
                        "span",
                        {
                          className: _().iconBackground,
                        },
                        t.createElement(
                          "div",
                          {
                            className: _().icon,
                          },
                          t.createElement(T.o, {
                            size: "20",
                          })
                        )
                      ),
                      t.createElement(
                        "div",
                        {
                          className: _().description,
                        },
                        t.createElement(
                          "span",
                          {
                            className: _().descriptionTitle,
                          },
                          K
                        ),
                        t.createElement(
                          "span",
                          {
                            className: _().descriptionSubtitle,
                          },
                          S
                        )
                      )
                    ),
                    t.createElement(
                      v.A,
                      {
                        "aria-label": I.t("Close"),
                        onClick: k,
                        className: _().closeButton,
                        autoClogProps: Y,
                      },
                      t.createElement(g.A, {
                        name: "close",
                        size: "16",
                      })
                    )
                  )
                )
              : null;
          });
        var i = e(9676597566),
          o = e(7115655993),
          l = e(2562405183),
          n = e(6259241484),
          d = e(3141349242);
        const r = new O.Ay("assistant"),
          m = {
            elementName: "try_slack_ai_for_free",
            onClick: {
              enableClogAction: !0,
            },
            isPrimaryCTA: !0,
          },
          M = {
            elementName: "dismiss",
            onClick: {
              enableClogAction: !0,
            },
          },
          P = c((D) => {
            let {
              recordAndClearNotificationEvent: y,
              offerInfo: K,
              trialInfo: S,
              notificationName: k,
            } = D;
            const C = (0, f.wA)();
            (0, o.A)(() => {
              C((0, d.Md)());
            });
            const Z = (0, t.useCallback)(() => {
                y(n.hw.DISMISS);
              }, [y]),
              Y = (0, t.useCallback)(() => {
                C(
                  (0, i.G)({
                    offerInfo: K,
                    trialInfo: S,
                    notificationName: k,
                  })
                );
              }, [C, K, S, k]),
              $ = (0, l.d4)(d.Gj);
            return t.createElement(b, {
              handleClick: Y,
              title: r.t("Try Slack AI for free"),
              subtitle: r.t("Get a free 14-day trial"),
              handleDismiss: Z,
              uiComponentName:
                h.UiComponentName.SLACK_AI_SIDEBAR_TRIAL_START_CTA,
              targetButtonAutoClogProps: m,
              cancelButtonAutoClogProps: M,
              autoClogDisplayName: $,
            });
          }, "SlackAiSidebarTrialOfferCta");
        P.displayName = "SlackAiSidebarTrialOfferCta";
      },
      784529096: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            TrialEndPromoDiscountSidebarCta: () => K,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4481313819),
          s = e(3801841745),
          v = e(7878745420),
          g = e(5519146941),
          T = e(6084388622),
          h = e(8683010724),
          E = e(1224315998),
          O = e(735940183),
          a = e(6323355797),
          u = e(2562405183),
          _ = e(1655938719),
          I = e(7003004874),
          b = e(6259241484),
          i = e(8871937520),
          o = e(3677514771),
          l = e(3193155968),
          n = e(2121234563),
          d = e.n(n),
          r = e(3281979720),
          m = e.n(r);
        const M = v.g.PROMOTIONAL_DISCOUNTS_SIDEBAR_MENU_HEADER_CTA,
          P = new O.Ay("trials"),
          D = {
            elementName: "trial_end_promo_discount_sidebar_cta",
            onClick: {
              enableClogAction: !0,
            },
          },
          y = {
            elementName: "trial_end_promo_discount_sidebar_cta_close_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          K = c((S) => {
            let {
              discountPercent: k,
              collapseState: C,
              collapsible: Z,
              discountExpirationTs: Y,
            } = S;
            const [$, X] = (0, t.useState)(C === "collapsed"),
              G = (0, f.wA)(),
              L = (0, u.d4)(o.H7),
              { activeTab: ee } = (0, t.useContext)(g.A),
              te = ee === l.k6.Home,
              W = (0, i.Zv)((Y ?? 0) * 1e3);
            (0, t.useEffect)(() => {
              X(C === "collapsed");
            }, [C]);
            const F = (0, t.useCallback)(() => {
                X(!0),
                  G(
                    (0, I.A)({
                      notificationName: M,
                      action: b.hw.CLICK,
                      step: "collapse",
                    })
                  ).then(() => {
                    G(
                      (0, _.iR)({
                        event: {
                          type: b.jo.REQUEST_SPACES,
                          spaces: [b.xu.SIDEBAR_MENU_HEADER],
                        },
                      })
                    );
                  });
              }, [G]),
              z = (0, t.useMemo)(() => {
                const oe = (0, a.Qn)({
                  team: L,
                  entryPoint: "trial_end_promo_discount_sidebar_cta",
                });
                return t.createElement(
                  p.A,
                  {
                    eventId: E.EventId.UPGRDEXP_TRIAL,
                    uiComponentName: "trial_end_promo_discount_sidebar_cta",
                    uiStep: $ ? E.UiStep.COLLAPSED : E.UiStep.EXPANDED,
                    clogImpression: !0,
                  },
                  $
                    ? t.createElement(
                        T.z9,
                        {
                          "data-qa": "plans-at-glance-upgrade-now-btn",
                          className: m().collapsedCtaButton,
                          href: oe,
                          autoClogProps: D,
                          type: "outline",
                        },
                        t.createElement(h.A, {
                          name: "rocket",
                          size: "20",
                        }),
                        t.createElement(
                          "span",
                          {
                            className: m().ctaButtonText,
                          },
                          P.rt("Get {discountPercent}% off Pro", {
                            discountPercent: k,
                          })
                        )
                      )
                    : t.createElement(
                        T.jV,
                        {
                          "data-qa": "trial-end-promo-upgrade-sidebar-cta",
                          className: m().ctaButton,
                          href: oe,
                          autoClogProps: D,
                        },
                        t.createElement(h.A, {
                          name: "rocket",
                          size: "20",
                        }),
                        t.createElement(
                          "span",
                          {
                            className: m().ctaButtonText,
                          },
                          P.t("Upgrade to Pro", {
                            fallbackHash:
                              "24de9364ba974a2fa4662ac82b52b83095290bbb",
                            fallbackHashNs: "trial_expiration_modals",
                          })
                        )
                      )
                );
              }, [$, L, k]);
            return te
              ? $
                ? t.createElement(
                    "div",
                    {
                      className: m().collapsedContainer,
                    },
                    z,
                    t.createElement(
                      "div",
                      {
                        className: m().subText,
                      },
                      P.rt(
                        "{daysRemaining, plural, =1 {# day} other {# days}} left",
                        {
                          daysRemaining: W,
                        }
                      )
                    )
                  )
                : t.createElement(
                    "div",
                    {
                      className: m().container,
                    },
                    t.createElement(
                      s.A,
                      {
                        flexDirection: "column",
                        gap: 4,
                      },
                      t.createElement(
                        s.A,
                        {
                          gap: 8,
                          alignItems: "flex-start",
                          justifyContent: "space-between",
                          className: m().innerContainer,
                        },
                        t.createElement(
                          "div",
                          null,
                          t.createElement(
                            "div",
                            {
                              className: m().expandedText,
                            },
                            P.rt("Get {discountPercent}% off Slack Pro", {
                              discountPercent: k,
                            })
                          ),
                          t.createElement(
                            "div",
                            {
                              className: m().subText,
                            },
                            P.rt(
                              "{daysRemaining, plural, =1 {# day} other {# days}} left",
                              {
                                daysRemaining: W,
                              }
                            )
                          )
                        ),
                        t.createElement(
                          "div",
                          {
                            className: m().imgContainer,
                          },
                          t.createElement("img", {
                            src: d(),
                            alt: P.t("Image of gift box"),
                          }),
                          Z &&
                            t.createElement(
                              T.Nm,
                              {
                                className: m().closeButton,
                                onClick: F,
                                autoClogProps: y,
                              },
                              t.createElement(h.A, {
                                name: "close",
                              })
                            )
                        )
                      ),
                      z
                    )
                  )
              : null;
          }, "TrialEndPromoDiscountSidebarCta");
        K.displayName = "TrialEndPromoDiscountSidebarCta";
      },
      4698264567: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => l,
          });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(4481313819),
          s = e(1267040415),
          v = e(3245843483),
          g = e(5519146941),
          T = e(8683010724),
          h = e(2312625946),
          E = e(1224315998),
          O = e(735940183),
          a = e(2562405183),
          u = e(6259241484),
          _ = e(3474336343),
          I = e(3193155968);
        const b = new O.Ay("plan_change"),
          i = {
            isPrimaryCTA: !0,
            onClick: {
              enableClogAction: !0,
            },
          },
          o = c((n) => {
            const {
                ctaLabel: d,
                action: r,
                productId: m,
                notificationName: M,
              } = n,
              P = d ?? b.t("Upgrade Plan"),
              D = M === u.ze.SIDEBAR_MENU_HEADER_UPGRADE_CTA,
              { activeTab: y, getSiblingView: K } = (0, t.useContext)(g.A),
              S = y === I.k6.Home,
              k = (0, a.d4)((C) =>
                (0, _.Li)(C, {
                  getSiblingView: K,
                })
              );
            return (0, v.Z9F)() || !S || k
              ? null
              : t.createElement(
                  p.A,
                  {
                    uiComponentName: E.UiComponentName.UPGRADE_BUTTON,
                  },
                  t.createElement(
                    s.A,
                    {
                      autoClogProps: i,
                      className: (0, f.A)("p-upgrades_button", {
                        "p-upgrades_button--themed": D,
                      }),
                      "data-qa": "upgrades-kit-upgrade-button",
                      entryPoint: "upgrade-button",
                      type: "outline",
                      "aria-label": P,
                      action: r,
                      productId: m,
                    },
                    t.createElement(
                      "div",
                      {
                        className: "p-upgrades_button__rocket",
                      },
                      t.createElement(T.A, {
                        name: "rocket",
                      })
                    ),
                    t.createElement(
                      h.Ay,
                      {
                        offsetX: -15,
                        position: "bottom",
                        delay: h.PK,
                        tip: P,
                        shouldOnlyShowWhenTruncated: !0,
                      },
                      t.createElement(
                        "div",
                        {
                          className: "p-upgrades_button__label",
                        },
                        P
                      )
                    )
                  )
                );
          }, "UpgradeButton");
        o.displayName = "UpgradeButton";
        const l = o;
      },
      6807544879: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            AutoChargeFeatureTrialsManageTrialWorkspaceMenuCta: () => _,
            default: () => b,
          });
        var t = e(5824283093),
          f = e(735940183),
          p = e(6449156268),
          s = e(2562405183),
          v = e(7878745420),
          g = e(6323355797),
          T = e(4761125736),
          h = e(3699548628),
          E = e(1030162945);
        function O() {
          return (
            (O =
              Object.assign ||
              function (i) {
                for (var o = 1; o < arguments.length; o++) {
                  var l = arguments[o];
                  for (var n in l)
                    Object.prototype.hasOwnProperty.call(l, n) && (i[n] = l[n]);
                }
                return i;
              }),
            O.apply(this, arguments)
          );
        }
        c(O, "_extends");
        const a = new f.Ay("auto_charge_feature_trials"),
          u = v.g.AUTO_CHARGE_FEATURE_TRIALS_MANAGE_TRIAL_WORKSPACE_MENU_CTA,
          _ = c((i) => {
            let {
              trialEndDate: o,
              planType: l,
              experimentPaidFeatureTrialAutoChargeTranslationGroupOn: n,
              ...d
            } = i;
            const r = n ? a.t("Slack Pro") : "",
              m = (0, p.A)(o).format("LL"),
              M = (0, t.useCallback)(
                () =>
                  t.createElement(
                    "span",
                    null,
                    t.createElement(E.Ay, {
                      text: "gift",
                      className: "margin_right_25",
                      emojiSize: E.lw.SMALL,
                    }),
                    n
                      ? a.rt(
                          "Your workspace is on a free {featureTrialLength} day trial through {trialThruDate}. Your first bill starts after your trial ends.",
                          {
                            featureTrialLength: g.ew.PAID_FEATURE_TRIAL,
                            trialThruDate: m,
                          }
                        )
                      : ""
                  ),
                [m, n]
              ),
              P = (0, t.useCallback)(
                () =>
                  t.createElement(
                    "span",
                    null,
                    n
                      ? a.rt("Manage your <strong>{planName}</strong> Plan", {
                          planName: r,
                        })
                      : ""
                  ),
                [r, n]
              );
            return t.createElement(
              h.A,
              O(
                {
                  bodyText: M(),
                  ctaHref: "admin/billing",
                  preText: P(),
                },
                d
              )
            );
          }, "AutoChargeFeatureTrialsManageTrialWorkspaceMenuCta");
        _.displayName = "AutoChargeFeatureTrialsManageTrialWorkspaceMenuCta";
        const I = c((i) => {
          const o = (0, s.d4)(
            (l) =>
              (0, T._Z)(l, "paid_feature_trial_auto_charge_translation", !1) ===
              "on"
          );
          return t.createElement(
            _,
            O(
              {
                experimentPaidFeatureTrialAutoChargeTranslationGroupOn: o,
              },
              i
            )
          );
        }, "ConnectedAutoChargeFeatureTrialsManageTrialWorkspaceMenuCta");
        I.displayName =
          "ConnectedAutoChargeFeatureTrialsManageTrialWorkspaceMenuCta";
        const b = I;
      },
      858410167: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => b,
          });
        var t = e(5824283093),
          f = e(5255740490),
          p = e(6449156268),
          s = e(735940183),
          v = e(6323355797),
          g = e(8871937520),
          T = e(3699548628),
          h = e(1030162945),
          E = e(4698264567),
          O = e(4761125736),
          a = e(2562405183);
        function u() {
          return (
            (u =
              Object.assign ||
              function (i) {
                for (var o = 1; o < arguments.length; o++) {
                  var l = arguments[o];
                  for (var n in l)
                    Object.prototype.hasOwnProperty.call(l, n) && (i[n] = l[n]);
                }
                return i;
              }),
            u.apply(this, arguments)
          );
        }
        c(u, "_extends");
        const _ = new s.Ay("classic_nav"),
          I = c((i) => {
            let {
              discountExpirationTs: o,
              discountPercent: l,
              discountDuration: n,
              expirationTs: d,
              promoSubType: r,
              promoType: m,
              upgradeProductIds: M,
              ...P
            } = i;
            const D = d || o;
            let y;
            const K = (0, a.d4)((L) => (0, O._Z)(L, "pnp_discounts") === "on"),
              S = (0, t.useMemo)(() => (M == null ? void 0 : M[0]), [M]);
            switch (m) {
              case v.k2.TenuredTeam:
              case v.k2.WfhBundle:
              case v.k2.PartnerGrowth:
              case v.k2.Atlassian2020:
                y = _.t(
                  "Ready to upgrade Slack? Here's {discountOfferPercent}% off.",
                  {
                    discountOfferPercent: l,
                  }
                );
                break;
              case v.k2.SmartDiscount:
              case v.k2.PaidAcquisitionSelfServe:
              case v.k2.NewYearDiscountV2:
              case v.k2.MilestoneTenuredTeamPromo:
                y = _.t(
                  "Get {discountOfferPercent}% off a premium plan for your first {discountDuration, plural, =1 {month} other {# months}}.",
                  {
                    discountOfferPercent: l,
                    discountDuration: n,
                  }
                );
                break;
              case v.k2.Local:
                y = _.t(
                  "Get {localDiscountOfferPercent}% off a paid plan, for a limited time.",
                  {
                    localDiscountOfferPercent: l,
                  }
                );
                break;
              case v.k2.PricingAndPackagingPromo:
                r === v.g0.Discount75Pct3Months
                  ? (y = K
                      ? _.t(
                          "Get {discountOfferPercent}% off your first three months of Slack Pro.",
                          {
                            discountOfferPercent: l,
                          }
                        )
                      : "")
                  : r === v.g0.Discount25Pct3Months
                  ? (y = K
                      ? _.t(
                          "Get {discountOfferPercent}% off your first three months of Business+.",
                          {
                            discountOfferPercent: l,
                          }
                        )
                      : "")
                  : r === v.g0.Discount15Pct12Months
                  ? (y = K
                      ? _.t(
                          "Get {discountOfferPercent}% off your first year of Business+.",
                          {
                            discountOfferPercent: l,
                          }
                        )
                      : "")
                  : r === v.g0.Discount41Pct12Months ||
                    r === v.g0.Discount42Pct12Months
                  ? (y = K
                      ? _.t(
                          "Get Business+ and pay close to the price you pay for Pro for one year.",
                          {
                            discountOfferPercent: l,
                          }
                        )
                      : "")
                  : (y = "");
                break;
              default:
                y = n
                  ? _.t(
                      "Get {discountOfferPercent}% off a premium plan for your first {discountDuration, plural, =1 {month} other {# months}}.",
                      {
                        discountOfferPercent: l,
                        discountDuration: n,
                      }
                    )
                  : _.t(
                      "Get {discountOfferPercent}% off a paid plan, for a limited time.",
                      {
                        localDiscountOfferPercent: l,
                        discountOfferPercent: l,
                        fallbackHash:
                          "68241b44ccbc2200c451557d8ed295e49e5a3f68",
                      }
                    );
            }
            let k = null;
            if (D && m !== v.k2.PricingAndPackagingPromo) {
              const L = (0, p.A)(D * 1e3).format("YYYY-MM-DD"),
                ee = (0, g.qe)(L);
              k = _.rt(
                "{discountOfferNumDaysRemaining, plural, =1 {# day} other {# days}} left to get this offer",
                {
                  discountOfferNumDaysRemaining: ee,
                }
              );
            }
            const C = `team_menu_discount_promo_${m}`,
              Z = (0, v.hZ)({
                entryPoint: r ? `${C}_${r}` : C,
              }),
              Y = `team_plan_pricing_link_${m}`,
              $ = {
                elementName: r ? `${Y}_${r}` : Y,
                promoType: m,
                promoSubtype: r,
              },
              X = (0, f.A)(
                "p-discount_promo",
                `p-discount_promo--${m}`,
                `p-discount_promo--${m}${r ? `_${r}` : ""}`
              );
            let G = null;
            return (
              m !== v.k2.PricingAndPackagingPromo &&
                (G = t.createElement(
                  "div",
                  {
                    className: "p-discount_promo_offer_days_remaining",
                  },
                  t.createElement(h.Ay, {
                    text: "hourglass_flowing_sand",
                    emojiSize: h.lw.SMALL,
                  }),
                  k
                )),
              t.createElement(
                t.Fragment,
                null,
                t.createElement(
                  T.A,
                  u(
                    {
                      bodyText: y,
                      ctaText: K
                        ? _.t("Compare Plans")
                        : _.t("See plan details"),
                      ctaHref: Z,
                      preText: D ? G : null,
                      infoBlurbClasses: X,
                      autoClogProps: $,
                    },
                    P
                  )
                ),
                t.createElement(E.default, {
                  ctaLabel: _.t("Upgrade Now"),
                  productId: S,
                  action: v.um.CHECKOUT,
                })
              )
            );
          }, "DiscountPromo");
        I.displayName = "DiscountPromo";
        const b = I;
      },
      3699548628: (x, A, e) => {
        "use strict";
        e.d(A, {
          A: () => o,
        });
        var t = e(5824283093),
          f = e(9391594207),
          p = e(7715417323),
          s = e(5255740490),
          v = e(3677514771),
          g = e(6839188756),
          T = e(4481313819),
          h = e(1224315998),
          E = e(8245211418),
          O = e(6355911212);
        function a() {
          return (
            (a =
              Object.assign ||
              function (l) {
                for (var n = 1; n < arguments.length; n++) {
                  var d = arguments[n];
                  for (var r in d)
                    Object.prototype.hasOwnProperty.call(d, r) && (l[r] = d[r]);
                }
                return l;
              }),
            a.apply(this, arguments)
          );
        }
        c(a, "_extends");
        const u = {
            onClick: {
              elementType: h.ElementType.LINK,
              enableClogAction: !0,
            },
          },
          _ = "team_plan_pricing_link";
        let I = c(
          class extends t.PureComponent {
            renderCtaLink() {
              const { ctaText: n, highlighted: d, ctaHref: r } = this.props,
                m = (0, s.A)("p-info_blurb__link", {
                  "p-info_blurb__link--highlighted": d,
                });
              return t.createElement(
                t.Fragment,
                null,
                " ",
                t.createElement(
                  "span",
                  {
                    className: m,
                    "data-qa": "info_blurb_link",
                    "data-qa-href": r,
                  },
                  n
                )
              );
            }
            render() {
              const {
                  bodyText: n,
                  subText: d,
                  ctaText: r,
                  preText: m,
                  autoClogProps: M,
                  infoBlurbClasses: P,
                  omitCTA: D,
                  team: y,
                  onMouseEnter: K,
                  highlighted: S,
                  showHelpArticleFlexpane: k,
                  ctaArticleId: C,
                  ctaHref: Z,
                } = this.props,
                Y = (0, s.A)("p-info_blurb__container", P),
                $ = (0, s.A)("p-info_blurb", {
                  "p-info_blurb--clickable": !D,
                }),
                X = (0, s.A)("p-info_blurb__sub_text", {
                  "p-info_blurb__sub_text--highlighted": S,
                }),
                G = t.createElement(
                  "div",
                  {
                    className: $,
                    "data-qa": D && "team-messages-limit-meter",
                    onMouseEnter: K,
                  },
                  t.createElement(
                    "div",
                    {
                      className: Y,
                      "data-qa": "classic_nav__team_menu__plan_info",
                    },
                    n,
                    r && !D && this.renderCtaLink()
                  ),
                  d &&
                    t.createElement(
                      "p",
                      {
                        className: X,
                      },
                      d
                    )
                ),
                L = c((ee) => {
                  C
                    ? (ee.preventDefault(),
                      k({
                        articleId: C,
                      }))
                    : Z && (0, g.gC)(y, Z);
                }, "onClick");
              return t.createElement(
                T.A,
                a(
                  {
                    eventId: h.EventId.GROWTH_PRICING,
                    uiStep: h.UiStep.SLACK_MENU,
                    elementType: h.ElementType.LINK,
                    elementName: _,
                    clogImpression: !0,
                  },
                  M
                ),
                D
                  ? G
                  : t.createElement(
                      E.A,
                      a(
                        {
                          "data-qa": "team-messages-limit-meter",
                          onSelected: L,
                        },
                        this.props,
                        {
                          autoClogProps: u,
                        }
                      ),
                      m,
                      G
                    )
              );
            }
          },
          "InfoBlurb"
        );
        (I.displayName = "InfoBlurb"),
          (I.defaultProps = {
            omitCTA: !1,
            ctaText: "",
            ctaHref: "",
            onClick: p.A,
            autoClogProps: {},
            infoBlurbClasses: "",
            highlighted: !1,
            onMouseEnter: p.A,
          });
        const b = c(
            (l, n) => ({
              team: (0, v.H7)(l),
            }),
            "mapStateToProps"
          ),
          i = c(
            (l) => ({
              showHelpArticleFlexpane: function () {
                for (
                  var n = arguments.length, d = new Array(n), r = 0;
                  r < n;
                  r++
                )
                  d[r] = arguments[r];
                return l((0, O.a)(...d));
              },
            }),
            "mapDispatchToProps"
          ),
          o = (0, f.N)(b, i)(I);
      },
      8269938703: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseLimitedHistoryCountdown: () => n,
            default: () => r,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(5255740490),
          s = e(2562405183),
          v = e(6839188756),
          g = e(735940183),
          T = e(6323355797),
          h = e(2925999200),
          E = e(3677514771),
          O = e(1224315998),
          a = e(1030162945),
          u = e(8854221189),
          _ = e(8245211418),
          I = e(4481313819),
          b = e(1884211172);
        function i() {
          return (
            (i =
              Object.assign ||
              function (m) {
                for (var M = 1; M < arguments.length; M++) {
                  var P = arguments[M];
                  for (var D in P)
                    Object.prototype.hasOwnProperty.call(P, D) && (m[D] = P[D]);
                }
                return m;
              }),
            i.apply(this, arguments)
          );
        }
        c(i, "_extends");
        const o = new g.Ay("classic_nav"),
          l = 7,
          n = c((m) => {
            let {
              daysRemaining: M,
              isEligibleForMessageLimitTrial: P,
              omitCTA: D,
              onPlansLinkClick: y,
              onStartTrialLinkClick: K,
              ...S
            } = m;
            const k = P && M <= l,
              { highlighted: C, onMouseEnter: Z } = S,
              Y = (0, s.d4)(b.S),
              $ = c(
                () =>
                  t.createElement(
                    "div",
                    {
                      className: "display_flex",
                    },
                    t.createElement(a.Ay, {
                      text: "hourglass_flowing_sand",
                      emojiSize: a.lw.SMALL,
                    }),
                    t.createElement(
                      "strong",
                      {
                        className: "padding_left_25",
                        "data-qa": "limited_history_countdown_header",
                      },
                      Y
                        ? o.t(
                            "{daysRemaining, plural, =1 {# day} other {# days}} left to view your history",
                            {
                              daysRemaining: M,
                            }
                          )
                        : o.t(
                            "{daysRemaining, plural, =1 {# day} other {# days}} left to view full history",
                            {
                              daysRemaining: M,
                            }
                          )
                    )
                  ),
                "renderHeading"
              );
            $.displayName = "renderHeading";
            const X = (0, t.useCallback)(
                (F) => {
                  const z = (0, p.A)("p-limited_history_countdown__link", {
                    "p-limited_history_countdown__link--highlighted": C,
                  });
                  return t.createElement(
                    "span",
                    {
                      className: z,
                      "data-qa": "limited_history_countdown_link_text",
                    },
                    F
                  );
                },
                [C]
              ),
              G = (0, t.useMemo)(() => {
                const F = {
                    "<Link>": (fe) => {
                      let { text: Me } = fe;
                      return X(Me);
                    },
                    limitInDays: T.RF,
                  },
                  z = Y
                    ? o.rt(
                        "On the free version of Slack, messages and files older than {limitInDays} days will be hidden. To access your history, <Link>try Pro for free.</Link>",
                        F
                      )
                    : "",
                  oe = Y
                    ? o.rt(
                        "On the free version of Slack, messages and files older than {limitInDays} days will be hidden. To access your history, <Link>upgrade now.</Link>",
                        F
                      )
                    : "";
                return k ? z : oe;
              }, [Y, X, k]),
              L = c(() => {
                const F = o.t(
                    "On the free version of Slack, messages and files sent more than {limitInDays} days ago will be hidden.",
                    {
                      limitInDays: T.RF,
                    }
                  ),
                  z = D
                    ? F
                    : t.createElement(
                        t.Fragment,
                        null,
                        F,
                        " ",
                        X(k ? o.t("Start trial") : o.t("See upgrade options"))
                      );
                return t.createElement(
                  "div",
                  {
                    className: "p-limited_history_countdown__body",
                    "data-qa": "limited_history_countdown__body",
                  },
                  Y ? G : z
                );
              }, "renderBody");
            L.displayName = "renderBody";
            const ee = (0, p.A)("p-limited_history_countdown", {
                "p-limited_history_countdown--clickable": !D,
              }),
              te = t.createElement(
                "div",
                {
                  className: ee,
                  "data-qa": "limited_history_countdown_content",
                  onMouseEnter: Z,
                },
                $(),
                L()
              ),
              W = D
                ? te
                : t.createElement(
                    _.A,
                    i(
                      {
                        "data-qa": "limited_history_countdown_menu_item",
                        onSelected: k ? K : y,
                        autoClogProps: {
                          elementName: k ? "start_trial" : "pricing",
                          isPrimaryCTA: !0,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      },
                      S
                    ),
                    te
                  );
            return t.createElement(
              I.A,
              {
                eventId: O.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES,
                uiComponentName: O.UiComponentName.LIMITED_HISTORY_COUNTDOWN,
                clogImpression: !0,
              },
              W
            );
          }, "LimitedHistoryCountdown");
        n.displayName = "LimitedHistoryCountdown";
        const d = c((m) => {
          let { daysRemaining: M, ...P } = m;
          const D = (0, f.wA)(),
            y = (0, s.d4)(E.H7),
            K = (0, s.d4)(h.j),
            S = (0, t.useCallback)(() => {
              (0, v.gC)(
                y,
                (0, T.hZ)({
                  feature: T.c4.UNLIMITED_MESSAGES,
                })
              );
            }, [y]),
            k = (0, t.useCallback)(() => {
              D(
                (0, u.A)({
                  uiComponentVariant:
                    O.UiComponentVariant.LIMITED_HISTORY_COUNTDOWN,
                })
              );
            }, [D]);
          return !M || M <= 0
            ? null
            : t.createElement(
                n,
                i(
                  {
                    daysRemaining: M,
                    omitCTA: K,
                    onPlansLinkClick: S,
                    onStartTrialLinkClick: k,
                  },
                  P
                )
              );
        }, "ConnectedLimitedHistoryCountdown");
        d.displayName = "ConnectedLimitedHistoryCountdown";
        const r = d;
      },
      2249844134: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseLimitedHistoryCounter: () => n,
            default: () => r,
            test: () => m,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(5255740490),
          s = e(2562405183),
          v = e(6839188756),
          g = e(7239742441),
          T = e(735940183),
          h = e(6323355797),
          E = e(2925999200),
          O = e(3677514771),
          a = e(1224315998),
          u = e(8854221189),
          _ = e(8245211418),
          I = e(4481313819),
          b = e(1884211172);
        function i() {
          return (
            (i =
              Object.assign ||
              function (M) {
                for (var P = 1; P < arguments.length; P++) {
                  var D = arguments[P];
                  for (var y in D)
                    Object.prototype.hasOwnProperty.call(D, y) && (M[y] = D[y]);
                }
                return M;
              }),
            i.apply(this, arguments)
          );
        }
        c(i, "_extends");
        const o = new T.Ay("classic_nav"),
          l = 100,
          n = c((M) => {
            let {
              messageAndFileCount: P,
              omitCTA: D,
              isEligibleForMessageLimitTrial: y,
              onPlansLinkClick: K,
              onStartTrialLinkClick: S,
              ...k
            } = M;
            const { highlighted: C, onMouseEnter: Z } = k,
              Y = (0, s.d4)(b.S),
              $ = P >= l,
              X = c(() => {
                let z = $
                  ? o.t(
                      "{messageAndFileCount} messages and files are hidden.",
                      {
                        messageAndFileCount: (0, g.$k)(P, {
                          noSpAbbr: !0,
                        }),
                      }
                    )
                  : o.t(
                      "Messages and files sent more than {limitInDays} days ago are hidden.",
                      {
                        limitInDays: h.RF,
                      }
                    );
                return (
                  Y &&
                    (z = Y
                      ? o.t(
                          "On the free version of Slack, messages and files older than {limitInDays} days will be hidden.",
                          {
                            limitInDays: h.RF,
                          }
                        )
                      : ""),
                  t.createElement("strong", null, z)
                );
              }, "renderHeading");
            X.displayName = "renderHeading";
            const G = (0, t.useCallback)(
                (z) => {
                  const oe = (0, p.A)("p-limited_history_countdown__link", {
                    "p-limited_history_countdown__link--highlighted": C,
                  });
                  return t.createElement(
                    "span",
                    {
                      className: oe,
                      "data-qa": "limited_history_counter_link_text",
                    },
                    z
                  );
                },
                [C]
              ),
              L = (0, t.useMemo)(() => {
                const z = {
                    "<Link>": (Me) => {
                      let { text: Re } = Me;
                      return G(Re);
                    },
                    limitInDays: h.RF,
                  },
                  oe = Y
                    ? o.rt(
                        "To access your history, <Link>try Pro for free.</Link>",
                        z
                      )
                    : "",
                  fe = Y
                    ? o.rt(
                        "To access your history, <Link>upgrade now.</Link>",
                        z
                      )
                    : "";
                return y ? oe : fe;
              }, [Y, y, G]),
              ee = c(() => {
                let z = o.t("Get unlimited access to your full history.");
                $ &&
                  (z = y
                    ? o.t(
                        "Get access to messages and files sent more than {limitInDays} days ago.",
                        {
                          limitInDays: h.RF,
                        }
                      )
                    : o.t(
                        "Messages and files sent more than {limitInDays} days ago are available on paid plans.",
                        {
                          limitInDays: h.RF,
                        }
                      ));
                const oe = D
                  ? z
                  : t.createElement(
                      t.Fragment,
                      null,
                      z,
                      " ",
                      G(y ? o.t("Start trial") : o.t("See upgrade options"))
                    );
                return Y ? L : oe;
              }, "renderBody"),
              te = (0, p.A)("p-limited_history_countdown", {
                "p-limited_history_countdown--clickable": !D,
              }),
              W = t.createElement(
                "div",
                {
                  className: te,
                  "data-qa": "limited_history_counter_content",
                  onMouseEnter: Z,
                },
                X(),
                " ",
                ee()
              ),
              F = D
                ? W
                : t.createElement(
                    _.A,
                    i(
                      {
                        "data-qa": "limited_history_counter_menu_item",
                        onSelected: y ? S : K,
                        autoClogProps: {
                          elementName: y ? "start_trial" : "pricing",
                          isPrimaryCTA: !0,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      },
                      k
                    ),
                    W
                  );
            return t.createElement(
              I.A,
              {
                eventId: a.EventId.UPGRDEXP_HIGHLIGHT_PAID_FEATURES,
                uiComponentName: a.UiComponentName.LIMITED_HISTORY_COUNTER,
                clogImpression: !0,
              },
              F
            );
          }, "LimitedHistoryCounter");
        n.displayName = "LimitedHistoryCounter";
        const d = c((M) => {
          const P = (0, f.wA)(),
            D = (0, s.d4)(O.H7),
            y = (0, s.d4)(E.j),
            K = (0, t.useCallback)(() => {
              (0, v.gC)(
                D,
                (0, h.hZ)({
                  feature: h.c4.UNLIMITED_MESSAGES,
                })
              );
            }, [D]),
            S = (0, t.useCallback)(() => {
              P(
                (0, u.A)({
                  uiComponentVariant:
                    a.UiComponentVariant.LIMITED_HISTORY_COUNTER,
                })
              );
            }, [P]);
          return t.createElement(
            n,
            i(
              {
                omitCTA: y,
                onPlansLinkClick: K,
                onStartTrialLinkClick: S,
              },
              M
            )
          );
        }, "ConnectedLimitedHistoryCounter");
        d.displayName = "ConnectedLimitedHistoryCounter";
        const r = d,
          m = {
            MIN_NUMBER_MSGS_FILES_TO_DISPLAY_AMOUNT: l,
          };
      },
      381260222: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BasePlanInfo: () => b,
            default: () => o,
            test: () => l,
          });
        var t = e(5824283093),
          f = e(9391594207),
          p = e(735940183),
          s = e(6839188756),
          v = e(3745851802),
          g = e(3677514771),
          T = e(6323355797),
          h = e(3699548628),
          E = e(2925999200);
        function O() {
          return (
            (O =
              Object.assign ||
              function (n) {
                for (var d = 1; d < arguments.length; d++) {
                  var r = arguments[d];
                  for (var m in r)
                    Object.prototype.hasOwnProperty.call(r, m) && (n[m] = r[m]);
                }
                return n;
              }),
            O.apply(this, arguments)
          );
        }
        c(O, "_extends");
        const a = new p.Ay("classic_nav"),
          u = "team_plan_pricing_link",
          _ = "team_menu_plan_info",
          I = {
            FREE: "free",
            STANDARD: "standard",
            PLUS: "plus",
            ENTERPRISE: "enterprise",
            COMPLIANCE: "compliance",
          };
        let b = c(
          class extends t.PureComponent {
            getPlanInfo() {
              const { team: d, orgName: r } = this.props;
              let m,
                M = a.t("Learn more"),
                P,
                D;
              return (
                (0, s.tc)(d)
                  ? ((m = a.t(
                      "Your workspace is currently on the free version of Slack."
                    )),
                    (M = a.t("See upgrade options")),
                    (P = (0, T.hZ)({
                      entryPoint: _,
                    })),
                    (D = I.FREE))
                  : (0, s.KJ)(d)
                  ? ((m = a.rt(
                      "Your workspace is currently on Slack\u2019s <strong>Pro Plan</strong>."
                    )),
                    (P = (0, T.hZ)({
                      planLevel: T.i6.standard.id,
                      entryPoint: _,
                    })),
                    (D = I.STANDARD))
                  : (0, s.NB)(d)
                  ? ((m = a.rt(
                      "Your workspace is currently on Slack\u2019s <strong>Business+ Plan</strong>."
                    )),
                    (P = (0, T.hZ)({
                      planLevel: T.i6.plus.id,
                      entryPoint: _,
                    })),
                    (D = I.PLUS))
                  : (0, s.r7)(d)
                  ? ((m = a.rt(
                      "This workspace is part of the <strong>{orgName}</strong> organization.",
                      {
                        orgName: r,
                      }
                    )),
                    (P = "account/workspace-settings"),
                    (D = I.ENTERPRISE))
                  : (0, s.Ah)(d) &&
                    ((m = a.rt(
                      "Your workspace is currently on Slack\u2019s <strong>Enterprise Select Plan</strong>."
                    )),
                    (M = ""),
                    (D = I.COMPLIANCE)),
                {
                  bodyText: m,
                  ctaText: M,
                  ctaHref: P,
                  stepVariant: D,
                }
              );
            }
            render() {
              const {
                bodyText: d,
                ctaText: r,
                ctaHref: m,
                stepVariant: M,
              } = this.getPlanInfo();
              return d
                ? t.createElement(
                    h.A,
                    O(
                      {
                        bodyText: d,
                        ctaText: r,
                        ctaHref: m,
                        autoClogProps: {
                          stepVariant: M,
                          elementName: u,
                        },
                      },
                      this.props
                    )
                  )
                : null;
            }
          },
          "PlanInfo"
        );
        b.displayName = "PlanInfo";
        const i = c((n) => {
            const d = (0, g.H7)(n),
              r = (0, g.lp)(n),
              m = (0, v.v4)(r) || (d == null ? void 0 : d.enterprise_name);
            return {
              team: d,
              orgName: m,
              omitCTA: (0, s._s)(d) || (0, E.j)(n) || (0, s.Ah)(d),
            };
          }, "mapStateToProps"),
          o = (0, f.N)(i)(b),
          l = {
            CLOG_ENTRY_POINT: _,
          };
      },
      6768452643: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => u,
          });
        var t = e(5824283093),
          f = e(735940183),
          p = e(7094978947),
          s = e(3801841745),
          v = e(3699548628),
          g = e(8871937520),
          T = e(1224315998);
        function h() {
          return (
            (h =
              Object.assign ||
              function (_) {
                for (var I = 1; I < arguments.length; I++) {
                  var b = arguments[I];
                  for (var i in b)
                    Object.prototype.hasOwnProperty.call(b, i) && (_[i] = b[i]);
                }
                return _;
              }),
            h.apply(this, arguments)
          );
        }
        c(h, "_extends");
        const E = new f.Ay("promotions"),
          O = {
            elementName:
              "slack_ai_auto_charge_manage_trial_workspace_menu_button",
            clogImpression: !0,
            onClick: {
              enableClogAction: !0,
            },
            displayName: T.UiPropertiesDisplayName.SLACK_AI_AUTO_CHARGE_TRIAL,
          },
          a = c((_) => {
            const { trialEndDate: I, highlighted: b } = _,
              i = (0, g.Pd)(I, !1),
              o = "admin/billing",
              l = t.createElement(
                s.A,
                {
                  gap: 12,
                },
                t.createElement(
                  "span",
                  null,
                  t.createElement(p.o, {
                    inline: !0,
                    variation: b ? "filled" : void 0,
                  })
                ),
                t.createElement("span", null, E.t("Manage your Slack AI trial"))
              ),
              n = E.rt(
                "Slack AI will be added to your bill at the end of your trial on <strong>{formattedTrialEndDate}</strong>.",
                {
                  formattedTrialEndDate: i,
                }
              );
            return t.createElement(
              v.A,
              h(
                {
                  bodyText: n,
                  preText: l,
                  ctaHref: o,
                  autoClogProps: O,
                },
                _
              )
            );
          }, "SlackAiManageTrialWorkspaceMenuCta");
        a.displayName = "SlackAiManageTrialWorkspaceMenuCta";
        const u = a;
      },
      7956527390: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseSlackAiTrialOfferWorkspaceMenuCta: () => i,
            ConnectedSlackAiTrialOfferWorkspaceMenuCta: () => o,
          });
        var t = e(5824283093),
          f = e(735940183),
          p = e(3514831633),
          s = e(6122756707),
          v = e(2562405183),
          g = e(7878745420),
          T = e(7094978947),
          h = e(3801841745),
          E = e(9676597566),
          O = e(3141349242),
          a = e(7115655993);
        function u() {
          return (
            (u =
              Object.assign ||
              function (l) {
                for (var n = 1; n < arguments.length; n++) {
                  var d = arguments[n];
                  for (var r in d)
                    Object.prototype.hasOwnProperty.call(d, r) && (l[r] = d[r]);
                }
                return l;
              }),
            u.apply(this, arguments)
          );
        }
        c(u, "_extends");
        const _ = g.g.SLACK_AI_TRIAL_OFFER_WORKSPACE_MENU_CTA,
          I = new f.Ay("promotions"),
          b = {
            elementName: "slack_ai_trial_offer_workspace_menu_button",
            clogImpression: !0,
            onClick: {
              enableClogAction: !0,
            },
          },
          i = c((l) => {
            const n = (0, s.wA)(),
              {
                offerInfo: d,
                trialInfo: r,
                highlighted: m,
                notificationName: M,
              } = l;
            (0, a.A)(() => {
              n((0, O.Md)());
            });
            const P = (0, t.useCallback)(() => {
                n(
                  (0, E.G)({
                    offerInfo: d,
                    trialInfo: r,
                    notificationName: M,
                  })
                );
              }, [n, d, r, M]),
              D = (0, v.d4)(O.Gj);
            return t.createElement(
              p.Dr,
              u({}, l, {
                onSelected: P,
                autoClogProps: {
                  displayName: D,
                  ...b,
                },
              }),
              t.createElement(
                h.A,
                {
                  gap: 12,
                },
                t.createElement(
                  "span",
                  null,
                  t.createElement(T.o, {
                    inline: !0,
                    variation: m ? "filled" : void 0,
                  })
                ),
                I.t("Try Slack AI for free")
              )
            );
          }, "SlackAiTrialOfferWorkspaceMenuCta");
        i.displayName = "SlackAiTrialOfferWorkspaceMenuCta";
        const o = c(
          (l) => t.createElement(i, u({}, l)),
          "ConnectedSlackAiTrialOfferWorkspaceMenuCta"
        );
        o.displayName = "ConnectedSlackAiTrialOfferWorkspaceMenuCta";
      },
      9590263900: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseSlackAiWorkspaceMenuCta: () => _,
            default: () => b,
          });
        var t = e(5824283093),
          f = e(735940183),
          p = e(6038992701),
          s = e(3514831633),
          v = e(2375333597),
          g = e(6122756707),
          T = e(7094978947),
          h = e(3801841745);
        function E() {
          return (
            (E =
              Object.assign ||
              function (i) {
                for (var o = 1; o < arguments.length; o++) {
                  var l = arguments[o];
                  for (var n in l)
                    Object.prototype.hasOwnProperty.call(l, n) && (i[n] = l[n]);
                }
                return i;
              }),
            E.apply(this, arguments)
          );
        }
        c(E, "_extends");
        const O = new f.Ay("promotions"),
          a = "slack_ai_workspace_menu",
          u = {
            elementName: "slack_ai_workspace_menu_button",
            clogImpression: !0,
            onClick: {
              enableClogAction: !0,
            },
          },
          _ = c((i) => {
            const o = (0, g.wA)(),
              {
                bauCount: l,
                availableAddonUpfrontUnitCost: n,
                availableAddonTerm: d,
                availableAddonCurrency: r,
                availableAddonId: m,
                canUserPurchase: M,
              } = i,
              P = (0, t.useCallback)(() => {
                o(
                  (0, v.q)({
                    element: t.createElement(p.P, {
                      activeMembersCount: l,
                      availableAddonUpfrontUnitCost: n,
                      availableAddonTerm: d,
                      currency: r,
                      checkoutEntryPoint: a,
                      addonId: m,
                      canUserPurchase: M,
                    }),
                  })
                );
              }, [o, l, r, n, d, m, M]);
            return t.createElement(
              s.Dr,
              E({}, i, {
                onSelected: P,
                autoClogProps: u,
              }),
              t.createElement(
                h.A,
                {
                  gap: 12,
                },
                t.createElement(
                  "span",
                  null,
                  t.createElement(T.o, {
                    inline: !0,
                    variation: i.highlighted ? "filled" : void 0,
                  })
                ),
                O.t("Get Slack AI")
              )
            );
          }, "SlackAiWorkspaceMenuCta");
        _.displayName = "SlackAiWorkspaceMenuCta";
        const I = c(
          (i) => t.createElement(_, E({}, i)),
          "ConnectedSlackAiWorkspaceMenuCta"
        );
        I.displayName = "ConnectedSlackAiWorkspaceMenuCta";
        const b = I;
      },
      1017327448: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseStraightToPaidWorkspaceMenuPrimaryTimeLimit: () => _,
            default: () => b,
          });
        var t = e(5824283093),
          f = e(7878745420),
          p = e(735940183),
          s = e(6323355797),
          v = e(3699548628),
          g = e(1030162945),
          T = e(3749988767),
          h = e(3405119017);
        function E() {
          return (
            (E =
              Object.assign ||
              function (i) {
                for (var o = 1; o < arguments.length; o++) {
                  var l = arguments[o];
                  for (var n in l)
                    Object.prototype.hasOwnProperty.call(l, n) && (i[n] = l[n]);
                }
                return i;
              }),
            E.apply(this, arguments)
          );
        }
        c(E, "_extends");
        const O = f.g.STRAIGHT_TO_PAID_WORKSPACE_MENU_PRIMARY_TIME_LIMIT,
          a = "straight_to_paid_workspace_menu_primary",
          u = new p.Ay("setup_straight_to_paid"),
          _ = c((i) => {
            const { discountPercent: o, discountExpirationTs: l = 0 } = i,
              n = (0, T.Q)(l),
              d = (0, s.hZ)({
                entryPoint: a,
              }),
              r = (0, t.useCallback)(
                () =>
                  t.createElement(
                    t.Fragment,
                    null,
                    t.createElement(
                      "div",
                      {
                        className:
                          "p-straight_to_paid_workspace_menu_primary_time_limit__countdown",
                      },
                      t.createElement(
                        "span",
                        {
                          className:
                            "p-straight_to_paid_workspace_menu_primary_time_limit__timer",
                        },
                        t.createElement(g.Ay, {
                          text: "hourglass_flowing_sand",
                          emojiSize: g.lw.SMALL,
                        })
                      ),
                      typeof n == "number" &&
                        u.t(
                          "{daysRemaining, plural, =1 {# day} other {# days}} left on your Pro Offer",
                          {
                            daysRemaining: n,
                          }
                        )
                    ),
                    u.t(
                      "Get {discountPercent}% off Slack Pro on your first 3 months.",
                      {
                        discountPercent: o,
                      }
                    )
                  ),
                [n, o]
              );
            return t.createElement(
              v.A,
              E(
                {
                  bodyText: r(),
                  infoBlurbClasses:
                    "p-straight_to_paid_workspace_menu_primary_time_limit",
                  ctaText: u.t("See plan details"),
                  ctaHref: d,
                  autoClogProps: h.Ez,
                },
                i
              )
            );
          }, "StraightToPaidWorkspaceMenuPrimaryTimeLimit");
        _.displayName = "StraightToPaidWorkspaceMenuPrimaryTimeLimit";
        const I = c(
          (i) => t.createElement(_, E({}, i)),
          "ConnectedStraightToPaidWorkspaceMenuPrimaryTimeLimit"
        );
        I.displayName = "ConnectedStraightToPaidWorkspaceMenuPrimaryTimeLimit";
        const b = I;
      },
      6077046070: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseStraightToPaidWorkspaceMenuSecondaryUpgradeCta: () => i,
            default: () => l,
          });
        var t = e(5824283093),
          f = e(7878745420),
          p = e(735940183),
          s = e(6323355797),
          v = e(6839188756),
          g = e(2562405183),
          T = e(3677514771),
          h = e(8683010724),
          E = e(6084388622),
          O = e(3514831633),
          a = e(3405119017);
        function u() {
          return (
            (u =
              Object.assign ||
              function (n) {
                for (var d = 1; d < arguments.length; d++) {
                  var r = arguments[d];
                  for (var m in r)
                    Object.prototype.hasOwnProperty.call(r, m) && (n[m] = r[m]);
                }
                return n;
              }),
            u.apply(this, arguments)
          );
        }
        c(u, "_extends");
        const _ = new p.Ay("setup_straight_to_paid"),
          I = "straight_to_paid_workspace_menu_secondary",
          b = f.g.STRAIGHT_TO_PAID_WORKSPACE_MENU_SECONDARY_UPGRADE_CTA,
          i = c((n) => {
            const { team: d } = n,
              r = (0, t.useCallback)(() => {
                const m = (0, s.Qn)({
                  team: d,
                  entryPoint: I,
                  productLevel: s.i6.standard.id,
                  excludeDomain: !0,
                });
                d && (0, v.gC)(d, m, "_self");
              }, [d]);
            return t.createElement(
              "div",
              {
                className:
                  "p-straight_to_paid_workspace_menu_secondary_upgrade_cta",
              },
              t.createElement(
                O.Dr,
                u({}, n, {
                  onSelected: r,
                  className:
                    "p-straight_to_paid_workspace_menu_secondary_upgrade_cta__upgrade-menu-button",
                  autoClogProps: a.MT,
                }),
                t.createElement(
                  E.Ay,
                  {
                    className:
                      "p-straight_to_paid_workspace_menu_secondary_upgrade_cta__upgrade-button",
                    type: "outline",
                    size: "small",
                    onClick: r,
                    autoClogProps: a.Mm,
                  },
                  t.createElement(
                    "span",
                    {
                      className:
                        "p-straight_to_paid_workspace_menu_secondary_upgrade_cta__rocket-icon",
                    },
                    t.createElement(h.A, {
                      name: "rocket",
                    })
                  ),
                  _.t("Upgrade Plan")
                )
              )
            );
          }, "StraightToPaidWorkspaceMenuSecondaryUpgradeCta");
        i.displayName = "StraightToPaidWorkspaceMenuSecondaryUpgradeCta";
        const o = c((n) => {
          const d = (0, g.d4)(T.H7);
          return t.createElement(
            i,
            u({}, n, {
              team: d,
            })
          );
        }, "ConnectedStraightToPaidWorkspaceMenuSecondaryUpgradeCta");
        o.displayName =
          "ConnectedStraightToPaidWorkspaceMenuSecondaryUpgradeCta";
        const l = o;
      },
      3854710577: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            BaseTrialInfo: () => I,
            default: () => i,
          });
        var t = e(5824283093),
          f = e(4418517660),
          p = e.n(f),
          s = e(9391594207),
          v = e(735940183),
          g = e(9160454416),
          T = e(6323355797),
          h = e(2925999200),
          E = e(7268021173),
          O = e(3699548628);
        function a() {
          return (
            (a =
              Object.assign ||
              function (o) {
                for (var l = 1; l < arguments.length; l++) {
                  var n = arguments[l];
                  for (var d in n)
                    Object.prototype.hasOwnProperty.call(n, d) && (o[d] = n[d]);
                }
                return o;
              }),
            a.apply(this, arguments)
          );
        }
        c(a, "_extends");
        const u = new v.Ay("classic_nav"),
          _ = "team_plan_pricing_link_trial";
        let I = c(
          class extends t.PureComponent {
            render() {
              const {
                trialExpirationDate: l,
                trialPlanLevel: n,
                nextProductLevel: d,
              } = this.props;
              let r, m, M;
              if (d) {
                const D = p()(l),
                  y = (0, g.A)(D, {
                    shortenDay: !0,
                    excludeYear: !0,
                  });
                (r = u.t("Learn more")),
                  (m = (0, T.hZ)({
                    planLevel: d,
                    entryPoint: "team_menu_trial_info",
                  })),
                  (M =
                    d === T.i6.standard.id
                      ? u.rt(
                          "Your team is scheduled to be upgraded to <strong>Pro</strong> once your trial ends on {trialExpirationDate}.",
                          {
                            trialExpirationDate: y,
                          }
                        )
                      : u.rt(
                          "Your team is scheduled to be upgraded to <strong>Business+</strong> once your trial ends on {trialExpirationDate}.",
                          {
                            trialExpirationDate: y,
                          }
                        ));
              } else {
                const D = p()(l).subtract(1, "day"),
                  y = (0, g.A)(D, {
                    shortenDay: !0,
                    excludeYear: !0,
                  });
                (r = u.t("See upgrade options")),
                  (m = (0, T.hZ)({
                    entryPoint: "team_menu_trial_info",
                  })),
                  (M =
                    n === T.i6.standard.id
                      ? u.rt(
                          "Your <strong>Pro trial</strong> lasts through {trialExpiryDate}.",
                          {
                            trialExpiryDate: y,
                          }
                        )
                      : u.rt(
                          "Your <strong>Business+ trial</strong> lasts through {trialExpiryDate}.",
                          {
                            trialExpiryDate: y,
                          }
                        ));
              }
              const P = `${n === T.i6.standard.id ? "standard" : "plus"}_trial`;
              return t.createElement(
                O.A,
                a(
                  {
                    infoBlurbClasses: "p-trial_info",
                    bodyText: M,
                    ctaText: r,
                    ctaHref: m,
                    autoClogProps: {
                      stepVariant: P,
                      elementName: _,
                    },
                  },
                  this.props
                )
              );
            }
          },
          "TrialInfo"
        );
        I.displayName = "TrialInfo";
        const b = c(
            (o) => ({
              nextProductLevel: (0, E.wM)(o),
              omitCTA: (0, h.j)(o),
            }),
            "mapStateToProps"
          ),
          i = (0, s.N)(b)(I);
      },
      2925999200: (x, A, e) => {
        "use strict";
        e.d(A, {
          j: () => t,
        });
        const t = c((f) => !1, "shouldOmitPrimaryCTA");
      },
      535424668: (x, A, e) => {
        "use strict";
        e.d(A, {
          n: () => O,
        });
        var t = e(9706240641),
          f = e.n(t),
          p = e(1031947056),
          s = e(9785228405),
          v = e(5201749224),
          g = e(8438703627);
        const T = (function () {
            var a = (0, t.coroutine)(function* (u, _) {
              const I = (function () {
                  var i = (0, t.coroutine)(function* (o) {
                    const {
                        app_id: l,
                        provider_key: n,
                        salesforce_org_id: d,
                      } = o,
                      r = yield u(
                        (0, v.d)({
                          appId: l,
                          providerKey: n,
                          salesforceOrgId: d,
                          reason: "salesforce-connections-silent-sign-in",
                        })
                      ),
                      m = r.ok && !r.authorization_url ? "ok" : "none";
                    return Promise.resolve({
                      salesforceOrgId: d,
                      auth: m,
                    });
                  });
                  return c(function (l) {
                    return i.apply(this, arguments);
                  }, "attemptToSignIntoSeamlessOrg");
                })(),
                b = _.map(I);
              return Promise.all(b);
            });
            return c(function (_, I) {
              return a.apply(this, arguments);
            }, "trySigningIntoSeamlessAuthOrgsSilently");
          })(),
          h = (function () {
            var a = (0, t.coroutine)(function* (u) {
              const _ = yield u((0, g.l)()),
                I = (0, s.N)(_);
              if (I.length === 0) return _;
              const b = yield T(u, I);
              return _.map((o) => {
                const l = b.find((n) => {
                  let { salesforceOrgId: d } = n;
                  return d === o.salesforce_org_id;
                });
                return l
                  ? {
                      ...o,
                      auth: l.auth,
                    }
                  : o;
              });
            });
            return c(function (_) {
              return a.apply(this, arguments);
            }, "fetchOrgsAndSignInSilentlyHandler");
          })();
        let E = null;
        const O = (0, p.Ay)(
          "Fetches a list of Salesforce organizations from sfdc.integration.listOrgs and tries to sing in user into those with auth=none",
          (a) => (
            E === null && (E = h(a)),
            E.finally(() => {
              E = null;
            })
          )
        );
        O.meta = {
          name: "createThunk",
          key: "createThunkfetchOrgsAndSignInSilently",
          description:
            "Fetches a list of Salesforce organizations from sfdc.integration.listOrgs and tries to sing in user into those with auth=none",
        };
      },
      2140279507: (x, A, e) => {
        "use strict";
        e.d(A, {
          FK: () => v,
          QJ: () => T,
          gV: () => E,
        });
        var t = e(8161242485),
          f = e(1031947056),
          p = e(6209625934),
          s = e(4761125736);
        const v = (0, t.Ay)((u) => (0, s._Z)(u, "first_login_loader_copy", !1));
        v.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyGetAssignment",
          description: (u) => (0, s._Z)(u, "first_login_loader_copy", !1),
        };
        const g = (0, t.Ay)(
          (u) => (0, s._Z)(u, "first_login_loader_copy", !1) === "control"
        );
        g.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsControl",
          description: (u) =>
            (0, s._Z)(u, "first_login_loader_copy", !1) === "control",
        };
        const T = (0, t.Ay)(
          (u) => (0, s._Z)(u, "first_login_loader_copy", !1) === "treatment"
        );
        T.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsTreatment",
          description: (u) =>
            (0, s._Z)(u, "first_login_loader_copy", !1) === "treatment",
        };
        const h = (0, t.Ay)((u) => {
          var _;
          return ["treatment"].includes(
            (_ = (0, s._Z)(u, "first_login_loader_copy", !1)) !== null &&
              _ !== void 0
              ? _
              : ""
          );
        });
        h.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsAnyTreatment",
          description: (u) => {
            var _;
            return ["treatment"].includes(
              (_ = (0, s._Z)(u, "first_login_loader_copy", !1)) !== null &&
                _ !== void 0
                ? _
                : ""
            );
          },
        };
        const E = (0, t.Ay)((u) => g(u) || h(u));
        E.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginLoaderCopyIsExposed",
          description: (u) => g(u) || h(u),
        };
        const O = c((u) => {
            const _ = (0, s.KK)(u, "first_login_loader_copy");
            _ && _.log_exposures && (0, p.K)("first_login_loader_copy", _, u);
          }, "firstLoginLoaderCopyLogExposure"),
          a = (0, f.Ay)(
            "Log exposure for the first_login_loader_copy experiment if it is exposed",
            (u, _) => {
              E(_()) && O(_());
            }
          );
        a.meta = {
          name: "createThunk",
          key: "createThunkfirstLoginLoaderCopyMaybeLogExposure",
          description:
            "Log exposure for the first_login_loader_copy experiment if it is exposed",
        };
      },
      789780423: (x, A, e) => {
        "use strict";
        e.d(A, {
          A: () => ee,
        });
        var t = e(5824283093),
          f = e(3686168196);
        const p = c(
          () =>
            t.createElement("div", {
              className: "p-browse_sidebar__divider",
            }),
          "BrowseSidebarDivider"
        );
        p.displayName = "BrowseSidebarDivider";
        const s = p;
        var v = e(5255740490),
          g = e(8710426075),
          T = e(4630993086),
          h = e(8011352381),
          E = e(8483873810),
          O = e(5760358277),
          a = e(8646446995),
          u = e(5812641038),
          _ = e(6105929840),
          I = e(8739505998),
          b = e(7026348746),
          i = e(8683010724),
          o = e(2312625946),
          l = e(2445586591),
          n = e(735940183),
          d = e(2562405183),
          r = e(3875705815);
        const m = new n.Ay("search"),
          M = c((te) => {
            let {
              label: W,
              description: F,
              type: z = g.R.OTHER,
              ariaLabel: oe,
              isSelected: fe = !1,
              isDisabled: Me = !1,
              iconName: Re = "home",
              secondaryIconName: Ye,
              calloutLabel: Se,
              showIcon: he = !0,
              showNotification: se,
              autoClogProps: H,
              hasUnreads: Q,
              toolTip: re,
              onDismiss: J,
            } = te;
            const Fe = (0, t.useContext)(E.o),
              We = (0, t.useContext)(T.M),
              Be = (0, d.d4)(l.O),
              Ze = (0, d.d4)(r.V),
              Ge = fe && !Ze,
              V = (0, t.useCallback)(
                (Ee) => {
                  J == null || J(Ee, fe);
                },
                [fe, J]
              ),
              ae = (0, t.useCallback)((Ee) => Ee.stopPropagation(), []);
            switch (z) {
              case g.R.LIST_SMALL:
                return t.createElement(
                  "div",
                  {
                    className: (0, v.A)(
                      "p-browse_sidebar__item",
                      "p-more_files_sidebar__item",
                      {
                        "p-browse_sidebar__item--selected": Ge,
                        "p-more_files_sidebar__item--disable_selection":
                          We.disableSelection,
                      }
                    ),
                  },
                  t.createElement(a.A, {
                    id: typeof W == "string" ? W : "",
                    shouldShowDetailText: !1,
                    shouldShowHighlight: !1,
                    fontWeight: se ? O.I.BLACK : O.I.NORMAL,
                    useLeadingEmojiAsIcon: We.shouldUseLeadingEmojiForIcon,
                    useMissingIconIfFileUnknown: !0,
                  })
                );
              case g.R.CANVAS_SMALL:
                return t.createElement(
                  "div",
                  {
                    className: (0, v.A)(
                      "p-browse_sidebar__item",
                      "p-more_files_sidebar__item",
                      {
                        "p-browse_sidebar__item--selected": Ge,
                        "p-more_files_sidebar__item--disable_selection":
                          Fe.disableSelection,
                      }
                    ),
                  },
                  t.createElement(a.A, {
                    id: typeof W == "string" ? W : "",
                    shouldShowDetailText: !1,
                    shouldShowHighlight: !1,
                    fontWeight: se ? O.I.BLACK : O.I.NORMAL,
                    useLeadingEmojiAsIcon: Fe.shouldUseLeadingEmojiForIcon,
                    shouldCheckForTemporaryFiles: Be,
                    useMissingIconIfFileUnknown: !0,
                    useLiveTitleForChannelCanvas: !0,
                  }),
                  !!J &&
                    Be &&
                    t.createElement(
                      "div",
                      {
                        className: "p-browse_sidebar__item_close_container",
                      },
                      t.createElement(
                        _.A,
                        {
                          "aria-label": Be
                            ? m.t("Remove from recent viewed list")
                            : "",
                          onMouseDown: ae,
                          onClick: V,
                          size: "x-small",
                          className: "p-browse_sidebar__item_close_button",
                        },
                        t.createElement(i.A, {
                          name: "close",
                          size: "16",
                        })
                      )
                    )
                );
              case g.R.SALES_LIST_SMALL:
                return t.createElement(
                  o.Ay,
                  {
                    tip: re,
                    delay: o.PK,
                  },
                  t.createElement(
                    I.A,
                    {
                      className: (0, v.A)("p-browse_sidebar__item"),
                      tabIndex: -1,
                      "aria-label": oe || W,
                      autoClogProps: H,
                    },
                    t.createElement(
                      h.A,
                      {
                        lines: 1,
                      },
                      t.createElement(
                        "span",
                        {
                          className: "p-browse_all_sidebar__label",
                        },
                        W
                      )
                    )
                  )
                );
              case g.R.EMPTY_STATE:
                return t.createElement(u.A, {
                  title: W,
                  description: F,
                  isExtended: !0,
                  className:
                    "padding_left_75 padding_right_50 margin_0 align_left padding_top_0",
                });
              case g.R.SHIMMER:
                return t.createElement(
                  "div",
                  {
                    className: (0, v.A)(
                      "p-browse_sidebar__item",
                      "p-more_files_sidebar__item",
                      "p-more_files_sidebar__item--shimmer"
                    ),
                  },
                  he &&
                    t.createElement(
                      "span",
                      {
                        className: "c-file_entity__icon",
                      },
                      t.createElement(i.A, {
                        name: Re,
                      })
                    ),
                  t.createElement(b.A, {
                    size: "random",
                  })
                );
              case g.R.OTHER:
                return t.createElement(
                  I.A,
                  {
                    className: (0, v.A)("p-browse_sidebar__item", {
                      "p-browse_sidebar__item--selected": Ge,
                      "p-browse_sidebar__item--hasUnreads": Q,
                    }),
                    disabled: Me,
                    tabIndex: -1,
                    "aria-label": oe || W,
                    autoClogProps: H,
                  },
                  he &&
                    t.createElement(
                      "span",
                      {
                        className: "p-browse_all_sidebar__icon",
                      },
                      t.createElement(i.A, {
                        name: Re,
                        inline: !0,
                        size: "18",
                      })
                    ),
                  t.createElement(
                    h.A,
                    {
                      lines: 1,
                    },
                    t.createElement(
                      "span",
                      {
                        className: "p-browse_all_sidebar__label",
                      },
                      W
                    )
                  ),
                  Ye &&
                    t.createElement(
                      "span",
                      {
                        className: "p-browse_all_sidebar__secondary_icon",
                      },
                      t.createElement(i.A, {
                        name: Ye,
                        inline: !0,
                        size: "18",
                      })
                    ),
                  Se &&
                    t.createElement(
                      "span",
                      {
                        className: "p-browse_all_sidebar__callout",
                      },
                      Se
                    )
                );
              default:
                return t.createElement(t.Fragment, null);
            }
          }, "BrowseSidebarItem");
        M.displayName = "BrowseSidebarItem";
        const P = M,
          D = c(
            () =>
              t.createElement("div", {
                className: "p-browse_sidebar__spacer",
              }),
            "BrowseSidebarSpacer"
          );
        D.displayName = "BrowseSidebarSpacer";
        const K = c((te) => {
          let { title: W } = te;
          return t.createElement(
            "div",
            {
              className: "p-browse_sidebar__sub_header",
            },
            t.createElement(
              "div",
              {
                className: "display_flex align_items_center",
              },
              t.createElement("div", null, W)
            )
          );
        }, "BrowseSidebarSubHeader");
        var S = e(352142497),
          k = e(5519146941),
          C = e(1149563359),
          Z = e(9163492386),
          Y = e(5103024697),
          $ = e(3193155968);
        const X = c((te) => {
          let { rows: W, renderContextMenuForItem: F } = te;
          const z = (0, t.useMemo)(
              () =>
                W.filter((V) => {
                  let { visible: ae } = V;
                  return ae !== !1;
                }),
              [W]
            ),
            oe = (0, t.useMemo)(() => z.map((V) => V.id), [z]),
            { getSiblingView: fe, view: Me } = (0, t.useContext)(k.A),
            Re = (0, d.d4)(
              (0, t.useCallback)(
                (V) => {
                  var ae;
                  return (ae = fe(V, {
                    container: $.mq.Primary,
                  })) === null || ae === void 0
                    ? void 0
                    : ae.viewType;
                },
                [fe]
              )
            ),
            Ye = (0, d.d4)(
              (0, t.useCallback)(
                (V) => {
                  var ae;
                  return (ae = fe(V, {
                    container: $.mq.Primary,
                  })) === null || ae === void 0
                    ? void 0
                    : ae.id;
                },
                [fe]
              )
            ),
            Se = (0, d.d4)(
              (0, t.useCallback)(
                (V) => {
                  var ae;
                  return (ae = fe(V, {
                    container: $.mq.Primary,
                  })) === null || ae === void 0
                    ? void 0
                    : ae.params;
                },
                [fe]
              )
            ),
            he = (0, t.useCallback)(
              (V) => {
                var ae;
                const Ee = z.find((we) => we.id === V.id);
                Ee == null ||
                  (ae = Ee.onClick) === null ||
                  ae === void 0 ||
                  ae.call(Ee, V);
              },
              [z]
            ),
            se = (0, t.useCallback)(
              (V, ae) => {
                var Ee;
                const we = z.find((et) => et.id === ae);
                we == null ||
                  (Ee = we.onMouseDown) === null ||
                  Ee === void 0 ||
                  Ee.call(we, V);
              },
              [z]
            ),
            H = (0, t.useCallback)(
              (V) => {
                var ae;
                const Ee = z.find((we) => we.id === V.id);
                Ee == null ||
                  (ae = Ee.onKeyDown) === null ||
                  ae === void 0 ||
                  ae.call(Ee, V);
              },
              [z]
            ),
            Q = (0, t.useCallback)(
              (V) => {
                let { index: ae } = V;
                var Ee;
                return (Ee = z[ae]) === null || Ee === void 0
                  ? void 0
                  : Ee.focusable;
              },
              [z]
            ),
            re = (0, t.useCallback)(
              (V) => {
                var ae,
                  Ee,
                  we,
                  et,
                  pt,
                  it,
                  w,
                  ge,
                  le,
                  ie,
                  Ae,
                  Xe,
                  Te,
                  Je,
                  dt,
                  ot,
                  mt,
                  ce,
                  xe,
                  Pe;
                const Ke = t.createElement(P, {
                    label:
                      (mt =
                        (ae = V.data) === null || ae === void 0
                          ? void 0
                          : ae.label) !== null && mt !== void 0
                        ? mt
                        : "",
                    description:
                      (ce =
                        (Ee = V.data) === null || Ee === void 0
                          ? void 0
                          : Ee.description) !== null && ce !== void 0
                        ? ce
                        : "",
                    type:
                      (xe =
                        (we = V.data) === null || we === void 0
                          ? void 0
                          : we.type) !== null && xe !== void 0
                        ? xe
                        : g.R.OTHER,
                    ariaLabel:
                      (Pe =
                        (et = V.data) === null || et === void 0
                          ? void 0
                          : et.ariaLabel) !== null && Pe !== void 0
                        ? Pe
                        : "",
                    isSelected:
                      (pt = V.data) === null ||
                      pt === void 0 ||
                      (it = pt.isSelected) === null ||
                      it === void 0
                        ? void 0
                        : it.call(pt, {
                            primaryViewType: Re,
                            primaryViewId: Ye,
                            primaryViewTypeParams: Se,
                          }),
                    iconName:
                      (w = V.data) === null || w === void 0
                        ? void 0
                        : w.iconName,
                    secondaryIconName:
                      (ge = V.data) === null || ge === void 0
                        ? void 0
                        : ge.secondaryIconName,
                    calloutLabel:
                      (le = V.data) === null || le === void 0
                        ? void 0
                        : le.calloutLabel,
                    isDisabled:
                      (ie = V.data) === null || ie === void 0
                        ? void 0
                        : ie.isDisabled,
                    showIcon:
                      (Ae = V.data) === null || Ae === void 0
                        ? void 0
                        : Ae.showIcon,
                    showNotification:
                      (Xe = V.data) === null || Xe === void 0
                        ? void 0
                        : Xe.showNotification,
                    autoClogProps:
                      (Te = V.data) === null || Te === void 0
                        ? void 0
                        : Te.autoClogProps,
                    hasUnreads:
                      (Je = V.data) === null || Je === void 0
                        ? void 0
                        : Je.hasUnreads,
                    toolTip:
                      (dt = V.data) === null || dt === void 0
                        ? void 0
                        : dt.toolTip,
                    onDismiss: V.onDismiss,
                  }),
                  q =
                    (ot = V.data) === null || ot === void 0
                      ? void 0
                      : ot.coachmarkComponent;
                return q ? t.createElement(q, null, Ke) : Ke;
              },
              [Re, Ye, Se]
            ),
            J = (0, t.useCallback)(
              (V) => {
                const ae = z[V];
                switch (ae.type) {
                  case g.D.ITEM:
                    return re(ae);
                  case g.D.DIVIDER:
                    return t.createElement(s, null);
                  case g.D.SUB_HEADER:
                    var Ee, we;
                    return t.createElement(K, {
                      title:
                        (we =
                          (Ee = ae.data) === null || Ee === void 0
                            ? void 0
                            : Ee.label) !== null && we !== void 0
                          ? we
                          : "",
                    });
                  case g.D.SPACER:
                    return t.createElement(D, null);
                  default:
                    return t.createElement(t.Fragment, null, "unknown");
                }
              },
              [re, z]
            ),
            Fe = (0, t.useCallback)(
              (V) => {
                let { index: ae } = V;
                return z[ae].type === g.D.ITEM
                  ? {
                      className: "p-browse_sidebar__item_container",
                    }
                  : {};
              },
              [z]
            ),
            We = (0, t.useRef)(null),
            Be = (0, t.useCallback)(
              () => (We.current ? (We.current.focus(), !0) : !1),
              []
            ),
            Ze = c((V, ae) => {
              ae && F && V.preventDefault();
            }, "onItemContextMenu");
          var Ge;
          return (
            (0, C.A)(
              (Ge = Me == null ? void 0 : Me.viewType) !== null && Ge !== void 0
                ? Ge
                : S.D.Unknown,
              Be
            ),
            t.createElement(
              "div",
              {
                className: "p-browse__navigable_list_wrapper",
              },
              t.createElement(Y.A, null, (V) => {
                let { width: ae, height: Ee } = V;
                return t.createElement(Z.A, {
                  ref: We,
                  width: ae,
                  height: Ee,
                  keys: oe,
                  rowRenderer: J,
                  isFocusableItem: Q,
                  onItemClick: he,
                  onItemMouseDown: se,
                  onItemKeyDown: H,
                  getPropsForItem: Fe,
                  renderContextMenuForItem: F,
                  onItemContextMenu: Ze,
                });
              })
            )
          );
        }, "BrowseSidebarList");
        X.displayName = "BrowseSidebarList";
        const G = t.memo(X),
          L = c((te) => {
            let {
              rows: W,
              renderControls: F,
              children: z,
              renderContextMenuForItem: oe,
            } = te;
            return t.createElement(
              "div",
              {
                className: "p-browse_sidebar",
              },
              t.createElement(f.A, {
                renderControls: F,
              }),
              t.createElement(
                "div",
                {
                  className: "p-browse_sidebar__list",
                },
                W
                  ? t.createElement(G, {
                      rows: W,
                      renderContextMenuForItem: oe,
                    })
                  : null,
                z
              )
            );
          }, "BrowseSidebar");
        L.displayName = "BrowseSidebar";
        const ee = L;
      },
      8710426075: (x, A, e) => {
        "use strict";
        e.d(A, {
          D: () => f,
          R: () => t,
        });
        var t;
        (function (p) {
          (p.CANVAS_SMALL = "canvas"),
            (p.LIST_SMALL = "list"),
            (p.SALES_LIST_SMALL = "sales_list"),
            (p.EMPTY_STATE = "empty"),
            (p.SHIMMER = "shimmer"),
            (p.OTHER = "other");
        })(t || (t = {}));
        var f;
        (function (p) {
          (p.DIVIDER = "browse_divider"),
            (p.ITEM = "browse-sidebar-item"),
            (p.COLLECTIONS = "collections"),
            (p.SUB_HEADER = "sub-header"),
            (p.SPACER = "spacer");
        })(f || (f = {}));
      },
      5724475318: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => it,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(5255740490),
          s = e(789780423),
          v = e(1789374007),
          g = e(5600956993),
          T = e(6105929840),
          h = e(735940183),
          E = e(5136495170);
        const O = new h.Ay("recent_page"),
          a = c((w) => {
            let { filter: ge, setFilter: le } = w;
            const ie = (0, t.useCallback)(() => le(E.I.ALL), [le]);
            let Ae;
            return (
              ge === E.I.EXTERNAL &&
                (Ae = O.rt(
                  "Showing conversations that include <b>external people</b>"
                )),
              ge === E.I.INTERNAL &&
                (Ae = O.rt(
                  "Showing conversations that include <b>only internal people</b>"
                )),
              t.createElement(
                t.Fragment,
                null,
                ge === E.I.EXTERNAL &&
                  t.createElement(
                    "div",
                    {
                      className: "p-dms_page_banner",
                    },
                    t.createElement(
                      "div",
                      {
                        className: "p-dms_page_banner__contents",
                      },
                      Ae
                    ),
                    t.createElement(T.A, {
                      className: "p-dms_page_banner__close_button",
                      icon: "times",
                      "aria-label": O.t("Close"),
                      size: "small",
                      onClick: ie,
                    })
                  ),
                ge === E.I.INTERNAL &&
                  t.createElement(
                    "div",
                    {
                      className: "p-dms_page_banner",
                    },
                    t.createElement(
                      "div",
                      {
                        className: "p-dms_page_banner__contents",
                      },
                      Ae
                    ),
                    t.createElement(T.A, {
                      className: "p-dms_page_banner__close_button",
                      icon: "times",
                      "aria-label": O.t("Close"),
                      size: "small",
                      onClick: ie,
                    })
                  )
              )
            );
          }, "DmsPageBanner");
        a.displayName = "DmsPageBanner";
        const u = a;
        var _ = e(5946234139),
          I = e(3514831633),
          b = e(8773153312),
          i = e(1224315998);
        function o() {
          return (
            (o =
              Object.assign ||
              function (w) {
                for (var ge = 1; ge < arguments.length; ge++) {
                  var le = arguments[ge];
                  for (var ie in le)
                    Object.prototype.hasOwnProperty.call(le, ie) &&
                      (w[ie] = le[ie]);
                }
                return w;
              }),
            o.apply(this, arguments)
          );
        }
        c(o, "_extends");
        const l = new h.Ay("recent_page"),
          n = {
            filterExternal: {
              eventId: i.EventId.DMS_TAB_FILTER_BY_EXTERNAL,
              elementName: "dms_tab_filter-external-button",
              uiStep: i.UiStep.DMS_TAB_FILTER_BY_EXTERNAL,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            filterInternal: {
              eventId: i.EventId.DMS_TAB_FILTER_BY_INTERNAL,
              elementName: "dms_tab_filter-internal-button",
              uiStep: i.UiStep.DMS_TAB_FILTER_BY_INTERNAL,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            filterAll: {
              eventId: i.EventId.DMS_TAB_FILTER_BY_ALL,
              elementName: "dms_tab_filter-all-button",
              uiStep: i.UiStep.DMS_TAB_FILTER_BY_ALL,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
          },
          d = c((w) => {
            let { filter: ge, setFilter: le, menuProps: ie } = w;
            const Ae = (0, t.useCallback)(() => le(E.I.ALL), [le]),
              Xe = (0, t.useCallback)(() => le(E.I.EXTERNAL), [le]),
              Te = (0, t.useCallback)(() => le(E.I.INTERNAL), [le]);
            return t.createElement(
              I.Ay,
              o({}, ie),
              t.createElement(I.Dr, {
                label: l.t("Internal and external"),
                onSelected: Ae,
                key: "filter-all",
                checked: ge === E.I.ALL,
                type: b.A.radio,
                autoClogProps: n.filterAll,
                "data-qa": "dms-page-filter-menu-filter-all",
              }),
              t.createElement(I.Dr, {
                label: l.t("Only internal people"),
                onSelected: Te,
                key: "filter-internal",
                checked: ge === E.I.INTERNAL,
                type: b.A.radio,
                autoClogProps: n.filterInternal,
                "data-qa": "dms-page-filter-menu-filter-internal-only",
              }),
              t.createElement(I.Dr, {
                label: l.t("Only external people"),
                onSelected: Xe,
                key: "filter-external",
                checked: ge === E.I.EXTERNAL,
                type: b.A.radio,
                autoClogProps: n.filterExternal,
                "data-qa": "dms-page-filter-menu-filter-external-only",
              })
            );
          }, "DmsPageFilterMenu");
        d.displayName = "DmsPageFilterMenu";
        const r = t.memo(d);
        var m = e(4800776962),
          M = e(6422693406),
          P = e(2827630194),
          D = e(5267010247),
          y = e(8822892075),
          K = e(1407713935),
          S = e(9268451279),
          k = e(145735569),
          C = e(2036354333),
          Z = e(7090824688),
          Y = e(8683010724),
          $ = e(4327331459),
          X = e(1098894407),
          G = e(2562405183),
          L = e(1031947056),
          ee = e(9101533895);
        const te = (0, L.Ay)(
          "Get the general channel from cache, fetch if we do not have it",
          (w, ge, le) => {
            let { memberId: ie } = le;
            if (!(0, $.A)(ie)) return;
            const Ae = ge();
            return (0, ee.o2)(Ae, ie);
          }
        );
        te.meta = {
          name: "createThunk",
          key: "createThunkgetImIdByMemberIdThunk",
          description:
            "Get the general channel from cache, fetch if we do not have it",
        };
        var W = e(1100145935),
          F = e(8520755420),
          z = e(4761125736);
        const oe = new h.Ay("recent_page"),
          fe = c((w) => {
            let { query: ge, handleClear: le, setSelectedChannelId: ie } = w;
            const Ae = (0, G.d4)(
                (Pe) => (0, z._Z)(Pe, "ia4_dms_tab_search_capability") === "on"
              ),
              Xe = (0, t.useRef)(),
              Te = (0, f.wA)(),
              Je = (0, t.useCallback)(
                (Pe) => {
                  le();
                  const Ke = {
                    dm_exists_already: !0,
                  };
                  if ((0, $.A)(Pe.value)) {
                    const q = Te(
                      te({
                        memberId: Pe.value,
                      })
                    );
                    if (q) ie(q, Ke), Te((0, D.o)((0, y.pr)(q)));
                    else {
                      const je = (0, S.h0)({
                        memberIds: [Pe.value],
                      });
                      Te((0, F.A)()).then((rt) => {
                        const ct = {
                          client_draft_id: rt,
                          is_from_composer: !1,
                          destinations: je,
                        };
                        Te((0, W.I$)(ct)),
                          Te(
                            (0, X.U)({
                              draftId: rt,
                            })
                          );
                      }),
                        (Ke.dm_exists_already = !1),
                        ie(null, Ke);
                    }
                  } else ie(Pe.value, Ke), Te((0, D.o)((0, y.pr)(Pe.value)));
                },
                [Te, le, ie]
              ),
              dt = (0, t.useCallback)(
                (Pe) => {
                  (Pe != null && Pe.length) || le();
                },
                [le]
              ),
              ot = (0, t.useCallback)(
                (Pe) =>
                  M.S.resolve(
                    Pe.filter((Ke) => {
                      let { entity: q, value: je } = Ke;
                      return (0, K.JM)(q) || (0, $.A)(je);
                    })
                  ),
                []
              ),
              mt = (0, t.useMemo)(
                () => ({
                  allowEmptyQuery: !0,
                  entities: {
                    channels: {
                      includeMpims: !0,
                    },
                    members: {
                      includeSelf: !0,
                      includeSlackbot: !1,
                      includeBots: !1,
                      includeWorkflows: !1,
                      includeExternal: !0,
                      onlyLocalTeam: !1,
                      includeGuests: !0,
                      matchEmailField: !0,
                    },
                    emails: null,
                    userGroups: !1,
                  },
                }),
                []
              ),
              ce = (0, t.useCallback)(() => M.S.resolve([]), []),
              xe = (0, t.useCallback)(
                (Pe, Ke) =>
                  t.createElement(P.A, {
                    entity: Pe.entity,
                    id: Pe.value,
                    isActive: Ke.isActive,
                    isDisabled: Pe.isDisabled,
                    isEmail: (0, k.CC)(Pe),
                  }),
                []
              );
            return t.createElement(
              v.Ay,
              {
                headerClassName: "p-dms_page_header__search-bar",
                "aria-label": oe.t("Search DMs"),
                useToolbar: !1,
              },
              t.createElement(
                "div",
                {
                  className: "p-dms_page_header_search_bar",
                },
                t.createElement(
                  "div",
                  {
                    role: "presentation",
                    className: "p-dms_page_header_search_bar__icon",
                  },
                  t.createElement(Y.A, {
                    name: "search",
                    size: "20",
                  })
                ),
                t.createElement(Z.h7, {
                  noTokens: !0,
                  ariaLabel: oe.t("Search query"),
                  className: "p-dms_page_header_search_bar__destination_select",
                  classPrefix: "p-dms_page_header_search_bar__destination",
                  enableLoadingState: !1,
                  ignoreSelectAllTokensAfterMount: !0,
                  expandOnFocus: !1,
                  inputRef: Xe,
                  maxHeight: 44,
                  dynamicHeight: !0,
                  processSelectedOptions: ce,
                  onSelectedItemsChange: dt,
                  optionsRowHeight: 32,
                  collapseHeightToOptions: !0,
                  placeholderText: Ae ? oe.t("Find a DM") : "Find a DM",
                  processOptions: ot,
                  renderOption: xe,
                  searchOnPaste: !0,
                  shouldTokenizeOnComma: !1,
                  searcherOptions: mt,
                  selectId: "dms_tab_page__destination",
                  width: "100%",
                  onOptionSelected: Je,
                }),
                !!ge &&
                  t.createElement(
                    C.A,
                    {
                      onClick: le,
                      "aria-label": oe.t("Clear search"),
                      className: "p-dms_page_header_search_bar__clear",
                    },
                    oe.t("Clear")
                  )
              )
            );
          }, "DmsHeaderSearchBarSearcher");
        fe.displayName = "DmsHeaderSearchBarSearcher";
        const Me = new h.Ay("recent_page"),
          Re = c((w) => {
            let {
              onChange: ge,
              onKeyDown: le,
              query: ie,
              inputRef: Ae,
              handleClear: Xe,
            } = w;
            const Te = (0, G.d4)(
              (Je) =>
                (0, z._Z)(
                  Je,
                  "ia4_dms_tab_search_capability_inline_results"
                ) === "on"
            );
            return t.createElement(
              v.Ay,
              {
                headerClassName: "p-dms_page_header__search-bar",
                "aria-label": Me.t("Search DMs", {
                  fallbackHash: "bce06414177f72ab70e6387b6af9f8ceef0d6049",
                  fallbackHashNs: "advanced-search",
                }),
                useToolbar: !1,
              },
              t.createElement(
                "div",
                {
                  className: "p-dms_page_header_search_bar",
                },
                t.createElement(
                  "div",
                  {
                    className: "p-dms_page_header_search_bar__icon",
                    role: "presentation",
                  },
                  t.createElement(Y.A, {
                    name: "search",
                    size: "20",
                  })
                ),
                t.createElement("input", {
                  "aria-label": Me.t("Search query", {
                    fallbackHash: "e5e05303eb8438af9bb692edd3208655d0860643",
                    fallbackHashNs: "help",
                  }),
                  className:
                    "p-dms_page_header_search_bar__search_input c-multi_select_input",
                  placeholder: Te ? Me.t("Find a DM") : "Find a DM",
                  onChange: ge,
                  onKeyDown: le,
                  value: ie,
                  ref: Ae,
                }),
                !!ie &&
                  t.createElement(
                    C.A,
                    {
                      onClick: Xe,
                      "aria-label": Me.t("Clear search", {
                        fallbackHash:
                          "67300d0fed7c771ee8938f628c61b4d840c15ba9",
                        fallbackHashNs: "team",
                      }),
                      className: "p-dms_page_header_search_bar__clear",
                    },
                    Me.t("Clear")
                  )
              )
            );
          }, "WipDmsHeaderSearchBarExperiment1");
        Re.displayName = "WipDmsHeaderSearchBarExperiment1";
        const Ye = c((w) => {
          let {
            onChange: ge,
            onKeyDown: le,
            query: ie,
            inputRef: Ae,
            handleClear: Xe,
            setSelectedChannelId: Te,
          } = w;
          const Je = (0, G.d4)(
              (mt) => (0, z._Z)(mt, "ia4_dms_tab_search_capability") === "on"
            ),
            dt = (0, G.d4)(
              (mt) =>
                (0, z._Z)(
                  mt,
                  "ia4_dms_tab_search_capability_inline_results"
                ) === "on"
            );
          if (!Je && !dt) return null;
          let ot = null;
          return (
            dt && (ot = Re),
            Je && (ot = fe),
            ot &&
              t.createElement(ot, {
                onChange: ge,
                onKeyDown: le,
                query: ie ?? "",
                inputRef: Ae,
                handleClear: Xe,
                setSelectedChannelId: Te,
              })
          );
        }, "DmsHeaderSearchBar");
        Ye.displayName = "DmsHeaderSearchBar";
        var Se = e(7133181643),
          he = e(7433650413),
          se = e(2312625946),
          H = e(2047021170),
          Q = e(387484329);
        const re = new h.Ay("recent_page"),
          J = {
            DMS_SEARCH_INPUT: "dms_search_input",
            DMS_FIND_CONVERSATION_BUTTON: "dms_find_conversation_button",
            DMS_COMPOSE_BUTTON: "dms_compose_button",
          },
          Fe = {
            filterMenuButton: {
              eventId: i.EventId.DMS_TAB_FILTER_MENU_OPEN,
              elementName: "dms_tab_filter-menu-button",
              uiStep: i.UiStep.DMS_TAB_FILTER_MENU_OPEN,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            newMessageButton: {
              eventId: i.EventId.DMS_TAB_NEW_MESSAGE_BUTTON_CLICK,
              elementName: "dms_tab_new-message-button",
              uiStep: i.UiStep.DMS_TAB_NEW_MESSAGE_BUTTON_CLICK,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
          },
          We = c((w) => {
            let {
              query: ge,
              setQuery: le,
              filter: ie,
              setFilter: Ae,
              setQueryTerms: Xe,
              setSelectedChannelId: Te,
            } = w;
            const Je = (0, f.wA)(),
              dt = (0, G.d4)(
                (ke) =>
                  (0, z._Z)(ke, "filter_conversations_menu_updates") === "on"
              ),
              ot = (0, G.d4)(
                (ke) => (0, z._Z)(ke, "ia4_dms_tab_search_capability") === "on"
              ),
              mt = (0, G.d4)(
                (ke) =>
                  (0, z._Z)(
                    ke,
                    "ia4_dms_tab_search_capability_inline_results"
                  ) === "on"
              ),
              ce = (0, G.d4)((ke) => (0, H.ty)(ke, Se.V)),
              xe = (0, G.d4)(Se.W),
              Pe = xe
                ? "desktop_ia4_new_teams_v3__treatment_home_more--highlighted"
                : "",
              Ke = (0, t.useMemo)(
                () => ({
                  ...Fe.newMessageButton,
                  stepVariant: Pe,
                }),
                [Pe]
              ),
              q = (0, t.useRef)(),
              je = (0, t.useCallback)(
                (ke) =>
                  t.createElement(r, {
                    filter: ie,
                    setFilter: Ae,
                    menuProps: ke,
                  }),
                [ie, Ae]
              ),
              { ariaLabel: rt, filterTooltip: ct } = (0, t.useMemo)(() => {
                switch (ie) {
                  case E.I.INTERNAL:
                    return {
                      ariaLabel: re.t(
                        "Filter Conversations: Only Internal People"
                      ),
                      filterTooltip: re.rt(
                        "Filter Conversations:<br></br>Only Internal People"
                      ),
                    };
                  case E.I.EXTERNAL:
                    return {
                      ariaLabel: re.t(
                        "Filter Conversations: Only External People"
                      ),
                      filterTooltip: re.rt(
                        "Filter Conversations:<br></br>Only External People"
                      ),
                    };
                  default:
                    return {
                      ariaLabel: re.t(
                        "Filter Conversations: Internal and External"
                      ),
                      filterTooltip: re.rt(
                        "Filter Conversations:<br></br>Internal and External"
                      ),
                    };
                }
              }, [ie]),
              ze = (0, t.useCallback)(() => {
                Je((0, X.U)({})),
                  xe &&
                    !ce &&
                    Je(
                      (0, Q.AZ)({
                        pref: Se.V,
                        value: !0,
                      })
                    );
              }, [Je, ce, xe]),
              lt = (0, t.useCallback)(
                (ke) => {
                  ke.key === "Escape" && le("");
                },
                [le]
              ),
              Et = (0, t.useCallback)(
                (ke) => {
                  le(ke.target.value);
                },
                [le]
              ),
              Qe = (0, t.useCallback)(() => {
                le(""), Xe([]), q.current && q.current.focus();
              }, [le, Xe]),
              tt = ot || mt;
            return t.createElement(
              t.Fragment,
              null,
              t.createElement(
                v.Ay,
                {
                  headerClassName: (0, p.A)("p-dms_page_header", {
                    "p-dms_page_header--search-active": tt,
                  }),
                  "aria-label": re.t("Actions"),
                },
                t.createElement(
                  v.PP,
                  null,
                  dt ? t.createElement(_.w, null) : re.t("Direct messages")
                ),
                t.createElement(
                  v.cs,
                  null,
                  t.createElement(m.A, {
                    setSelectedChannelId: Te,
                  }),
                  !dt &&
                    t.createElement(
                      he.A,
                      {
                        position: "bottom-left",
                        renderMenu: je,
                      },
                      t.createElement(
                        se.Ay,
                        {
                          tip: ct,
                          position: "bottom-right",
                        },
                        t.createElement(
                          T.A,
                          {
                            "aria-label": rt,
                            autoClogProps: Fe.filterMenuButton,
                            "data-qa": "dms-filter-button",
                            className: "p-dms_page_header__button",
                          },
                          t.createElement(Y.A, {
                            name: "refine",
                            size: "20",
                          })
                        )
                      )
                    ),
                  t.createElement(
                    se.Ay,
                    {
                      tip: re.t("New message"),
                      position: "bottom-right",
                    },
                    t.createElement(
                      T.A,
                      {
                        "data-qa": J.DMS_COMPOSE_BUTTON,
                        "aria-label": re.t("New message"),
                        onClick: ze,
                        autoClogProps: Ke,
                        className: (0, p.A)("p-dms_page_header__button", {
                          "p-dms_page_header__button--highlight": xe,
                        }),
                      },
                      t.createElement(Y.A, {
                        name: "compose",
                        size: "20",
                      })
                    )
                  )
                )
              ),
              tt &&
                t.createElement(Ye, {
                  onChange: Et,
                  onKeyDown: lt,
                  query: ge,
                  inputRef: q,
                  handleClear: Qe,
                  setSelectedChannelId: Te,
                })
            );
          }, "DmsPageHeader");
        We.displayName = "DmsPageHeader";
        const Be = t.memo(We);
        var Ze = e(4481313819),
          Ge = e(5602423845),
          V = e(3841231120),
          ae = e(4517041377);
        const Ee = {
            DMS_SEARCH_INPUT: "dms_search_input",
            DMS_FIND_CONVERSATION_BUTTON: "dms_find_conversation_button",
            DMS_COMPOSE_BUTTON: "dms_compose_button",
          },
          we = {
            filterMenuButton: {
              eventId: i.EventId.DMS_TAB_FILTER_MENU_OPEN,
              elementName: "dms_tab_filter-menu-button",
              uiStep: i.UiStep.DMS_TAB_FILTER_MENU_OPEN,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            newMessageButton: {
              eventId: i.EventId.DMS_TAB_NEW_MESSAGE_BUTTON_CLICK,
              elementName: "dms_tab_new-message-button",
              uiStep: i.UiStep.DMS_TAB_NEW_MESSAGE_BUTTON_CLICK,
              action: i.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
          },
          et = new h.Ay("recent_page"),
          pt = c(() => {
            const w = (0, Ge.A)(),
              ge = (0, f.wA)(),
              le = (0, G.d4)(ae.Q),
              [ie, Ae] = (0, t.useState)(""),
              [Xe, Te] = (0, t.useState)([]),
              [Je, dt] = (0, t.useState)([]),
              ot = (0, G.d4)(
                (ye) =>
                  (0, z._Z)(ye, "filter_conversations_menu_updates") === "on"
              ),
              mt = (0, G.d4)(
                (ye) => (0, z._Z)(ye, "ia4_dms_tab_search_capability") === "on"
              ),
              ce = (0, G.d4)(
                (ye) =>
                  (0, z._Z)(
                    ye,
                    "ia4_dms_tab_search_capability_inline_results"
                  ) === "on"
              ),
              xe = mt || ce;
            (0, t.useEffect)(() => {
              ie != null && ie.length
                ? Te(ie == null ? void 0 : ie.split(" "))
                : Te([]);
            }, [ge, ie]);
            const Pe = (0, t.useCallback)(
                (ye) => {
                  ge((0, V.W)(ye));
                },
                [ge]
              ),
              [Ke, q] = (0, t.useState)(""),
              je = (0, t.useCallback)(
                (ye, gt) => {
                  if ((q(ye ?? ""), ye && gt)) {
                    const _t = {
                      contexts: {
                        ui_context: {
                          action: i.UiAction.CLICK,
                        },
                      },
                      dm_exists_already: gt.dm_exists_already,
                      dm_in_client_store: Je.includes(ye ?? ""),
                    };
                    w.track(i.EventId.DMS_TAB_SEARCH_RESULT_SELECTED, _t);
                  }
                },
                [Je, w]
              ),
              rt = (0, G.d4)((ye) => (0, H.ty)(ye, Se.V)),
              ct = (0, G.d4)(Se.W),
              ze = ct
                ? "desktop_ia4_new_teams_v3__treatment_home_more--highlighted"
                : "",
              lt = (0, t.useMemo)(
                () => ({
                  ...we.newMessageButton,
                  stepVariant: ze,
                }),
                [ze]
              ),
              Et = (0, t.useCallback)(() => {
                ge((0, X.U)({})),
                  ct &&
                    !rt &&
                    ge(
                      (0, Q.AZ)({
                        pref: Se.V,
                        value: !0,
                      })
                    );
              }, [ge, rt, ct]),
              Qe = (0, t.useCallback)(
                () =>
                  t.createElement(
                    v.cs,
                    null,
                    t.createElement(m.A, {
                      setSelectedChannelId: q,
                    }),
                    t.createElement(
                      se.Ay,
                      {
                        tip: et.t("New message"),
                        position: "bottom-right",
                      },
                      t.createElement(
                        T.A,
                        {
                          "data-qa": Ee.DMS_COMPOSE_BUTTON,
                          "aria-label": et.t("New message"),
                          onClick: Et,
                          autoClogProps: lt,
                          className: (0, p.A)("p-dms_page_header__button", {
                            "p-dms_page_header__button--highlight": ct,
                          }),
                        },
                        t.createElement(Y.A, {
                          name: "compose",
                          size: "20",
                        })
                      )
                    )
                  ),
                [lt, Et, ct]
              ),
              tt = (0, t.useRef)(),
              ke = (0, t.useCallback)(
                (ye) => {
                  ye.key === "Escape" && Ae("");
                },
                [Ae]
              ),
              Ve = (0, t.useCallback)(
                (ye) => {
                  Ae(ye.target.value);
                },
                [Ae]
              ),
              nt = (0, t.useCallback)(() => {
                Ae(""), Te([]), tt.current && tt.current.focus();
              }, [Ae, Te]);
            return t.createElement(
              Ze.A,
              {
                eventId: i.EventId.DMS_VIEW_OPEN,
                clogImpression: !0,
                enableClogImpressionOffScreen: !1,
                clogImpressionDuration: !0,
              },
              ot
                ? t.createElement(
                    s.A,
                    {
                      renderControls: Qe,
                    },
                    xe &&
                      t.createElement(Ye, {
                        onChange: Ve,
                        onKeyDown: ke,
                        query: ie,
                        inputRef: tt,
                        handleClear: nt,
                        setSelectedChannelId: je,
                      }),
                    le !== E.I.ALL &&
                      t.createElement(u, {
                        filter: le,
                        setFilter: Pe,
                      }),
                    t.createElement(
                      "div",
                      {
                        className: "p-view_sidebar p-view_sidebar--list",
                      },
                      t.createElement(g.A, {
                        shouldTrackScroll: !0,
                        selectedChannelId: Ke,
                        queryTerms: Xe,
                        scrollToKey: Ke,
                        setChannelIds: dt,
                        setSelectedChannelId: q,
                      })
                    )
                  )
                : t.createElement(
                    t.Fragment,
                    null,
                    t.createElement(Be, {
                      query: ie,
                      setQuery: Ae,
                      filter: le,
                      setFilter: Pe,
                      setQueryTerms: Te,
                      setSelectedChannelId: je,
                    }),
                    le !== E.I.ALL &&
                      t.createElement(u, {
                        filter: le,
                        setFilter: Pe,
                      }),
                    t.createElement(
                      "div",
                      {
                        className: "p-view_sidebar p-view_sidebar--list",
                      },
                      t.createElement(g.A, {
                        shouldTrackScroll: !0,
                        selectedChannelId: Ke,
                        queryTerms: Xe,
                        scrollToKey: Ke,
                        setChannelIds: dt,
                        setSelectedChannelId: q,
                      })
                    )
                  )
            );
          }, "DmsPage");
        pt.displayName = "DmsPage";
        const it = t.memo(pt);
      },
      5946234139: (x, A, e) => {
        "use strict";
        e.d(A, {
          w: () => r,
        });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4459831283),
          s = e(1063683520),
          v = e(6084388622),
          g = e(3514831633),
          T = e(8773153312),
          h = e(8683010724),
          E = e(1224315998),
          O = e(735940183),
          a = e(3841231120),
          u = e(5136495170),
          _ = e(4517041377),
          I = e(6280700824),
          b = e(2562405183),
          i = e(4761125736);
        function o() {
          return (
            (o =
              Object.assign ||
              function (M) {
                for (var P = 1; P < arguments.length; P++) {
                  var D = arguments[P];
                  for (var y in D)
                    Object.prototype.hasOwnProperty.call(D, y) && (M[y] = D[y]);
                }
                return M;
              }),
            o.apply(this, arguments)
          );
        }
        c(o, "_extends");
        const l = new O.Ay("ia4"),
          n = {
            filterExternal: {
              eventId: E.EventId.DMS_TAB_FILTER_BY_EXTERNAL,
              elementName: "dms_tab_filter-external-button",
              uiStep: E.UiStep.DMS_TAB_FILTER_BY_EXTERNAL,
              action: E.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            filterInternal: {
              eventId: E.EventId.DMS_TAB_FILTER_BY_INTERNAL,
              elementName: "dms_tab_filter-internal-button",
              uiStep: E.UiStep.DMS_TAB_FILTER_BY_INTERNAL,
              action: E.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
            filterAll: {
              eventId: E.EventId.DMS_TAB_FILTER_BY_ALL,
              elementName: "dms_tab_filter-all-button",
              uiStep: E.UiStep.DMS_TAB_FILTER_BY_ALL,
              action: E.UiAction.CLICK,
              onClick: {
                enableClogAction: !0,
              },
            },
          },
          d = c((M) => {
            let { menuProps: P } = M;
            const D = (0, b.d4)(
                (X) =>
                  (0, i._Z)(X, "filter_conversations_menu_updates") === "on"
              ),
              y = (0, b.d4)(p.FT),
              K = (0, f.wA)(),
              S = (0, b.d4)(_.Q),
              k = (0, t.useCallback)(
                (X) => {
                  K((0, a.W)(X));
                },
                [K]
              ),
              C = (0, t.useCallback)(() => {
                K(
                  (0, I.A)({
                    activeSection: s._.vip,
                  })
                );
              }, [K]),
              Z = l.t("Filter conversations"),
              Y = D ? l.t("Manage VIP") : "",
              $ = (0, t.useMemo)(
                () =>
                  [
                    {
                      label: Y,
                      click: C,
                      key: "vip-preferences",
                      show: y,
                    },
                    {
                      label: Z,
                      type: T.y.submenu,
                      key: "filter-conversations",
                      show: !0,
                      template: [
                        {
                          label: D ? l.t("Everyone") : "",
                          click: () => k(u.I.ALL),
                          key: "filter-all",
                          type: T.A.radio,
                          checked: S === u.I.ALL,
                          autoClogProps: n.filterAll,
                          dataQa: "dms-page-filter-menu-filter-all",
                        },
                        {
                          label: D ? l.t("Only internal people") : "",
                          click: () => k(u.I.INTERNAL),
                          key: "filter-internal",
                          type: T.A.radio,
                          checked: S === u.I.INTERNAL,
                          autoClogProps: n.filterInternal,
                          dataQa: "dms-page-filter-menu-filter-internal-only",
                        },
                        {
                          label: D ? l.t("Only external people") : "",
                          click: () => k(u.I.EXTERNAL),
                          key: "filter-external",
                          type: T.A.radio,
                          checked: S === u.I.EXTERNAL,
                          autoClogProps: n.filterExternal,
                          dataQa: "dms-page-filter-menu-filter-external-only",
                        },
                      ],
                    },
                  ].filter((G) => ("show" in G ? G.show !== !1 : !0)),
                [D, S, k, Z, y, Y, C]
              );
            return t.createElement(
              g.a,
              o({}, P, {
                menuClassNames: "p-ia4_home_header_menu__menu",
                template: $,
              })
            );
          }, "DirectMessagesHeaderMenu");
        d.displayName = "DirectMessagesHeaderMenu";
        const r = c(() => {
          const M = (0, t.useCallback)(
            (P) =>
              t.createElement(d, {
                menuProps: P,
              }),
            []
          );
          return t.createElement(
            g.cQ,
            {
              renderMenu: M,
              position: "bottom-left",
            },
            t.createElement(
              v.Nm,
              {
                className: "p-ia4_home_header_menu__button ",
                "data-qa": "workspace_actions_button",
              },
              t.createElement(
                "span",
                {
                  className: "p-ia4_home_header_menu__team_name",
                },
                l.t("Direct messages")
              ),
              t.createElement(h.A, {
                name: "caret-down",
              })
            )
          );
        }, "DirectMessagesHeaderMenuTrigger");
        r.displayName = "DirectMessagesHeaderMenuTrigger";
        var m = null;
      },
      3686168196: (x, A, e) => {
        "use strict";
        e.d(A, {
          A: () => Uo,
        });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(5255740490),
          s = e(5946234139),
          v = e(5557117347),
          g = e(6839188756),
          T = e(6084388622),
          h = e(3514831633),
          E = e(8683010724),
          O = e(735940183),
          a = e(2562405183),
          u = e(3677514771);
        function _() {
          return (
            (_ =
              Object.assign ||
              function (N) {
                for (var B = 1; B < arguments.length; B++) {
                  var R = arguments[B];
                  for (var U in R)
                    Object.prototype.hasOwnProperty.call(R, U) && (N[U] = R[U]);
                }
                return N;
              }),
            _.apply(this, arguments)
          );
        }
        c(_, "_extends");
        const I = new O.Ay("events"),
          b = c((N) => {
            let { menuProps: B, externalWorkspaceId: R } = N;
            const U = (0, a.d4)((Ie) => (0, u._J)(Ie, R)),
              de = (0, g.F1)(U);
            return t.createElement(
              v.P,
              _(
                {
                  workspaceId: R,
                  isWorkspaceHeaderMenu: !0,
                  classNames: "p-event_header_menu__menu",
                },
                B,
                {
                  menuClassNames: "p-event_header_menu__menu",
                  ariaLabel: I.t("{teamDisplayName} Actions", {
                    teamDisplayName: de,
                    fallbackHash: "dde3b41abdc106c7934277e6ce75b7165c603697",
                    fallbackHashNs: "ia4",
                  }),
                }
              )
            );
          }, "EventHeaderMenu");
        b.displayName = "EventHeaderMenu";
        const i = c((N) => {
          let { externalWorkspaceId: B } = N;
          const R = (0, t.useCallback)(
              (de) =>
                t.createElement(b, {
                  menuProps: de,
                  externalWorkspaceId: B,
                }),
              [B]
            ),
            U = (0, a.d4)((de) => (0, g.F1)((0, u._J)(de, B)));
          return t.createElement(
            h.cQ,
            {
              renderMenu: R,
              position: "bottom-left",
            },
            t.createElement(
              T.Nm,
              {
                className: "p-event_header_menu__button",
                "aria-label": I.t("{externalWorkspaceName} Actions", {
                  externalWorkspaceName: U,
                  fallbackHash: "dde3b41abdc106c7934277e6ce75b7165c603697",
                  fallbackHashNs: "ia4",
                }),
                "data-qa": "workspace_actions_button",
              },
              t.createElement(
                "span",
                {
                  className: "p-event_header_menu__team_name",
                },
                U
              ),
              t.createElement(E.A, {
                name: "caret-down",
                "aria-label": "caret-down",
              })
            )
          );
        }, "EventHeaderMenuTrigger");
        i.displayName = "EventHeaderMenuTrigger";
        var o = e(6879781695),
          l = e(6105929840),
          n = e(8773153312),
          d = e(2312625946),
          r = e(1224315998),
          m = e(2112238546),
          M = e(2235302340),
          P = e(3943207487),
          D = e(2047021170),
          y = e(387484329);
        function K() {
          return (
            (K =
              Object.assign ||
              function (N) {
                for (var B = 1; B < arguments.length; B++) {
                  var R = arguments[B];
                  for (var U in R)
                    Object.prototype.hasOwnProperty.call(R, U) && (N[U] = R[U]);
                }
                return N;
              }),
            K.apply(this, arguments)
          );
        }
        c(K, "home_filter_menu_extends");
        const S = new O.Ay("ia4"),
          k = c((N) => {
            let { autoClogProps: B } = N;
            const R = (0, f.wA)(),
              U = (0, a.d4)(M.ce),
              de = (0, a.d4)((ne) => (0, D.ty)(ne, "sidebar_behavior")),
              Ie = (0, t.useCallback)(
                (ne) => {
                  R(
                    (0, y.AZ)({
                      pref: "sidebar_behavior",
                      value: ne,
                    })
                  );
                },
                [R]
              ),
              ue = (0, t.useCallback)(function () {
                let ne =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : o.UN,
                  Ce = null;
                switch (ne) {
                  case o.nU:
                    Ce = S.t("Unreads only");
                    break;
                  case o.Ao:
                    Ce = S.t("Mentions only");
                    break;
                  case o.eF:
                    Ce = S.t("Custom by section");
                    break;
                  default:
                    Ce = S.t("All activity");
                }
                return Ce;
              }, []),
              Oe = (0, t.useCallback)(
                (ne) => {
                  R(
                    (0, m.UG)({
                      peopleFilter: {
                        type: ne,
                      },
                    })
                  );
                },
                [R]
              ),
              De = (0, t.useCallback)(function () {
                let ne =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : P.E7.All,
                  Ce = null;
                switch (ne) {
                  case P.E7.Internal:
                    Ce = S.t("Without external people");
                    break;
                  case P.E7.External:
                    Ce = S.t("Including external people");
                    break;
                  default:
                    Ce = S.t("Everyone");
                }
                return Ce;
              }, []),
              me = (0, t.useMemo)(() => {
                const ne = [o.UN, o.nU, o.Ao, o.eF],
                  Ce = [P.E7.All, P.E7.Internal, P.E7.External],
                  He = c((Ne) => {
                    switch (Ne) {
                      case o.UN:
                        return r.EventId.HOME_FILTER_ALL_ACTIVITY;
                      case o.nU:
                        return r.EventId.HOME_FILTER_UNREADS_ONLY;
                      case o.Ao:
                        return r.EventId.HOME_FILTER_MENTIONS_ONLY;
                      case o.eF:
                        return r.EventId.HOME_FILTER_CUSTOM_BY_SECTION;
                      case P.E7.All:
                        return r.EventId.HOME_FILTER_EVERYONE;
                      case P.E7.Internal:
                        return r.EventId.HOME_FILTER_WITHOUT_EXTERNAL;
                      case P.E7.External:
                        return r.EventId.HOME_FILTER_INCLUDE_EXTERNAL;
                      default:
                        return "";
                    }
                  }, "getClogEventIdForEntry"),
                  $e = U == null ? void 0 : U.type;
                return [
                  ...ne.map((Ne) => ({
                    label: ue(Ne),
                    type: n.A.checkbox,
                    click: () => Ie(Ne),
                    checked: (!de && Ne === o.UN) || de === Ne,
                    autoClogProps: {
                      onClick: {
                        enableClogAction: !0,
                      },
                      eventId: He(Ne),
                    },
                  })),
                  {
                    type: n.A.separator,
                  },
                  ...Ce.map((Ne) => ({
                    label: De(Ne),
                    type: n.A.checkbox,
                    click: () => Oe(Ne),
                    checked: (!$e && Ne === P.E7.All) || $e === Ne,
                    autoClogProps: {
                      onClick: {
                        enableClogAction: !0,
                      },
                      eventId: He(Ne),
                    },
                  })),
                ];
              }, [de, Ie, ue, De, Oe, U]),
              Ue = (0, t.useCallback)(
                (ne) =>
                  t.createElement(
                    h.a,
                    K({}, ne, {
                      template: me,
                    })
                  ),
                [me]
              );
            return t.createElement(
              h.cQ,
              {
                renderMenu: Ue,
                position: "bottom-left",
              },
              t.createElement(
                d.Ay,
                {
                  tip: S.t("Filter conversations"),
                  position: "bottom",
                },
                t.createElement(
                  l.A,
                  {
                    autoClogProps: B,
                    "data-qa": "home_filter_menu",
                    "aria-label": S.t("Home filter"),
                    className: "p-home_header_controls__filter_menu",
                  },
                  t.createElement(E.A, {
                    name: "refine",
                    "aria-label": "refine",
                    size: "20",
                  })
                )
              )
            );
          }, "HomeFilterMenu");
        k.displayName = "HomeFilterMenu";
        const C = k;
        var Z = e(7133181643),
          Y = e(4626613428),
          $ = e(4481313819),
          X = e(219228829),
          G = e(485355941),
          L = e(1098894407),
          ee = e(4761125736);
        const te = new O.Ay("drafts"),
          W = {
            elementName: "home_header_filter_menu_button",
            elementType: r.ElementType.BUTTON,
            eventId: r.EventId.HOME_FILTER_MENU,
            onClick: {
              enableClogAction: !0,
            },
            uiStep: r.UiStep.HOME_FILTER_MENU,
            stepVariant: "desktop_ia4_new_teams_v3__treatment_home_more",
          };
        function F(N) {
          let { isSetupPage: B } = N;
          const R = (0, a.d4)(
              (ne) =>
                (0, ee._Z)(ne, "filter_conversations_menu_updates") === "on"
            ),
            U = (0, f.wA)(),
            de = (0, t.useRef)(),
            Ie = (0, t.useCallback)((ne) => {
              de.current = ne;
            }, []),
            ue = (0, a.d4)(G.M2),
            Oe = (0, a.d4)((ne) => (0, D.ty)(ne, Z.V)),
            De = (0, a.d4)(Z.W),
            me = (0, a.d4)(Y.Ty) && !R,
            Ue = (0, t.useCallback)(
              (ne) => {
                var Ce;
                U(
                  (0, L.U)({
                    shouldOpenInTile: ue && (0, X.A)(ne),
                  })
                ),
                  De &&
                    !Oe &&
                    U(
                      (0, y.AZ)({
                        pref: Z.V,
                        value: !0,
                      })
                    ),
                  (Ce = de.current) === null ||
                    Ce === void 0 ||
                    Ce.call(de, {
                      action: r.UiAction.CLICK,
                    });
              },
              [ue, U, Oe, De]
            );
          return B
            ? null
            : t.createElement(
                t.Fragment,
                null,
                me &&
                  t.createElement(C, {
                    autoClogProps: W,
                  }),
                t.createElement(
                  $.A,
                  {
                    clogImpression: !0,
                    elementName: "home_header_composer_button",
                    elementType: r.ElementType.BUTTON,
                    eventId: r.EventId.COMPOSE_FLOW,
                    stepVariant:
                      "desktop_ia4_new_teams_v3__treatment_home_more",
                    trackClogRef: Ie,
                    uiStep: r.UiStep.COMPOSE_FLOW_CREATE,
                  },
                  t.createElement(
                    d.Ay,
                    {
                      tip: te.t("New message"),
                      position: "bottom",
                    },
                    t.createElement(
                      l.A,
                      {
                        "aria-label": te.t("New message"),
                        className: (0, p.A)(
                          "p-home_header_controls__composer_button",
                          {
                            "p-home_header_controls__composer_button--highlight":
                              De,
                          }
                        ),
                        "data-qa": "composer_button",
                        onClick: Ue,
                        size: De ? "x-small" : "medium",
                      },
                      t.createElement(E.A, {
                        name: "compose",
                        size: "20",
                      })
                    )
                  )
                )
              );
        }
        c(F, "HomeHeaderControls"), (F.displayName = "HomeHeaderControls");
        const z = (0, t.memo)(F);
        var oe = e(506684971),
          fe = e.n(oe),
          Me = e(7715417323),
          Re = e(9948985554),
          Ye = e(7043699030),
          Se = e(1031947056),
          he = e(9190452268);
        const se = (0, Se.Ay)(
          "Counts the number of times the Open App team menu item is selected",
          (N, B) => {
            (0, he.Cy)({
              getState: B,
            }).count("team_menu_download_apps");
          }
        );
        se.meta = {
          name: "createThunk",
          key: "createThunkcountOpenAppClick",
          description:
            "Counts the number of times the Open App team menu item is selected",
        };
        const H = se;
        var Q = e(301719806),
          re = e.n(Q),
          J = e(8245211418),
          Fe = e(101973425),
          We = e(8161242485),
          Be = e(2995501183),
          Ze = e(2140279507),
          Ge = e(6827180593);
        const V = (0, We.Ay)((N) => {
          const B = (0, Ze.QJ)(N),
            R = (0, Be.Yx)(N),
            U = (0, Ge.H)(N) < 1;
          return B && R && U;
        });
        V.meta = {
          name: "createSelector",
          key: "createSelectorfirstLoginIntoWorkspaceSelector",
          description: (N) => {
            const B = (0, Ze.QJ)(N),
              R = (0, Be.Yx)(N),
              U = (0, Ge.H)(N) < 1;
            return B && R && U;
          },
        };
        function ae() {
          return (
            (ae =
              Object.assign ||
              function (N) {
                for (var B = 1; B < arguments.length; B++) {
                  var R = arguments[B];
                  for (var U in R)
                    Object.prototype.hasOwnProperty.call(R, U) && (N[U] = R[U]);
                }
                return N;
              }),
            ae.apply(this, arguments)
          );
        }
        c(ae, "open_desktop_app_menu_item_extends");
        const Ee = new O.Ay("native_apps_entry_points"),
          we = {
            onClick: {
              enableClogAction: !0,
            },
          },
          et = c((N) => {
            let {
              showMobileEntryPoint: B,
              teamUrl: R,
              className: U,
              ...de
            } = N;
            const Ie = (0, f.wA)();
            let ue = Ee.rt("Open the Slack App", {
                fallbackHash: "3d3bf52716f61d19b7b9959018e54757226c17ca",
                fallbackHashNs: "classic_nav",
              }),
              Oe =
                r.UiComponentVariant
                  .PERSISTENT_ENTRY_CONTROL_DESKTOP_DEFAULT_COPY;
            B &&
              ((ue = Ee.rt("Open the desktop app", {
                fallbackHash: "f1ccafab17e31b70d527e3984ece02b6e92d9d25",
                fallbackHashNs: "classic_nav",
              })),
              (Oe =
                r.UiComponentVariant
                  .PERSISTENT_ENTRY_TREATMENT_DESKTOP_UPDATED_COPY));
            const De = t.createElement(
                t.Fragment,
                null,
                t.createElement(
                  "span",
                  {
                    className: "p-ia__main_menu__open_native_app_copy",
                  },
                  ue
                ),
                t.createElement(
                  "span",
                  {
                    className: (0, p.A)(
                      "p-ia__main_menu__open_slack_app_icon",
                      "p-ia__main_menu__open_native_app_icon"
                    ),
                  },
                  t.createElement("img", {
                    src: re(),
                    alt: "Slack app logo",
                  })
                )
              ),
              me = (0, t.useCallback)(() => Ie(H()), [Ie]),
              ne = (0, a.d4)(V)
                ? `${R}ssb/redirect?open_desktop=1`
                : `${R}ssb/redirect`;
            return t.createElement(
              $.A,
              {
                eventId: r.EventId.EDUCATION_PERSISTENT_MOBILE_ENTRY,
                uiStep: r.UiStep.MAIN_MENU,
                uiComponentName: r.UiComponentName.DESKTOP_ENTRY_POINT,
                uiComponentVariant: Oe,
                clogImpression: !0,
              },
              t.createElement(
                J.A,
                ae({}, de, {
                  "data-qa": "open-desktop-app",
                  className: (0, p.A)(
                    "p-ia__main_menu__open_slack_app_item",
                    U
                  ),
                  onSelected: me,
                  href: ne,
                  showLinkIndicatorIcon: !1,
                  label: De,
                  autoClogProps: we,
                })
              )
            );
          }, "OpenDesktopAppMenuItem");
        et.displayName = "OpenDesktopAppMenuItem";
        const pt = (0, Fe.Ay)(et);
        var it = e(4902318931),
          w = e(6259241484);
        const ge = {
            [w.ze.PERSISTENT_MOBILE_PROMO]: {
              component: t.lazy(() =>
                Promise.resolve().then(e.bind(e, 7391266585))
              ),
            },
          },
          le = t.lazy(() => Promise.resolve().then(e.bind(e, 381260222))),
          ie = t.lazy(() => Promise.resolve().then(e.bind(e, 3854710577))),
          Ae = t.lazy(() => Promise.resolve().then(e.bind(e, 8269938703))),
          Xe = t.lazy(() => Promise.resolve().then(e.bind(e, 2249844134))),
          Te = t.lazy(() => Promise.resolve().then(e.bind(e, 1017327448))),
          Je = {
            spaceName: w.xu.WORKSPACE_MENU_PRIMARY_PLAN_INFO,
            notifications: {
              [w.ze.PLAN_INFO]: {
                component: le,
              },
              [w.ze.TRIAL_INFO]: {
                component: ie,
              },
              [w.ze.STRAIGHT_TO_PAID_WORKSPACE_MENU_PRIMARY_TIME_LIMIT]: {
                component: Te,
              },
              [w.ze.LIMITED_HISTORY_COUNTDOWN]: {
                component: Ae,
              },
              [w.ze.LIMITED_HISTORY_COUNTER]: {
                component: Xe,
              },
            },
          },
          dt = t.lazy(() => Promise.resolve().then(e.bind(e, 858410167))),
          ot = t.lazy(() => Promise.resolve().then(e.bind(e, 6077046070))),
          mt = t.lazy(() => Promise.resolve().then(e.bind(e, 9590263900))),
          ce = t.lazy(() => Promise.resolve().then(e.bind(e, 6768452643))),
          xe = t.lazy(() => Promise.resolve().then(e.bind(e, 6807544879))),
          Pe = {
            spaceName: w.xu.WORKSPACE_MENU_SECONDARY_PLAN_INFO,
            notifications: {
              [w.ze.STRAIGHT_TO_PAID_WORKSPACE_MENU_SECONDARY_UPGRADE_CTA]: {
                component: ot,
              },
              [w.ze.DISCOUNT_PROMO]: {
                component: dt,
              },
              [w.ze.SLACK_AI_WORKSPACE_MENU_CTA]: {
                component: mt,
              },
              [w.ze.SLACK_AI_TRIAL_OFFER_WORKSPACE_MENU_CTA]: {
                component: t.lazy(() =>
                  Promise.resolve()
                    .then(e.bind(e, 7956527390))
                    .then((N) => ({
                      default: N.ConnectedSlackAiTrialOfferWorkspaceMenuCta,
                    }))
                ),
              },
              [w.ze.SLACK_AI_AUTO_CHARGE_TRIAL_MANAGE_TRIAL_WORKSPACE_MENU_CTA]:
                {
                  component: ce,
                },
              [w.ze.AUTO_CHARGE_FEATURE_TRIALS_MANAGE_TRIAL_WORKSPACE_MENU_CTA]:
                {
                  component: xe,
                },
            },
          };
        var Ke = e(4979382452),
          q = e(9003400431),
          je = e(980293773),
          rt = e(9706240641),
          ct = e(1138952178),
          ze = e(6422693406),
          lt = e(796111729);
        const Et = c(
          (N) =>
            new ze.S((B, R) => {
              if (!N) {
                R(new Error("Invalid params"));
                return;
              }
              try {
                B(ct.toDataURL(`${N}`));
              } catch (U) {
                const de = (0, lt.Wo)();
                de.warn("Error generating QR code"), de.warn(U), R(U);
              }
            }),
          "generateQrCode"
        );
        var Qe = e(5795074931),
          tt = e(8847766420),
          ke = e(6308822),
          Ve = e(5812641038),
          nt = e(1942804440),
          ye = e(9420092417),
          gt = e.n(ye),
          _t = e(3715013583),
          zt = e(1269227002),
          Yt = e(5257368278),
          ht = e(5873468694);
        const _a = {
            Ratelimited: "ratelimited",
            NotAuthed: "not_authed",
            InvalidAuth: "invalid_auth",
          },
          Ot = (0, Yt.A)(
            "auth.magicLogins.create generated fetcher",
            (N, B, R) =>
              new ze.S((U, de) => {
                const { reason: Ie, ...ue } = R,
                  Oe = (0, ht.VA)(ue);
                N(
                  (0, zt.apiCall)({
                    method: "auth.magicLogins.create",
                    args: Oe,
                    reason: Ie,
                  })
                )
                  .then((De) => {
                    U(De);
                  })
                  .catch((De) => {
                    (0, lt.Ay)({
                      getState: B,
                    }).error(`API call to auth.magicLogins.create
						with reason ${Ie} failed, initiated by generated fetcher`),
                      de(De);
                  });
              })
          );
        Ot.meta = {
          name: "createFetcher",
          key: "createFetcherauthMagicLoginsCreateFetcher",
          description: "auth.magicLogins.create generated fetcher",
        };
        const Lt = new O.Ay("mobile_app_promos"),
          qt = c((N) => {
            let { teamDisplayName: B, userEmail: R, onErrorCallback: U } = N;
            const [de, Ie] = (0, t.useState)(),
              ue = (0, a.d4)(Qe.WR),
              Oe = (0, a.d4)(tt.ZT),
              {
                data: De,
                loading: me,
                error: Ue,
                refetch: ne,
              } = (0, _t.L)({
                fetcher: Ot,
                args: {
                  reason: "qr-code-signin",
                },
              }),
              Ce = (De == null ? void 0 : De.magic_login_url) || "",
              He = (0, t.useCallback)(
                (0, rt.coroutine)(function* () {
                  const Ne = yield Et(
                    `${Ce}?src=qr_code&user_id=${ue}&team_id=${Oe}`
                  );
                  Ie(Ne);
                }),
                [Ce, ue, Oe]
              ),
              $e = Lt.rt(
                "You\u2019re signing in as <b>{userEmail}</b>.",
                {
                  userEmail: R,
                },
                (Ne) => {
                  let { tag: Tt, text: Pt } = Ne;
                  return Tt === "b"
                    ? t.createElement("strong", null, Pt)
                    : null;
                }
              );
            return (
              (0, t.useEffect)(() => {
                Ce && He();
              }, [He, Ce]),
              me
                ? t.createElement(
                    "div",
                    {
                      className: "p-qr_code_signin_modal__qr_code_wrapper",
                      "data-qa": "qr-code-signin-loading-wrapper",
                    },
                    t.createElement(ke.A, {
                      color: "blue",
                      size: "jumbo",
                      loadingMessage: "generating QR code",
                    })
                  )
                : Ue
                ? (U(),
                  t.createElement(
                    "div",
                    {
                      className:
                        "p-qr_code_signin_modal__qr_code_wrapper p-qr_code_signin_modal__qr_code--error",
                      "data-qa": "qr-code-signin-error-wrapper",
                    },
                    t.createElement(
                      nt.A,
                      {
                        className: "p-qr_code_signin_modal__error_container",
                        size: "medium",
                      },
                      t.createElement(Ve.A, {
                        className: "margin_auto",
                        title: Lt.t("Error"),
                        primaryActionText: "Refresh QR code",
                        primaryActionDataQA: "refresh-qr-code",
                        onClickPrimaryAction: ne,
                        description: Lt.t(
                          "Sorry, an error occurred while generating the QR code."
                        ),
                      })
                    ),
                    t.createElement("img", {
                      alt: "",
                      className: "p-mobile_download_modal__robot_img",
                      src: gt(),
                    })
                  ))
                : t.createElement(
                    "div",
                    {
                      className: "p-qr_code_signin_modal__qr_code_wrapper",
                    },
                    de &&
                      t.createElement(
                        t.Fragment,
                        null,
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-qr_code_signin_modal__qr_code_image--wrapper",
                          },
                          t.createElement("img", {
                            alt: Lt.t(
                              "Quick Response (QR) code to sign in to workspace on the Slack mobile app"
                            ),
                            className: "p-qr_code_signin_modal__qr_code--image",
                            "data-qa": "qr-code-signin-link-image",
                            src: de,
                          })
                        ),
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-qr_code_signin_modal__qr_code_workspace_name",
                          },
                          B
                        ),
                        R &&
                          t.createElement(
                            "div",
                            {
                              className: "margin_top_125",
                            },
                            $e
                          )
                      )
                  )
            );
          }, "MagicLoginQrCode");
        qt.displayName = "MagicLoginQrCode";
        const da = qt;
        var ma = e(8276911661),
          ua = e(8170643398);
        const St = new O.Ay("mobile_app_promos"),
          Ea = c(() => {
            const N = (0, f.wA)();
            let B = null;
            const [R, U] = (0, t.useState)(!1),
              de = (0, t.useCallback)(() => {
                N((0, q.O)()),
                  B == null ||
                    B({
                      action: r.UiAction.CLOSE,
                      elementName: "close_qr_code_signin_modal",
                    });
              }, [N, B]),
              Ie = (0, t.useCallback)(() => {
                U(!0);
              }, [U]),
              ue = (0, a.d4)(u.H7),
              Oe = (0, g.F1)(ue),
              De = (0, a.d4)(Qe.WR),
              me = (0, a.d4)((Ce) => (0, ma.nv)(Ce, De)),
              Ue = (0, ua.zY)(me),
              ne = St.t("Sign in to {teamDisplayName} on mobile", {
                teamDisplayName: Oe,
              });
            return t.createElement(
              $.A,
              {
                eventId: r.EventId.EDUCATION_QR_CODE_SIGNIN,
                uiStep: r.UiStep.QR_CODE_SIGNIN_MODAL,
                trackClogRef: (Ce) => {
                  B = Ce;
                },
              },
              t.createElement(
                Ke.A,
                {
                  contentLabel: ne,
                  closeModal: de,
                  isOpen: !0,
                  centered: !0,
                  dataQa: "qr-code-signin-modal",
                  className: "p-qr_code_signin_modal",
                  describedby: "qr-code-signin-modal-described-by-label",
                },
                t.createElement(
                  je.rQ,
                  null,
                  t.createElement(da, {
                    teamDisplayName: Oe,
                    onErrorCallback: Ie,
                    userEmail: Ue,
                  })
                ),
                !R &&
                  t.createElement(
                    je.$m,
                    null,
                    t.createElement(je.Rc, {
                      title: ne,
                      className: "p-qr_code_signin_modal__title",
                    }),
                    t.createElement(
                      je.qf,
                      {
                        className: "p-qr_code_signin_modal__content_section",
                      },
                      t.createElement(
                        "span",
                        {
                          hidden: !0,
                          id: "qr-code-signin-modal-described-by-label",
                        },
                        St.t(
                          "Scan Quick Response (QR) code to sign in to workspace on mobile by following these 4 steps."
                        )
                      ),
                      t.createElement(
                        "p",
                        null,
                        St.t("To access this workspace on your phone:")
                      ),
                      t.createElement(
                        "ol",
                        null,
                        t.createElement(
                          "li",
                          null,
                          St.t(
                            "Open Slack on your mobile device. From the home tab, swipe right.",
                            {
                              fallbackHash:
                                "6d5c50550323dc0d497d39864b434da8a004e50e",
                            }
                          )
                        ),
                        t.createElement(
                          "li",
                          null,
                          St.rt(
                            "Tap <strong>Add a workspace</strong> at the bottom of the pane."
                          )
                        ),
                        t.createElement(
                          "li",
                          null,
                          St.rt(
                            "Tap <strong>Sign in to another workspace</strong> at the bottom of the list.",
                            {
                              fallbackHash:
                                "d07a17677cdcbc15745eb4eaceb7a02fe436ffe8",
                            }
                          )
                        ),
                        t.createElement(
                          "li",
                          null,
                          St.rt("Tap <strong>Scan QR Code.</strong>")
                        )
                      )
                    )
                  )
              )
            );
          }, "QRCodeSigninModal");
        Ea.displayName = "QRCodeSigninModal";
        const pa = Ea;
        var At = e(2375333597);
        function ea() {
          return (
            (ea =
              Object.assign ||
              function (N) {
                for (var B = 1; B < arguments.length; B++) {
                  var R = arguments[B];
                  for (var U in R)
                    Object.prototype.hasOwnProperty.call(R, U) && (N[U] = R[U]);
                }
                return N;
              }),
            ea.apply(this, arguments)
          );
        }
        c(ea, "open_qr_code_signin_menu_item_extends");
        const ta = new O.Ay("classic_nav"),
          aa = {
            onClick: {
              enableClogAction: !0,
            },
          },
          wt = c((N) => {
            let { teamDisplayName: B, showInSubMenu: R = !1, ...U } = N;
            const de = (0, f.wA)();
            let Ie = ta.rt("Sign in on mobile", {
              teamDisplayName: B,
            });
            return (
              R &&
                (Ie = ta.rt("Scan QR code", {
                  fallbackHash: "e7d8c30678ab2dafeb1e17cf2c302dca8a218c36",
                  fallbackHashNs: "mobile_app_promos",
                })),
              t.createElement(
                $.A,
                {
                  eventId: r.EventId.EDUCATION_QR_CODE_SIGNIN,
                  uiStep: r.UiStep.MAIN_MENU,
                  clogImpression: !0,
                },
                t.createElement(
                  J.A,
                  ea({}, U, {
                    "data-qa": "qr-code-signin-menu-item",
                    onSelected: () =>
                      de(
                        (0, At.q)({
                          element: t.createElement(pa, null),
                        })
                      ),
                    label: Ie,
                    autoClogProps: aa,
                  })
                )
              )
            );
          }, "OpenQrCodeSigninMenuItem");
        wt.displayName = "OpenQrCodeSigninMenuItem";
        const Ta = (0, Fe.Ay)(wt);
        var Le = e(3245843483),
          qe = e(5267010247),
          na = e(8822892075),
          ga = e(5603851674),
          sa = e(1206744593),
          Aa = e(7148679525),
          Da = e(371109550),
          Nt = e(1632876296),
          ds = e(7763544542),
          ms = e(9026698167),
          us = e(7112191091),
          Es = e(7589743571),
          rn = e(3559837422),
          ps = e(5169892262),
          gs = e(6693783993),
          As = e(235108050);
        const Cs = c((N) => {
          if ((0, rn.sV)(N)) return [];
          const B = (0, gs.yw)(N),
            R = (0, ps.DH)(N, "stats_only_admins");
          return (0, As.A)([...R, ...B]);
        }, "getWorkspaceIdsOnWhichUserCanAccessWorkspaceAnalyticsInTeamSite");
        var hs = e(5651018374),
          vs = e(1680890044),
          fs = e(9697101230),
          Ps = e(7045483416),
          ln = e(5510392579),
          Is = e(7717529491),
          Os = e(5338283246),
          Ms = e(5934889916),
          Ts = e(9225229866),
          cn = e(2689960678),
          Ds = e(5112543963),
          ya = e(571104883),
          ys = e(322597465),
          Ss = e(3707193570),
          _n = e(160660242),
          Ns = e(529182726),
          dn = e(6280700824),
          Rs = e(9391594207),
          Ls = e(12753e4),
          mn = e(7138682671),
          un = e(2219904496),
          bs = e(8739505998),
          En = e(3165300465),
          pn = e(581167618);
        const Ct = new O.Ay("rename_team_in_client"),
          jt = {
            EditWorkspaceInfoModalContent: "edit_workspace_info_modal_content",
            EditWorkspaceInfoModalCancelButton:
              "edit_workspace_info_modal_cancel_button",
            EditWorkspaceInfoModalSaveButton:
              "edit_workspace_info_modal_save_button",
            EditWorkspaceInfoModalError: "edit_workspace_info_modal_error",
            EditWorkspaceInfoModalTeamNameInput:
              "edit_workspace_info_modal_team_name_input",
            EditWorkspaceInfoModalDomainInput:
              "edit_workspace_info_modal_domain_input",
          };
        var yt;
        (function (N) {
          (N.OpenedEditWorkspaceInfoModal = "edit_workspace_info_opened_modal"),
            (N.RenamedTeam = "edit_workspace_info_renamed_team"),
            (N.ChangedUrl = "edit_workspace_info_changed_url"),
            (N.UpdatedBoth =
              "edit_workspace_info_renamed_team_and_changed_url"),
            (N.FailedRenameTeam = "edit_workspace_info_failed_rename_team"),
            (N.FailedChangeUrl = "edit_workspace_info_failed_change_url"),
            (N.FailedBoth =
              "edit_workspace_info_failed_rename_team_and_change_url"),
            (N.ClickedCustomizeIcon = "edit_workspace_info_click_change_icon");
        })(yt || (yt = {}));
        var Vt;
        (function (N) {
          (N.EditWorkspaceInfoModal = "edit-workspace-info-modal"),
            (N.EditWorkspaceInfoEditUrlLink =
              "edit-workspace-info-edit-url-link"),
            (N.EditWorkspaceInfoModalSubmit = "edit-workspace-info-submit"),
            (N.EditWorkspaceInfoModalCancel = "edit-workspace-info-cancel");
        })(Vt || (Vt = {}));
        const ks = {
            elementName: Vt.EditWorkspaceInfoEditUrlLink,
            onClick: {
              enableClogAction: !0,
            },
          },
          Us = {
            elementName: Vt.EditWorkspaceInfoModalCancel,
            onClick: {
              enableClogAction: !0,
            },
          },
          Sa = {
            elementName: Vt.EditWorkspaceInfoModalSubmit,
            isPrimaryCTA: !0,
            onClick: {
              enableClogAction: !0,
            },
            isRenamingWorkspace: !1,
            isChangingUrl: !1,
          },
          Bs = /^[a-z0-9-.-]*$/,
          xs = /^[a-z0-9]/i,
          gn = 21,
          An = 50,
          Cn = c((N) => {
            let {
              updateWorkspaceInfo: B,
              closeModal: R,
              currentWorkspaceDomain: U,
              currentWorkspaceName: de,
              teamRootDomain: Ie,
              telemeter: ue,
            } = N;
            const [Oe, De] = (0, t.useState)(""),
              [me, Ue] = (0, t.useState)(!1),
              [ne, Ce] = (0, t.useState)(de),
              [He, $e] = (0, t.useState)(U);
            (0, t.useEffect)(() => {
              ue.count(yt.OpenedEditWorkspaceInfoModal);
            }, [ue]);
            const Ne = (0, t.useCallback)(
                (ft) => {
                  Oe && De(""), Ce(ft);
                },
                [Oe, Ce]
              ),
              Tt = (0, t.useCallback)(
                (ft) => {
                  Oe && De(""), $e(ft);
                },
                [Oe, $e]
              ),
              Pt = (0, t.useCallback)(() => {
                ue.count(yt.ClickedCustomizeIcon);
              }, [ue]),
              vt = (0, t.useCallback)(() => {
                Ue(!0);
                const ft = ne !== de ? ne : void 0,
                  Ft = He !== U ? He : void 0;
                let Dt, kt;
                ft && Ft
                  ? ((Dt = yt.UpdatedBoth), (kt = yt.FailedBoth))
                  : ft
                  ? ((Dt = yt.RenamedTeam), (kt = yt.FailedRenameTeam))
                  : ((Dt = yt.ChangedUrl), (kt = yt.FailedChangeUrl)),
                  B({
                    name: ft,
                    url: Ft,
                    reason: "rename_team_modal",
                  })
                    .then(() => {
                      ue.count(Dt), R();
                    })
                    .catch((pe) => {
                      var ut, It, Ut;
                      ue.count(kt),
                        Ue(!1),
                        !(
                          pe == null ||
                          (ut = pe.message) === null ||
                          ut === void 0
                        ) && ut.includes("bad_url")
                          ? De(
                              Ct.t(
                                "Your workspace URL can only contain lowercase letters, numbers and dashes. It must contain at least one letter. It may not start or end with a dash."
                              )
                            )
                          : !(
                              pe == null ||
                              (It = pe.message) === null ||
                              It === void 0
                            ) && It.includes("taken_url")
                          ? De(
                              Ct.t(
                                "That URL is unavailable. Please choose another."
                              )
                            )
                          : !(
                              pe == null ||
                              (Ut = pe.message) === null ||
                              Ut === void 0
                            ) && Ut.includes("team_name_too_long")
                          ? De(
                              Ct.t("That workspace name is too long. ", {
                                fallbackHash:
                                  "933690ea9d6ea311cd62c266cf3e6557da70df90",
                                fallbackHashNs: "message",
                              })
                            )
                          : De(
                              Ct.t(
                                "Something went wrong trying to update your workspace information. Please try again."
                              )
                            );
                    });
              }, [Ue, ne, de, He, U, R, B, ue]);
            let be;
            Bs.test(He)
              ? xs.test(He) ||
                (be = Ct.t(
                  "Your workspace URL must start with a letter or number."
                ))
              : (be = Ct.t(
                  "Your workspace URL can only contain lowercase letters, numbers and dashes."
                ));
            const Xt =
              !ne ||
              !He ||
              (ne === de && He === U) ||
              He.length > gn ||
              ne.length > An ||
              !!be;
            (Sa.isRenamingWorkspace = ne !== de && !!ne),
              (Sa.isChangingUrl = He !== U && !!He);
            const Ht = "edit_workspace_modal_title";
            return t.createElement(
              $.A,
              {
                elementName: Vt.EditWorkspaceInfoModal,
                elementType: r.ElementType.MODAL,
              },
              t.createElement(
                je.dW,
                {
                  closeModal: R,
                  "data-qa": jt.EditWorkspaceInfoModalContent,
                  labelledby: Ht,
                },
                t.createElement(
                  je.rQ,
                  {
                    id: Ht,
                  },
                  t.createElement(je.Rc, {
                    title: Ct.t("Edit workspace details"),
                  })
                ),
                t.createElement(
                  je.$m,
                  null,
                  t.createElement(
                    je.qf,
                    null,
                    t.createElement(
                      "div",
                      {
                        className: "margin_bottom_75",
                      },
                      Ct.t(
                        "Add a name to represent your company or organization. This name will also be shown to other organizations that you work with using Slack."
                      )
                    ),
                    t.createElement(
                      mn.A,
                      {
                        text: Ct.t("Workspace name"),
                        htmlFor: "desiredTeamName",
                      },
                      t.createElement(un.A, {
                        id: "desiredTeamName",
                        name: "desiredTeamName",
                        value: ne,
                        onChange: Ne,
                        maxCharacterLimit: An,
                        "data-qa": jt.EditWorkspaceInfoModalTeamNameInput,
                        autoFocus: !0,
                      })
                    ),
                    t.createElement(
                      mn.A,
                      {
                        text: Ct.t("URL"),
                        htmlFor: "desiredDomain",
                      },
                      t.createElement(un.A, {
                        id: "desiredDomain",
                        name: "desiredDomain",
                        value: He,
                        onChange: Tt,
                        hintText: Ct.t(
                          "Your workspace URL can only contain lowercase letters, numbers and dashes. It must contain at least one letter. It may not start or end with a dash."
                        ),
                        prefix: "https://",
                        suffix: `.${Ie}`,
                        maxCharacterLimit: gn,
                        errorText: be,
                        "data-qa": jt.EditWorkspaceInfoModalDomainInput,
                      })
                    ),
                    Oe &&
                      t.createElement(
                        pn.Ay,
                        {
                          level: "error",
                          "data-qa": jt.EditWorkspaceInfoModalError,
                        },
                        Oe
                      )
                  )
                ),
                t.createElement(
                  je.jl,
                  null,
                  t.createElement(
                    "div",
                    {
                      className: "p-rename_team_modal_edit_url_link",
                    },
                    t.createElement(
                      bs.A,
                      {
                        href: "/customize/icon",
                        autoClogProps: ks,
                        onClick: Pt,
                      },
                      Ct.t("Edit Workspace Icon")
                    )
                  ),
                  t.createElement(
                    je.ox,
                    {
                      className: "display_flex",
                    },
                    t.createElement(
                      T.Ay,
                      {
                        onClick: R,
                        type: "outline",
                        "data-qa": jt.EditWorkspaceInfoModalCancelButton,
                        autoClogProps: Us,
                      },
                      Ct.t("Cancel")
                    ),
                    t.createElement(
                      En.A,
                      {
                        loading: me,
                        "data-qa": jt.EditWorkspaceInfoModalSaveButton,
                        disabled: Xt,
                        onClick: vt,
                        autoClogProps: Sa,
                        "aria-label": Ct.t("Save"),
                      },
                      Ct.t("Save")
                    )
                  )
                )
              )
            );
          }, "EditWorkspaceInfoModal");
        Cn.displayName = "EditWorkspaceInfoModal";
        const Ws = c((N) => {
            const B = (0, u.H7)(N);
            var R;
            return {
              currentWorkspaceDomain:
                (R = (0, g.Ic)(B)) !== null && R !== void 0 ? R : "",
              currentWorkspaceName: (0, g.F1)(B),
              teamRootDomain: (0, g.S5)(B),
              telemeter: (0, he.Cy)({
                state: N,
              }),
            };
          }, "mapStateToProps"),
          Ks = c(
            (N) => ({
              closeModal: () => N((0, q.O)()),
              updateWorkspaceInfo: (B) => N((0, Ls.j)(B)),
            }),
            "mapDispatchToProps"
          ),
          Hs = (0, Rs.N)(Ws, Ks)(Cn),
          hn = (0, Se.Ay)("Opens the rename team modal in the client", (N) => {
            N(
              (0, At.q)({
                element: t.createElement(Hs, null),
              })
            );
          });
        hn.meta = {
          name: "createThunk",
          key: "createThunkopenRenameTeamModal",
          description: "Opens the rename team modal in the client",
        };
        const vn = hn;
        var Fs = e(6533394955),
          bt = e(716227588),
          Na = e(6473974991);
        function oa() {
          return (
            (oa =
              Object.assign ||
              function (N) {
                for (var B = 1; B < arguments.length; B++) {
                  var R = arguments[B];
                  for (var U in R)
                    Object.prototype.hasOwnProperty.call(R, U) && (N[U] = R[U]);
                }
                return N;
              }),
            oa.apply(this, arguments)
          );
        }
        c(oa, "home_header_menu_extends");
        const _e = new O.Ay("ia4"),
          Gs = new O.Ay("classic_nav"),
          zs = {
            [w.ze.WORKSPACE_MENU_UPGRADE_ITEM]: {
              component: t.lazy(() =>
                Promise.resolve().then(e.bind(e, 6761947926))
              ),
            },
          },
          fn = c((N) => {
            let { menuProps: B } = N;
            const R = (0, f.wA)(),
              U = (0, a.d4)(
                (j) =>
                  (0, ee._Z)(j, "ia4_admin_and_settings_translations") === "on"
              ),
              de = (0, a.d4)(
                (j) => (0, ee._Z)(j, "idsc_exports_admin_role_fe") === "on"
              ),
              Ie =
                (0, a.d4)((j) =>
                  (0, ee._Z)(j, "idsc_exports_admin_role_fe")
                ) === "on",
              ue =
                (0, a.d4)((j) => (0, ee._Z)(j, "flag_message_admin_dash")) ===
                "on",
              Oe = (0, a.d4)(
                (j) => (0, ee._Z)(j, "native_dlp_canvas") === "on"
              ),
              De = (0, a.d4)(
                (j) => (0, ee._Z)(j, "audit_logs_client") === "on"
              ),
              me = (0, a.d4)(sa.NH),
              Ue = (0, a.d4)(sa.pV),
              ne = (0, a.d4)(
                (j) => (0, ee._Z)(j, "integrations_admin_system_role") === "on"
              ),
              Ce = (0, a.d4)(
                (j) => (0, ee._Z)(j, "deprecate_email_signin") === "on"
              ),
              He = (0, a.d4)(
                (j) => (0, ee._Z)(j, "sfdc_seamless_auth_fe") === "on"
              ),
              $e = (0, a.d4)(
                (j) =>
                  (0, ee._Z)(j, "filter_conversations_menu_updates") === "on"
              ),
              Ne = (0, a.d4)(u.H7);
            var Tt;
            const Pt =
                (Tt = (0, g.ZT)(Ne)) !== null && Tt !== void 0 ? Tt : void 0,
              vt = (0, g.F1)(Ne),
              be = (0, g.Zl)(Ne),
              Xt = (0, a.d4)(Aa.Lz),
              Ht = (0, a.d4)(vs.W),
              ft = (0, a.d4)(ln.PY),
              Ft = (0, a.Z2)(us.Fm),
              Dt = (0, a.d4)(ln.p2),
              kt = (0, a.d4)(Is.k),
              pe = (0, g.r7)(Ne),
              ut = (0, Ss.JV)(Pt),
              It = (0, a.d4)(Ms.t_),
              Ut = (0, a.d4)(Da.U),
              fa = ft,
              ka = (0, a.d4)(ms.U),
              st = (0, a.d4)(Os.IF),
              Bo = (0, a.d4)(ga.h),
              xo = (0, a.d4)(Nt.xk),
              Wo = (0, a.d4)(Nt.zi),
              Ko = (0, a.d4)(Nt.p4),
              Ho = (0, a.d4)(Nt.zd),
              Fo = (0, a.d4)(ds.S),
              Go = (0, a.d4)(Nt.oM),
              zo = (0, a.d4)(Nt.Ak),
              Yo = (0, g.qR)(Ne),
              wo = (0, a.d4)((j) => (0, D.ty)(j, "purchaser")),
              Fn = (0, a.d4)(g.FH),
              Ua = (0, a.d4)(Es.N),
              Ba = (0, a.d4)(hs.g),
              xa = pe ? ft : Yo && (Dt || wo),
              Gn = `https://app.${(0, g.S5)(Ne)}/apps-manage/${
                Ne == null ? void 0 : Ne.id
              }/`,
              Qt = Dt && !pe,
              Pa = (0, a.d4)(M.ce),
              Wa = (0, a.d4)((j) => (0, D.ty)(j, "sidebar_behavior")),
              jo = (0, a.d4)(rn.sV),
              Ka = (0, a.d4)(Nt.B9),
              Vo = (0, a.d4)(Nt.wF),
              Zo = (0, a.d4)(Nt.lN),
              Ha = (0, a.Z2)(Cs),
              Fa = Ha.length > 0,
              Ga = (0, a.d4)(Ps._),
              zn = _e.rt("Tools & settings"),
              Yn = _e.rt("Tools"),
              wn = _e.rt("Settings"),
              ra = Ft.length > 0,
              la = ra || (pe && fa),
              za = !jo && (ra || Ua.length > 0 || Ba.length > 0),
              Ya = Ut,
              Xo = (0, a.d4)(fs.M),
              wa = ne && ut ? Xo : kt,
              Qo = ka,
              ja = st,
              Va = de && Bo,
              Za = Ie && xo,
              Xa = ue && Wo,
              Qa = Oe && Ko,
              $a = De && Fo,
              Ja = Ho,
              qa = (ut && Go) || (!ut && zo),
              en =
                Ya ||
                wa ||
                xa ||
                Qo ||
                ja ||
                Va ||
                Za ||
                Xa ||
                Ga ||
                $a ||
                Ja ||
                Qa ||
                qa,
              jn = la || en,
              tn = !!(0, a.d4)((j) =>
                (0, bt.Hp)(j, w.xu.WORKSPACE_MENU_SECONDARY_PLAN_INFO)
              ),
              $o = !!(0, a.d4)((j) =>
                (0, bt.Hp)(j, w.xu.WORKSPACE_MENU_PRIMARY_PLAN_INFO)
              ),
              an = !pe && $o,
              nn = !!(0, a.d4)(
                (j) =>
                  (0, bt.Hp)(j, w.xu.WORKSPACE_MENU_UPSELL) && !(0, Le.Z9F)()
              ),
              Jo = (0, a.d4)((j) => (0, bt.Hp)(j, w.xu.MAIN_MENU)),
              sn = (0, a.d4)((j) => (0, bt.OL)(j, w.xu.MAIN_MENU)),
              Ia = Jo === w.ze.PERSISTENT_MOBILE_PROMO,
              ia = sn == null ? void 0 : sn.signedInMobileOtherTeam,
              Vn =
                (0, a.d4)((j) =>
                  (0, bt.Hp)(j, w.xu.WORKSPACE_MENU_PRIMARY_PLAN_INFO)
                ) === w.ze.STRAIGHT_TO_PAID_WORKSPACE_MENU_PRIMARY_TIME_LIMIT,
              Zn = (0, t.useCallback)(() => {
                R((0, dn.A)());
              }, [R]),
              Xn = (0, t.useCallback)(() => {
                R(
                  (0, Ns.A)({
                    source: Ts.K3.TeamMenu,
                  })
                );
              }, [R]),
              Qn = (0, t.useCallback)(() => {
                R((0, q.O)());
              }, [R]),
              qo = (0, t.useCallback)(
                (j, at, ca) => () => {
                  R(
                    (0, At.q)({
                      element: t.createElement(Re.A, {
                        adminRoute: j,
                        closeModal: Qn,
                        title: at,
                        workspaceIds: ca,
                      }),
                    })
                  );
                },
                [Qn, R]
              ),
              Bt = ut ? qo : Me.A,
              Rt = (0, t.useCallback)(
                (j) => (ut ? void 0 : `${be}${j}`),
                [be, ut]
              );
            let Oa = `${be}manage/analytics`;
            Zo && !Vo && (Oa = `${Oa}/canvas`);
            const $n =
                "customize?utm_source=in-prod&utm_medium=inprod-customize_link-slack_menu-click",
              on =
                "apps/manage?utm_source=in-prod&utm_medium=inprod-apps_link-slack_menu-click",
              Jn = (0, t.useCallback)(
                () =>
                  ne
                    ? pe
                      ? `${be}manage/integrations?utm_source=in-prod&utm_medium=inprod-apps_link-slack_menu-click`
                      : `${be}${on}`
                    : Rt(on),
                [be, ne, Rt, pe]
              ),
              Gt = (0, t.useMemo)(() => {
                if (!za && !It && !Fa && !Ka) return cn.Ml;
                const j = _e.t("Customize workspace");
                return [
                  {
                    label: j,
                    show: za,
                    click: Bt($n, j, [...Ua, ...Ba]),
                    href: Rt($n),
                    key: "customize-workspace",
                    showLinkIndicatorIcon: !1,
                  },
                  {
                    click: () => {
                      R(
                        me
                          ? (0, qe.o)((0, na.x6)())
                          : (0, _n.A)({
                              source: "workspace_menu",
                              subPath: "",
                            })
                      );
                    },
                    label: _e.t("Workflow Builder"),
                    key: "launch-workflow-builder",
                    showLinkIndicatorIcon: !me,
                    show: It,
                  },
                  {
                    click: () =>
                      R(
                        (0, _n.A)({
                          source: "workspace_menu",
                          subPath: "/workflows-v1",
                        })
                      ),
                    label: me
                      ? _e.t("Legacy Workflow Management")
                      : "Legacy Workflow Management",
                    key: "launch-legacy-workflow-management",
                    showLinkIndicatorIcon: !0,
                    show: !Ue && me && It,
                  },
                  {
                    key: "workspace-analytics",
                    label: _e.t("Workspace analytics"),
                    click: Bt("stats", _e.t("Workspace analytics"), Ha),
                    href: Rt("stats"),
                    show: Fa,
                  },
                  {
                    key: "org-analytics",
                    label: _e.t("Organization analytics"),
                    href: `${Oa}`,
                    show: Ka,
                  },
                ].filter((at) => ("show" in at ? at.show !== !1 : !0));
              }, [za, It, Fa, Ka, Bt, Ua, Ba, Rt, me, Ue, Ha, Oa, R]),
              xt = (0, t.useMemo)(() => {
                if (!jn) return cn.Ml;
                const j = _e.rt("Workspace settings");
                return [
                  {
                    label: j,
                    click: Bt("admin/settings", j),
                    href: Rt("admin/settings"),
                    key: "workspace-settings",
                    showLinkIndicatorIcon: !1,
                    show: ra,
                  },
                  {
                    label: _e.t("Edit workspace details", {
                      fallbackHash: "77c33adfdac1c3ccaa95abf3a1c1a42c99935e68",
                      fallbackHashNs: "classic_nav",
                    }),
                    show: Qt,
                    click: () => R(vn()),
                    key: "edit-workspace-details",
                  },
                  {
                    label: _e.rt(
                      "Organization settings \u2013 {teamDisplayName}",
                      {
                        fallbackHash:
                          "89a2060bc73faa1446542140fe7536e0d41b726b",
                        teamDisplayName: vt,
                      }
                    ),
                    href: `${be}manage`,
                    key: "organization-settings",
                    showLinkIndicatorIcon: !1,
                    show: ut && ft,
                  },
                  {
                    type: n.y.separator,
                    key: "settings-administration-separator",
                    show: la,
                  },
                  {
                    type: n.y.header,
                    label: _e.t("Administration"),
                    key: "administration",
                    show: en,
                  },
                  {
                    label: He
                      ? _e.t("Manage Salesforce Organizations")
                      : _e.t("Manage Salesforce organizations"),
                    href: pe
                      ? `${be}manage/salesforce/organizations`
                      : `${be}admin/salesforce-organizations`,
                    key: "manage-salesforce-organizations",
                    showLinkIndicatorIcon: !1,
                    show: qa,
                  },
                  {
                    label: _e.t("Manage Slack Connect Invitations"),
                    show: Ya,
                    href:
                      pe && Ht
                        ? `${be}manage/slack-connect/requests-pending-invites`
                        : `${Fn}admin/slack-connect-invitations`,
                    key: "manage-slack-connect-invitations",
                    dataQa:
                      "main_menu_settings_submenu_manage_slack_connect_invitations",
                    showLinkIndicatorIcon: !1,
                  },
                  {
                    label: _e.rt("Manage members"),
                    click: Bt(
                      "admin",
                      U
                        ? _e.rt("Manage workspace members")
                        : _e.rt("Manage members")
                    ),
                    href: Rt("admin"),
                    key: "manage-members",
                    showLinkIndicatorIcon: !1,
                    show: ra,
                  },
                  {
                    label: U ? _e.rt("Manage roles") : _e.rt("Manage Roles"),
                    click: Bt(
                      "admin/roles",
                      U
                        ? _e.rt("Manage workspace roles")
                        : _e.rt("Manage Roles")
                    ),
                    href: Rt("admin/roles"),
                    key: "manage-roles",
                    showLinkIndicatorIcon: !1,
                    show: ja,
                  },
                  {
                    label: _e.rt("Manage apps"),
                    click: ne
                      ? Me.A
                      : Bt(
                          on,
                          U
                            ? _e.rt("Manage workspace apps")
                            : _e.rt("Manage apps")
                        ),
                    href: Jn(),
                    key: "manage-apps",
                    showLinkIndicatorIcon: !1,
                    show: wa,
                  },
                  {
                    label: _e.rt("Manage workflows"),
                    href: pe
                      ? `${be}manage/integrations/workflows`
                      : `${Gn}integrations/workflows`,
                    key: "manage-workflows",
                    showLinkIndicatorIcon: !1,
                    show: Ga,
                  },
                  {
                    label: _e.rt("Manage legal holds"),
                    href: `${be}manage/security/legal-holds`,
                    key: "manage-legal-holds",
                    showLinkIndicatorIcon: !1,
                    show: Ja,
                  },
                  {
                    label: de ? _e.t("Manage exports") : "",
                    href: `${be}manage/security/exports`,
                    key: "manage-exports-admin",
                    showLinkIndicatorIcon: !1,
                    show: Va,
                  },
                  {
                    label: Ie ? _e.t("Manage security") : "",
                    href: `${be}manage/security`,
                    key: "manage-security-admin",
                    showLinkIndicatorIcon: !1,
                    show: Za,
                  },
                  {
                    label: De ? _e.t("Manage Audit Logs") : "",
                    href: pe
                      ? `${be}manage/security/audit-logs`
                      : `${be}admin/audit_logs`,
                    key: "manage-audit-logs-admin",
                    showLinkIndicatorIcon: !1,
                    show: $a,
                  },
                  {
                    label: Oe ? _e.t("Manage DLP") : "",
                    href: `${be}manage/security/dlp`,
                    key: "manage-dlp-admin",
                    showLinkIndicatorIcon: !1,
                    show: Qa,
                  },
                  {
                    label: ue ? _e.t("Manage content") : "",
                    href: `${be}manage/security/flagged-content`,
                    key: "manage-content-admin",
                    showLinkIndicatorIcon: !1,
                    show: Xa,
                  },
                  {
                    label: _e.rt("Billing"),
                    href: pe ? `${be}manage/billing` : `${be}admin/billing`,
                    key: "billing",
                    showLinkIndicatorIcon: !1,
                    show: xa,
                  },
                ];
              }, [
                jn,
                Bt,
                Rt,
                ra,
                Qt,
                vt,
                be,
                ut,
                ft,
                la,
                en,
                Ya,
                pe,
                Ht,
                U,
                ja,
                ne,
                Jn,
                wa,
                Gn,
                Ga,
                Ja,
                de,
                Va,
                Ie,
                Za,
                De,
                $a,
                Oe,
                Qa,
                ue,
                Xa,
                xa,
                R,
                qa,
                Fn,
                He,
              ]),
              $t = (0, t.useCallback)(() => {
                const j = "open-desktop-app";
                return [
                  {
                    type: n.y.custom,
                    ariaHidden: !1,
                    children: t.createElement(pt, {
                      key: j,
                      showMobileEntryPoint: Ia,
                      teamUrl: be,
                    }),
                    show: !(0, ya.y3)() && !fe().chromeBook,
                    key: j,
                  },
                ];
              }, [be, Ia]),
              Ma = (0, t.useCallback)(() => {
                if (Ce) return [];
                const j = ia ? "sign-in-on-mobile" : "get-mobile-app";
                return [
                  {
                    type: n.y.custom,
                    ariaHidden: !1,
                    children: t.createElement(it.Ay, {
                      spaceName: w.xu.MAIN_MENU,
                      notifications: ge,
                      key: j,
                      showExistingHumansMobileEntry: ia,
                    }),
                    show: !0,
                    key: j,
                  },
                ];
              }, [Ce, ia]),
              Jt = (0, t.useCallback)(
                (j) => [
                  {
                    type: n.y.custom,
                    ariaHidden: !1,
                    children: t.createElement(Ta, {
                      key: "qr-code-signin-mobile",
                      teamDisplayName: vt,
                      showInSubMenu: j,
                    }),
                    show: (0, ys.O)(Pt) !== Ds.j.GOV,
                    key: "qr-code-signin-mobile",
                  },
                ],
                [vt, Pt]
              ),
              qn = (0, t.useCallback)(
                () =>
                  Ce
                    ? [
                        ...$t(),
                        ...Ma(),
                        {
                          type: n.y.separator,
                          show: !0,
                          key: "sign-out-separator",
                        },
                        ...Jt(),
                      ]
                    : ia
                    ? [
                        ...$t(),
                        {
                          label: Gs.rt("Sign in on mobile", {
                            fallbackHash:
                              "648468ff942deda0826e667407776fe77f12f76d",
                            teamDisplayName: vt,
                          }),
                          type: n.y.submenu,
                          key: "sign-in-mobile-submenu",
                          template: [...Jt(!0), ...Ma()],
                          show: !0,
                        },
                      ]
                    : [
                        ...$t(),
                        ...Ma(),
                        {
                          type: n.y.separator,
                          show: !0,
                          key: "sign-out-separator",
                        },
                        ...Jt(),
                      ],
                [Ce, ia, vt, $t, Ma, Jt]
              ),
              es = c((j) => {
                switch (j) {
                  case o.UN:
                    return r.EventId.HOME_FILTER_ALL_ACTIVITY;
                  case o.nU:
                    return r.EventId.HOME_FILTER_UNREADS_ONLY;
                  case o.Ao:
                    return r.EventId.HOME_FILTER_MENTIONS_ONLY;
                  case o.eF:
                    return r.EventId.HOME_FILTER_CUSTOM_BY_SECTION;
                  case P.E7.All:
                    return r.EventId.HOME_FILTER_EVERYONE;
                  case P.E7.Internal:
                    return r.EventId.HOME_FILTER_WITHOUT_EXTERNAL;
                  case P.E7.External:
                    return r.EventId.HOME_FILTER_INCLUDE_EXTERNAL;
                  default:
                    return r.EventId.UNKNOWN;
                }
              }, "getClogEventIdForEntry"),
              ts = (0, t.useCallback)(function () {
                let j =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : P.E7.All,
                  at = null;
                switch (j) {
                  case P.E7.Internal:
                    at = _e.t("Without external people");
                    break;
                  case P.E7.External:
                    at = _e.t("Including external people");
                    break;
                  default:
                    at = _e.t("Everyone");
                }
                return at;
              }, []),
              as = (0, t.useCallback)(
                (j) => {
                  R(
                    (0, m.UG)({
                      peopleFilter: {
                        type: j,
                      },
                    })
                  );
                },
                [R]
              ),
              ns = (0, t.useMemo)(
                () => [P.E7.All, P.E7.Internal, P.E7.External],
                []
              ),
              ss = (0, t.useCallback)(() => {
                const j = Pa == null ? void 0 : Pa.type;
                return ns.map((at) => ({
                  label: ts(at),
                  type: n.y.checkbox,
                  click: () => as(at),
                  checked: (!j && at === P.E7.All) || j === at,
                  autoClogProps: {
                    onClick: {
                      enableClogAction: !0,
                    },
                    eventId: es(at),
                  },
                }));
              }, [ts, as, Pa, ns]),
              os = (0, t.useCallback)(
                (j) => {
                  R(
                    (0, y.AZ)({
                      pref: "sidebar_behavior",
                      value: j,
                    })
                  );
                },
                [R]
              ),
              rs = (0, t.useMemo)(() => [o.UN, o.nU, o.Ao, o.eF], []),
              ls = (0, t.useCallback)(function () {
                let j =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : o.UN,
                  at = null;
                switch (j) {
                  case o.nU:
                    at = _e.t("Unreads only");
                    break;
                  case o.Ao:
                    at = _e.t("Mentions only");
                    break;
                  case o.eF:
                    at = _e.t("Custom by section");
                    break;
                  default:
                    at = _e.t("All activity");
                }
                return at;
              }, []),
              is = (0, t.useCallback)(
                () => [
                  ...rs.map((j) => ({
                    label: ls(j),
                    type: n.y.checkbox,
                    click: () => os(j),
                    checked: (!Wa && j === o.UN) || Wa === j,
                    autoClogProps: {
                      onClick: {
                        enableClogAction: !0,
                      },
                      eventId: es(j),
                    },
                  })),
                ],
                [ls, os, Wa, rs]
              ),
              er = (0, t.useMemo)(() => {
                let j = zn;
                Gt.length && !xt.length && (j = Yn),
                  !Gt.length && xt.length && (j = wn);
                const ca = [
                    {
                      children: t.createElement(Ye.A, {
                        key: "team-blurb-menu-item",
                        isMenuItem: Qt,
                        ariaDescribedById: "team-blurb-text",
                      }),
                      type: Qt ? void 0 : n.y.custom,
                      key: "team-blurb-menu-item",
                      click: () => (Qt ? R(vn()) : void 0),
                    },
                    {
                      type: n.y.separator,
                      key: "upsell-separator-top",
                      show: nn,
                    },
                    {
                      type: n.y.custom,
                      ariaHidden: !1,
                      children: t.createElement(it.sl, {
                        key: "workspace-menu-upsell",
                        uiPage: r.UiPage.MAIN_MENU,
                        notifications: zs,
                        spaceName: w.xu.WORKSPACE_MENU_UPSELL,
                        showDescription: !0,
                      }),
                      key: "workspace-menu-upsell",
                      show: nn,
                    },
                    {
                      type: n.y.separator,
                      key: "primary-plan-info-separator-top",
                    },
                    {
                      type: n.y.custom,
                      ariaHidden: !1,
                      children: t.createElement(
                        it.sl,
                        oa(
                          {
                            key: "workspace-menu-primary-plan-info",
                          },
                          Je
                        )
                      ),
                      key: "workspace-menu-primary-plan-info",
                      show: an,
                    },
                    {
                      type: n.y.separator,
                      key: "primary-plan-info-separator-bottom",
                      show: an && !Vn,
                    },
                    {
                      type: n.y.custom,
                      ariaHidden: !1,
                      children: t.createElement(
                        it.sl,
                        oa(
                          {
                            key: "workspace-menu-secondary-plan-info",
                          },
                          Pe
                        )
                      ),
                      key: "workspace-menu-secondary-plan-info",
                      show: tn,
                    },
                    {
                      type: n.y.separator,
                      key: "secondary-plan-info-separator-bottom",
                      show: tn,
                    },
                    {
                      label: _e.rt("Invite people to {teamDisplayName}", {
                        teamDisplayName: vt,
                      }),
                      click: Xn,
                      show: Xt,
                      key: "invite-people",
                      autoClogProps: {
                        elementName: "team_menu_invite_people",
                        onClick: {
                          enableClogAction: !0,
                        },
                      },
                    },
                    {
                      type: n.y.separator,
                      show: Xt,
                      key: "invite-people-separator",
                    },
                    {
                      label: _e.rt("Preferences"),
                      click: Zn,
                      shortcut: (0, ya.cX)() && (0, ya.y3)() && "\u2318,",
                      key: "sidebar-preferences",
                    },
                    {
                      type: n.y.submenu,
                      label: $e ? _e.rt("Filter sidebar") : "",
                      key: "filter-sidebar",
                      show: $e,
                      template: [
                        {
                          type: n.y.submenu,
                          label: _e.rt("Activity"),
                          key: "filter-activity",
                          show: $e,
                          template: is(),
                        },
                        {
                          type: n.y.submenu,
                          label: $e ? _e.rt("People") : "",
                          key: "filter-people",
                          show: $e,
                          template: ss(),
                        },
                      ].filter((Wt) => ("show" in Wt ? Wt.show !== !1 : !0)),
                    },
                    {
                      label: j,
                      type: n.y.submenu,
                      show: Gt.length > 0 || xt.length > 0,
                      key: "tools-and-settings-submenu",
                      template: [
                        {
                          type: n.y.header,
                          label: _e.rt("Tools"),
                          show: Gt.length > 0 && xt.length > 0,
                          key: "tools-header",
                        },
                        ...Gt,
                        {
                          type: n.y.separator,
                          show: Gt.length > 0 && xt.length > 0,
                          key: "tools-bottom-separator",
                        },
                        {
                          type: n.y.header,
                          label: _e.rt("Settings"),
                          show: la && xt.length > 0,
                          key: "settings-header",
                        },
                        ...xt,
                      ].filter((Wt) => ("show" in Wt ? Wt.show !== !1 : !0)),
                    },
                  ],
                  cs = {
                    label: _e.rt("Sign out"),
                    key: "sign-out",
                    shortcut: "",
                    click: () =>
                      (0, Fs.dispatchForClientStore)(
                        Na.H === null || Na.H === void 0
                          ? void 0
                          : (0, Na.H)({
                              teamId: Pt,
                            })
                      ),
                  },
                  _s = {
                    label: _e.rt("Join or leave workspaces", {
                      fallbackHash: "6f729817a58c0cb75dc807b9771f19119fced3cc",
                      fallbackHashNs: "enterprise_dashboard",
                    }),
                    show: pe,
                    key: "join-leave-workspaces",
                    href: be,
                    click: () => {},
                  };
                return (
                  Ia
                    ? ca.push(
                        {
                          type: n.y.separator,
                          show: !0,
                          key: "native-apps-separator",
                        },
                        ...qn(),
                        _s,
                        cs
                      )
                    : ca.push(
                        {
                          type: n.y.separator,
                          key: "workspace-tools-separator",
                          show: !0,
                        },
                        ...Jt(),
                        _s,
                        cs,
                        ...$t()
                      ),
                  ca.filter((Wt) => ("show" in Wt ? Wt.show !== !1 : !0))
                );
              }, [
                zn,
                Gt,
                xt,
                vt,
                nn,
                an,
                tn,
                Xn,
                Xt,
                Zn,
                la,
                Ia,
                Yn,
                wn,
                Pt,
                qn,
                Jt,
                $t,
                pe,
                be,
                Qt,
                R,
                Vn,
                is,
                ss,
                $e,
              ]);
            return t.createElement(
              h.a,
              oa({}, B, {
                menuClassNames: "p-ia4_home_header_menu__menu",
                "aria-label": _e.t("{teamDisplayName} Actions", {
                  teamDisplayName: vt,
                  fallbackHash: "f0b9c8a7e7825e826adb6a5ac5e29ee7ae2281a2",
                }),
                template: er,
              })
            );
          }, "HomeHeaderMenu");
        fn.displayName = "HomeHeaderMenu";
        const Pn = c(() => {
          const N = (0, t.useCallback)(
              (U) =>
                t.createElement(fn, {
                  menuProps: U,
                }),
              []
            ),
            B = (0, a.d4)(u.H7),
            R = (0, g.F1)(B);
          return t.createElement(
            h.cQ,
            {
              renderMenu: N,
              position: "bottom-left",
            },
            t.createElement(
              T.Nm,
              {
                className: "p-ia4_home_header_menu__button",
                "aria-label": _e.t("{teamDisplayName} Actions", {
                  teamDisplayName: R,
                  fallbackHash: "f0b9c8a7e7825e826adb6a5ac5e29ee7ae2281a2",
                }),
                "data-qa": "workspace_actions_button",
              },
              t.createElement(
                "span",
                {
                  className: "p-ia4_home_header_menu__team_name",
                },
                R
              ),
              t.createElement(E.A, {
                name: "caret-down",
                "aria-label": "caret-down",
              })
            )
          );
        }, "HomeHeaderMenuTrigger");
        Pn.displayName = "HomeHeaderMenuTrigger";
        const ar = null;
        var Ys = e(5055839243),
          Ra = e(5734745215),
          ws = e(1427522952),
          js = e(8029613601),
          In = e(4947127560),
          On = e(4636370173),
          Mn = e(8523371695),
          Tn = e(3606117573),
          Dn = e(3602521375),
          yn = e(5737676300),
          Vs = e(8285458961),
          Ca = e(2409757433),
          Sn = e(320067417),
          Zs = e(6690200241),
          Xs = e(1320149267),
          Qs = e(2683115972);
        const Zt = new Ra.Ay("salesforce_connections"),
          Nn = c((N) => {
            let {
              orgs: B,
              mainText: R,
              closeDialog: U,
              setNextStep: de,
              dismissSignInReminder: Ie,
            } = N;
            const ue = (0, a.d4)(
                ($e) => (0, ee._Z)($e, "sfdc_seamless_auth_fe") === "on"
              ),
              [Oe, De, me] = (0, Zs.q)(),
              [Ue, ne] = (0, t.useState)(""),
              Ce = (0, t.useCallback)(() => {
                const {
                  salesforce_org_id: $e = "",
                  name: Ne = "",
                  app_id: Tt = "",
                  provider_key: Pt = "",
                } = B.find((vt) => vt.salesforce_org_id === Ue) || {};
                me(
                  {
                    appId: Tt,
                    providerKey: Pt,
                    salesforceOrgId: $e,
                  },
                  () =>
                    de({
                      orgName: Ne,
                    })
                );
              }, [me, B, Ue, de]),
              He = (0, t.useCallback)(() => {
                Ie(), U();
              }, [U, Ie]);
            return t.createElement(
              t.Fragment,
              null,
              t.createElement(
                js.A,
                null,
                t.createElement(In.A, {
                  title: ue
                    ? Zt.t("Sign in to a Salesforce org")
                    : "Sign in to a Salesforce org",
                })
              ),
              t.createElement(
                On.A,
                null,
                t.createElement(
                  Sn.a,
                  {
                    paddingInline: "150",
                  },
                  t.createElement(
                    yn.B,
                    {
                      space: "150",
                    },
                    De &&
                      t.createElement(
                        pn.Ay,
                        {
                          type: "boxed",
                          level: "error",
                          icon: "info-circle",
                          heading: ue
                            ? Zt.t(
                                "There was a problem requesting your Salesforce connection"
                              )
                            : "There was a problem requesting your Salesforce connection",
                        },
                        (0, Xs.Q)()
                      ),
                    R &&
                      t.createElement(
                        Ca.E,
                        {
                          as: "p",
                        },
                        R
                      ),
                    t.createElement(Vs.v, {
                      defaultCheckedOrgId: Ue,
                      orgs: B,
                      onOrgSelect: ne,
                    }),
                    t.createElement(
                      Ca.E,
                      {
                        color: "Core/Content/Secondary",
                        size: "caption",
                      },
                      ue
                        ? Zt.t(
                            "To sign in to orgs not listed here, contact your admin."
                          )
                        : "To sign in to orgs not listed here, contact your admin."
                    )
                  )
                )
              ),
              t.createElement(
                Mn.A,
                null,
                t.createElement(
                  Qs.Ay,
                  {
                    type: "outline",
                    onClick: He,
                  },
                  ue
                    ? Zt.t("Dismiss Sign In Reminder")
                    : "Dismiss Sign In Reminder"
                ),
                t.createElement(
                  Tn.A,
                  null,
                  t.createElement(
                    Dn.A,
                    {
                      onClick: U,
                      type: "outline",
                    },
                    ue ? Zt.t("Not Now") : "Not Now"
                  ),
                  t.createElement(
                    En.A,
                    {
                      loading: Oe,
                      type: "primary",
                      disabled: !Ue,
                      onClick: Ce,
                    },
                    ue ? Zt.t("Continue") : "Continue"
                  )
                )
              )
            );
          }, "SelectSalesforceOrg");
        Nn.displayName = "SelectSalesforceOrg";
        var $s = e(6044196829),
          Js = e(3579140003),
          qs = e.n(Js),
          eo = e(4829524689);
        const ha = new Ra.Ay("salesforce_connections"),
          to = c(
            (N) => (B) => {
              let { text: R } = B;
              return t.createElement(
                $s.A,
                {
                  onClick: N,
                },
                R
              );
            },
            "getManageUserSFConnectionsLink"
          ),
          Rn = c((N) => {
            let {
              orgName: B,
              isMoreOrgsToSignIn: R,
              closeDialog: U,
              setSelectSalesforceOrgStep: de,
              openSalesforcePreferences: Ie,
              experimentSfdcSeamlessAuthFeGroupOn: ue,
            } = N;
            const Oe = (0, t.useCallback)(() => {
              R ? de() : U();
            }, [U, R, de]);
            return t.createElement(
              t.Fragment,
              null,
              t.createElement(
                On.A,
                null,
                t.createElement(eo.A, {
                  src: qs(),
                }),
                t.createElement(In.A, {
                  title: ue
                    ? ha.t("\u2705 You\u2019re all set")
                    : "\u2705 You\u2019re all set",
                }),
                t.createElement(
                  Sn.a,
                  {
                    paddingInline: "150",
                  },
                  t.createElement(
                    yn.B,
                    {
                      space: "75",
                    },
                    t.createElement(
                      Ca.E,
                      {
                        as: "p",
                      },
                      ue
                        ? ha.t(
                            "Now that you\u2019re signed in to {orgName}, you can keep track of all the deals you care about \u2014 right in Slack.",
                            {
                              orgName: B,
                            }
                          )
                        : `Now that you\u2019re signed in to ${B}, you can keep track of all the deals you care about \u2014 right in Slack.`
                    ),
                    t.createElement(
                      Ca.E,
                      {
                        as: "p",
                      },
                      ue
                        ? ha.rt(
                            "Manage your Salesforce account connections <link>here</link>.",
                            {
                              "<link>": to(Ie),
                            }
                          )
                        : "Manage your Salesforce account connections here."
                    )
                  )
                )
              ),
              t.createElement(
                Mn.A,
                null,
                t.createElement(
                  Tn.A,
                  null,
                  t.createElement(
                    Dn.A,
                    {
                      onClick: Oe,
                      type: "primary",
                    },
                    ue ? ha.t("Done") : "Done"
                  )
                )
              )
            );
          }, "SignInSuccess");
        Rn.displayName = "SignInSuccess";
        var ao = e(1063683520),
          no = e(3385422400),
          so = e(9785228405);
        const Ln = (0, We.Ay)((N) => N.salesforceConnections.organizations);
        Ln.meta = {
          name: "createSelector",
          key: "createSelectorselectSalesforceOrganizations",
          description: (N) => N.salesforceConnections.organizations,
        };
        const bn = (0, no.Mz)(Ln, so.N),
          La = new Ra.Ay("salesforce_connections"),
          kn = "select-org",
          oo = "sign-in-success",
          Un = c((N) => {
            let { dismissSignInReminder: B } = N;
            const R = (0, a.d4)(
                (Ue) => (0, ee._Z)(Ue, "sfdc_seamless_auth_fe") === "on"
              ),
              U = (0, f.wA)(),
              de = (0, a.d4)(bn),
              Ie = (0, t.useCallback)(() => {
                U((0, q.O)());
              }, [U]),
              ue = (0, t.useCallback)(() => {
                U(
                  (0, dn.A)({
                    activeSection: ao._.salesforce,
                  })
                );
              }, [U]),
              Oe = R
                ? La.t(
                    "You have access to the Salesforce orgs listed here. Select an org you\u2019d like access to in Slack. After you sign in to the first org, you\u2019ll have the chance to sign in to another one."
                  )
                : "You have access to the Salesforce orgs listed here. Select an org you\u2019d like access to in Slack. After you sign in to the first org, you\u2019ll have the chance to sign in to another one.",
              De = R
                ? La.t(
                    "Select the Salesforce org you\u2019d like access to in Slack."
                  )
                : "Select the Salesforce org you\u2019d like access to in Slack.",
              me = (0, t.useMemo)(() => {
                const Ue = R
                  ? La.t("Sign in to a Salesforce org")
                  : "Sign in to a Salesforce org";
                return {
                  "select-org": {
                    render: (ne) => {
                      let { mainText: Ce = Oe, switchPane: He } = ne;
                      return t.createElement(Nn, {
                        orgs: de,
                        mainText: Ce,
                        closeDialog: Ie,
                        dismissSignInReminder: B,
                        setNextStep: ($e) => He(oo, $e),
                      });
                    },
                    modalProps: {
                      centered: !0,
                      contentLabel: Ue,
                    },
                  },
                  "sign-in-success": {
                    render: (ne) => {
                      let { orgName: Ce, switchPane: He } = ne;
                      return t.createElement(Rn, {
                        orgName: Ce,
                        isMoreOrgsToSignIn: de.length > 0,
                        closeDialog: Ie,
                        setSelectSalesforceOrgStep: () =>
                          He(kn, {
                            mainText: De,
                          }),
                        openSalesforcePreferences: ue,
                        experimentSfdcSeamlessAuthFeGroupOn: R,
                      });
                    },
                    modalProps: {
                      closeButtonTone: "dark",
                      centered: !0,
                      contentLabel: Ue,
                    },
                  },
                };
              }, [R, Oe, de, Ie, B, ue, De]);
            return t.createElement(ws.A, {
              defaultPane: kn,
              panes: me,
              closeModal: Ie,
            });
          }, "SignIntoSalesforceOrgDialog");
        Un.displayName = "SignIntoSalesforceOrgDialog";
        const Bn = c(() => {
          const N = (0, f.wA)(),
            B = c((R) => {
              let { dismissSignInReminder: U } = R;
              N(
                (0, At.q)({
                  element: t.createElement(Un, {
                    dismissSignInReminder: U,
                  }),
                })
              );
            }, "openSalesforceSignInDialog");
          return (B.displayName = "openSalesforceSignInDialog"), B;
        }, "useOpenSalesforceSignInDialog");
        Bn.displayName = "useOpenSalesforceSignInDialog";
        var ro = e(289112722),
          lo = e(8624014077),
          io = e(5071438952),
          co = e(535424668);
        const _o = c(() => {
            const N = (0, f.wA)(),
              B = (0, a.d4)(bn),
              R = (0, t.useCallback)(
                (0, rt.coroutine)(function* () {
                  try {
                    const U = yield N((0, co.n)());
                    N((0, io.Z)(U));
                  } catch {
                    (0, lt.Ay)({
                      label: "SALESFORCE-CONNECTIONS",
                    }).error(
                      new Error(
                        "Error thrown when executing calls to sfdc.integration.listOrgs and sfdc.integration.authUser from SalesforceSignIn "
                      )
                    );
                  }
                }),
                [N]
              );
            return (
              (0, t.useEffect)(() => {
                R();
              }, [R]),
              B
            );
          }, "useFetchOrgsAndSignInSilently"),
          xn = c((N) => {
            let { experimentSfdcSeamlessAuthFeGroupOn: B } = N;
            const R = _o(),
              [U, de] = (0, lo.r)(ro.A, "visible"),
              Ie = (0, t.useCallback)(() => {
                de("hidden");
              }, [de]),
              ue = Bn(),
              Oe = (0, t.useCallback)(() => {
                ue({
                  dismissSignInReminder: Ie,
                });
              }, [ue, Ie]);
            return !R.length || U === "hidden"
              ? null
              : t.createElement(Ys._, {
                  onSignIn: Oe,
                  experimentSfdcSeamlessAuthFeGroupOn: B,
                });
          }, "SalesforceSignIn");
        xn.displayName = "SalesforceSignIn";
        var Wn = e(352142497),
          Kn = e(4899054948);
        const mo = t.lazy(() => Promise.resolve().then(e.bind(e, 4698264567))),
          uo = t.lazy(() => Promise.resolve().then(e.bind(e, 3540014338))),
          Eo = t.lazy(() => Promise.resolve().then(e.bind(e, 1720631741))),
          po = t.lazy(() => Promise.resolve().then(e.bind(e, 6046495019))),
          go = t.lazy(() => Promise.resolve().then(e.bind(e, 629068863))),
          Ao = t.lazy(() => Promise.resolve().then(e.bind(e, 2811650336))),
          Co = t.lazy(() => Promise.resolve().then(e.bind(e, 8317025457))),
          ho = t.lazy(() => Promise.resolve().then(e.bind(e, 7205738127))),
          vo = t.lazy(() => Promise.resolve().then(e.bind(e, 3566375448))),
          fo = t.lazy(() =>
            Promise.resolve()
              .then(e.bind(e, 9949873423))
              .then((N) => ({
                default: N.SlackAiSidebarTrialOfferCta,
              }))
          ),
          Po = t.lazy(() =>
            Promise.resolve()
              .then(e.bind(e, 6962982910))
              .then((N) => ({
                default: N.PNPSidebarBadgeBanner,
              }))
          ),
          Io = t.lazy(() =>
            Promise.resolve()
              .then(e.bind(e, 784529096))
              .then((N) => ({
                default: N.TrialEndPromoDiscountSidebarCta,
              }))
          ),
          Oo = t.lazy(() => Promise.resolve().then(e.bind(e, 5684595131))),
          Mo = t.lazy(() => Promise.resolve().then(e.bind(e, 7328268421))),
          To = t.lazy(() => Promise.resolve().then(e.bind(e, 4061500210))),
          Do = {
            spaceName: w.xu.SIDEBAR_MENU_HEADER,
            notifications: {
              [w.ze.STRAIGHT_TO_PAID_SIDEBAR_MENU_HEADER_OFFER_CTA]: {
                component: Eo,
              },
              [w.ze.SIDEBAR_BENEFITS_ACTIVE_TRIAL_TAB_MENU_HEADER]: {
                component: uo,
              },
              [w.ze.SIDEBAR_MENU_HEADER_UPGRADE_CTA]: {
                component: mo,
              },
              [w.ze.SUPPORT_UPGRADE_DECISION_TRIAL_USAGE_SIDEBAR_MENU_HEADER]: {
                component: po,
              },
              [w.ze.SLACK_AI_TRIAL_AWARENESS_SIDEBAR_MENU_HEADER]: {
                component: t.lazy(() =>
                  Promise.resolve()
                    .then(e.bind(e, 3998269055))
                    .then((N) => ({
                      default: N.SlackAITrialAwarenessSidebarBadge,
                    }))
                ),
              },
              [w.ze.SIDEBAR_MENU_HEADER_SLACK_AI_NFX_CTA]: {
                component: Ao,
              },
              [w.ze.SLACK_AI_SIDEBAR_PURCHASE_CTA]: {
                component: Co,
              },
              [w.ze
                .JOINER_LAUNCHPAD_RESURRECTED_USER_WELCOME_SIDEBAR_MENU_HEADER]:
                {
                  component: go,
                },
              [w.ze.LISTS_WELCOME_TO_LISTS_HOME_BANNER]: {
                component: ho,
              },
              [w.ze.VOLUME_DISCOUNT_HALFWAY_PROMO_BANNER]: {
                component: vo,
              },
              [w.ze.SLACK_AI_TRIAL_OFFER_SIDEBAR_CTA]: {
                component: fo,
              },
              [w.ze.PNP_SIDEBAR]: {
                component: Po,
              },
              [w.ze.PROMOTIONAL_DISCOUNTS_SIDEBAR_MENU_HEADER_CTA]: {
                component: Io,
              },
              [w.ze.EDUCATION_CREATE_CUSTOM_SECTIONS]: {
                component: Oo,
              },
              [w.ze.EDUCATION_SIDEBAR_SWEEPER]: {
                component: Mo,
              },
              [w.ze.SOLUTIONS_WELCOME_TO_SOLUTIONS_HOME_SIDEBAR_BANNER]: {
                component: To,
              },
            },
          };
        var yo = e(5519146941),
          So = e(1931938858),
          Mt = e(4240442510),
          No = e(4469810895),
          va = e(3474336343),
          Ro = e(5873629730),
          Hn = e(2832209848),
          Lo = e(5492559860),
          ve = e(3193155968);
        function ba() {
          return (
            (ba =
              Object.assign ||
              function (N) {
                for (var B = 1; B < arguments.length; B++) {
                  var R = arguments[B];
                  for (var U in R)
                    Object.prototype.hasOwnProperty.call(R, U) && (N[U] = R[U]);
                }
                return N;
              }),
            ba.apply(this, arguments)
          );
        }
        c(ba, "sidebar_header_extends");
        const Kt = new O.Ay("ia4"),
          bo = [
            ve.k6.Home,
            ve.k6.DMs,
            ve.k6.Activity,
            ve.k6.Later,
            ve.k6.SalesHome,
          ],
          ko = c((N) => bo.includes(N), "isTopLevelTab");
        function Uo(N) {
          let { renderControls: B, isChannelListOverflowing: R } = N;
          const U = (0, f.wA)(),
            de = (0, a.d4)(
              (st) => (0, ee._Z)(st, "view_header_overflow_borders") === "on"
            ),
            Ie = (0, a.d4)(
              (st) => (0, ee._Z)(st, "files_explorer_prototype") === "on"
            ),
            ue = (0, a.d4)(Ro.OT),
            Oe = (0, a.d4)(
              (st) => (0, ee._Z)(st, "sfdc_seamless_auth_fe") === "on"
            ),
            {
              windowId: De,
              activeTab: me,
              getSiblingView: Ue,
            } = (0, t.useContext)(yo.A),
            ne = (0, a.d4)((st) =>
              Ue(st, {
                container: ve.mq.Sidebar,
              })
            ),
            Ce = De !== ve.N2,
            He = (0, a.d4)(u.H7),
            $e = (0, a.d4)((st) =>
              (0, va.Li)(st, {
                getSiblingView: Ue,
              })
            ),
            Ne = (0, a.d4)((st) =>
              (0, va.N1)(st, {
                getSiblingView: Ue,
              })
            ),
            Tt = (0, a.d4)((st) =>
              (0, va.g6)(st, {
                getSiblingView: Ue,
              })
            ),
            Pt = (0, a.d4)(va.eF),
            be = (ue && Tt) || Ne ? Pt : (0, g.F1)(He),
            Ht =
              (0, a.d4)((st) => (0, bt.Hp)(st, w.xu.SIDEBAR_MENU_HEADER)) ===
                w.ze.SIDEBAR_MENU_HEADER_UPGRADE_CTA || !(0, Le.Z9F)(),
            ft = (0, a.d4)(
              (st) =>
                (0, bt.Hp)(st, w.xu.SIDEBAR_MENU_HEADER) ===
                w.ze.SUPPORT_UPGRADE_DECISION_TRIAL_USAGE_SIDEBAR_MENU_HEADER
            ),
            Ft = (0, a.d4)(No.mU),
            Dt = (0, ve.Zu)(me);
          (0, t.useEffect)(() => {
            Ft &&
              U(
                (0, Lo.b)({
                  interactions: [
                    {
                      component: Hn.G7.PaidBenefitsPage,
                      type: Hn.X8.Impression,
                    },
                  ],
                  reason: "benefits-sidebar-link",
                })
              );
          }, [U, Ft]);
          const kt = (0, t.useCallback)(() => U((0, qe.o)((0, na.JJ)())), [U]);
          let pe = null,
            ut,
            It = B ? B() : null;
          switch (!0) {
            case me === ve.k6.Home:
              (pe = $e
                ? be
                : t.createElement(
                    Kn.A,
                    {
                      subtype: "home-header-menu",
                    },
                    t.createElement(Pn, null)
                  )),
                (It = t.createElement(z, {
                  isSetupPage: $e,
                }));
              break;
            case me === ve.k6.DMs:
              pe = t.createElement(s.w, null);
              break;
            case me === ve.k6.Activity:
              pe = Kt.t("Activity");
              break;
            case me === ve.k6.Later:
              pe = Kt.t("Later");
              break;
            case me === ve.k6.SalesHome:
              pe = Kt.t("Sales");
              break;
            case me === ve.k6.Browse:
              pe = Kt.t("Browse");
              break;
            case me === ve.k6.Search:
              pe = (0, Mt.A)({
                tab: ve.k6.Search,
              });
              break;
            case me === ve.k6.Files:
              pe = (0, Mt.A)({
                tab: ve.k6.Files,
              });
              break;
            case me === ve.k6.Lists:
              pe = (0, Mt.A)({
                tab: ve.k6.Lists,
              });
              break;
            case me === ve.k6.Todos:
            case Ce && (ne == null ? void 0 : ne.id) === Wn.D.MoreTodosSidebar:
              pe = (0, Mt.A)({
                tab: ve.k6.Todos,
              });
              break;
            case me === ve.k6.ExternalConnections:
              pe = Kt.t("External connections", {
                fallbackHash: "ffe740c3e742622ea4e92503c4f06ce40984d073",
              });
              break;
            case Dt: {
              const st = (0, ve.CI)(me);
              (pe = t.createElement(
                Kn.A,
                {
                  subtype: "event-header-menu",
                },
                t.createElement(i, {
                  externalWorkspaceId: st,
                })
              )),
                (ut = t.createElement(
                  T.Nm,
                  {
                    onClick: kt,
                    className: "p-ia4_sidebar_header__subtitleLink",
                  },
                  Kt.t("All external connections", {
                    fallbackHash: "ffe740c3e742622ea4e92503c4f06ce40984d073",
                  })
                ));
              break;
            }
            case me === ve.k6.Channels:
              pe = (0, Mt.A)({
                tab: ve.k6.Channels,
              });
              break;
            case me === ve.k6.People:
              pe = (0, Mt.A)({
                tab: ve.k6.People,
              });
              break;
            case me === ve.k6.Platform:
              pe = (0, Mt.A)({
                tab: ve.k6.Platform,
              });
              break;
            case me === ve.k6.Huddles:
              pe = (0, Mt.A)({
                tab: ve.k6.Huddles,
              });
              break;
            case me === ve.k6.Canvases:
            case Ce &&
              (ne == null ? void 0 : ne.id) === Wn.D.MoreCanvasesSidebar:
              pe = (0, Mt.A)({
                tab: ve.k6.Canvases,
              });
              break;
            case me === ve.k6.FilesPrototype:
              pe = (0, Mt.A)({
                tab: ve.k6.FilesPrototype,
                experimentFilesExplorerPrototypeGroupOn: Ie,
              });
              break;
            case me === ve.k6.Solutions:
              pe = (0, Mt.A)({
                tab: ve.k6.Solutions,
              });
              break;
            default:
              pe = "";
          }
          const Ut = (0, p.A)("p-ia4_sidebar_header", {
              "p-ia4_home_header": me === ve.k6.Home || me === ve.k6.DMs,
              "p-event_header": Dt,
              "p-ia4_home_header--setup": $e,
              "p-ia4_home_header--with_upgrade": Ht,
              "p-ia4_sidebar_header--withControls": It,
              "p-ia4_home_header--with_guided_trial_badge": ft,
              "p-ia4_sidebar_header--list_isnt_overflowing": de && !R,
              "p-ia4_sidebar_header--withSubtitle": !!ut,
            }),
            fa = t.createElement(
              t.Fragment,
              null,
              t.createElement(
                "div",
                {
                  className: Dt
                    ? "p-ia4_sidebar_header__title__event"
                    : "p-ia4_sidebar_header__title",
                },
                pe
              ),
              It &&
                t.createElement(
                  "div",
                  {
                    className: "p-ia4_sidebar_header__controls",
                  },
                  It
                )
            ),
            ka = ko(me)
              ? t.createElement(
                  So.A,
                  {
                    "aria-label": Kt.t("Actions"),
                    className: Ut,
                  },
                  fa
                )
              : t.createElement(
                  "div",
                  {
                    className: Ut,
                  },
                  fa
                );
          return t.createElement(
            t.Fragment,
            null,
            ut &&
              t.createElement(
                "div",
                {
                  className: "p-ia4_sidebar_header__subtitle",
                },
                ut
              ),
            ka,
            t.createElement(it.Ay, ba({}, Do)),
            Oe &&
              me === ve.k6.Home &&
              t.createElement(xn, {
                experimentSfdcSeamlessAuthFeGroupOn: Oe,
              })
          );
        }
        c(Uo, "SidebarHeader");
      },
      6046495019: (x, A, e) => {
        "use strict";
        e.r(A),
          e.d(A, {
            default: () => mt,
          });
        var t = e(5824283093),
          f = e(6122756707),
          p = e(4509434386),
          s = e(5255740490),
          v = e(7618569952),
          g = e(4481313819),
          T = e(277750594),
          h = e(4330129149),
          E = e(3405119017),
          O = e(3749988767),
          a = e(1267040415),
          u = e(6862327721),
          _ = e(5267010247),
          I = e(8822892075),
          b = e(5519146941),
          i = e(5602423845),
          o = e(7115655993),
          l = e(7940058138),
          n = e(6084388622),
          d = e(3514831633),
          r = e(1959847761),
          m = e(8683010724),
          M = e(1224315998),
          P = e(7239742441),
          D = e(735940183),
          y = e(6323355797),
          K = e(9805895677),
          S = e(5928243913),
          k = e(3785575952),
          C = e(2562405183),
          Z = e(716227588),
          Y = e(6259241484),
          $ = e(3810478625),
          X = e(2967538512),
          G = e(6814386530);
        const L = new D.Ay("guided_trials"),
          ee = new D.Ay("setup_straight_to_paid");
        var te;
        (function (ce) {
          (ce.UPGRADE_NOW = "upgrade_now_cta"),
            (ce.PLANS_AT_GLANCE = "plans_at_glance_cta"),
            (ce.SEE_UPGRADE_OPTIONS = "see_upgrade_options_cta");
        })(te || (te = {}));
        var W;
        (function (ce) {
          (ce.MESSAGES = "messages"),
            (ce.SLACK_CONNECT_CHANNELS = "slack-connect-channels"),
            (ce.HUDDLES = "huddles"),
            (ce.HUDDLES_OVER_30_MINUTES = "huddles_over_30_minutes"),
            (ce.CANVASES = "canvases"),
            (ce.APPS_INTEGRATIONS = "apps-integrations"),
            (ce.LISTS = "lists"),
            (ce.APPS = "apps"),
            (ce.WORKFLOWS = "workflows");
        })(W || (W = {}));
        const F = {
            elementName: te.UPGRADE_NOW,
            onClick: {
              enableClogAction: !0,
            },
          },
          z = {
            elementName: te.SEE_UPGRADE_OPTIONS,
            onClick: {
              enableClogAction: !0,
            },
          },
          oe = {
            elementName: te.PLANS_AT_GLANCE,
            onClick: {
              enableClogAction: !0,
            },
          },
          fe = c(() => {
            const ce = (0, f.wA)(),
              xe = (0, i.A)(),
              { shouldUseNavigate: Pe } = (0, t.useContext)(b.A),
              { maybeClosePeek: Ke } = (0, t.useContext)(h.Z),
              q = (0, C.d4)($.g),
              je = (0, C.d4)(X.u0),
              rt = (0, C.d4)(X.PU),
              ct = (0, t.useMemo)(
                () => ({
                  ...F,
                  stepVariant: rt,
                }),
                [rt]
              ),
              ze = (0, C.d4)((Le) => (0, Z.OL)(Le, Y.xu.SIDEBAR_MENU_HEADER)),
              {
                appsAndIntegrations: lt,
                filesAndMessages: Et,
                sharedChannels: Qe,
                huddles: tt,
                canvases: ke,
                apps: Ve = {
                  checked: !1,
                },
                lists: nt = {
                  checked: !1,
                },
                workflows: ye = {
                  checked: !1,
                },
                huddlesOver30M: gt = {
                  checked: !1,
                },
              } = ze,
              _t = (0, t.useMemo)(
                () => [
                  ...Qe.privateSharedChannels.map((Le) => ({
                    ...Le,
                    isPrivate: !0,
                  })),
                  ...Qe.publicSharedChannels.map((Le) => ({
                    ...Le,
                    isPrivate: !1,
                  })),
                ],
                [Qe]
              ),
              zt = c(
                () =>
                  t.createElement(
                    "div",
                    {
                      className:
                        "p-sidebar_trial_peek_view__section__check_icon_wrapper",
                    },
                    t.createElement(m.A, {
                      name: "check",
                      variation: "filled",
                      size: "20",
                    })
                  ),
                "renderCheckIcon"
              ),
              Yt = c(
                (Le) =>
                  t.createElement(
                    "div",
                    {
                      className: (0, s.A)(
                        "p-sidebar_trial_peek_view__section__icon_wrapper",
                        {
                          "p-sidebar_trial_peek_view__section__icon_wrapper_gray":
                            q,
                        }
                      ),
                    },
                    t.createElement(m.A, {
                      name: Le,
                      size: "20",
                    })
                  ),
                "renderIcon"
              ),
              ht = (0, t.useCallback)(() => {
                Ke({
                  forceClose: !0,
                });
              }, [Ke]),
              _a = (0, t.useCallback)(() => {
                ht(), ce((0, k.XO)());
              }, [ce, ht]),
              Ot = (0, t.useCallback)(() => {
                ht(), ce((0, K.R)());
              }, [ce, ht]),
              Lt = (0, t.useCallback)(() => ce((0, _.o)((0, I.CR)())), [ce]),
              qt = (0, t.useCallback)(() => ce((0, S.A)()), [ce]),
              da = (0, t.useCallback)(() => {
                ht(), ce((0, T.A)());
              }, [ce, ht]),
              ma = (0, t.useCallback)(
                (Le) => () => {
                  ht(),
                    ce(
                      Pe
                        ? (0, _.o)((0, I.pr)(Le))
                        : (0, G.A)({
                            id: Le,
                          })
                    );
                },
                [Pe, ce, ht]
              ),
              ua = (0, t.useCallback)(() => {
                ht(),
                  ce(
                    (0, u.A)({
                      canUserPurchase: ze.canUserPurchase,
                    })
                  );
              }, [ht, ce, ze.canUserPurchase]),
              St = c(
                (Le) =>
                  t.createElement(
                    "span",
                    {
                      className: "p-sidebar_trial_peek_view__sub_menu_text",
                    },
                    t.createElement(m.A, {
                      name: Le.isPrivate ? "lock" : "channel",
                    }),
                    Le.channelName
                  ),
                "renderChannelSubMenuText"
              ),
              Ea = c(
                () =>
                  t.createElement(
                    d.Ay,
                    {
                      width: 244,
                      menuClassNames: "p-sidebar_trial_peek_view__wrapper",
                    },
                    _t.map((Le) =>
                      t.createElement(d.Dr, {
                        "data-qa": `${Le.channelName}-menu-item`,
                        disableHoverStyling: !0,
                        key: Le.encodedId,
                        label: St(Le),
                        className: "p-sidebar_trial_peek_view__section",
                        onSelected: ma(Le.encodedId),
                        autoClogProps: {
                          elementName: `peek_view_row_${W.SLACK_CONNECT_CHANNELS}`,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      })
                    )
                  ),
                "renderChannelSubMenu"
              ),
              pa = c((Le) => {
                let {
                  key: qe,
                  title: na,
                  description: ga,
                  checked: sa,
                  icon: Aa,
                  handleClick: Da,
                } = Le;
                return qe === W.SLACK_CONNECT_CHANNELS &&
                  Qe.checked &&
                  _t.length > 1
                  ? t.createElement(
                      r.A,
                      {
                        key: qe,
                        showFullCarat: !0,
                        disableHoverStyling: !0,
                        "data-qa": `${qe}-menu-item`,
                        renderSubmenu: Ea,
                        className: "p-sidebar_trial_peek_view__section",
                        classNameListItem: "p-sidebar_trial_peek_view__item",
                      },
                      sa ? zt() : Yt(Aa),
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-sidebar_trial_peek_view__section_text_container",
                        },
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_title",
                          },
                          na
                        ),
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_sub_title",
                          },
                          ga
                        )
                      )
                    )
                  : t.createElement(
                      d.Dr,
                      {
                        className: "p-sidebar_trial_peek_view__section",
                        classNameListItem: "p-sidebar_trial_peek_view__item",
                        disableHoverStyling: !0,
                        onSelected: Da,
                        key: qe,
                        "data-qa": `${qe}-menu-item`,
                        autoClogProps: {
                          elementName: `peek_view_row_${qe}`,
                          onClick: {
                            enableClogAction: !0,
                          },
                        },
                      },
                      sa ? zt() : Yt(Aa),
                      t.createElement(
                        "div",
                        {
                          className:
                            "p-sidebar_trial_peek_view__section_text_container",
                        },
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_title",
                          },
                          na
                        ),
                        t.createElement(
                          "div",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_sub_title",
                          },
                          ga
                        )
                      )
                    );
              }, "renderMenuItem");
            pa.displayName = "renderMenuItem";
            const At = c((Le) => {
              switch (Le) {
                case W.MESSAGES:
                  return q
                    ? L.t("Searched messages older than 90 days")
                    : Et.lockedMessagesCount > 0
                    ? L.rt(
                        "Search {messageCount} messages older than <div>90 days</div>",
                        {
                          messageCount: (0, P.$k)(Et.lockedMessagesCount),
                        }
                      )
                    : L.t("Search messages older than 90 days");
                case W.SLACK_CONNECT_CHANNELS: {
                  let qe = "";
                  return (
                    !Qe.checked || _t.length === 0
                      ? (qe = q
                          ? L.t("Message someone outside your company")
                          : L.t("Work with people outside your company"))
                      : q
                      ? (qe = L.rt(
                          "Your team has {channelCount} external {channelCount, plural, =1 {conversation} other {conversations}}",
                          {
                            channelCount: _t.length,
                          }
                        ))
                      : _t.length === 1
                      ? (qe = t.createElement(
                          "span",
                          {
                            className:
                              "p-sidebar_trial_peek_view__section_sub_title_channel",
                          },
                          L.rt("View <span>{icon}</span>{channelName}", {
                            channelName: _t[0].channelName,
                            icon: t.createElement(m.A, {
                              name: _t[0].isPrivate ? "lock" : "channel",
                            }),
                          })
                        ))
                      : _t.length > 1 &&
                        (qe = L.rt(
                          "View {channelCount} channels with external people",
                          {
                            channelCount: _t.length,
                          }
                        )),
                    qe
                  );
                }
                case W.HUDDLES:
                  return tt.checked && tt.count > 0
                    ? L.rt(
                        "Your team has completed {count} group {count, plural, =1 {call} other {calls}}",
                        {
                          count: tt.count,
                        }
                      )
                    : L.t("Initiate video calls with screen sharing");
                case W.HUDDLES_OVER_30_MINUTES:
                  return q
                    ? gt != null && gt.checked && gt.count > 0
                      ? L.rt(
                          "Your team has completed {count} {count, plural, =1 {huddle} other {huddles}}",
                          {
                            count: gt.count,
                          }
                        )
                      : L.t("Huddles can now be longer than 30 minutes")
                    : "";
                case W.CANVASES:
                  return ke.checked && ke.count > 0
                    ? q
                      ? L.rt(
                          "Your team has created {count} {count, plural, =1 {canvas} other {canvases}}",
                          {
                            count: ke.count,
                          }
                        )
                      : L.rt(
                          "Your team has created {count} {count, plural, =1 {document} other {documents}}",
                          {
                            count: ke.count,
                          }
                        )
                    : L.t("Document and share ideas and knowledge");
                case W.APPS_INTEGRATIONS: {
                  let qe = "";
                  return (
                    !lt.checked || lt.count === 0
                      ? (qe = L.t("Integrate tools and services into Slack"))
                      : (qe = L.rt(
                          "Your team has installed {count} {count, plural, =1 {app} other {apps}}",
                          {
                            count: lt.count,
                          }
                        )),
                    qe
                  );
                }
                case W.LISTS:
                  return q
                    ? nt != null && nt.checked && nt.count > 0
                      ? L.t(
                          "Your team has created {count} {count, plural, =1 {list} other {lists}}",
                          {
                            count: nt.count,
                          }
                        )
                      : L.t("Plan, track or manage projects")
                    : "";
                case W.APPS:
                  return q
                    ? Ve != null && Ve.checked && Ve.count > 0
                      ? L.t(
                          "Your team has added {count} {count, plural, =1 {app} other {apps}}",
                          {
                            count: Ve.count,
                          }
                        )
                      : L.t("Access tools you use every day in Slack")
                    : "";
                case W.WORKFLOWS:
                  return q
                    ? ye != null && ye.checked && ye.count > 0
                      ? L.t(
                          "Your team has published {count} {count, plural, =1 {workflow} other {workflows}}",
                          {
                            count: ye.count,
                          }
                        )
                      : L.t("Work faster by automating tasks")
                    : "";
                default:
                  return "";
              }
            }, "getSectionDescription");
            At.displayName = "getSectionDescription";
            const ea = [
                {
                  key: W.MESSAGES,
                  title: q
                    ? L.t("Message and file history")
                    : L.t("Message & file history"),
                  description: At(W.MESSAGES),
                  checked: !0,
                  handleClick: _a,
                  icon: "check",
                  altText: L.t("Message icon"),
                  shouldRender: !0,
                },
                {
                  key: W.SLACK_CONNECT_CHANNELS,
                  title: q
                    ? L.t("Start a Slack Connect conversation")
                    : L.t("Slack Connect channels"),
                  description: At(W.SLACK_CONNECT_CHANNELS),
                  checked: Qe.checked,
                  handleClick:
                    _t.length > 0 && Qe.checked ? ma(_t[0].encodedId) : Ot,
                  icon: "shared-channel",
                  altText: L.t("Shared channels icon"),
                  shouldRender: !0,
                },
                {
                  key: W.HUDDLES,
                  title: L.t("Huddles"),
                  description: At(W.HUDDLES),
                  checked: tt.checked,
                  handleClick: da,
                  icon: "headphones",
                  altText: L.t("Huddle icon"),
                  shouldRender: !q,
                },
                {
                  key: W.HUDDLES_OVER_30_MINUTES,
                  title: q ? L.t("Start a huddle without a time limit") : "",
                  description: At(W.HUDDLES_OVER_30_MINUTES),
                  checked: gt == null ? void 0 : gt.checked,
                  handleClick: da,
                  icon: "headphones",
                  altText: L.t("Huddle icon"),
                  shouldRender: q,
                },
                {
                  key: W.CANVASES,
                  title: q ? L.t("Create a canvas") : L.t("Canvas"),
                  description: At(W.CANVASES),
                  handleClick: Lt,
                  checked: ke.checked,
                  icon: "canvas-browser",
                  altText: L.t("Canvas browser icon"),
                  shouldRender: !0,
                },
                {
                  key: W.APPS_INTEGRATIONS,
                  title: L.t("Apps & automations"),
                  description: At(W.APPS_INTEGRATIONS),
                  checked: lt.checked,
                  handleClick: qt,
                  icon: "bolt",
                  altText: L.t("Bolt icon"),
                  shouldRender: !q,
                },
                {
                  key: W.LISTS,
                  title: q ? L.t("Create a list") : "",
                  description: At(W.LISTS),
                  checked: nt == null ? void 0 : nt.checked,
                  handleClick: () => ce((0, _.o)((0, I.ZF)(l.c.BrowseLists))),
                  icon: "lists",
                  altText: q ? L.t("Lists icon") : "",
                  shouldRender: q,
                },
                {
                  key: W.APPS,
                  title: q ? L.t("Add an app") : "",
                  description: At(W.APPS),
                  checked: Ve == null ? void 0 : Ve.checked,
                  handleClick: qt,
                  icon: "apps",
                  altText: q ? L.t("Apps icon") : "",
                  shouldRender: q,
                },
                {
                  key: W.WORKFLOWS,
                  title: q ? L.t("Publish a workflow") : "",
                  description: At(W.WORKFLOWS),
                  checked: ye == null ? void 0 : ye.checked,
                  handleClick: () => ce((0, _.o)((0, I.ZF)(l.c.Shortcuts))),
                  icon: "bolt",
                  altText: L.t("Bolt icon"),
                  shouldRender: q,
                },
              ],
              ta = (0, C.d4)((Le) =>
                (0, y.m6)(Le, {
                  action: y.um.CHECKOUT,
                  productLevel: y.i6.standard.id,
                  entryPoint: "guided_trials_peek_upgrade_cta",
                })
              ),
              aa =
                je && ze.promoType === "straight_to_paid" && ze.discountPercent,
              wt = (0, O.Q)(ze.discountExpirationTs);
            (0, o.A)(() => {
              if (aa) {
                const { eventId: Le, contexts: qe } = (0, E.wy)(rt);
                xe.track(Le, {
                  contexts: qe,
                });
              }
            });
            const Ta = t.createElement(
              "div",
              {
                className: "p-sidebar_trial_peek_view__stp_wrapper",
              },
              t.createElement(
                n.z9,
                {
                  autoClogProps: ct,
                  href: ta,
                  className: "p-sidebar_trial_peek_view__cta_upgrade",
                  "data-qa": "peek-view-upgrade-now-cta",
                },
                ee.t("Get {discountPercent}% Off Slack Pro", {
                  discountPercent: ze.discountPercent,
                })
              ),
              t.createElement(
                "p",
                {
                  className: "p-sidebar_trial_peek_view__stp_subtext",
                },
                typeof wt == "number" &&
                  wt >= 0 &&
                  ee.t(
                    "{daysRemaining, plural, =1 {# day} other {# days}} left on this offer",
                    {
                      daysRemaining: wt,
                    }
                  )
              )
            );
            return t.createElement(
              g.A,
              {
                uiComponentName:
                  M.UiComponentName.GUIDED_TRIAL_SIDEBAR_PEEK_VIEW,
                clogImpression: !0,
              },
              t.createElement(
                d.Ay,
                {
                  width: 355,
                  menuClassNames: "p-sidebar_trial_peek_view__wrapper",
                },
                t.createElement(d.c$, {
                  label: q
                    ? L.t("Make the most of Pro")
                    : L.t("How you and your team are using Pro features"),
                  className: "p-sidebar_trial_peek_view__header_text",
                }),
                ea
                  .filter((Le) => {
                    let { shouldRender: qe } = Le;
                    return qe;
                  })
                  .map((Le) => pa(Le)),
                t.createElement(d.bX, {
                  className: "p-sidebar_trial_peek_view__section_sperator",
                }),
                t.createElement(
                  "div",
                  {
                    className: (0, s.A)(
                      "p-sidebar_trial_peek_view__cta_wrapper",
                      {
                        padding_bottom_25: aa,
                      }
                    ),
                  },
                  ze.canUserPurchase &&
                    (aa
                      ? Ta
                      : t.createElement(
                          n.z9,
                          {
                            autoClogProps: F,
                            href: ta,
                            className: "p-sidebar_trial_peek_view__cta_upgrade",
                            "data-qa": "peek-view-upgrade-now-cta",
                          },
                          q ? L.t("Upgrade to Pro") : L.t("Upgrade Now")
                        )),
                  !ze.canUserPurchase &&
                    !q &&
                    t.createElement(
                      a.A,
                      {
                        "data-qa": "peek-view-upgrade-now-cta",
                        className: "p-sidebar_trial_peek_view__cta_upgrade",
                        entryPoint: "guided_trials_peek_upgrade_cta",
                        autoClogProps: z,
                      },
                      L.t("See Upgrade Options")
                    ),
                  !ze.canUserPurchase &&
                    q &&
                    t.createElement(
                      n.z9,
                      {
                        autoClogProps: F,
                        onClick: ua,
                        className: "p-sidebar_trial_peek_view__cta_upgrade",
                        "data-qa": "peek-view-compare-plans-primary-cta",
                      },
                      q ? L.t("Compare Plans") : ""
                    ),
                  (!q || ze.canUserPurchase) &&
                    t.createElement(
                      n.Nm,
                      {
                        autoClogProps: oe,
                        onClick: ua,
                        className: "p-sidebar_trial_peek_view__cta_compare",
                        "data-qa": "peek-view-compare-plans-cta",
                      },
                      t.createElement(m.A, {
                        name: q ? "open-in-window" : "help",
                      }),
                      q
                        ? L.t("Compare plans")
                        : L.t("Compare free vs. paid", {
                            fallbackHash:
                              "a9e8db275411da93383d650ea5f5f2c3022f2f01",
                          })
                    )
                )
              )
            );
          }, "SidebarTrialPeekView");
        fe.displayName = "SidebarTrialPeekView";
        const Me = fe;
        var Re = e(8214116048);
        const Ye = -10,
          Se = c((ce) => {
            let { children: xe } = ce;
            const Pe = (0, t.useCallback)(() => t.createElement(Me, null), []);
            return t.createElement(
              v.A,
              {
                position: Re.yX.RightBottom,
                renderContent: Pe,
                offsetY: Ye,
              },
              xe
            );
          }, "SidebarTrialPeekTrigger");
        Se.displayName = "SidebarTrialPeekTrigger";
        const he = Se;
        var se = e(7512049997),
          H = e(9137628070),
          Q = e(2994893019),
          re = e(8871937520),
          J = e(2047021170),
          Fe = e(3451446614),
          We = e(3193155968),
          Be = e(2802517438);
        const Ze = new D.Ay("guided_trials"),
          Ge = {
            elementName: "sidebar_trial_badge_paid_benfits_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          V = c(() => {
            const ce = (0, f.wA)(),
              { shouldUseNavigate: xe, getSiblingView: Pe } = (0, t.useContext)(
                b.A
              ),
              Ke = (0, C.d4)(Fe.Y),
              q = (0, C.d4)((Ve) => (0, Z.OL)(Ve, Y.xu.SIDEBAR_MENU_HEADER)),
              je = (0, C.d4)((Ve) => {
                var nt;
                return xe
                  ? (nt = Pe(Ve, {
                      container: We.mq.Primary,
                    })) === null || nt === void 0
                    ? void 0
                    : nt.id
                  : (0, Be.A)(Ve);
              }),
              rt = (0, C.d4)(
                (Ve) =>
                  (0, J.ty)(Ve, "trials_sidebar_banner_wrapper_dismissed") ===
                  !1
              ),
              ct = je === "Ppaid-benefits",
              ze = (0, re.qe)(q.trialEndDate) || 0,
              lt = ze === y.ew.PAID_FEATURE_TRIAL,
              Et = ze === 1,
              Qe = (lt && rt) || Et,
              tt = (0, t.useCallback)(() => {
                ce(
                  xe
                    ? (0, _.o)((0, I.ZF)(l.c.PaidBenefits))
                    : (0, G.A)({
                        id: H.IN,
                      })
                );
              }, [ce, xe]),
              ke = c(
                () =>
                  Et
                    ? Ze.t("View Paid Benefits")
                    : Ze.rt(
                        "{trialDaysRemaining} {trialDaysRemaining, plural, =1 {day} other {days}} left in trial",
                        {
                          trialDaysRemaining: ze,
                        }
                      ),
                "getButtonText"
              );
            return t.createElement(Q.M, {
              isTrialFirstDay: lt,
              isTrialLastDay: Et,
              trialDaysRemaining: ze,
              isSelected: ct,
              showWrapper: Qe,
              autoClogProps: Ge,
              onClick: tt,
              buttonText: ke(),
              experimentFeatReverseTrialGroupTreatment: Ke,
            });
          }, "SideBarTrialBadge");
        V.displayName = "SideBarTrialBadge";
        const ae = V;
        var Ee = e(1641606663),
          we = e(7878745420),
          et = e(3328068409),
          pt = e(387484329),
          it = e(3677514771),
          w = e(7531383956),
          ge = e.n(w),
          le = e(3758927666),
          ie = e.n(le);
        const Ae = new D.Ay("guided_trials"),
          Xe = {
            elementName: "sidebar_trial_badge_upgrade_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          Te = {
            elementName: "sidebar_trial_badge_see_upgrade_options_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          Je = {
            elementName: "sidebar_trial_badge_wrapper_close_btn",
            onClick: {
              enableClogAction: !0,
            },
          },
          dt = we.g.SUPPORT_UPGRADE_DECISION_TRIAL_USAGE_SIDEBAR_MENU_HEADER,
          ot = c((ce) => {
            let { canUserPurchase: xe, trialEndDate: Pe } = ce;
            const Ke = (0, f.wA)(),
              { activeTab: q } = (0, t.useContext)(b.A),
              je = q === We.k6.Home,
              { windowRef: rt } = (0, t.useContext)(Ee.Mn),
              ct = (0, C.d4)(et.to),
              ze = (0, C.d4)(it.H7),
              lt = (0, C.d4)(
                (Ot) =>
                  (0, J.ty)(Ot, "trials_sidebar_banner_wrapper_dismissed") ===
                  !1
              ),
              Et = (0, C.d4)($.g),
              Qe = (0, C.d4)(Fe.Y),
              tt = (0, re.qe)(Pe) || 0,
              ke = tt === y.ew.PAID_FEATURE_TRIAL,
              Ve = tt === 1,
              nt = Qe && tt <= y.ew.PAID_FEATURE_TRIAL - 7 && tt > 1,
              ye = (ke && lt) || Ve || (nt && lt),
              gt = (0, t.useCallback)(() => {
                Ke(
                  (0, pt.AZ)({
                    pref: "trials_sidebar_banner_wrapper_dismissed",
                    value: !0,
                  })
                );
              }, [Ke]),
              _t = (0, C.d4)((Ot) =>
                (0, y.m6)(Ot, {
                  action: y.um.CHECKOUT,
                  productLevel: y.i6.standard.id,
                  entryPoint: "guided_trials_peek_upgrade_cta",
                })
              ),
              zt = (0, t.useCallback)(() => {
                var Ot;
                const Lt = xe
                  ? _t
                  : (0, y.hZ)({
                      team: ze,
                      entryPoint: "guided_trials_sidebar_upgrade_cta",
                    });
                (Ot = rt.deref()) === null || Ot === void 0 || Ot.open(Lt);
              }, [ze, rt, xe, _t]),
              Yt = (0, t.useMemo)(
                () =>
                  xe
                    ? Et
                      ? Ae.t("Upgrade to Pro")
                      : Ae.t("Upgrade Now")
                    : Ae.t("See Upgrade Options"),
                [xe, Et]
              ),
              ht = c(
                () =>
                  ke
                    ? Ae.t("Get started with your Pro trial")
                    : Ve
                    ? Ae.t("It\u2019s the last day of your Pro trial")
                    : nt
                    ? Ae.t("Take advantage of Slack Pro")
                    : "",
                "getWrapperText"
              ),
              _a = c(() => {
                if (Qe) {
                  if (Ve) return "last_day";
                  if (tt === 2) return "second_to_last_day";
                }
              }, "getUiStep");
            return !je || tt <= 0
              ? null
              : t.createElement(
                  g.A,
                  {
                    uiComponentName:
                      M.UiComponentName.GUIDED_TRIAL_SIDEBAR_BADGE,
                    uiStep: _a(),
                    stepVariant: Qe ? "reverse_trial" : void 0,
                    clogImpression: !0,
                  },
                  t.createElement(
                    se.A,
                    null,
                    t.createElement(
                      "div",
                      {
                        className: (0, s.A)({
                          "p-sidebar_trial_badge_wrapper": Qe,
                        }),
                      },
                      ye &&
                        t.createElement(
                          "div",
                          {
                            className: (0, s.A)(
                              "p-sidebar_trial_badge_wrapper__wrapper",
                              {
                                "p-sidebar_trial_badge_wrapper__wrapper--reverse_trial":
                                  Qe,
                                [p.A7]: ct === Re.Sx.Light,
                              }
                            ),
                          },
                          t.createElement(
                            "div",
                            {
                              className:
                                "p-sidebar_trial_badge_wrapper__wrapper_header",
                            },
                            t.createElement(
                              "div",
                              {
                                className:
                                  "p-sidebar_trial_badge_wrapper__wrapper_text",
                              },
                              ht()
                            ),
                            t.createElement(
                              "div",
                              {
                                className:
                                  "p-sidebar_trial_badge_wrapper__wrapper_header_image_container",
                              },
                              (ke || nt) &&
                                t.createElement("img", {
                                  src: ie(),
                                  alt: "gift",
                                }),
                              Ve &&
                                t.createElement("img", {
                                  src: ge(),
                                  alt: "clock",
                                }),
                              (ke || nt) &&
                                t.createElement(
                                  n.Nm,
                                  {
                                    className:
                                      "p-sidebar_trial_badge_wrapper__wrapper_header_close_btn",
                                    onClick: gt,
                                    autoClogProps: Je,
                                    "data-qa":
                                      "sidebar-badge-wrapper-close-btn",
                                  },
                                  t.createElement(m.A, {
                                    name: "close",
                                  })
                                )
                            )
                          ),
                          Ve &&
                            t.createElement(
                              n.Nm,
                              {
                                onClick: zt,
                                autoClogProps: xe ? Xe : Te,
                                className:
                                  "p-sidebar_trial_badge_wrapper__upgrade_now_btn dt-hocus:theme-base-pry",
                                "data-qa":
                                  "sidebar-badge-wrapper-upgrade-now-btn",
                              },
                              xe &&
                                t.createElement(m.A, {
                                  size: "20",
                                  name: "rocket",
                                }),
                              t.createElement("span", null, Yt)
                            )
                        ),
                      t.createElement(
                        "div",
                        {
                          className: (0, s.A)(
                            "p-sidebar_trial_badge_wrapper__button_wrapper",
                            {
                              "p-sidebar_trial_badge_wrapper__button_wrapper_bg":
                                ye,
                              "p-sidebar_trial_badge_wrapper__button_wrapper--reverse_trial":
                                Qe,
                              "p-sidebar_trial_badge_wrapper__button_wrapper--no_padding":
                                Qe && !ye,
                              [p.A7]: ct === Re.Sx.Light,
                            }
                          ),
                        },
                        t.createElement(
                          he,
                          null,
                          t.createElement(
                            "div",
                            null,
                            t.createElement(ae, null)
                          )
                        )
                      )
                    )
                  )
                );
          }, "SideBarTrialBadgeWrapper");
        ot.displayName = "SideBarTrialBadgeWrapper";
        const mt = ot;
      },
      7133181643: (x, A, e) => {
        "use strict";
        e.d(A, {
          V: () => s,
          W: () => v,
        });
        var t = e(8161242485),
          f = e(2047021170),
          p = e(6827180593);
        const s = "has_clicked_highlighted_header_compose_button",
          v = (0, t.Ay)((g) => ((0, f.ty)(g, s) ? !1 : (0, p.H)(g) < 5));
        v.meta = {
          name: "createSelector",
          key: "createSelectorshouldShowHighlightedComposeButton",
          description: (g) => ((0, f.ty)(g, s) ? !1 : (0, p.H)(g) < 5),
        };
      },
      289112722: (x, A, e) => {
        "use strict";
        e.d(A, {
          A: () => t,
        });
        const t = "SALESFORCE_LOGIN_WIDGET:v2";
      },
      5055839243: (x, A, e) => {
        "use strict";
        e.d(A, {
          _: () => i,
        });
        var t = e(5824283093),
          f = e(2683115972),
          p = e(8683010724),
          s = e(2539163284),
          v = e(2409757433),
          g = e(7925057078),
          T = e.n(g),
          h = e(735940183),
          E = e(5946832122),
          O = e(8624014077),
          a = e(289112722),
          u = e(6065326583),
          _ = e.n(u);
        const I = new h.Ay("salesforce_connections"),
          b = c((o) => {
            let { onClick: l, experimentSfdcSeamlessAuthFeGroupOn: n } = o;
            return t.createElement(
              f.Ay,
              {
                type: "outline",
                onClick: l,
              },
              t.createElement(
                "span",
                {
                  className: _().buttonContent,
                },
                t.createElement(
                  s.c,
                  {
                    space: "25",
                  },
                  t.createElement(p.A, {
                    name: "sf-cloud",
                    size: "20",
                  }),
                  t.createElement(
                    v.E,
                    {
                      weight: "bold",
                    },
                    n ? I.t("Sign in to Salesforce") : "Sign in to Salesforce"
                  )
                ),
                t.createElement(p.A, {
                  name: "caret-right",
                  size: "20",
                })
              )
            );
          }, "SalesforceSignInButton");
        b.displayName = "SalesforceSignInButton";
        const i = c((o) => {
          let { experimentSfdcSeamlessAuthFeGroupOn: l, onSignIn: n } = o;
          const [d, r] = (0, O.r)(a.A, "visible"),
            m = (0, t.useCallback)(() => {
              r("collapsed");
            }, [r]);
          return t.createElement(
            t.Fragment,
            null,
            d === "collapsed" &&
              t.createElement(
                "div",
                {
                  className: _().collapsed,
                },
                t.createElement(b, {
                  onClick: n,
                  experimentSfdcSeamlessAuthFeGroupOn: l,
                })
              ),
            d === "visible" &&
              t.createElement(
                "div",
                {
                  className: _().widget,
                },
                t.createElement(
                  "div",
                  {
                    className: _().header,
                  },
                  t.createElement(
                    v.E,
                    {
                      weight: "black",
                      size: "subtitle",
                      color: "Theme/Content/Inverse primary",
                    },
                    l
                      ? I.t("Bring Salesforce data into Slack")
                      : "Bring Salesforce data into Slack"
                  ),
                  t.createElement(
                    s.c,
                    {
                      space: "75",
                      alignY: "start",
                    },
                    t.createElement("img", {
                      className: _().icon,
                      src: T(),
                      alt: "ladder to the cloud",
                    }),
                    t.createElement(
                      E.A,
                      {
                        onClick: m,
                        "aria-label": l
                          ? I.t("Collapse this widget")
                          : "Collapse this widget",
                      },
                      t.createElement(p.A, {
                        name: "close",
                      })
                    )
                  )
                ),
                t.createElement(b, {
                  onClick: n,
                  experimentSfdcSeamlessAuthFeGroupOn: l,
                })
              )
          );
        }, "SalesforceSignInWidget");
        i.displayName = "SalesforceSignInWidget";
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-client-dms-list-view.664197d2166407e2cc69.min.js.map
