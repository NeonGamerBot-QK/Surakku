slacks source code that i extracted
`g#` is all gantry files
