"use strict";
(() => {
  var ho = Object.defineProperty;
  var u = (X, F) =>
    ho(X, "name", {
      value: F,
      configurable: !0,
    });
  (globalThis.webpackChunkwebapp = globalThis.webpackChunkwebapp || []).push([
    ["gantry-v2-async-client-boot-data"],
    {
      6097732015: (X, F, s) => {
        s.r(F),
          s.d(F, {
            register: () => uo,
            test: () => Ft,
          });
        var d = s(9706240641),
          Et = s(1460808057),
          Bt = s(1472964078),
          Q = s(4850281085);
        function k(a) {
          let { store: t, contextualInfo: e } = a;
          const { experimentGroupOverrides: o, teamId: n } = e;
          if ((o != null && o.all && t.dispatch((0, Q.g)(o.all)), !n)) return;
          const r = o == null ? void 0 : o[n];
          r && t.dispatch((0, Q.g)(r));
        }
        u(k, "dispatchExperimentOverrides");
        var b = s(796111729),
          q = s(8445020572),
          Mt = s(7337645755),
          _ = s(7389288395),
          $t = s(23236051);
        function Pt(a, t, e) {
          const { teamId: o } = e;
          (0, b.Wo)().info("BOOT", `(${o}) Dispatching boot data`);
          const n = xt(t, e);
          a.dispatch((0, _.B)(n));
          const { config_version_ts: r, ...c } = t.experimentData;
          a.dispatch((0, $t.ob)(c)),
            k({
              store: a,
              contextualInfo: e,
            }),
            a.dispatch((0, Mt.$)(t.featureAccessData));
        }
        u(Pt, "dispatchBootData");
        function xt(a, t) {
          const { featureFlagData: e } = a,
            o = a.clientBootData,
            {
              should_reload: n,
              client_min_version: r,
              acceptTosUrl: c,
              isEurope: i,
              selfData: l,
              hidden_messages_count: p,
            } = o,
            { enterpriseBootData: g } = a.allEnterpriseData,
            h = a.allOnboardingData,
            { onboardingData: S, labFeaturesStartupData: f } = h,
            { featureFlagURLOverrides: v, userId: A } = t,
            K = {
              ...e,
              ...v,
            };
          return {
            app: "client",
            user_id: A,
            user_team_id: l == null ? void 0 : l.team_id,
            version_uid: (0, q.X3)(),
            acceptTosUrl: c,
            isEurope: i,
            onboardingData: S,
            labFeaturesStartupData: f,
            should_reload: n,
            client_min_version: r,
            hidden_messages_count: p,
            ...(g || {}),
            ...K,
          };
        }
        u(xt, "extractBootData");
        var Rt = s(4594256912),
          tt = s(8170643398),
          et = s(5510392579),
          M = s(8276911661),
          Ut = s(6339723554),
          Ht = s(9776496806),
          Wt = s(8444325411),
          ot = s(603616571);
        function jt(a) {
          let { store: t, onboardingData: e } = a;
          const o = t.getState(),
            n = (0, Ut.b)(o),
            r = (0, ot.fZ)(o),
            c = (0, ot.TX)(o),
            i = e == null ? void 0 : e.use_case_onboarding_selection,
            l = r || c,
            p = (0, et.$G)(o);
          if (!l || p) return;
          const g = i == null ? void 0 : i.split("|"),
            h = new Date().getTime() / 1e3,
            S = 5 * 60;
          var f;
          const v =
            (f = (0, tt.yF)((0, M.cA)(o))) !== null && f !== void 0 ? f : -1;
          v > 0 &&
            v + S > h &&
            t.dispatch(
              (0, Wt.P)({
                tabRailCustomization: (0, Rt.w)(n, g),
                reason: Ht.pU.Auto,
              })
            );
        }
        u(jt, "maybeSetJoinerUseCaseOnboardingTabs");
        var Nt = s(9879145827),
          Lt = s(1091269426);
        function wt(a) {
          let { apiData: t, store: e } = a;
          const { labFeaturesStartupData: o, onboardingData: n } =
            t.allOnboardingData;
          if (o) {
            var r;
            e.dispatch(
              (0, Nt.V)(
                (r = o.emailClassification) === null || r === void 0
                  ? void 0
                  : r.enabled
              )
            );
          }
          n &&
            (e.dispatch(
              (0, Lt.Uv)({
                ...n,
              })
            ),
            jt({
              onboardingData: n,
              store: e,
            }));
        }
        u(wt, "dispatchOnboardingData");
        var Yt = s(1948141093),
          Gt = s(5623069041);
        const Jt = u(
          (a) => !(0, Yt.K)((0, Gt.h)(a)),
          "isDownloadAppPromptShowable"
        );
        var zt = s(7216577906),
          $ = s(6839188756),
          Vt = s(571104883),
          nt = s(2786906754),
          Kt = s(1269227002),
          Zt = s(5257368278);
        const at = (0, Zt.A)(
          "Trigger Slackbot channel suggestions (if any available)",
          (a) =>
            a(
              (0, Kt.apiCall)({
                method: "conversations.suggestions",
                args: {},
                reason: "conversations-suggestions",
              })
            )
        );
        at.meta = {
          name: "createFetcher",
          key: "createFetcherconversationsSuggestions",
          description:
            "Trigger Slackbot channel suggestions (if any available)",
        };
        var Xt = s(4096483543),
          Qt = s(4949104520),
          kt = s(1031947056),
          qt = s(8726613433);
        const st = (0, kt.Ay)(
          "Trigger Slackbot channel suggestions (if any available)",
          (a, t) => {
            const e = (0, Qt.A)(75, -0.6, 0.6);
            setTimeout(() => {
              const o = t();
              ((0, Xt.A)() && !(0, qt.T2)(o)) || a(at());
            }, e * 1e3);
          }
        );
        st.meta = {
          name: "createThunk",
          key: "createThunkmaybeSendConversationsSuggestions",
          description:
            "Trigger Slackbot channel suggestions (if any available)",
        };
        const _t = st;
        var te = s(1960898919),
          rt = s(2995501183),
          ee = s(3474336343),
          oe = s(6320982782),
          it = s(3977512448),
          ne = s(3677514771);
        function ae(a) {
          let { store: t, routeInfo: e } = a;
          var o;
          (0, rt.xr)(t.getState()) &&
            !(0, Vt.y3)() &&
            t.dispatch(
              (0, _.B)({
                ...t.getState().bootData,
                userSawNotificationsBanner: (0, zt.a)() && Jt(t.getState()),
              })
            ),
            t.dispatch(_t());
          const n = (0, ne.H7)(t.getState()),
            r = !(0, $.Ny)(n),
            c =
              (0, rt.Yx)(t.getState()) &&
              (0, te.ax)(t.getState(), "setup_flow_step") === it.GO.Completed &&
              (0, et.$G)(t.getState()),
            i =
              (e == null || (o = e.params) === null || o === void 0
                ? void 0
                : o.entityId) === it.vZ.Tada && c;
          if ((e == null ? void 0 : e.params.entityId) === "paid-benefits") {
            const l = [
                "email_trial_activation_day_zero",
                "trial_seven_day_reminder",
                "trial_seven_day_reminder_revamp",
              ],
              p = (0, nt.qN)(window.location.href).entry_point;
            if (l.includes(p)) return;
          }
          ((r && c) || i) &&
            t.dispatch(
              (0, oe.R)({
                redirectId: (0, ee.xS)(t.getState()),
              })
            );
        }
        u(ae, "dispatchOnboardingViewData");
        var se = s(6004808763),
          T = s(7031360717),
          re = s(9403162303),
          lt = s(1296967326),
          ie = s(7620349556),
          le = s(1503483212);
        function ue(a, t, e) {
          return P.apply(this, arguments);
        }
        u(ue, "dispatchApiData");
        function P() {
          return (
            (P = (0, d.coroutine)(function* (a, t, e) {
              (0, T.pq)("BOOT", `(${e.teamId}) Dispatching API data`),
                Pt(a, t, e);
              const n = (yield e.isBootingWarm)
                  ? lt.xT.ClientBootWarmBoot
                  : lt.xT.ClientBootColdBoot,
                r = ce(t);
              a.dispatch(
                (0, ie.A)({
                  modelData: r,
                  source: n,
                })
              );
              const { clientBootData: c, clientChannelsData: i } = t,
                { teamData: l } = c;
              let p = c.unchangedChannelIds;
              i &&
                ((p = i.unchangedChannelIds),
                a.dispatch(
                  (0, Bt.r)({
                    ...i,
                    teamId: l.id,
                    source: n,
                  })
                )),
                p &&
                  a.dispatch(
                    (0, re.T6)({
                      teamId: l.id,
                      unchangedChannelIds: p,
                      unchangedChannelsJoinedIds: p,
                    })
                  );
              const g = yield (0, Et.E)({
                contextualInfo: e,
                channels: c.channelsData,
              });
              l.acquisition_source &&
                a.dispatch((0, le.A)(l.acquisition_source)),
                wt({
                  apiData: t,
                  contextualInfo: e,
                  store: a,
                }),
                (0, se.Cf)({
                  apiData: t,
                  contextualInfo: e,
                  store: a,
                  routeInfo: g,
                }),
                ae({
                  store: a,
                  routeInfo: g,
                });
            })),
            P.apply(this, arguments)
          );
        }
        u(P, "_dispatchApiData");
        function ce(a) {
          const { clientBootData: t } = a,
            {
              accountTypes: e,
              channelsData: o,
              starredChannels: n,
              readOnlyChannels: r,
              threadOnlyChannels: c,
              teamData: i,
              selfData: l,
              userPrefsData: p,
              teamPrefsData: g,
              userGroupMembershipData: h,
              paidFeatures: S,
              emojiBootData: f,
              appCommandsCacheTs: v,
              domainsBootData: A,
              workspaces: K,
              defaultWorkspace: co,
              channelsPriorityData: po,
              unchangedChannelIds: mo,
            } = t,
            go = a.allEnterpriseData,
            { enterpriseData: It, enterprisePrefsData: Ot } = go,
            Z = {
              accountTypes: e,
              channelsData: o,
              starredChannels: n,
              readOnlyChannels: r,
              threadOnlyChannels: c,
              teamData: i,
              selfData: l,
              userPrefsData: p,
              teamPrefsData: g,
              userGroupMembershipData: h,
              paidFeatures: S,
              emojiBootData: f,
              appCommandsCacheTs: v,
              domainsBootData: A,
              workspaces: K,
              defaultWorkspace: co,
              channelsPriorityData: po,
              unchangedChannelIds: mo,
            };
          return (
            It && (Z.enterpriseData = It), Ot && (Z.enterprisePrefsData = Ot), Z
          );
        }
        u(ce, "extractModelData");
        function de(a) {
          return x.apply(this, arguments);
        }
        u(de, "fetchAdditionalMembers");
        function x() {
          return (
            (x = (0, d.coroutine)(function* (a) {
              let { clientBootData: t, store: e } = a;
              const o = e.getState(),
                n = (0, M.Zo)(o),
                r = ((t == null ? void 0 : t.membersToFetch) || []).filter(
                  (c) => !(n != null && n[c])
                );
              (0, M.gA)(o, r);
            })),
            x.apply(this, arguments)
          );
        }
        u(x, "_fetchAdditionalMembers");
        var pe = s(8221303755);
        function me(a) {
          return R.apply(this, arguments);
        }
        u(me, "initialEmojiTranslationLoad");
        function R() {
          return (
            (R = (0, d.coroutine)(function* (a) {
              let { contextualInfo: t } = a;
              return (
                (0, pe.A)(),
                {
                  contextualInfo: t,
                }
              );
            })),
            R.apply(this, arguments)
          );
        }
        u(R, "_initialEmojiTranslationLoad");
        var ge = s(2212859256),
          he = s(5751532669),
          ut = s(1212501486),
          I = s(9733150292),
          O = s(4423055085),
          fe = s(8645544190),
          ct = s(6533394955);
        function ve(a) {
          return U.apply(this, arguments);
        }
        u(ve, "populateTeamDebugger");
        function U() {
          return (
            (U = (0, d.coroutine)(function* (a) {
              let { contextualInfo: t } = a;
              const { teamId: e } = t;
              if (!e)
                return {
                  contextualInfo: t,
                };
              (0, O.GW)(e, "openGantryApp", function () {
                for (
                  var r = arguments.length, c = new Array(r), i = 0;
                  i < r;
                  i++
                )
                  c[i] = arguments[i];
                return (0, ct.dispatchForTeamId)(e, (0, fe.Dx)(...c));
              });
              const o = (0, I._z)(e, "url"),
                n = o ? o.match(/^https:\/\/([^.]+)\./) : null;
              if (n && n[1]) {
                const r = n[1];
                (0, O.zv)(`teams.${r}`, () => window.slackDebug[e]);
              }
              return {
                contextualInfo: t,
              };
            })),
            U.apply(this, arguments)
          );
        }
        u(U, "_populateTeamDebugger");
        var De = s(6998663753),
          Se = s(9190452268),
          dt = s(6156519813);
        let E = !1;
        const pt = u(() => {
            const a = (0, Se.rh)(),
              t = (0, b.Wo)();
            a.count(`${(0, dt.fj)()}_beforeunload`),
              t.info(
                "RELOAD",
                "Page is about to unload. This might not be a reload, it could be a window close or navigation"
              );
          }, "globalBeforeunloadHandler"),
          Ce = u(() => {
            E || (window.addEventListener("beforeunload", pt), (E = !0));
          }, "registerGlobalBeforeunloadHandler");
        Object.defineProperty(
          {
            globalBeforeunloadHandler: pt,
          },
          "hasRegisteredGlobalBeforeunloadHandler",
          {
            get: () => E,
            set: (a) => {
              E = a;
            },
          }
        );
        var be = s(3945243579),
          ye = s(5555111087);
        const Te = (0, De.A)(Ae);
        function Ae() {
          (0, be.A)(), Ce(), (0, ye.A)();
        }
        u(Ae, "registerEventHandlersInner");
        var mt = s(1780675971);
        function Fe(a) {
          return H.apply(this, arguments);
        }
        u(Fe, "setBootTypeForTeam");
        function H() {
          return (
            (H = (0, d.coroutine)(function* (a) {
              let { store: t, contextualInfo: e } = a;
              const { isBootingWarm: o } = e,
                n = (yield o) ? "warm" : "cold";
              return (
                t.dispatch(
                  (0, mt.pb)({
                    bootType: n,
                  })
                ),
                {
                  store: t,
                  contextualInfo: e,
                }
              );
            })),
            H.apply(this, arguments)
          );
        }
        u(H, "_setBootTypeForTeam");
        var Ie = s(8233775522);
        function Oe(a) {
          return W.apply(this, arguments);
        }
        u(Oe, "setFocus");
        function W() {
          return (
            (W = (0, d.coroutine)(function* (a) {
              let { store: t, contextualInfo: e } = a;
              const n = (0, ct.getClientStoreInstance)().getState(),
                r = (0, Ie.zk)(n);
              return (
                r && t.dispatch((0, mt.d1)(r)),
                {
                  store: t,
                  contextualInfo: e,
                }
              );
            })),
            W.apply(this, arguments)
          );
        }
        u(W, "_setFocus");
        var Ee = s(2131777110),
          Be = s(8946917827),
          Me = s(9113979368),
          m = s(3371371503),
          gt = s(6422693406),
          $e = s(4570099997),
          Pe = s(6180122993);
        let C = "3";
        const j = "persist:slack-persistence-method-version";
        function ht(a) {
          const t = (0, b.Wo)();
          if (!(0, $e.A)("localStorage"))
            return (
              t.info(
                m.JY,
                "Not checking persistence storage method version because localStorage doesn't appear to be supported"
              ),
              gt.S.resolve()
            );
          const e = `${j}-${a}`,
            o = `${j}-${(0, dt.fj)()}-${a}`;
          let n = localStorage.getItem(o);
          if (!n) {
            n = localStorage.getItem(e) || "0";
            try {
              localStorage.setItem(o, C), localStorage.removeItem(e);
            } catch (r) {
              t.error(
                `Error persisting persistence method version for ${a}: ${r}`
              );
            }
          }
          if (n !== C) {
            try {
              localStorage.setItem(o, C);
            } catch (r) {
              t.error(
                `Error persisting persistence method version for ${a}: ${r}`
              );
            }
            if (n === "1" && C === "2")
              t.info(
                m.JY,
                `(${a}) Removing localStorage persistence data because it is now stored in IndexedDb`
              ),
                localStorage.removeItem(`persist:${m.kl}-${a}`);
            else if (n === "2" && C === "3") {
              t.info(
                m.JY,
                `(${a}) Removing outdated persistence data because it is now stored key off of which gantry app you are using`
              );
              const r = `persist:${m.kl}-${a}`;
              return Pe.A.delete(r).catch((c) => {
                t.error(
                  `Error removing persisted data "persist:${m.kl}-${a}"`,
                  c
                );
              });
            }
          }
          return gt.S.resolve();
        }
        u(ht, "checkForPersistenceMethodChanges");
        const xe = {
          persistConfigKeyPrefix: m.kl,
          persistNamespace: m.O7,
          PERSISTENCE_METHOD_VERSION_PREFIX: j,
          PERSISTENCE_METHOD_VERSION: void 0,
        };
        Object.defineProperty(xe, "PERSISTENCE_METHOD_VERSION", {
          get: () => C,
          set: (a) => {
            C = a;
          },
        });
        const Re = (0, b.Wo)();
        function Ue(a) {
          let { teamId: t, reducerConfig: e, state: o = {} } = a;
          return Object.keys(e).some((n) => {
            const r = e[n],
              c = (0, m.F_)(r) && (o[n] === null || o[n] === void 0);
            return (
              c &&
                Re.info(
                  m.JY,
                  `(${t}) Not using persisted model because ${n} is required and empty`
                ),
              c
            );
          });
        }
        u(Ue, "checkForMissingRequiredReducers");
        var He = s(705409307),
          ft = s(7754948169),
          We = s(2250002584),
          je = s(7078696899);
        const Ne = "process-stored-state";
        function vt() {
          let {
            teamId: a,
            enterpriseId: t,
            method: e,
            storeKey: o,
          } = arguments.length > 0 && arguments[0] !== void 0
            ? arguments[0]
            : {};
          const n = (0, We.F)(),
            r = n.createMetricsTrace({
              label: "redux-persistence",
            });
          r
            .count({
              name: "store-invalidated",
            })
            .addTags({
              team_id: a,
              enterprise_id: t,
              method: e,
              store: o,
            }),
            n.reportTrace(r);
        }
        u(vt, "beaconStoreInvalidation");
        function Le(a) {
          let { state: t, logger: e, teamId: o, reducerConfig: n = {} } = a;
          const r = {},
            c = (0, I._z)(o, "enterprise_id");
          return (
            Object.keys(t).forEach((i) => {
              const l = n[i],
                {
                  persistenceEnabled: p = !1,
                  persistImmediately: g = !1,
                  afterReadTransform: h,
                  validateFn: S,
                } = (0, m.jZ)(l) || {};
              if (!p || g) return;
              const f = !1,
                v = `${m.Is}${i}`;
              if (
                (0, ft.E)(v) &&
                !(0, ft.i)(v, t[i], {
                  logErrorOnFailure: f,
                })
              ) {
                vt({
                  teamId: o,
                  enterpriseId: c,
                  method: "schema",
                  storeKey: i,
                }),
                  e.info(
                    m.JY,
                    `${i} persisted data does not pass schema validation, throwing away persisted data for it`
                  );
                return;
              }
              if (S && !S(t[i])) {
                vt({
                  teamId: o,
                  enterpriseId: c,
                  method: "validateFn",
                  storeKey: i,
                }),
                  e.info(
                    m.JY,
                    `${i} persisted data does not pass validateFn validation, throwing away persisted data for it`
                  );
                return;
              }
              const A = c || o;
              r[i] = h ? h(t[i], A) : t[i];
            }),
            r
          );
        }
        u(Le, "prepareStateForHydration");
        function Dt(a) {
          return N.apply(this, arguments);
        }
        u(Dt, "processStoredState");
        function N() {
          return (
            (N = (0, d.coroutine)(function* (a) {
              let { teamId: t, reducerConfig: e, storedState: o = {} } = a;
              const n = (0, b.Ay)({
                teamId: t,
              });
              n.info(m.JY, "Checking for persistence method changes"),
                yield ht(t),
                n.info(m.JY, "Preparing state for hydration");
              const r = Le({
                state: o || {},
                teamId: t,
                logger: n,
                reducerConfig: e,
              });
              return !r || (0, Me.A)(r)
                ? (n.info(m.JY, "No persisted state found"), null)
                : (n.info(m.JY, "State prepared for hydration"),
                  n.info(m.JY, "Checking for required data"),
                  Ue({
                    teamId: t,
                    reducerConfig: e,
                    state: r,
                  })
                    ? (n.info(
                        m.JY,
                        "Missing some required data, throwing away persisted state"
                      ),
                      (0, je.H)({
                        successState: !1,
                        spanName: `${Ne}:missing-required-reducers`,
                      }),
                      null)
                    : r);
            })),
            N.apply(this, arguments)
          );
        }
        u(N, "_processStoredState"),
          (0, O.ul)(
            "persist.processStoredState",
            (function () {
              var a = (0, d.coroutine)(function* (t, e) {
                const o = (0, m.KN)(t),
                  n = yield (0, He.A)({
                    teamId: t,
                    userId: e,
                  });
                return Dt({
                  teamId: t,
                  reducerConfig: o,
                  storedState: n,
                });
              });
              return function (t, e) {
                return a.apply(this, arguments);
              };
            })()
          );
        var we = s(3993025903),
          L = s(723189278),
          St = s(9272190578),
          w = s(7408076233);
        function Ye(a) {
          return Y.apply(this, arguments);
        }
        u(Ye, "setInitialState");
        function Y() {
          return (
            (Y = (0, d.coroutine)(function* (a) {
              let { contextualInfo: t } = a;
              const e = yield t.isBootingWarm,
                { teamId: o } = t;
              if (!e)
                return (
                  (0, T.pq)("BOOT", `(${o}) Booting with empty store`),
                  Ct({
                    contextualInfo: t,
                    storedState: {},
                  })
                );
              (0, T.pq)("BOOT", `(${o}) Booting with persisted store`);
              try {
                if (!o)
                  throw new Error(
                    "Attempt to calculate initial state failed because teamId is missing."
                  );
                const n = yield t.maybeStoredStatePromise,
                  r = yield Dt({
                    teamId: o,
                    reducerConfig: w,
                    storedState: n,
                  });
                return Ct({
                  contextualInfo: t,
                  storedState: r,
                });
              } catch (n) {
                return (
                  (0, Ee.sY)(
                    t == null ? void 0 : t.teamOrEnterpriseBootId,
                    we.Tn,
                    St.As,
                    n
                  ),
                  (0, L.A)()
                );
              }
            })),
            Y.apply(this, arguments)
          );
        }
        u(Y, "_setInitialState");
        function Ct(a) {
          return G.apply(this, arguments);
        }
        u(Ct, "buildInitialState");
        function G() {
          return (
            (G = (0, d.coroutine)(function* (a) {
              let { contextualInfo: t, storedState: e } = a;
              const {
                teamId: o = "",
                featureFlagURLOverrides: n,
                userId: r,
              } = t;
              if (!e)
                return (
                  (0, St.As)({
                    reason:
                      "maybeStoredStatePromise didn\u2019t resolve to any stored state",
                    reasonKey: "warm_boot_without_stored_state",
                    immediate: !0,
                  }),
                  (0, L.A)()
                );
              var c;
              const i = {
                ...e,
                bootData: {
                  ...((c = e.bootData) !== null && c !== void 0 ? c : {}),
                  ...n,
                  version_ts: (0, q.HF)(),
                },
              };
              return (0, Be.Ay)({
                teamId: o,
                userId: r,
                reducerConfig: w,
                state: i,
              });
            })),
            G.apply(this, arguments)
          );
        }
        u(G, "_buildInitialState");
        var Ge = s(9137897911),
          Je = s(735940183),
          bt = s(9022734571),
          ze = s(5795074931);
        function Ve(a) {
          return J.apply(this, arguments);
        }
        u(Ve, "validateLocaleAccess");
        function J() {
          return (
            (J = (0, d.coroutine)(function* (a) {
              let { contextualInfo: t, store: e } = a;
              const { teamId: o } = t,
                n = e.getState(),
                r = (0, ze.uo)(n),
                c = Object.keys(r).reduce(
                  (g, h) => ({
                    ...g,
                    [(0, Ge.A)(h)]: r[h],
                  }),
                  {}
                ),
                i = (0, Je.Dh)(c),
                l = (0, bt.nT)(window.location.search),
                p = l.locale || "";
              return !i[p] && Object.keys(l).includes("locale")
                ? ((0, T.pq)(
                    "BOOT",
                    `team ${o} attempted to boot into locale ${p} which has not been enabled; clearing credentials and reloading app`
                  ),
                  (0, I.U_)(),
                  (window.location.href = (0, nt.qy)(
                    window.location.href,
                    "locale"
                  )),
                  (0, L.A)())
                : {
                    store: e,
                    contextualInfo: t,
                  };
            })),
            J.apply(this, arguments)
          );
        }
        u(J, "_validateLocaleAccess");
        var Ke = s(4650542030),
          yt = s(8426925643),
          Ze = s(6806844646),
          Xe = s(6735185257),
          Tt = s(4724591729),
          Qe = s(9746734072),
          ke = s(5797466484),
          qe = s(8040098042),
          z = s(5824283093);
        const _e = 50,
          y = 10;
        function D(a) {
          return Math.round((a + Number.EPSILON) * 10) / 10;
        }
        u(D, "roundNumberForHumans");
        let to = u(
          class {
            getComputedPropsDevHint(t, e) {
              return `
		\u269B\uFE0F We spent ${e} ms during the last Redux subscriber notification calculating props!
			\u269B\uFE0F We called useSelector ${t.totalUseSelectorCount} times with ${
                t.unmemoizedUseSelectorCount
              } unique selectors, taking ${D(
                t.unmemoizedUseSelectorTotalTime
              )} ms.
			\u269B\uFE0F We calculated ${t.mappedPropsCount} mapped props, which took ${D(
                t.mappedPropsTotalTime
              )} ms.`;
            }
            getUnstableUseSelectorDevHint(t) {
              return `
			\u269B\uFE0F ${t} useSelectors returned values that failed equality checks but are deep-equal. This means these components might be re-rendering unnecessarily.`;
            }
            getUnstableMappedPropsDevHint(t) {
              return `
			\u269B\uFE0F ${t} mapped props failed equality checks but are deep-equal. This means these components might be re-rendering unnecessarily.`;
            }
            getRenderTimeDevHint(t, e) {
              return `
		\u269B\uFE0F We spent ${D(
      t - e
    )} ms during the last Redux subscriber notification rendering components!`;
            }
            getReduxLoopTimeDevHint(t) {
              return `
		\u269B\uFE0F The last Redux loop (subscriber notification) took ${t} ms.`;
            }
            getSuggestionForUnstablePropLogging(t) {
              let e = "";
              return (
                (0, Qe.A)(t) && !t.length
                  ? (e =
                      "Consider using the EMPTY_ARRAY helper to prevent this.")
                  : (0, ke.A)(t) &&
                    !Object.keys(t).length &&
                    !Object.getOwnPropertySymbols(t).length
                  ? (e =
                      "Consider using the EMPTY_OBJECT helper to prevent this.")
                  : (0, qe.A)(t.id)
                  ? (e =
                      "This value might be a channel, which are known to be unstable due to our upsert strategy. Consider returning a more stable derived value from your selector.")
                  : (0, tt.NB)(t)
                  ? (e =
                      "This value might be a member, which are known to be unstable due to our upsert strategy. Consider returning a more stable derived value from your selector.")
                  : t.id && ((0, $.IJ)(t) || (0, $.r7)(t))
                  ? (e =
                      "This value might be a team, which are known to be unstable due to our upsert strategy. Consider returning a more stable derived value from your selector.")
                  : (0, z.isValidElement)(t) &&
                    (e =
                      "Returning React nodes from selectors is not recommended due to the performance implications."),
                e
              );
            }
            getTotalPropCalcTime(t, e) {
              return D(t + e);
            }
            logWarnings(t) {
              this.lastMetrics = t;
              const e = this.getTotalPropCalcTime(
                  t.unmemoizedUseSelectorTotalTime,
                  t.mappedPropsTotalTime
                ),
                o = e > _e,
                n = !!t.unstableUseSelectorCount,
                r = !!t.unstableMappedPropCount,
                c = t.loopEndTime - t.loopStartTime;
              (o || n || r) &&
                ((0, b.Wo)().devHint(
                  "PERF DEBUG",
                  "\u{1F3A2} We found some performance opportunities during the last Redux loop:",
                  `${this.getReduxLoopTimeDevHint(c)}`,
                  `${o ? this.getComputedPropsDevHint(t, e) : ""}`,
                  `${n || r ? this.getRenderTimeDevHint(c, e) : ""}`,
                  `${
                    n
                      ? this.getUnstableUseSelectorDevHint(
                          t.unstableUseSelectorCount
                        )
                      : ""
                  }`,
                  `${
                    r
                      ? this.getUnstableMappedPropsDevHint(
                          t.unstableMappedPropCount
                        )
                      : ""
                  }`
                ),
                console.groupCollapsed("[PERF DEBUG] \u{1F3A2} See more..."),
                o &&
                  (console.log(
                    `The ${y} functions we spent the longest calling from useSelector, how long each took, and how many times we called them:`
                  ),
                  console.table(
                    Object.entries(t.selectorMetrics)
                      .sort((i, l) => l[1].totalMs - i[1].totalMs)
                      .slice(0, y)
                      .map((i) => ({
                        selector: i[0],
                        count: i[1].count,
                        totalMs: D(i[1].totalMs),
                      }))
                  ),
                  console.log(
                    `The ${y} most mapped props, how many times they were computed, and by what components:`
                  ),
                  console.table(
                    Object.entries(t.mappedPropCounts)
                      .sort((i, l) => l[1].propCount - i[1].propCount)
                      .slice(0, y)
                      .map((i) => ({
                        propName: i[0],
                        count: i[1].propCount,
                        computers: Object.entries(i[1].computers)
                          .sort((l, p) => p[1] - l[1])
                          .map((l) => `${l[0]} (${l[1]})`)
                          .join(", "),
                      }))
                  ),
                  console.log(
                    `The ${y} components that took longest mapping props, how many of each component there were, how long it took to calculate props, and the props:`
                  ),
                  console.table(
                    Object.entries(t.mappedPropsTimeByComponents)
                      .sort((i, l) => l[1].totalMs - i[1].totalMs)
                      .slice(0, y)
                      .map((i) => ({
                        component: i[0],
                        count: i[1].count,
                        totalMs: D(i[1].totalMs),
                        props: i[1].props.sort().join(", "),
                      }))
                  )),
                n &&
                  (console.log("These useSelector calls were unstable:"),
                  console.table(
                    t.unstableUseSelectors.map((i) => {
                      const { value: l, selector: p } = i;
                      let g = l;
                      if ((0, z.isValidElement)(l)) {
                        var h;
                        g = `React component "${
                          ((h = l.type) === null || h === void 0
                            ? void 0
                            : h.displayName) ||
                          l.key ||
                          "<unknown>"
                        }"`;
                      } else g = l;
                      return {
                        ...i,
                        selector: p,
                        value: g,
                        suggestion: this.getSuggestionForUnstablePropLogging(l),
                      };
                    })
                  )),
                r &&
                  (console.log("These mapped props were unstable:"),
                  console.table(
                    t.unstableMappedProps.map((i) => {
                      const { value: l } = i;
                      let p = l;
                      if ((0, z.isValidElement)(l)) {
                        var g;
                        p = `React component "${
                          ((g = l.type) === null || g === void 0
                            ? void 0
                            : g.displayName) ||
                          l.key ||
                          "<unknown>"
                        }"`;
                      } else p = l;
                      return {
                        ...i,
                        value: p,
                        suggestion: this.getSuggestionForUnstablePropLogging(l),
                      };
                    })
                  )),
                console.groupEnd());
            }
            logDebug() {
              if (!this.lastMetrics) return;
              const t = this.getTotalPropCalcTime(
                  this.lastMetrics.unmemoizedUseSelectorTotalTime,
                  this.lastMetrics.mappedPropsTotalTime
                ),
                e =
                  this.lastMetrics.loopEndTime - this.lastMetrics.loopStartTime;
              console.log(
                "\u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} ",
                `${this.getReduxLoopTimeDevHint(e)}`,
                `${this.getComputedPropsDevHint(this.lastMetrics, t)}`,
                `${this.getRenderTimeDevHint(e, t)}`,
                `${this.getUnstableUseSelectorDevHint(
                  this.lastMetrics.unstableUseSelectorCount
                )}`,
                `${this.getUnstableMappedPropsDevHint(
                  this.lastMetrics.unstableMappedPropCount
                )}`
              ),
                console.groupCollapsed(
                  "See a table of functions called from useSelector, how long each took, and how many times we called them:"
                ),
                console.table(
                  Object.entries(this.lastMetrics.selectorMetrics)
                    .sort((o, n) => n[1].totalMs - o[1].totalMs)
                    .map((o) => ({
                      selector: o[0],
                      count: o[1].count,
                      totalMs: D(o[1].totalMs),
                    }))
                ),
                console.groupEnd(),
                console.groupCollapsed(
                  "See a table of the mapped props, how many times they were computed, and by what components:"
                ),
                console.table(
                  Object.entries(this.lastMetrics.mappedPropCounts)
                    .sort((o, n) => n[1].propCount - o[1].propCount)
                    .map((o) => ({
                      propName: o[0],
                      count: o[1].propCount,
                      computers: Object.entries(o[1].computers)
                        .sort((n, r) => r[1] - n[1])
                        .map((n) => `${n[0]} (${n[1]})`)
                        .join(", "),
                    }))
                ),
                console.groupEnd(),
                console.groupCollapsed(
                  "See a table of components that mapped props, how many of each component there were, how long it took to calculate props, and the props:"
                ),
                console.table(
                  Object.entries(this.lastMetrics.mappedPropsTimeByComponents)
                    .sort((o, n) => n[1].totalMs - o[1].totalMs)
                    .map((o) => ({
                      component: o[0],
                      count: o[1].count,
                      totalMs: D(o[1].totalMs),
                      props: o[1].props.sort().join(", "),
                    }))
                ),
                console.groupEnd(),
                console.log(
                  "\u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} \u{1F3A2} "
                );
            }
            constructor() {
              (this.lastMetrics = void 0),
                (this.isEnabled =
                  ((0, Tt.Cu)() || (0, Tt.b3)()) &&
                  !(0, bt.nT)(window.location.search)
                    .force_silence_perf_debugger);
            }
          },
          "ReduxLoopPerfDebugger"
        );
        const At = new to();
        (0, O.ul)("getReduxLoopMetrics", () => {
          At.logDebug();
        });
        const eo = u(() => {
          const a = u(
              (e) => ({
                ...(0, yt.Kh)(),
                ...(0, yt.It)(e),
              }),
              "getStandardTraceTags"
            ),
            t = new Xe._({
              getStandardTraceTags: a,
              perfDebugger: At,
            });
          Ze.M.register(() => t);
        }, "registerReduxExtensions");
        var oo = s(412642378),
          no = s(1429453038),
          ao = s(9163810830),
          so = s(3845884005),
          ro = s(7808782809),
          io = s(1314103953);
        const lo = (0, ro.U)(so.A);
        function B(a) {
          return V.apply(this, arguments);
        }
        u(B, "setupRedux");
        function V() {
          return (
            (V = (0, d.coroutine)(function* (a) {
              let { contextualInfo: t, initialState: e } = a;
              const {
                teamOrEnterpriseBootId: o,
                enterpriseId: n,
                userId: r,
              } = t;
              (0, T.pq)("BOOT", `(${o}) Configuring redux store`),
                (yield t.isBootingWarm) || (yield ht(o));
              const i = {
                teamOrEnterpriseId: o,
                reducers: w,
                middlewares: lo,
                initialState: e,
                sideEffects: ao.G,
              };
              return (
                n && (i.enterpriseId = n),
                (0, no.p)({
                  ...i,
                  userId: r,
                  isWarmBooting: t.isBootingWarm,
                })
              );
            })),
            V.apply(this, arguments)
          );
        }
        u(V, "_setupRedux");
        function uo(a) {
          eo(),
            a.hooks.dataSetupInitialState.tap(
              "Set initial state (and rehydrating cached data during a warm boot)",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: o } = e;
                  return {
                    initialState: yield Ye({
                      contextualInfo: o,
                    }),
                    contextualInfo: o,
                  };
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataSetupInitialState.tap(
              "Set up team debugger (dev/jspath only)",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { contextualInfo: o, initialState: n } = e;
                  return (
                    ve({
                      contextualInfo: o,
                    }),
                    {
                      contextualInfo: o,
                      initialState: n,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataSetupStore.tap(
              "Setup team-level Redux Store",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { initialState: o, contextualInfo: n } = e;
                  return {
                    store: yield B({
                      contextualInfo: n,
                      initialState: o,
                    }),
                    initialState: o,
                    contextualInfo: n,
                  };
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Dispatch API data into the store",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    yield ue(o, n, r),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Fetch additional members for DM/MDPM/conversations.view",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    de({
                      clientBootData: n.clientBootData,
                      store: o,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Navigate to the expected route based on fresh dispatched data",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    (0, ut.r)({
                      store: o,
                      contextualInfo: r,
                      shouldUpdateRoute: !1,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Update local config with lastColdBootTs as current date on cold boot",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    (yield r.isBootingWarm) ||
                      (0, I.q9)("lastColdBootTs", Date.now()),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Mark boot as completed when all data has been dispatched",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    (0, ge.y)(r.teamId),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Connect to socket",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    (0, Ke.v)({
                      store: o,
                      contextualInfo: r,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Set boot type (warm/cold)",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    Fe({
                      store: o,
                      contextualInfo: r,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Set focus",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    Oe({
                      store: o,
                      contextualInfo: r,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap("Set workspace booted", he.V),
            a.hooks.dataDispatch.tap(
              "Load emoji translations",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    me({
                      contextualInfo: r,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataDispatch.tap(
              "Validate that the locale we are loading into is valid",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, apiData: n, contextualInfo: r } = e;
                  return (
                    Ve({
                      store: o,
                      contextualInfo: r,
                    }),
                    {
                      store: o,
                      apiData: n,
                      contextualInfo: r,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataAfterInitialStoreHydration.tap(
              "Indicate whether we're performing a warm boot",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, contextualInfo: n } = e;
                  return (yield n.isBootingWarm)
                    ? (o.dispatch((0, io.b)(!0)),
                      {
                        store: o,
                        contextualInfo: n,
                      })
                    : {
                        store: o,
                        contextualInfo: n,
                      };
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataAfterInitialStoreHydration.tap(
              "Dispatch experiment overrides from persisted dispatched data on warm boot",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, contextualInfo: n } = e;
                  return (yield n.isBootingWarm)
                    ? (k({
                        store: o,
                        contextualInfo: n,
                      }),
                      {
                        store: o,
                        contextualInfo: n,
                      })
                    : {
                        store: o,
                        contextualInfo: n,
                      };
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataAfterInitialStoreHydration.tap(
              "Navigate to the expected route based on persisted dispatched data on warm boot",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, contextualInfo: n } = e;
                  return (yield n.isBootingWarm)
                    ? ((0, ut.r)({
                        store: o,
                        contextualInfo: n,
                        shouldUpdateRoute: !0,
                      }),
                      {
                        store: o,
                        contextualInfo: n,
                      })
                    : {
                        store: o,
                        contextualInfo: n,
                      };
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataAfterInitialStoreHydration.tap(
              "Register event handlers",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, contextualInfo: n } = e;
                  return (
                    Te(),
                    {
                      contextualInfo: n,
                      store: o,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            ),
            a.hooks.dataAfterInitialStoreHydration.tap(
              "Signal that the store has been hydrated",
              (function () {
                var t = (0, d.coroutine)(function* (e) {
                  let { store: o, contextualInfo: n } = e;
                  return (
                    o.dispatch((0, oo._)()),
                    {
                      contextualInfo: n,
                      store: o,
                    }
                  );
                });
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()
            );
        }
        u(uo, "register");
        const Ft = {
          setupRedux: B,
        };
        Object.defineProperty(Ft, "setupRedux", {
          get: () => B,
          set: (a) => {
            B = a;
          },
        });
      },
    },
  ]);
})();

//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-client-boot-data.0101fbc11c10146dd75f.min.js.map
